"""Descent selects witnessed cases instead of inventing a sigma inverse."""
import torch

from test_cs_sparse_weights import _cs, _mint_row


def test_descent_intersects_cases_with_the_present_field():
    cs = _cs()
    parent = _mint_row(cs, 1, 101)
    cs.add_concept_edge(parent, 0, 1.)
    cs.add_concept_edge(parent, 1, 1.)
    query = torch.zeros(sum(cs._order_caps()), 1, 1, 2)
    query[parent, 0, 0, 0] = .8
    observed = torch.zeros_like(query)
    observed[1, 0, 0, 0] = .7
    result = cs.cs_reverse_presence(query, observed=observed)
    torch.testing.assert_close(result[1, 0, 0], torch.tensor([.7, 0.]))
    assert result[0].count_nonzero() == 0
    observed.zero_()
    observed[2, 0, 0, 0] = 1.
    result = cs.cs_reverse_presence(query, observed=observed)
    assert result[:2].count_nonzero() == 0


def test_descent_without_a_field_chooses_one_case():
    cs = _cs()
    parent = _mint_row(cs, 1, 101)
    cs.add_concept_edge(parent, 0, .2)
    cs.add_concept_edge(parent, 1, .8)
    query = torch.zeros(sum(cs._order_caps()), 1, 1, 2)
    query[parent, 0, 0, 0] = 1.
    result = cs.cs_reverse_presence(query)
    torch.testing.assert_close(result[:2, 0, 0, 0], torch.tensor([0., 1.]))


def test_descent_keeps_the_source_pole_and_scope():
    cs = _cs()
    parent = _mint_row(cs, 1, 101)
    cs.add_concept_edge(parent, 0, 1., negated=True)
    query = torch.zeros(sum(cs._order_caps()), 1, 2, 2)
    query[parent, 0, 1, 0] = .8
    observed = torch.zeros_like(query)
    observed[0, 0, 1, 1] = .7
    result = cs.cs_reverse_presence(query, observed=observed)
    torch.testing.assert_close(result[0, 0, 1], torch.tensor([0., .7]))
    assert result[:, :, 0].count_nonzero() == 0


def test_percept_attribution_follows_signed_definitions_without_complements():
    cs = _cs()
    cs.add_concept_feature(0, 'ps', 65, 1.)
    cs.add_concept_feature(0, 'ws', 3, -1.)
    query = torch.zeros(sum(cs._order_caps()), 1, 1, 2)
    query[0, 0, 0] = torch.tensor([.8, .6])
    columns, values, spans = cs.cs_percept_attribution(query)
    # Both requested poles descend independently. An unlocated inverse
    # returns both native poles; no subtraction creates an absence claim.
    assert columns.tolist() == [4 * 65, 4 * 65 + 1, 4 * 3 + 2, 4 * 3 + 3]
    torch.testing.assert_close(values[:, 0, 0, 0], torch.tensor([.8, .6, .6, .8]))
    assert spans is None


from types import SimpleNamespace

import torch

import Spaces

from Models import BasicModel

from test_cs_sparse_weights import _cs, _mint_row

from test_concept_memberships import binary_features


def test_passback_scales_unknown_parts_without_erasing_location():
    cs = SimpleNamespace(_field_caps=lambda: (2,), cs_percept_attribution=lambda *a, **k:
        (torch.tensor([0]), torch.tensor([[[[1., 0.]]]]),
         torch.tensor([[[0, 1], [1, 2]]])))
    model = SimpleNamespace(subsymbolic_loop={1}, conceptualSpaces=[cs],
        conceptualSpace=cs, _subsymbolic_field=torch.zeros(2, 1, 1, 2),
        perceptualSpace=SimpleNamespace(nWhat=2, _forward_input={
            'part_spans': torch.tensor([[[0, 1], [1, 2]]])}),
        _staged_concepts_in=torch.tensor([[[65, 66]]]))
    sub = Spaces.SubSpace(inputShape=(2, 4), outputShape=(2, 4), nInputDim=4, nOutputDim=4)
    event = torch.tensor([[[.4, .8, -.2, .6], [.8, .4, .6, -.2]]])
    sub.set_event(event)
    result = BasicModel._passback_scope_ps(model, 1, sub, None).materialize()
    assert bool((result[..., :2] > 0).all())
    torch.testing.assert_close(result[0, 0, :2], event[0, 0, :2])
    torch.testing.assert_close(result[0, 1, :2], .5 * event[0, 1, :2])
    torch.testing.assert_close(result[..., 2:], event[..., 2:])
    torch.testing.assert_close(sub.materialize(), event)

