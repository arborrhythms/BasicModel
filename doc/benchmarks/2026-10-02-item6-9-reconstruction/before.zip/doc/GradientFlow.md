# Gradient flow across the architecture

The current contract is item 6.9 [plan §15](plans/2026-09-29-item-6-9-xor-grammar.md#15-one-writer-for-each-weight-alec-2026-10-02),
October 2. Each optimizer parameter has one objective owner. The supplied
answer stops at the understanding, and expectation detaches both its evidence
and targets. Step 5a's uncut answer and the supplied-answer gradient projection
are retired. Forward representations and numerical operator hosts remain shared.

<a id="the-training-step-october-1"></a>

## The training step (October 2)

A sentence has a greedy and an explore derivation. Both are composed and
costed at identical parameters before either trains. Each trial then takes
its own restricted backward and optimizer step, including its own perception
pullback for reconstruction. Saved forward parameter values preserve the
second graph. A batch-end step runs only when its remaining registered total
has a derivative. No extra step is added for diagnostics.

Explore is kept only when its reconstruction is no higher and its
**reconstruction plus supplied-answer cost is strictly lower**. Expectation,
lessons and penalties train their owners but do not select the trial. A tie
keeps greedy. The kept state is committed detached; no gradient crosses that
boundary into the next sentence.

| Parameter owner | Weights and permitted update |
|---|---|
| Reconstruction (R) | Perception, joint perceptual embedding, parameterized object codes, compose operators and their tied inverses, compose chooser. Compose lessons update only that chooser. |
| Expectation (E) | Within-sentence, between-sentence, ARMA and contrastive predictors; the predictive reading-attention module where enabled. All sources, routing evidence and targets are detached. |
| Answer (A) | Numeric head, the record reader, output adapters, generate chooser and conditioner, answer-consumed global attention, and explicit supplied-answer policy readers. Generate lessons update only the generate chooser. |

[ObjectiveOwnership](../bin/ObjectiveOwnership.py) reads the trained named
terms from `Layers.Error` and obtains gradients only for their owner lists.
A differentiable numerical operator can transmit a generation derivative to
the conditioner while its own parameters receive no answer update. Regularizers
are unnormalized and follow the parameters they use. The diagnostic operand
term of a grammar lesson trains no operator. `expectationPolicyWeight` stays 0.
The chooser's negative prediction image remains detached forward evidence.

Where `conceptualContextLearningRate` is configured, the concept dictionary
is a persistent non-grad buffer. The existing sentence-local distributional
rotation still moves it; it is outside all three autograd owner lists. In
XOR_grammar and MM_grammar the dictionary is a parameter and reconstruction
owns its update. Ownership audits distinguish absent gradients from zero
ones and do not claim that every parameter is active in every batch.

## One understanding record, two consumers

[SentenceUnderstanding](../bin/SentenceUnderstanding.py) is built once per
trial. The tied reconstruction and the supplied answer receive that same
object. It carries the concluded root, three end slots and depth, packed
sentence roots/depths, per-word values/rows/validity, rule ids/arities/validity,
operand positions, operation values, witness offsets, journal columns and
validity, sentence id, and a primed-symbol snapshot. Addresses select evidence;
they are not semantic magnitudes.

The snapshot contains each row's own sentence symbols plus up to
`reconstructionBasisLimit` activated others from `Space.prime_seen`. It is
taken after the sentence's seen write and shared by both trials. The `[B,V]`
surface decays, diffuses with `primingSpread` over on-device sparse definition
edges and bumps the seen rows. Serial reading also diffuses; there is no
4,096-edge cap and no cross-row priming. A row at neutral sends no energy.
Symbols with surfaces are byte candidates; all valid rows enter answer context
with their priming weights.

The numeric head reads detached end slots plus an answer-owned, zero-initialized
affine record reader. Its fixed features are position-weighted linear sums of
witness offsets (2D), operation operands/results (3D) and word references (D),
the priming-weighted code sum (D), a weighted rule histogram, two arity counts
and end depth. Position weights are `(index+1)/width`. The extra input width
is `7D + number_of_rules + 3`. This preserves additive evidence for the sum-only
control; no nonlinear bank scorer is added to XOR's numeric reader. Generate
receives the same record as named context, detached before its conditioner.
The receipt checks identity of the two consumers' object and measures activated
candidates that outrank an own word.

## State paths and shared parameters

`resolveAnswer()` prepares an owned `AnswerDerivation`; `reverseOutput()`
consumes it without repeating resolution. Both numeric and generated answers
cut the concluded state, all contextual operands and the record features.
Generation keeps the declared numerical hosts and their tied interfaces,
without a second optimizer owner or checkpoint copy. Grammar lessons cannot
move those hosts. Catalogue migration still follows rule meaning, preserving
unchanged chooser weights and optimizer moments.

The bounded tied inverse trains the selected compose operations through their
witnesses. Candidate addresses, target spellings and hard retrieval are detached.
The compose chooser retains its existing straight-through estimator. Durable
LTM writes, finished episodes and retained expectations detach; they cannot
reopen an old graph. Query masks, reference matching and work accounting remain
hard bookkeeping. These mechanisms do not establish useful learned reasoning.

## Trained total and diagnostic objectives

`Layers.Error` owns the trained sum. Its targeted APIs register the error
and a detached uninformed baseline over the same active entries. Repeated
contributions to one named term combine before division: `sum(error) /
sum(baseline)`, a ratio of means, with no epsilon floor or running scale.
For squared errors the baseline is the target's squared norm about the
origin. For categorical errors it is `log K`, and for binary errors `log 2`.
A constant target therefore has a usable baseline. If every active squared
target is exactly zero, the term is an unnormalized penalty toward zero.
An empty active set contributes zero.

Every relative term has weight 1 unless the configuration supplies a
priority, including inherited, explicitly stated `model.xml` priorities.
`reconstructionScale` multiplies reconstruction terms independently.
`Error.total(kind='relative')` and `Error.total(kind='penalty')` report the
two sums separately; `total()` supplies their trained sum. A row registry
normalizes with the shared target sum, then returns row contributions whose
active-row mean is that same training objective. A small-target row does
not get a separate large inverse scale. `breakdown()` records raw error,
baseline, entries, weight, contextual multiplier, kind, ownership and row
selection values. `trained=False` metrics never enter the optimizer total.

All retained serial grammar readings reconstruct through their understanding.
The old reading modes, D3 path and detached student runtime are retired. A
reading without a grammar keeps perceptual reconstruction. A sentence with no
admitted surface candidate has no reconstruction term and is counted.
A zero-weight term does not require its source registry.

The inventory below gives each active term's definition. “Origin” means the
detached target mean square over exactly the error's active entries. R is the
input reading and tied inverse; A is the answer reading map; E is the
expectation predictor. Every A term stops at the understanding, in a trial and at batch end.
Every E term detaches both its source and target. Restricted backward also
prevents generation or lessons from writing an operator.

| Registered term | Comparison and uninformed baseline | Priority | Owner and gradient |
|---|---|---|---|
| `answer.what/where/when` | Numeric output or generated surface band vs supplied target; origin per band | corresponding event-band scale | Trial and batch; A |
| `reconstruction.bytes` | Recovered spelling vs observed bytes including NUL, with the existing word/sentence reduction; `log 256` | `reconstructionScale` | Trial; R. Detached chosen cost is reported at batch end without replaying its graph |
| `reconstruction.what/where/when`, `reconstruction_reverse.what/where/when` | Grammar-free perceptual/masked or reverse event vs input target; origin per band | reconstruction scale × band scale | Batch; perception and the active input inverse |
| `leaf_distill` | Historical root decoder's predicted exact leaves vs retained leaves; origin | `leafDistillWeight` | Batch; decoder and live input root where enabled |
| `expectation.roles` | Predicted complete role payload vs arriving detached meaning; origin | `interLossWeight` | Trial or batch, once; E only; source and target detached |
| `expectation.presence` | Role-presence logits vs occupied-role bits; `log 2` | `interLossWeight` | Trial or batch, once; E |
| `expectation.kind` | Idea/relation logit vs arriving kind; `log 2` | `interLossWeight` | Trial or batch, once; E |
| `expectation.root` | Root predictor vs arriving root where structured roles are inactive; origin | `interLossWeight` | Trial or batch, once; E only |
| `expectation.contrast` | Next-idea candidate CE vs actual next idea; `log(candidate count)` | `interContrastiveWeight` | Trial or batch, once; E only |
| `expectation.intra` | Predict-then-perceive code vs arriving code; origin over active scalar entries | `intraLossWeight` | Trial or batch, once; within-sentence predictor only |
| `expectation.arma` | ARMA forecast vs detached arriving representation; origin | `armaScale` | Batch; ARMA predictor only |
| `grammar.compose.choice` | Joint compose probability vs annotated operator; `log(choice count)` | `grammarLessonWeight` | Trial; compose chooser; unlabelled waiting sites excluded |
| `grammar.generate.choice` | Generate action logits vs annotated action; `log(choice count)` | `grammarLessonWeight` | Trial; generate policy |
| `grammar.generate.operands` | Generated children vs annotated detached codes; origin | `grammarLessonWeight` | Reporting only (`trained=False`); no operator gradient |
| `embedding.positive/negative` | Sampled lexical logits vs positive/negative membership; `log 2` separately | `embeddingScale` | Batch; joint perceptual embedding |
| `conceptual_sbow.positive/negative` | Cosine logits vs context/non-context membership; `log 2` separately | `conceptualSimilarityScale` × existing SBOW strength | Batch; conceptual codes on the enabled parallel path |
| `reading_attention` | Next unconsumed span NLL; `log(legal span count)` | 1 | Batch; expectation-owned reading attention |

Targetless terms retain their strength and are recorded apart from relative
errors. They have no fabricated target or normalization denominator:

| Term | Definition and strength | Owner and gradient |
|---|---|---|
| `definition_sparsity` | Rank-ordered soft-L0; `definitionSparsityScale` | Batch; definition coefficients |
| `gate_l1` | Absolute lift/lower raw gates; `gateL1Lambda` | Batch; operator gates |
| `concept_readout_l1` | Active sparse readout L1; configured `l1Lambda`, averaged over distinct observed concepts | Trial/batch report only; one proximal application per applicable optimizer step, never another autograd penalty |
| `truth.falsity`, `truth.balance` | Stored-truth incompatibility and forbidden-corner penalties; `truthLossWeight` and balance strength | Batch; live operands if present |
| `output_policy` | Supplied-answer return advantage × sampled generate action NLL; `outputPolicyWeight` | Batch only; generate chooser. Trial generation neither records nor trains it |
| `selected_thought_policy` | Answer/work return advantage × selected-controller log probability; `selectedThoughtPolicyWeight` | Batch; answer-owned selected controller |
| `expectation_policy` | Historical residual/work return advantage; `expectationPolicyWeight` stays 0 | Disabled: expectation must not train a thought controller |

Policy return baselines remain detached variance-reduction baselines; they
are not relative-error divisors. Raw `output`, reconstruction, reverse and
embedding totals, already-trained grammar-lesson summaries, and missing-candidate
counts are reporting-only entries. The old `ws_codebook_recon` and
`ws_semantic_arrangement` stash consumers have no production writer.
Standalone embedding pretraining and contextual sphere rotation are separate
optimizers, not hidden terms of these two costs.

<a id="per-operator-agreement"></a>

## Ownership audit

`branchDiagnosticsEvery` now reports `[gradient-ownership]` rather than
per-operator opposition. The audit lists every trainable optimizer parameter,
its sole declared owner and the actual writers observed during backward.
Inactive parameters remain listed; they are not counted as reached. Duplicate
owners or multiple objective writers raise an error. The receipt aggregates
these reports across actual training steps on XOR_grammar and the production
native benchmark, alongside the stage-1 term and gradient measurements.

No gradient projection, opposition streak, norm rebalance or persistent
conflict counter remains in training or the checkpoint. The stateless gradient
math utilities remain available for read-only measurements. Historical per-operator receipts retain their
original interpretation; they are not evidence about the new ownership split.
Separate weights remove direct shared-weight competition, but reconstruction
can still change the forward inputs of the answer or expectation predictors.

## Verification and retired checks

[Ownership tests](../test/test_objective_ownership.py) check restricted writers,
expectation source/routing cuts, perception pullback ownership, a common trial
record and the answer cut. [Priming tests](../test/test_sentence_priming.py)
check row isolation, serial diffusion and the uncapped sparse edge path.
[Selection tests](../test/test_reconstruction_precedence.py) retain reconstruction
precedence; [sentence comparison tests](../test/test_sentence_comparison.py)
check equal-parameter costs before updates. The old uncut-answer, projection
and expectation-encoder training tests are retired with those behaviors; the
receipt preserves their old bodies and the complete bodies of each port.

## Expectation at the closing

The signed image and observed meaning produce detached negative evidence for
the compose chooser. Prediction separately minimizes all-role relative squared
error and presence/kind BCE against detached targets. Empty roles have zero
targets, not zero residuals. Context, arriving ideas and routing inputs are
all detached; only predictor weights train. Pending estimates survive an
update as detached evidence and are recomputed for the current predictor's
step. The configured zero expectation-policy weight preserves the one-owner
rule. Expectation quality and utility remain empirical questions.
