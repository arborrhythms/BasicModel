# Operators round 3a — identity by construction

Status: runtime, form audit, frozen-source sweep, thirty measured trainings and final documents complete. The standing gate passes. This receipt is held for review; no commit, push or parent-repository bump has been made.

| Gate | Accepted round 2e | Round 3a |
|---|---:|---:|
| XOR_grammar class, presented reader | 9/10 | **10/10** |
| XOR_grammar reconstruction | 10/10 | **10/10** |
| Class and reconstruction in the same training | 9/10 | **10/10** |
| Affine sum control at ¼ | 10/10 | **10/10** |
| MM_xor, raw count under the RNG-only amendment | 10/10 | **10/10** |

The ten XOR trainings finish with **40/40 conjunction roots and 40/40 correct labels**. Every run is permanently all-conjunction by epoch 41. The four starts with all-disjunction roots reach that state at epochs 33, 21, 41 and 29. Class reads the presented reader's four final answers from the committed roots: all four labels must be right and MSE must be below 0.05. The “at 0” band means that unchanged threshold, not literal zero error. Final MSE ranges from 8.26e-14 to 0.02072. Reconstruction requires all four word multisets from the same trained model. [All thirty result tables](measurement-results.md), [raw summary](measurements/summary.json), [validation](results-validation.json).

## Source, scope and construction

The start is the accepted frozen round-2e source, manifest `3fd07f0cd516da3102867207614e11a9153638d37057bcc82a8c7ff821689106`. Git still points to round 1 because the accepted round-2 source was never committed. Its source and archive are preserved in [before/](before/). The [construction review](construction-review.md) is preserved verbatim. This candidate applies plan §§25–26 and the October 7 amendment.

Boundary-marked pair atoms have three fixed bits in 64 coordinates. Length atoms remain parts in the postings and contribute the separate 32-coordinate thermometer. Atom codes and the fixed 96-by-64 binding projection use private byte-seeded generators. Sparse forms are max-joins of parts, address the word rows through the index, and supply the containment and reconstruction audits. Binding and pair search read the dense projection. Mints check the joined forms, grow each word's own positional atom bit by bit, and proceed through differing triples and the declared quadruple fallback. Existing word addresses survive rekeying. Unidentified words are assembled from pairs and length; indexed words read exact row bytes.

Signed ingestion trust becomes the positive/negative pair, with negation exchanging its poles. The independent provenance scalar is retired; its compatibility read is the difference of the poles. The operator kernels, two reader computations, keep rule, walk-first proposal, correction and ownership rules retain the accepted round-2 behavior. [Runtime contract check](runtime-contract-check.json) and [complete changed runtime texts](changed-runtime-texts.json) delimit the implementation.

## Forms and storage

| Native vocabulary | Words | Collision groups before → after minting | Containment pairs | Violations | Indexed byte errors |
|---|---:|---:|---:|---:|---:|
| XOR_grammar | 4 | 0 → 0 | 0 | 0 | 0 |
| MM_grammar | 4 | 0 → 0 | 0 | 0 | 0 |
| BasicModel configured corpus census | 67,391 | 2 → 0 | 18,309 | 0 | 0 |

Native containment is vacuous for the four gate words. Separate witness banks under every configuration pass `bana/banana`, `cat/concat` and `aba/ababa`; `an/and` and `an/ant` are not comparable because `n#` is missing from the longer words. The anagram fixtures, `circus/cursic/cirrus`, and `bana/banana` are distinct. Lengths 1–32 are exact before minting, including `aaaaaa/aaaaaaa`. Projection hashes agree across configurations and runs; every gate root is nonzero; atom admission consumes no global Torch RNG.

The BasicModel census uses the configured first 2,000 local FineWeb documents and existing sentence/letter lexer, across all splits. Its static audit bank requires **69,566 atom/word rows against the production capacity of 32,768**. This reports the all-distinct-word census, not the recurrence-filtered production admission count or a full-corpus training pass. The production bank was not resized. Plan §27's capacity/admission distinction is retained as a storage follow-up separate from the measured gates.

Every native mint is listed here, with three bits on each atom:

- `SPSS / SSPS`: `#SP@0 / #SS@0`.
- `enteriditis / enteritidis`: `rid@5 / rit@5`.

The unchanged toy sample has 19,986 unique words from 20,000 draws: one initial collision group and zero after minting. `calaba/cabala` mint `cal@1/cab@1`, three bits each; each configuration's witness bank records that mint too. Bit growth and quadruple fallback have focused tests even though these measured vocabularies do not require them. [Form audit](form-audit.json), [identity report](identity-report.md).

## What moved in class, and what the operator result means

The fixed projected conjunction roots are identical across all ten final XOR runs. Their augmented affine rank is four, with optimal affine MSE 2.40e-31. The presented reader reaches the unchanged class bar in all ten runs, versus nine in round 2e. Runs 2, 3 and 9 retain final MSE 0.02072, 0.01602 and 0.003708. Their saved curves reach much lower errors earlier and then oscillate; their final errors are almost entirely a common offset across the four sentences. Their centered error MSEs are 3.75e-8, 3.91e-8 and 5.79e-9. Thus the residuals are in the reader's attained fit on the same separable roots; they are not evidence of a root collision or late flip. This does not establish the precise optimizer cause. No run was extended or replaced. [Both reader trajectories and norms](reader-trajectories.md).

Plan §27's static finding stands: both conjunction and disjunction roots are affinely separable under the fixed projection. Plan §29 requests their centered spectra to assess the comparison reader's observed preference. Saved all-disjunction starts and final conjunction roots give:

| Operator | Nonzero centered singular values | Condition number | Minimum affine weight norm, including bias |
|---|---|---:|---:|
| Conjunction | 0.877855, 0.800607, 0.482921 | 1.8178 | 2.09393 |
| Disjunction | 0.691670, 0.523711, 0.0588575 | 11.7516 | 20.4507 |

The fourth centered singular value is zero up to rounding. Disjunction's weakest direction is 8.205 times smaller, but is well above float32 noise. These spectra support a difference in convergence difficulty; they do not prove why the comparison reader favors conjunction after finite training. This gate records that practical preference without certifying a semantic distinction between the operators. The meanings gate remains future work. [Centered spectra, saved roots and residuals](operator-geometry.md).

The sum control remains the affine-floor certificate: all ten runs finish at ¼, with maximum absolute checkerboard contrast 5.07e-7. A numerical qualification is necessary for the frozen observer: it applies float64 rank/pseudoinverse defaults to float32 values and counts tiny sum-root rounding residuals as a fourth direction. The raw diagnostics are retained. A separately declared post-hoc SVD at the stored data's precision gives sum rank three and optimal affine MSE ¼, while XOR remains rank four with an exact affine fit. It changes no gate result. [Precision report](precision-geometry.md).

## Credit, reconstruction and ownership

All 32,000 sum/XOR sentence comparisons tie on reconstruction and keep greedy. Both trials' R and E are zero. Of 16,000 XOR departures, 8,040 are compose departures with nonzero answer advantage and 7,960 are narrowing departures with zero advantage. Answer credit rewards explore on 864 rows and greedy on 7,176. All 16,000 sum departures are narrowing with zero advantage. Every proposal records its walk, W, R_walk and K; the K·R_walk·W correction is checked for every row. Maximum analytic-gradient error is 4.47e-8 and finite-difference error 1.75e-8, with both walks covered. [Aggregate costs](aggregate-audit.json), [walk/proposal details](audit-details.json), [late costs and final commitments](miss-costs.json).

Each sum/XOR training has 400 updates per reader and final active Adam counters of 400. The presented reader's rejected-root weight is exactly zero. The comparison reader supplies the answer term only. There are no class misses to classify. Sentence-path perception gradients, code displacement and ownership conflicts are zero. Each run's rung-0 audit reads 12,800 identified words over 801 trials with zero errors: **256,000 reads, zero errors** across the twenty sum/XOR trainings.

The sum/XOR configurations reach `_attention_sentence_payload` and both reference-slab paths; the explicit-poles `_pushed_word_slab` branch is unused. MM records zero calls to these four sentence-path consumers. Per-run counts, before/after containment, logit ranges, closing images and gradient records remain in the raw audits and [audit details](audit-details.json). Higher-order folds retain their existing behavior; the construction's containment guarantee is on native sparse forms.

## MM_xor and the amendment

Numeric MM retains its original dimensions and has no lexical identity bank. The repeated seed-zero first-forward bisection takes zero training steps. It confirms the same historical path: retired percept-stage exploration changes global RNG consumption, which changes the Bernoulli mask. Restoring the earlier stage reproduces the 6.8 landing; restoring RNG after greedy reproduces the candidate. The 2c bisection path is unchanged. Against accepted 2e, construction, first output, parameters and RNG after the first forward are identical. [Bisection](mm-first-forward/result.json).

The separately declared paired diagnostics use seeds 0, 1 and 2 for 200 epochs per side; all three trajectories are bitwise identical to accepted 2e throughout. These six diagnostic replays are separate from the thirty unseeded gate trainings. The raw MM count is 10/10, and the §5 RNG-only amendment applies. [Paired trajectories](paired-mm/result.json).

## Sweep, freeze and review record

The delivered-source sweep completed **5,289/5,289 cases: 5,003 passed, 285 skipped, one XPASS, zero failures**, in 394.85 seconds. The historical non-strict xfail marker and 0.8 overlap threshold remain; its dictionary now uses the projected binding directions and XPASSes. The source was then measured once in the declared order: ten sum controls, ten shared class/reconstruction trainings, ten MM trainings. All thirty completed in 1,214.49 seconds, without a seed, retry or replacement. CPU execution, process commands, budgets and logs are retained. [Sweep](full-sweep/result.json), [protocol](measurement-protocol.json), [campaign completion](measurements/complete.json).

Frozen candidate manifest: **`84edc57e0ef1c95478a0e17a78a44b23fbafb8bc441031591c5f70bb27d580dc`**. Archive: `fea1f7831380ba4758cbd30932a45564e1d6ed344f2012c6fe6621805162ba05`. All 707 source files and 188 frozen measurement helpers match the sweep and campaign. [Manifest](delivered-source/source.json), [archive](delivered-source/source.zip), [freeze diff](delivered-source/changes.patch), [helper hashes](delivered-source/measurement-helpers.json).

Complete old/new texts cover 29 test files, including the new round-3a tests, and the observer probe. No test seed calls changed; the class/reconstruction and MM gate files are byte-identical to accepted 2e. Ports cover dimensions, pair/length admission, exact byte reads, fixed projection, mints, checkpoints and trust-to-pair. The two numerical tolerance changes and the commutative permutation fixture correction are explicit in the [port notes](test-port-notes.md), [complete texts](delivered-source/test-ports.json) and [seed audit](delivered-source/seed-port-audit.json). Development failures and repair checks are retained under `development/`.

Three post-hoc helpers are declared separately from the frozen 188: stored-precision geometry, centered operator geometry, and final receipt verification. They read saved measurements and package the review; they do not train models or alter the candidate. [Supplemental hashes](postprocessing-helper-manifest.json).

All earlier round-2/2b/2c/2d/2e receipt files and the construction review remain unchanged. Of the 7,834 initially tracked preservation entries, 7,832 still match. The shared plan and identity-toy README advanced during the run, including Claude's §29 review; their original hashes are retained and their review-time contents, with the newly observed 3b toy, are separately archived. This agent has not edited that plan or toy. [Preservation manifest](before/preserved-files.json), [shared-document update record](before/shared-document-updates.json).

Architecture, GradientFlow, the catalogue's §12.7 and FutureWork carry the round-3a changes. [Final documentation diff](documentation-final.patch), [document archive](documentation-final.zip), [measurement-input hashes](measurement-inputs.json), [final review state](review-state.json). Both repositories' HEADs remain unchanged and both indexes are empty. Commit, push and bump await explicit authorization after review.
