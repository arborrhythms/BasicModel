"""Only the answer's opposing component is removed, before either trial steps."""
import torch
import pytest


def test_lower_total_explore_cannot_win_with_worse_reconstruction():
    from SentenceCompose import sentence_pair
    active = torch.tensor([True, True, True])
    r = [torch.tensor([1., 2., 3.]), torch.tensor([2., 1., 3.])]
    def compose(cache, prior):
        return torch.zeros(3) if prior is None else torch.ones(3)
    def score(path, alternative):
        return torch.full((3,), 1. if alternative else 2.), path
    chosen, _, wins = sentence_pair(None, compose, score, lambda loss: None,
        active=active, reconstruction=lambda state: r[int(state[0])])
    assert wins.tolist() == [False, True, True]
    assert chosen.tolist() == [0., 1., 1.]


def test_projection_preserves_reconstruction_other_objectives_and_reading_map():
    from SentenceCompose import reconstruction_answer_correction
    shared = torch.tensor([1., 2.], requires_grad=True)
    reading = torch.tensor([3.], requires_grad=True)
    r = shared[0] + 2*shared[1]
    a = -3*shared[0] + shared[1] + 5*reading.sum()
    other = 7*shared[0]
    correction = reconstruction_answer_correction(r, a, (shared, reading))
    (r+a+other).backward()
    for p, c in zip((shared, reading), correction):
        if c is not None:
            p.grad.add_(c)
    # gR=[1,2], gA=[-3,1], dot=-1, so only .2*gR is added.
    torch.testing.assert_close(shared.grad, torch.tensor([5.2, 3.4]))
    torch.testing.assert_close(reading.grad, torch.tensor([5.]))


def test_projection_includes_the_trial_perception_pullback():
    from SentenceCompose import fork_perception, reconstruction_answer_correction
    perception = torch.tensor([2., 3.], requires_grad=True)
    (leaf,), pullback = fork_perception((perception*2,))
    r, a = leaf.sum(), -leaf.sum()
    correction = reconstruction_answer_correction(r, a, (perception,), gradient_fn=pullback.gradients)
    (r+a).backward()
    pullback()
    perception.grad.add_(correction[0])
    torch.testing.assert_close(perception.grad, torch.tensor([2., 2.]))


def test_nonopposing_answer_and_absent_reconstruction_need_no_correction():
    from SentenceCompose import reconstruction_answer_correction
    p = torch.tensor([1.], requires_grad=True)
    assert reconstruction_answer_correction(p.sum(), 2*p.sum(), (p,)) == (None,)
    assert reconstruction_answer_correction(None, p.sum(), (p,)) == (None,)


def test_sparse_answer_projection_preserves_the_sparse_code_gradient():
    from SentenceCompose import reconstruction_answer_correction
    codes = torch.nn.Embedding(4, 2, sparse=True)
    values = codes(torch.tensor([0, 2]))
    r, a = values.sum(), -2 * values.sum()
    correction, = reconstruction_answer_correction(r, a, (codes.weight,))
    assert correction.is_sparse
    torch.testing.assert_close(correction.to_dense(), torch.tensor([[2., 2.], [0., 0.], [2., 2.], [0., 0.]]))


@pytest.mark.parametrize('backend', ['none', 'eager'])
def test_real_answer_and_reconstruction_trials_use_one_registry_and_shared_projection(tmp_path, monkeypatch, backend):
    from pathlib import Path
    import Models
    import SentenceCompose
    import util
    from test_mm_xor import _fresh_model
    root = Path(Models.__file__).resolve().parents[1]
    config = tmp_path / 'supplied_reconstruction.xml'
    config.write_text((root/'data/XOR_grammar.xml').read_text().replace(
        '<training>', '<training><reconstructInLoop>true</reconstructInLoop>', 1))
    monkeypatch.setattr(util, 'TheCompileBackend', backend)
    model, _, data = _fresh_model(str(config))
    optimizer = model.getOptimizer(lr=.01)
    project = SentenceCompose.reconstruction_answer_correction
    measured = []
    def observe(reconstruction, answer, parameters, **kwargs):
        assert reconstruction.requires_grad and answer.requires_grad
        registry = model._sentence_cost_registry
        terms = registry.breakdown()
        assert terms['reconstruction.bytes']['baseline'] == pytest.approx(__import__('math').log(256))
        assert any(name.startswith('answer.') for name in terms)
        assert all(item['value'] is not None for item in terms.values())
        corrected = project(reconstruction, answer, parameters, **kwargs)
        # No objective outside the shared R/A parameter space is corrected.
        rg = kwargs['gradient_fn'](reconstruction, parameters)
        ag = kwargs['gradient_fn'](answer, parameters)
        dot = 0.
        for r, a, c in zip(rg, ag, corrected):
            if r is None or a is None:
                assert c is None
                continue
            r, a = r.to_dense(), a.to_dense()
            if c is not None:
                a = a + c.to_dense()
            dot += float((r*a).sum())
        assert dot >= -1e-6
        measured.append(tuple(p._version for p in parameters))
        return corrected
    monkeypatch.setattr(SentenceCompose, 'reconstruction_answer_correction', observe)
    try:
        raw, target = next(iter(data.data_loader(split='train', num_streams=4)))
        batch = model.inputSpace.prepInput(raw), model.outputSpace.prepOutput(target)
        model.runBatch(train=True, optimizer=optimizer, batchSize=4, split='train', batch_override=batch)
        assert len(measured) == 2 and measured[0] == measured[1]
        assert model._word_symbol_concept_ids() is None
        assert torch.isfinite(model.errors.total())
        assert any(name.startswith('answer.') for name in model.errors.breakdown())
    finally:
        model.End()
        model.symbolSpace.soft_reset()
        torch._dynamo.reset()
