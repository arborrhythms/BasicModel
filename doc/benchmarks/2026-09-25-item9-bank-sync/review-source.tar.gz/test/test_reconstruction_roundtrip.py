"""Task 5b+5e pins (doc/plans/2026-07-03-reconstruction-fidelity-execution.md):
meronomy configs get a LIVE masked reconstruction objective (Codebook
``.what`` IR mask), the output-head shape gate reconciles or warns (never a
silent zero), the serial/D3 reconstruction is ONE reverse-implemented
objective (no reconstruction/reconstruction_reverse double count), and the
meronomy percepts TILE WORDS (5e: the word-isolation cut bounds promotion
and spell-out; no percept spans a word/space/punct boundary)."""
import os
import warnings

os.environ.setdefault("BASICMODEL_DEVICE", "cpu")
os.environ.setdefault("MODEL_COMPILE", "eager")

import numpy as np
import pytest
import torch

import recon_bench
from recon_bench import run_config


def _build(config):
    """Use the ambient initialization, with no selected training trajectory."""
    return recon_bench._build_model(recon_bench._resolve_config(config))


# Keep the pre-audit training budget; it is not evidence of convergence.
RECONSTRUCTION_EPOCHS = 160


@pytest.mark.slow
def test_xor_recon_loss_is_live(tmp_path):
    """5b: meronomy configs get a real reconstruction objective.

    Pre-fix baseline (plan Task 3): recon_loss exactly 0.0 -- the
    Codebook-``.what`` early return in ``create_ir_mask`` starved the
    masked-LM branch and lossIn was explicit zeros, silently.
    """
    rec = run_config("data/MM_20M_xor.xml", epochs=1, seed=None,
                     out_dir=str(tmp_path))
    assert rec.recon_loss > 0.0


@pytest.mark.slow
def test_xor_recon_grads_flow():
    """5b: the live reverse loss backpropagates into reconstruction params.

    Captures the ``reconstruction`` term during one train batch and
    checks grads reach the percept codebook (the reconstruction table)
    plus at least one body parameter.
    """
    from Layers import TheError

    model, dev, lr, bs = _build("data/MM_20M_xor.xml")
    captured = {}
    orig_add = TheError.add

    def add_hook(name, value, weight=1.0, **kw):
        if (name == "reconstruction_reverse" and torch.is_tensor(value)
                and value.grad_fn is not None and "nz" not in captured):
            params = [(n, p) for n, p in model.named_parameters()
                      if p.requires_grad]
            grads = torch.autograd.grad(
                value, [p for _, p in params],
                retain_graph=True, allow_unused=True)
            captured["lossRev"] = float(value.detach())
            captured["nz"] = [n for (n, _), g in zip(params, grads)
                              if g is not None and float(g.abs().sum()) > 0]
        return orig_add(name, value, weight=weight, **kw)

    TheError.add = add_hook
    try:
        opt = model.getOptimizer(lr=lr)
        model.runEpoch(optimizer=opt, batchSize=bs, split="train",
                       max_batches=1)
    finally:
        TheError.add = orig_add

    assert captured.get("lossRev", 0.0) > 0.0, \
        "reverse reconstruction term never carried grad_fn (channel dead?)"
    nz = captured.get("nz", [])
    assert len(nz) > 0, "reconstruction loss has no grad-bearing params"
    # Re-scoped (2026-07-16 fold-width unification): the percept codebook
    # is no longer a D3-trainable param. Pre-change, PS sigma folded the
    # muxed event INCLUDING the where/when band, so the reverse replay's
    # band scaffold leaked gradient into sigma/what.W -- and training
    # could perturb the band the .where ladder decodes byte-exact.
    # Content-width folds + band passthrough remove that leak; measured
    # (probe 2026-07-16): D3 grad at the PS event is band-columns-only,
    # content-column grad exactly zero, what_scale=0.7. The D3 trainable
    # surface is the reverse-path body (CS/SS layers); assert THAT.
    assert any("conceptualSpaces." in n or "_model_symbolSpace." in n
               for n in nz), nz


@pytest.mark.slow
def test_recon_channel_within_decade_of_output():
    """5a rebalance pin: the SCALED reconstruction channel sits within a
    decade of the SCALED output term at init on xor.

    Assembly (ModelLoss.forward + the lossRev add in Models.runBatch):
    total = (1-rr)*lossOut + rr*lossIn + rr*lossRev, rr=reconstructionScale.
    Pre-5a (rr=0.5) the scaled ratio was ~0.018 (a ~56x imbalance; the
    reverse term alone was ~3700x under output) -- too weak to constrain
    per-slot content (non-monotone convergence, seed spread). Post-5a
    (rr=0.85, config-local to MM_20M_xor.xml) the deterministic init ratio
    was 0.1015 -- the decade's bottom edge; rr is unitInterval-bounded and
    convex ((1-rr)out + rr*recon), so deeper rebalance starves the head.
    RE-BASELINED (nWhere=0 lossRev wiring fix, 2026-07-04): the where band
    now enters lossRev at where_scale, raw lossRev 7.7e-4 -> 5.55e-2 at
    init, measured ratio 1.874 -- mid-decade, same [0.1, 10] intent, no rr
    retune needed. RE-BASELINED again (silent-band lossIn wiring fix,
    2026-07-04): raw init lossIn 0.0023637 -> 0.0370179 (the live percept
    where band enters at where_scale), measured ratio 2.997 -- still
    mid-decade, interval unchanged.
    """
    from Layers import TheError

    model, dev, lr, bs = _build("data/MM_20M_xor.xml")
    rr = float(model.loss.reconstruction_scale)
    raw = {}
    orig_add = TheError.add

    def add_hook(name, value, weight=1.0, **kw):
        if (name in ("output", "reconstruction", "reconstruction_reverse")
                and name not in raw):
            raw[name] = (float(value.detach()) if torch.is_tensor(value)
                         else float(value))
        return orig_add(name, value, weight=weight, **kw)

    TheError.add = add_hook
    try:
        opt = model.getOptimizer(lr=lr)
        model.runEpoch(optimizer=opt, batchSize=bs, split="train",
                       max_batches=1)
    finally:
        TheError.add = orig_add

    out_scaled = (1.0 - rr) * raw.get("output", 0.0)
    recon_scaled = rr * (raw.get("reconstruction", 0.0)
                         + raw.get("reconstruction_reverse", 0.0))
    assert out_scaled > 0.0, raw  # the rebalance must not zero output supervision
    assert recon_scaled > 0.0, raw
    ratio = recon_scaled / out_scaled
    assert 0.1 <= ratio <= 10.0, (ratio, rr, raw)


@pytest.mark.slow
def test_where_scale_applies_to_lossrev():
    """nWhere=0 loss-wiring fix (Alec 2026-07-04, intentional re-baseline):
    lossRev compares INPUT events (muxed ``[what|where(2)|when(2)]``,
    canonical_shape("InputSpace")), but ModelLoss is built with
    canonical_shape("OutputSpace") == (0, 0) -- correct for the lossOut
    call, wrong for the event comparison -- so the whole 1024-dim event
    took what_scale and the 2-dim where band was diluted ~512x inside the
    what-mean. The runBatch lossRev seam must weight the band at
    where_scale * MSE(band); a real train batch must route through it.
    """
    model, dev, lr, bs = _build("data/MM_20M_xor.xml")
    sub = model.inputSpace.subspace
    nw, nn_ = int(sub.nWhere), int(sub.nWhen)
    assert nw > 0, "precondition: input events carry a where band"
    D = int(sub.muxedSize)
    fwd = torch.zeros(2, 4, D)
    rev = fwd.clone()
    rev[..., D - nw - nn_:D - nn_] = 0.5  # ONLY the where band differs
    seam = getattr(model, "_reverse_event_loss", None)
    if seam is None:  # pre-fix inline form (Models.py runBatch lossRev)
        loss = model.loss.compute(rev, fwd.detach())
    else:
        loss = seam(rev, fwd)
    band_mse = torch.nn.functional.mse_loss(
        rev[..., D - nw - nn_:D - nn_], fwd[..., D - nw - nn_:D - nn_])
    expected = model.loss.where_scale * band_mse
    torch.testing.assert_close(loss, expected, rtol=1e-5, atol=1e-8)

    # Wiring: a REAL train batch's lossRev must carry the input event band.
    calls = []
    orig_compute = model.loss.compute

    def spy(pred, target, **kw):
        calls.append((tuple(pred.shape), dict(kw)))
        return orig_compute(pred, target, **kw)

    model.loss.compute = spy
    try:
        opt = model.getOptimizer(lr=lr)
        model.runEpoch(optimizer=opt, batchSize=bs, split="train",
                       max_batches=1)
    finally:
        model.loss.compute = orig_compute
    banded = [kw for shape, kw in calls
              if len(shape) == 3 and kw.get("nWhere") == nw
              and kw.get("nWhen") == nn_]
    assert banded, (calls, "no 3-dim event compare carried the input band")


@pytest.mark.slow
def test_where_scale_applies_to_d3_reconstruction():
    """Silent-band fix, remaining site 1 of 2 (the D3 twin; Alec-approved
    re-baseline 2026-07-04): grammar's D3 reverse objective compares
    INPUT-layout events (muxed ``[what(8)|where(2)|when(2)]``, muxedSize 12,
    canonical_shape("InputSpace")) but called ``loss.compute`` WITHOUT the
    band -- the LIVE where band entered the what-mean at what_scale*(2/12)
    ~= 0.117 instead of where_scale 0.2 (~1.71x where dilution; measured
    first-batch compare 0.2693996 unbanded -> 0.3771294 banded, where/when
    band MSE 0.5556/0.5448 vs what 0.3022). On the serial path the D3 term
    IS the reconstruction objective (the dedupe made it so). The site must
    route through the ``_reverse_event_loss`` seam (same input-event layout
    as lossRev); a real grammar train batch's D3 compare must carry the band.
    (Historical widths above are the pre-Task-6 byte-analysis shape; since
    the 2026-07-04 meronomy switch grammar's input event width is 1024 --
    the test reads D from the built model, so the pin is shape-agnostic.)
    """
    model, dev, lr, bs = _build("data/MM_20M_grammar.xml")
    sub = model.inputSpace.subspace
    nw, nn_ = int(sub.nWhere), int(sub.nWhen)
    assert nw > 0, "precondition: input events carry a where band"
    D = int(sub.muxedSize)
    tgt = torch.zeros(2, 6, D)
    rec = tgt.clone()
    rec[..., D - nw - nn_:D - nn_] = 0.5  # ONLY the where band differs
    orig_rev = model._reverse_from_S
    model._reverse_from_S = lambda S: rec
    model._stm_single_S = torch.zeros(2, D)
    model.inputSpace._ar_embedded = tgt
    try:
        loss, _metric = model._d3_reconstruction_loss()
    finally:
        del model._reverse_from_S
        model._stm_single_S = None
        model.inputSpace._ar_embedded = None
    band_mse = torch.nn.functional.mse_loss(
        rec[..., D - nw - nn_:D - nn_], tgt[..., D - nw - nn_:D - nn_])
    expected = model.loss.where_scale * band_mse
    torch.testing.assert_close(loss, expected, rtol=1e-5, atol=1e-8)

    # Wiring: a REAL grammar train batch's D3 compare must carry the band.
    calls = []
    orig_compute = model.loss.compute

    def spy(pred, target, **kw):
        calls.append((tuple(pred.shape), dict(kw)))
        return orig_compute(pred, target, **kw)

    model.loss.compute = spy
    try:
        opt = model.getOptimizer(lr=lr)
        model.runEpoch(optimizer=opt, batchSize=bs, split="train",
                       max_batches=1)
    finally:
        model.loss.compute = orig_compute
    assert model._d3_active, "grammar train batch should take the D3 path"
    banded = [kw for shape, kw in calls
              if len(shape) == 3 and shape[-1] == D
              and kw.get("nWhere") == nw and kw.get("nWhen") == nn_]
    assert banded, (calls, "the D3 event compare did not carry the input band")


@pytest.mark.slow
def test_where_scale_applies_to_masked_lossin():
    """Silent-band fix, remaining site 2 of 2 (the compute_masked lossIn;
    Alec-approved re-baseline 2026-07-04): the whole-slab masked-LM lossIn
    compares PERCEPTUAL events (muxed ``[what(1020)|where(2)|when(2)]``,
    canonical_shape("PartSpace") == (2, 2), xor muxedSize 1024) via
    ``compute_masked``, which read the constructor band (0, 0) -- the LIVE
    where band (measured first-batch masked SE 1.387 vs what 12.43) was
    diluted ~146x (where_scale/(what_scale*2/1024)); measured first-batch
    lossIn 0.0023637 unbanded -> 0.0370181 banded. ``compute_masked`` gains
    the same per-call nWhere/nWhen overrides as ``compute``; runBatch routes
    through the ``_masked_event_loss`` seam (percept-layout band source,
    fail-loud fallback). compute_masked IS xor's live recon term.
    """
    model, dev, lr, bs = _build("data/MM_20M_xor.xml")
    psub = model.perceptualSpace.subspace
    nw, nn_ = int(psub.nWhere), int(psub.nWhen)
    assert nw > 0, "precondition: percept events carry a where band"
    D = int(psub.muxedSize)
    tgt = torch.zeros(2, 4, D)
    pred = tgt.clone()
    pred[..., D - nw - nn_:D - nn_] = 0.5  # ONLY the where band differs
    mask = torch.zeros(2, 4, dtype=torch.bool)
    mask[:, :2] = True
    seam = getattr(model, "_masked_event_loss", None)
    if seam is None:  # pre-fix inline form (Models.py runBatch lossIn)
        loss = model.loss.compute_masked(pred, tgt, mask)
    else:
        loss = seam(pred, tgt, mask)
    band_mse = torch.nn.functional.mse_loss(
        pred[mask][:, D - nw - nn_:D - nn_], tgt[mask][:, D - nw - nn_:D - nn_])
    expected = model.loss.where_scale * band_mse
    torch.testing.assert_close(loss, expected, rtol=1e-5, atol=1e-8)

    # Wiring: a REAL train batch's masked compare must carry the percept band.
    calls = []
    orig_cm = model.loss.compute_masked

    def spy(pred, target, mask, **kw):
        calls.append((tuple(pred.shape), dict(kw)))
        return orig_cm(pred, target, mask, **kw)

    model.loss.compute_masked = spy
    try:
        opt = model.getOptimizer(lr=lr)
        model.runEpoch(optimizer=opt, batchSize=bs, split="train",
                       max_batches=1)
    finally:
        model.loss.compute_masked = orig_cm
    banded = [kw for shape, kw in calls
              if kw.get("nWhere") == nw and kw.get("nWhen") == nn_]
    assert banded, (calls, "no masked compare carried the percept band")


def test_model_loss_honors_explicit_zero_scales():
    """Falsy-zero fix (Alec 2026-07-04): ModelLoss must KEEP an explicit 0.0
    (the old ``float(x or default)`` coerced falsy 0.0 back to the default,
    so the XSD-documented "0 = output-only training" regime was unreachable
    -- data/MM_xor_loopback.xml and data/idempotent.xml silently trained at
    rr=0.5). None still means unset (default preserved).
    """
    from Layers import ModelLoss

    ml = ModelLoss(reconstruction_scale=0.0, what_scale=0.0)
    assert ml.reconstruction_scale == 0.0
    assert ml.what_scale == 0.0
    # rr=0.0 makes total() EXACTLY the output loss (output-only training).
    loss_out = torch.tensor(0.7311)
    loss_in = torch.tensor(123.456)
    assert float(ml.total(loss_out, loss_in)) == float(loss_out)
    # None-unset keeps each documented default.
    md = ModelLoss()
    assert (md.reconstruction_scale, md.what_scale, md.where_scale,
            md.when_scale, md.embedding_scale) == (0.5, 0.7, 0.2, 0.1, 0.1)


@pytest.mark.slow
def test_grammar_output_loss_not_silent_zero(tmp_path):
    """5b: shape-reconcilable head loss computes, never a silent 0.0/weight-0.

    Grammar's head pred [B,4,4] vs labels [B,1,1] used to fail the exact
    shape-equality gate -> silent zeros. Post-fix the label-singleton axes
    are mean-reduced and the loss computes. Task 6 (2026-07-04 meronomy
    switch) RESOLVED the stub-label story: analysis=meronomy resolves the
    lexer to raw, use_byte_cursor=False, and the REAL XOR labels
    [0,1,1,0] reach the head (probe-verified: pred [4,4,1] vs target
    [4,1,1] carrying the labels) -- the pin is liveness AND now real
    supervision.
    """
    rec = run_config("data/MM_20M_grammar.xml", epochs=1, seed=None,
                     out_dir=str(tmp_path))
    assert rec.output_loss > 0.0


def test_shape_gate_reconciles_singleton_axes():
    """_align_output_pred mean-reduces label-singleton axes ([4,4,4]->[4,1,1])."""
    from Models import BasicModel

    m = object.__new__(BasicModel)
    torch.nn.Module.__init__(m)
    pred = torch.randn(4, 4, 4)
    tgt = torch.zeros(4, 1, 1)
    with warnings.catch_warnings():
        warnings.simplefilter("error")  # reconcilable path must not warn
        aligned = m._align_output_pred(pred, tgt)
    assert aligned is not None and tuple(aligned.shape) == (4, 1, 1)
    assert torch.allclose(
        aligned, pred.mean(dim=2, keepdim=True).mean(dim=1, keepdim=True))
    # Trailing-dim reduce (the pre-existing behavior) is preserved.
    aligned2 = m._align_output_pred(torch.randn(4, 1, 5), torch.zeros(4, 1))
    assert aligned2 is not None and tuple(aligned2.shape) == (4, 1)


def test_silent_zero_sites_warn_once():
    """5b fail-loud: both former silent-zero sites warn once, naming the gate.

    Site 1 (output shape gate): irreconcilable head/label shapes emit ONE
    RuntimeWarning naming both shapes; a second call is silent.
    Site 2 (dead reconstruction channel): a train batch that stages no IR
    mask (and no D3) emits ONE RuntimeWarning naming the config + the
    percept ``.what`` type; the second epoch is silent.
    """
    from Models import BasicModel

    # Site 1: the shape gate, unit-level on a bare model instance.
    m = object.__new__(BasicModel)
    torch.nn.Module.__init__(m)
    pred, tgt = torch.randn(4, 3, 4), torch.zeros(4, 2, 1)
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        assert m._align_output_pred(pred, tgt) is None
        assert m._align_output_pred(pred, tgt) is None  # warn-once
    gate_msgs = [str(x.message) for x in w
                 if issubclass(x.category, RuntimeWarning)
                 and "output_shape_gate" in str(x.message)]
    assert len(gate_msgs) == 1, gate_msgs
    assert "(4, 3, 4)" in gate_msgs[0] and "(4, 2, 1)" in gate_msgs[0]
    assert "config" in gate_msgs[0]

    # Site 2: the zeroed reconstruction channel, end-to-end on the fixture.
    model, dev, lr, bs = _build("data/MM_xor_fixture.xml")
    model.mask_rate = 0.0  # forces create_ir_mask's no-mask gate
    opt = model.getOptimizer(lr=lr)
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        model.runEpoch(optimizer=opt, batchSize=bs, split="train")
        model.runEpoch(optimizer=opt, batchSize=bs, split="train")
    recon_msgs = [str(x.message) for x in w
                  if issubclass(x.category, RuntimeWarning)
                  and "reconstruction loss zeroed" in str(x.message)]
    assert len(recon_msgs) == 1, recon_msgs
    assert "MM_xor_fixture" in recon_msgs[0]
    assert ".what=" in recon_msgs[0]


@pytest.mark.slow
def test_xor_percepts_tile_words():
    """5e (Alec 2026-07-03): the learned xor percept tiling IS the word
    tiling -- 'hello world' -> [b'hello', b' ', b'world'] (the
    ``Meronomy.word_tiling`` word/space/punct convention); no percept spans
    a whitespace boundary. Pre-fix, promotion saw the whole-line lexer
    token and each row collapsed to ONE whole-sentence percept.
    """
    import Meronomy

    model, dev, lr, bs = _build("data/MM_20M_xor.xml")
    opt = model.getOptimizer(lr=lr)
    for _ in range(3):
        model.runEpoch(optimizer=opt, batchSize=bs, split="train")
    model.set_sigma(0)
    model.train(False)
    with torch.no_grad():
        model.runEpoch(batchSize=4, split="test")

    fwd = model.perceptualSpace._forward_input
    ps = fwd["percept_store"]
    pid_grid = fwd["indices"]
    null_pid = ps.get_id(b"\x00")
    assert len(fwd["tokens"]) == 4  # the xor rows
    for b, row in enumerate(fwd["tokens"]):
        surface = "".join(t for t in row if t).encode("utf-8")
        tiles = [surface[s:e]
                 for (s, e) in Meronomy.word_tiling(surface)]
        pids = [int(p) for p in pid_grid[b] if int(p) != null_pid]
        decoded = [ps.bytes_for(p) for p in pids]
        assert decoded == tiles, (surface, decoded, tiles)
    # No whole-sentence percept survives in the learned store.
    for key in ps.hash_map:
        assert len(Meronomy.word_tiling(key)) <= 1, key


def test_spell_out_respects_tile_cut():
    """5e (M2, unit pin): the Pass-2 word-tile cut in ``PerceptualSpace``
    bounds spell-out INDEPENDENTLY of the promotion gate -- even a
    crossing percept seeded directly via ``RadixLayer.insert()`` (bypassing
    ``observe_chunk``/``lookup_with_id`` promotion entirely) must never be
    emitted whole; the caller only ever calls ``spell_out`` on tile-cut
    pieces, so the crossing chunk can only come back as its per-tile pieces.
    """
    from Layers import RadixLayer

    store = RadixLayer(8, promotion_threshold=2, promotion_min_length=2,
                       word_bounded=True)
    crossing = b"hello world"
    crossing_id = store.insert(crossing)
    assert store.get_id(crossing) == crossing_id  # precondition: it IS known

    tiles = [(0, 5), (5, 6), (6, 11)]  # b"hello", b" ", b"world"
    pids = []
    for (s, e) in tiles:
        pids.extend(store.spell_out(crossing[s:e]))
    assert crossing_id not in pids, (crossing_id, pids)
    decoded = [store.bytes_for(p) for p in pids]
    assert b"".join(decoded) == crossing
    assert all(len(chunk) <= 5 for chunk in decoded), decoded  # pieces only


def test_word_tiling_survives_promotion():
    """5e: promotion cannot merge across word boundaries even when size
    allows (min_length satisfied, no max) -- at BOTH promotion sites
    (``observe_chunk`` and ``lookup_with_id`` step 4). Within-tile chunks
    (words, separator runs) still promote; an unbounded store keeps the
    legacy whole-line behavior.
    """
    from Layers import RadixLayer

    store = RadixLayer(8, promotion_threshold=2, promotion_min_length=2,
                       word_bounded=True)
    # Site 1: observe_chunk never promotes a boundary-crossing chunk.
    for _ in range(5):
        assert store.observe_chunk(b"hello world") is None
    assert store.get_id(b"hello world") is None
    for _ in range(5):
        assert store.observe_chunk(b"hello,world") is None
    assert store.get_id(b"hello,world") is None
    # Words and separator RUNS are single tiles: they promote at threshold.
    assert store.observe_chunk(b"hello") is None
    pid = store.observe_chunk(b"hello")
    assert pid is not None and store.get_id(b"hello") == pid
    assert store.observe_chunk(b"  ") is None
    assert store.observe_chunk(b"  ") is not None
    # Site 2: the lookup_with_id promotion gate rejects crossers too.
    for _ in range(6):
        _, lpid = store.lookup_with_id(b"good day")
        assert lpid is None
    assert store.get_id(b"good day") is None
    # The un-bounded store (legacy radix/bpe mirror) is unchanged.
    legacy = RadixLayer(8, promotion_threshold=2, promotion_min_length=2)
    assert legacy.observe_chunk(b"hello world") is None
    assert legacy.observe_chunk(b"hello world") is not None


@pytest.mark.slow
def test_reconstruction_not_double_counted():
    """Dedupe pin (Alec 2026-07-03): on the serial/D3 path the two
    reconstruction terms were bit-identical (probe: 0.2683708... under
    weights 1.0 and rr) -- ONE reverse-implemented objective counted twice.
    Post-fix a train batch carries a single ``reconstruction`` term; no
    ``reconstruction_reverse`` is accumulated (eval keeps the reverse pass
    for decode staging only).
    """
    from Layers import TheError

    model, dev, lr, bs = _build("data/MM_20M_grammar.xml")
    terms = {}
    orig_add = TheError.add

    def add_hook(name, value, weight=1.0, **kw):
        v = float(value.detach()) if torch.is_tensor(value) else float(value)
        terms.setdefault(name, []).append((v, float(weight)))
        return orig_add(name, value, weight=weight, **kw)

    TheError.add = add_hook
    try:
        opt = model.getOptimizer(lr=lr)
        model.runEpoch(optimizer=opt, batchSize=bs, split="train",
                       max_batches=1)
    finally:
        TheError.add = orig_add

    assert model._d3_active, "grammar train batch should take the D3 path"
    assert "reconstruction" in terms
    assert len(terms["reconstruction"]) == 1
    assert terms["reconstruction"][0][0] > 0.0
    assert "reconstruction_reverse" not in terms, terms.keys()


@pytest.mark.slow
def test_mm20m_xor_roundtrip_at_harness_budget(tmp_path):
    """Retain the three-epoch .5 reconstruction bar without a selected seed."""
    rec = run_config("data/MM_20M_xor.xml", epochs=3, seed=None,
                     out_dir=str(tmp_path), blind=False)
    assert rec.exact_match_rate >= 0.5
    assert rec.where_recovery == 1.0


@pytest.mark.skipif(os.environ.get("RUN_SLOW") != "1",
                    reason="~40s (build + 3 epochs + decode) -- RUN_SLOW gates it")
def test_mm20m_grammar_free_derivation_roundtrip(tmp_path):
    """Free derivation should recover the input; a measured zero is a gap.

    The old assertion required the seed-0 failure (exact match == 0). Its
    historical measurement is not a correctness contract or a ceiling.
    """
    rec = run_config("data/MM_20M_grammar.xml", epochs=3, seed=None,
                     out_dir=str(tmp_path), blind=False, free_derivation=True)
    assert rec.exact_match_rate == 1.0
    assert rec.where_recovery == 1.0


@pytest.mark.skipif(
    os.environ.get("RUN_SLOW") != "1",
    reason="160-epoch reconstruction acceptance -- set RUN_SLOW=1")
def test_mm20m_xor_exact_roundtrip(tmp_path):
    """Decoded reconstruction must equal input at the declared 160 epochs."""
    rec = run_config("data/MM_20M_xor.xml", epochs=RECONSTRUCTION_EPOCHS, seed=None,
                     out_dir=str(tmp_path), blind=False)
    assert rec.exact_match_rate == 1.0
    assert rec.where_recovery == 1.0


def test_associate_span_two_arms():
    """5c association: arm (a) restricts to percepts covering EXACTLY the
    span's byte size and is scale-invariant (cosine -- the reverse path
    inflates norms 2-3.4x); an empty size bucket returns None (arm (b)
    falls back to parts); NaN fails loud; a zero vector is no-symbol."""
    from Layers import RadixLayer

    store = RadixLayer(8, promotion_threshold=2, promotion_min_length=2)
    pid_world = store.insert(b"world")
    store.insert(b"hello")
    pid_sp = store.insert(b" ")
    v = store.vector_for(pid_world).detach()
    assert store.associate_span(3.4 * v, size=5) == pid_world
    assert store.associate_span(v, size=1) == pid_sp    # forced into the bucket
    assert store.associate_span(v, size=9) is None      # empty bucket -> arm (b)
    assert store.associate_span(torch.zeros_like(v)) is None
    with pytest.raises(RuntimeError):
        store.associate_span(torch.full_like(v, float("nan")), size=5)


@pytest.mark.slow
def test_radix_decode_gates_pad_slots():
    """5d: the reverse render emits ONLY forward-active slots -- a
    4-content-slots-padded-to-8 row renders its real content only (pads
    carry no .where claim; pre-fix all 8 slots decoded as content chunks
    at noise offsets)."""
    model, dev, lr, bs = _build("data/MM_20M_xor.xml")
    opt = model.getOptimizer(lr=lr)
    for _ in range(3):
        model.runEpoch(optimizer=opt, batchSize=bs, split="train")
    model.set_sigma(0)
    model.train(False)
    with torch.no_grad():
        model.runEpoch(batchSize=4, split="test")
    psp = model.perceptualSpace
    fwd = psp._forward_input
    ps = fwd["percept_store"]
    null_pid = ps.get_id(b"\x00")
    meta = psp._materialize_recovered_input()
    assert meta is not None
    for b, row in enumerate(fwd["indices"]):
        n_active = sum(1 for p in row if int(p) != null_pid)
        assert len(meta["tokens"][b]) == n_active, (b, meta["tokens"][b])
    assert int(fwd["indices"].shape[1]) == 8  # rows really are padded


def test_idempotent_config_trains_one_epoch_clean(tmp_path):
    """Version-counter pin (2026-07-04): the meronomy factored crossing
    read (``ConceptualSpace._factor_crossing``) let ``factor_percept``'s
    matmul save a LIVE transposed view of the muxed CS event-codebook
    Parameter; the four ``set_event`` -> ``Codebook.quantize`` VQ-EMA
    ``copy_`` writes later in the same runBatch bumped its version (0->4)
    and backward died ('inplace operation ... [104, 10] at version 4').
    The read site must CLONE before any later dictionary write.
    idempotent.xml uniquely arms the path: CS ``<codebook>quantize</codebook>``
    (muxed event Codebook) + the uniform 104-wide slab (both width gates
    pass). One epoch must complete with finite losses.
    """
    rec = run_config("data/idempotent.xml", epochs=1, seed=None,
                     out_dir=str(tmp_path))
    assert np.isfinite(rec.output_loss) and np.isfinite(rec.recon_loss)


@pytest.mark.slow
def test_codebook_mask_path_inert_under_no_grad():
    """Determinism pin (Alec 2026-07-03): the 5b Codebook-``.what`` IR mask
    is a TRAIN-STEP objective -- a no_grad forward must stage nothing and
    must not corrupt the stage-0 percept event (the handoff test's
    byte-identity bar). Grad-enabled forwards still stage it (5b liveness).
    Pins only the NEW mutation class; pre-existing eval-time store
    observes (hit counters etc.) stay tolerated as at HEAD.
    """
    model, dev, lr, bs = _build("data/MM_mereology.xml")
    assert not hasattr(model.perceptualSpace.subspace.what,
                       "null_percept_idx"), "precondition: Codebook .what"
    loader = model.inputSpace.data.data_loader(split="train", num_streams=4)
    items, _ = next(iter(loader))
    x = model.inputSpace.prepInput(items)
    with torch.no_grad():
        model.forward(x)
        assert model._ir_mask_positions is None, \
            "no_grad forward staged an IR mask on the Codebook path"
        assert model._ir_pre_mask_input is None
    # Liveness guard: the SAME forward with grads on must stage the mask.
    model.forward(x)
    assert model._ir_mask_positions is not None
    assert model._ir_pre_mask_input is not None
