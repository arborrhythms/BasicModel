"""Tests for SigmaPi layers and the LogicalFunctionNet."""

import os
import sys
import unittest

os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

import pytest
import torch
import torch.nn as nn
import torch.optim as optim

_BIN = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "bin")
if _BIN not in sys.path:
    sys.path.insert(0, _BIN)
import Layers

from util import TheDevice


class TestPiLayerForward(unittest.TestCase):
    """PiLayer produces the correct output shape for 2D and 3D inputs.

    PiLayer expects inputs in [-1, 1].
    """

    def test_3d_input_shape(self):
        nBatch, nInput, nOutput, nSymbols = 5, 3, 4, 6
        layer = Layers.PiLayer(nInput, nOutput, nonlinear=True)
        layer.set_sigma(0)
        x = torch.rand(nBatch, nSymbols, nInput).clamp(min=Layers.epsilon).to(TheDevice.get())
        y = layer(x)
        self.assertEqual(y.shape, (nBatch, nSymbols, nOutput))

    def test_2d_input_shape(self):
        nBatch, nInput, nOutput = 4, 3, 5
        layer = Layers.PiLayer(nInput, nOutput, nonlinear=True)
        layer.set_sigma(0)
        x = torch.rand(nBatch, nInput).clamp(min=Layers.epsilon).to(TheDevice.get())
        y = layer(x)
        self.assertEqual(y.shape, (nBatch, nOutput))

    def test_gradient_flows(self):
        layer = Layers.PiLayer(2, 3, ergodic=True, nonlinear=True)
        with torch.no_grad():
            layer.var.fill_(0.001)
            layer.bias.fill_(0.999)
        x = torch.rand(4, 2).clamp(min=Layers.epsilon).to(TheDevice.get()).requires_grad_(True)
        y = layer(x)
        loss = y.sum()
        loss.backward()
        self.assertIsNotNone(x.grad)
        self.assertFalse(torch.all(x.grad == 0))


class TestSigmaLayerForward(unittest.TestCase):
    """SigmaLayer produces the correct output shape and supports backprop."""

    def test_3d_input_shape(self):
        nBatch, nInput, nOutput, nSymbols = 4, 3, 5, 6
        layer = Layers.SigmaLayer(nInput, nOutput, nonlinear=True)
        layer.set_sigma(0)
        x = torch.randn(nBatch, nSymbols, nInput).to(TheDevice.get())
        y = layer(x)
        self.assertEqual(y.shape, (nBatch, nSymbols, nOutput))

    def test_output_bounded_by_tanh(self):
        """With saturate=True (default), outputs should be in [-1, 1]."""
        layer = Layers.SigmaLayer(4, 3, nonlinear=True)
        layer.set_sigma(0)
        x = torch.randn(10, 4).to(TheDevice.get()) * 10  # large inputs
        y = layer(x)
        self.assertTrue(torch.all(y >= -1.0))
        self.assertTrue(torch.all(y <= 1.0))

    def test_gradient_flows(self):
        layer = Layers.SigmaLayer(3, 2, nonlinear=True)
        layer.set_sigma(0)
        x = torch.randn(4, 3).to(TheDevice.get()).requires_grad_(True)
        y = layer(x)
        loss = y.sum()
        loss.backward()
        self.assertIsNotNone(x.grad)


class TestPiSigmaChartComposition(unittest.TestCase):
    """Adjacent bounded charts cancel; they do not create an XOR hidden layer."""

    def test_hidden_tanh_is_cancelled_by_the_next_chart(self):
        # Explicit interior inputs/weights test the algebra, not a selected
        # training trajectory. Sigma's atanh cancels Pi's output tanh.
        pi = Layers.PiLayer(2, 4, nonlinear=True).double()
        sigma = Layers.SigmaLayer(4, 1, nonlinear=True).double()
        pi.set_sigma(0)
        sigma.set_sigma(0)
        with torch.no_grad():
            for layer in (pi, sigma):
                for parameter in layer.parameters():
                    parameter.copy_(torch.linspace(-.2, .3, parameter.numel(),
                                                   device=parameter.device,
                                                   dtype=parameter.dtype).reshape_as(parameter))
        x = torch.tensor([[-.4, -.2], [-.4, .3], [.2, -.2], [.2, .3]],
                         dtype=torch.float64, device=TheDevice.get())
        w_pi, w_sigma = pi.layer.compute_W_current(), sigma.layer.compute_W_current()
        # Plain LinearLayer.forward omits its separately applied bias. Pi
        # includes its bias explicitly; this Sigma host has no affine offset.
        b_pi = pi.layer._effective_bias()
        chart_affine = x.atanh() @ (w_pi @ w_sigma) + (b_pi / 2) @ w_sigma
        hidden = pi(x)
        self.assertLess(float(hidden.detach().abs().max()), .9)
        torch.testing.assert_close(sigma(hidden), chart_affine.tanh(), rtol=1e-10, atol=1e-10)
        # The former <.1 XOR learning assertion selected among nine seeds.
        # Away from clipping this composition is a monotone readout of an
        # affine chart, so it has no XOR decision boundary. The exponential
        # Pi + linear Sigma case below retains the genuine learning gate.


class TestTanhFreePiSigmaXORTestpoint(unittest.TestCase):
    """Tanh-free Pi exponential features plus linear Sigma solve MM_xor."""

    def test_mm_xor_solves_in_10_epochs_without_tanh(self):
        from itertools import chain

        X = torch.tensor(
            [[0, 0], [0, 1], [1, 0], [1, 1]],
            dtype=torch.float32,
            device=TheDevice.get(),
        ) - 0.5
        Y = torch.tensor(
            [[0], [1], [1], [0]],
            dtype=torch.float32,
            device=TheDevice.get(),
        )

        pi = Layers.PiLayer(2, 8, nonlinear=False)
        sigma = Layers.SigmaLayer(8, 1, nonlinear=False)
        pi.set_sigma(0)
        sigma.set_sigma(0)

        optimizer = optim.LBFGS(
            chain(pi.parameters(), sigma.parameters()),
            lr=1.0,
            max_iter=5,
            line_search_fn="strong_wolfe",
        )
        criterion = nn.MSELoss()

        for _ in range(10):
            def closure():
                optimizer.zero_grad()
                loss = criterion(sigma(pi(X)), Y)
                loss.backward()
                return loss

            optimizer.step(closure)

        with torch.no_grad():
            pred = sigma(pi(X))
            loss = criterion(pred, Y)

        print(
            "\n  tanh-free MM_xor loss="
            f"{loss.item():.8f}, pred={pred.flatten().tolist()}"
        )
        self.assertLess(loss.item(), 1e-4)
        self.assertTrue(torch.allclose(pred, Y, atol=2e-2))


class TestLogicalFunctionNet(unittest.TestCase):
    """The SigmaPi.py LogicalFunctionNet runs without error."""

    def test_forward_shape(self):
        from SigmaPi import LogicalFunctionNet
        model = LogicalFunctionNet(2, 3, 1)
        x = torch.randn(4, 1, 2).to(TheDevice.get())
        y = model(x)
        self.assertEqual(y.shape, (4, 1, 1))

    def test_backward_no_error(self):
        from SigmaPi import LogicalFunctionNet
        model = LogicalFunctionNet(2, 3, 1)
        x = torch.randn(4, 1, 2).to(TheDevice.get())
        y = model(x)
        loss = y.sum()
        loss.backward()
        # Verify at least some parameters got gradients
        grads = [p.grad for p in model.parameters() if p.grad is not None]
        self.assertGreater(len(grads), 0)


if __name__ == '__main__':
    unittest.main()


@pytest.mark.slow
@pytest.mark.parametrize('run', range(3))
def test_normalized_sigma_current_pi_learns_crisp_xor(run):
    from fold_evaluation import xor_trial
    result = xor_trial(width=4)
    print(result)
    assert result['initial_mse'] > .05
    assert result['mse'] < .05
    assert result['clamp_fraction'] == 0.
