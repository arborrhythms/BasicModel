"""Item 10 evaluation mode: column means, tied inverses and binary means."""
import pytest
import torch

from Layers import PiLayer, SigmaLayer


@pytest.mark.parametrize('kind', [SigmaLayer, PiLayer])
@pytest.mark.parametrize('monotonic', [True, False])
def test_normalized_unary_and_binary_roundtrip(kind, monotonic):
    layer = kind(8, 8, invertible=True, monotonic=monotonic, normalize=True).double()
    x = .2 + .6 * torch.rand(7, 8, dtype=torch.float64)
    if not monotonic:
        x = .6 * torch.nn.functional.normalize(x - .5, dim=-1)
    gate = torch.linspace(.6, .9, 8, dtype=torch.float64)
    y = layer(x, gate=gate)
    torch.testing.assert_close(layer.reverse(y, gate=gate), x, atol=1e-10, rtol=1e-10)
    other = x.flip(0)
    parent = layer.compose(x, other, gate=gate)
    left, right = layer.generate(parent, gate=gate)
    torch.testing.assert_close(layer.compose(left, right, gate=gate), parent, atol=1e-10, rtol=1e-10)
    l, r = layer.generate_functional(parent, gate=gate, reference=x,
        reference_side=(torch.zeros(7, dtype=torch.bool), torch.ones(7, dtype=torch.bool)))
    torch.testing.assert_close(l, x, atol=1e-10, rtol=1e-10)
    torch.testing.assert_close(r, other, atol=1e-10, rtol=1e-10)


def test_monotone_means_remain_bounded_through_thirty_layers():
    x = torch.rand(16, 8, dtype=torch.float64, requires_grad=True)
    y = x
    for depth in range(30):
        kind = SigmaLayer if depth % 2 == 0 else PiLayer
        y = kind(8, 8, invertible=True, monotonic=True, normalize=True).double()(y)
        assert bool(((0 <= y) & (y <= 1)).all())
    y.square().sum().backward()
    assert torch.isfinite(x.grad).all() and x.grad.norm() > 0


def test_normalized_set_and_empty_set():
    sigma = SigmaLayer(4, 4, invertible=True, monotonic=True, normalize=True).double()
    parts = torch.rand(2, 3, 4, dtype=torch.float64)
    torch.testing.assert_close(sigma.synthesize_over_set(parts), sigma(parts.mean(-2)))
    empty = torch.zeros(2, 3, dtype=torch.bool)
    assert sigma.synthesize_over_set(parts, mask=empty).count_nonzero() == 0


def test_width_scaled_monotone_initialization_keeps_own_input():
    layer = SigmaLayer(264, 264, invertible=True, monotonic=True, normalize=True)
    w, scale = layer.normalized_weights()
    assert w.diag().amin() > .9
    torch.testing.assert_close(w.sum(0), torch.ones(264))


def test_signed_l2_is_not_a_cube_bound():
    layer = SigmaLayer(4, 1, normalize=True)
    with torch.no_grad():
        layer.layer.W.fill_(1.)
    assert layer(torch.ones(1, 4)).item() > 1.
    assert layer(torch.ones(1, 4) / 2).item() <= 1.


@pytest.mark.parametrize('kind', ['lift', 'lower'])
def test_grammar_hosts_use_the_selected_normalized_fold(kind):
    from Language import LiftLayer, LowerLayer
    host = (LiftLayer if kind == 'lift' else LowerLayer)(8, 8, normalize=True).double()
    left = .6 * torch.nn.functional.normalize(torch.randn(3, 8, dtype=torch.float64), dim=-1)
    right = left.flip(0)
    parent = host(left, right)
    a, b = host.reverse(parent)
    torch.testing.assert_close(host(a, b), parent, atol=1e-10, rtol=1e-10)


def test_normalized_functional_composition_compiles_without_mutating_gate():
    layer = SigmaLayer(4, 4, invertible=True, normalize=True)
    compose = torch.compile(layer.compose, backend='eager', fullgraph=True)
    x = torch.rand(3, 4) / 3
    gate = torch.full((4,), .8)
    expected = layer.compose(x, x.flip(0), gate=gate)
    torch.testing.assert_close(compose(x, x.flip(0), gate=gate), expected)
    assert getattr(layer.layer, '_current_gate', None) is None
