"""Controlled real-layer measurements shared by item 10 and its gates."""
import torch
import torch.nn.functional as F
from Layers import SigmaLayer, PiLayer


def xor_trial(width=4, mode='selective', unit_energy=True, steps=2500):
    sigma = SigmaLayer(2, width, normalize=mode != 'current')
    pi = PiLayer(width, 1, normalize=mode == 'both')
    x = torch.tensor([[-1., -1.], [-1., 1.], [1., -1.], [1., 1.]]) * .9
    if unit_energy:
        x = F.normalize(x, dim=-1) * .9
    target = torch.tensor([[-1.], [1.], [1.], [-1.]])
    optimizer = torch.optim.Adam(list(sigma.parameters()) + list(pi.parameters()), lr=.03)
    initial = None
    for step in range(steps):
        optimizer.zero_grad()
        out = pi(sigma(x))
        loss = (out-target).square().mean()
        if initial is None:
            initial = float(loss.detach())
        loss.backward()
        optimizer.step()
    with torch.no_grad():
        hidden = sigma(x)
        out = pi(hidden)
    return dict(width=width, mode=mode, unit_energy=unit_energy, steps=steps,
                initial_mse=initial, mse=float((out-target).square().mean()),
                probability_mse=float(((out-target)/2).square().mean()),
                output=out[:, 0].tolist(), hidden_max=float(hidden.abs().max()),
                clamp_fraction=float((hidden.abs() >= 1-1e-6).float().mean()))

