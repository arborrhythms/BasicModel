"""Native percept/property insertion; word-object META is owned by CS."""

from __future__ import annotations

import os
import sys
import unittest

import torch

os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
os.environ.setdefault("BASICMODEL_DEVICE", "cpu")

_HERE = os.path.dirname(os.path.abspath(__file__))
_PROJECT = os.path.dirname(_HERE)
_BIN = os.path.join(_PROJECT, "bin")
if _BIN not in sys.path:
    sys.path.insert(0, _BIN)

_DATA_DIR = os.path.join(_PROJECT, "data")
_CONFIG = os.path.join(_DATA_DIR, "MM_xor_fixture.xml")
_DEFAULTS = os.path.join(_DATA_DIR, "model.xml")


def _make_radix_model():
    """Build the MM_xor radix-chunking model for end-to-end tests."""
    import warnings
    import Models
    import Language
    from util import init_config
    init_config(path=_CONFIG, defaults_path=_DEFAULTS)
    Language.TheGrammar._configured = False
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore")
        m, _ = Models.BasicModel.from_config(_CONFIG)
    Models.TheData.load("xor")
    m.eval()
    return m


# ---------------------------------------------------------------------------
# Position → row helpers (mirror the implementation lookup tables).
# ---------------------------------------------------------------------------


def _ws_row_from_pos(ws, pos):
    """``pos`` -> SS.codebook row index via ``WholeSpace._ws_pos_to_row``."""
    row = ws._ws_pos_to_row.get(int(pos))
    if row is None:
        raise AssertionError(
            f"position {pos} has no SS-side row binding; expected an "
            f"SS or META position")
    return int(row)


def _ps_row_from_pos(ws, pos):
    """``pos`` -> PerceptStore row index via ``WholeSpace._ps_pos_to_row``."""
    row = ws._ps_pos_to_row.get(int(pos))
    if row is None:
        raise AssertionError(
            f"position {pos} has no PS-side row binding; expected a "
            f"PS position")
    return int(row)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestInsertPercept(unittest.TestCase):
    """``insert_percept`` delegates to PerceptStore; returns positive idx."""

    def test_insert_percept_returns_positive_idx_and_inserts(self):
        m = _make_radix_model()
        ws = m.wholeSpace
        # PerceptStore starts empty in a freshly built model
        ps = m.perceptualSpace.percept_store
        self.assertIsNotNone(ps,
                             "MM_xor radix-mode model must have a "
                             "percept_store on PartSpace")
        starting_size = len(ps)
        pos = ws.insert_percept(b"hello")
        self.assertIsInstance(pos, int)
        self.assertGreater(pos, 0,
                           f"insert_percept must return a positive position; "
                           f"got {pos}")
        self.assertEqual(ws._pos_kind.get(pos), "ps",
                         "PS position must be tagged 'ps' in _pos_kind")
        ps_row = _ps_row_from_pos(ws, pos)
        self.assertEqual(ps_row, starting_size,
                         "the new percept id should be the next slot")
        self.assertEqual(ps.bytes_for(ps_row), b"hello",
                         "inverse_table lookup must match insertion")
        # Repeat insert of the same canonical bytes returns the same position.
        again = ws.insert_percept(b"hello")
        self.assertEqual(again, pos,
                         "re-inserting same bytes must return the same position")


class TestInsertWhole(unittest.TestCase):
    """``insert_whole`` allocates a fresh WS row + position (positive int)."""

    def test_insert_whole_returns_positive_position_and_writes_row(self):
        m = _make_radix_model()
        ws = m.wholeSpace
        cb = ws.subspace.what
        W_before = cb.getW().detach().clone()
        # Use a custom init vector so the test can check exact write.
        init_vec = torch.zeros(int(ws.nDim))
        init_vec[0] = 0.7
        init_vec[1] = -0.3
        pos = ws.insert_whole(init_vec=init_vec)
        self.assertIsInstance(pos, int)
        self.assertGreater(pos, 0,
                           f"insert_whole must return a positive position; "
                           f"got {pos}")
        self.assertEqual(ws._pos_kind.get(pos), "ws",
                         "fresh WS whole must be tagged 'ws' in _pos_kind")
        ws_row = _ws_row_from_pos(ws, pos)
        self.assertGreaterEqual(ws_row, 0)
        self.assertLess(ws_row, cb.nVectors)
        W_after = cb.getW().detach()
        # Compare on the codebook's dtype/device.
        expected = init_vec.to(device=W_after.device, dtype=W_after.dtype)
        self.assertTrue(
            torch.allclose(W_after[ws_row], expected, atol=1e-5),
            f"WS row {ws_row} should match init_vec; got "
            f"{W_after[ws_row].tolist()} vs {expected.tolist()}")
        # Other pre-existing rows untouched.
        for r in range(min(W_before.shape[0], W_after.shape[0])):
            if r == ws_row:
                continue
            self.assertTrue(
                torch.allclose(W_before[r], W_after[r], atol=1e-6),
                f"row {r} changed unexpectedly after insert_whole")

    def test_insert_whole_default_init_random(self):
        """init_vec=None falls back to a random-ish init."""
        m = _make_radix_model()
        ws = m.wholeSpace
        pos_a = ws.insert_whole()
        pos_b = ws.insert_whole()
        self.assertNotEqual(pos_a, pos_b,
                            "Distinct insert_whole calls must return "
                            "distinct positions")














if __name__ == "__main__":
    unittest.main()


def test_wholespace_has_no_meta_decode_or_persisted_taxonomy():
    from Spaces import WholeSpace
    for name in ('insert_meta', 'reverse_decode', 'taxonomy_parent', 'taxonomy_children'):
        assert not hasattr(WholeSpace, name)
