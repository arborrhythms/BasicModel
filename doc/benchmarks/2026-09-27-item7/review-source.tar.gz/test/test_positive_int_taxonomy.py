"""Positive native addresses and retirement of position-keyed taxonomy."""

from __future__ import annotations

import os
import sys
import unittest

import torch

os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
os.environ.setdefault("BASICMODEL_DEVICE", "cpu")

_HERE = os.path.dirname(os.path.abspath(__file__))
_PROJECT = os.path.dirname(_HERE)
_BIN = os.path.join(_PROJECT, "bin")
if _BIN not in sys.path:
    sys.path.insert(0, _BIN)

_DATA_DIR = os.path.join(_PROJECT, "data")
_CONFIG = os.path.join(_DATA_DIR, "MM_xor_fixture.xml")
_DEFAULTS = os.path.join(_DATA_DIR, "model.xml")


def _make_radix_model():
    """Build the MM_xor radix-chunking model for end-to-end tests."""
    import warnings
    import Models
    import Language
    from util import init_config
    init_config(path=_CONFIG, defaults_path=_DEFAULTS)
    Language.TheGrammar._configured = False
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore")
        m, _ = Models.BasicModel.from_config(_CONFIG)
    Models.TheData.load("xor")
    m.eval()
    return m


# ---------------------------------------------------------------------------
# Positive-int returns from insert_*.
# ---------------------------------------------------------------------------


class TestInsertReturnsPositiveInt(unittest.TestCase):
    """Each ``insert_*`` allocates a position and returns it as a positive int."""

    def test_insert_percept_returns_positive_position(self):
        m = _make_radix_model()
        ws = m.wholeSpace
        pos = ws.insert_percept(b"alpha")
        self.assertIsInstance(pos, int)
        self.assertGreater(pos, 0,
                           "insert_percept must return a positive position "
                           f"(allocated via allocate_position); got {pos}")
        # Repeat insert of the same bytes returns the SAME position.
        again = ws.insert_percept(b"alpha")
        self.assertEqual(again, pos,
                         "idempotent insert: same bytes -> same position")
        # _pos_kind tags this as a PS slot.
        self.assertEqual(ws._pos_kind.get(pos), "ps",
                         "PS-side insert should tag _pos_kind[pos]='ps'")

    def test_insert_whole_returns_positive_position(self):
        m = _make_radix_model()
        ws = m.wholeSpace
        init = torch.zeros(int(ws.nDim))
        init[0] = 0.5
        pos = ws.insert_whole(init_vec=init)
        self.assertIsInstance(pos, int)
        self.assertGreater(pos, 0,
                           f"insert_whole must return a positive position; got {pos}")
        self.assertEqual(ws._pos_kind.get(pos), "ws",
                         "SS-side insert should tag _pos_kind[pos]='ws'")
        # The position resolves to a real SS row.
        ws_row = ws._ws_pos_to_row[pos]
        self.assertIsInstance(ws_row, int)
        self.assertGreaterEqual(ws_row, 0)
        # Inverse direction works too.
        self.assertEqual(ws._ws_row_to_pos[ws_row], pos)




# ---------------------------------------------------------------------------
# Taxonomy storage uses positive ints throughout.
# ---------------------------------------------------------------------------




# ---------------------------------------------------------------------------
# vocab_extras roundtrip with positive-int keys + legacy migration.
# ---------------------------------------------------------------------------




if __name__ == "__main__":
    unittest.main()


def test_meta_members_are_positive_native_concept_ids():
    from test_item9b_interpret import _operator
    cs, interpret = _operator()
    word = interpret.lookup_word([1, 2], [], form='ab')
    obj = interpret.forward(word)
    meta = cs._concept_allocator.interpretations[word, 1][1]
    assert all(type(cid) is int and cid > 0 for cid in (word, obj, meta))
    assert cs.meta_members(meta) == ((word,), (obj,))
