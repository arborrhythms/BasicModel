"""Metric arithmetic and an explicitly requested native measurement job."""
import os
from pathlib import Path
import pytest
import torch


def test_categorical_discrimination_counts_each_pair_once():
    from bench_mode_erosion import discrimination
    readings = torch.tensor([[0.], [1.], [4.], [5.]])
    measured = discrimination(readings, [0, 0, 1, 1])
    assert measured == dict(cp=3., within=1., between=4., within_pairs=2, between_pairs=4)


@pytest.mark.skipif(os.environ.get('RUN_ITEM9B_EROSION') != '1', reason='explicit 9b measurement job')
def test_three_seed_native_erosion_measurement():
    from bench_mode_erosion import run
    report = run(Path(__file__).resolve().parents[1] / 'output/item9b-erosion-measurements')
    assert len(report['conditions']) == 9
    assert len(report['findings']) == 6
    # No ordering assertion: violated predictions are architectural findings.
