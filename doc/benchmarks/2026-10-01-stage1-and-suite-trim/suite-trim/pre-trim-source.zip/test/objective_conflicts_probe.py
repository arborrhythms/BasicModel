"""Read-only objective measurements, shared by the weekly slow test and receipts.

No RNG draws, optimizer edits, extra updates or configuration edits.
The step-5a arm observes the candidate; the cut arm omits only the trial answer
term in memory. Both save their instrumentation and leave production untouched.
"""
import argparse
from collections import Counter
import difflib
import hashlib
import inspect
import itertools
import json
import math
import os
from pathlib import Path
import sys
import textwrap
import time
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path[:0] = [str(ROOT/'bin'), str(ROOT/'test')]
parser = argparse.ArgumentParser()
parser.add_argument('--config', required=True)
parser.add_argument('--config-xml', help='Receipt-local fixture; production XML is never edited')
parser.add_argument('--output', required=True)
parser.add_argument('--arm',choices=('step5a','cut'),default='step5a')
parser.add_argument('--validate-only',action='store_true')
args = parser.parse_args()
OUT = Path(args.output).resolve()
OUT.mkdir(exist_ok=True)
os.environ.pop('BASIC_SEED', None)
os.environ.update(BASICMODEL_DEVICE='cpu', BASIC_AUTOLOAD='false', BASIC_AUTOSAVE='false',
                  MODEL_COMPILE='none' if args.config=='XOR_grammar' else 'eager')
import torch
import Models
import Layers
import SentenceCompose
import util
from GradientDiagnostics import _norm, _dot_unit
from bounded_tests import source_snapshot

SOURCE = source_snapshot(ROOT)
(OUT/'source.json').write_text(json.dumps(SOURCE, indent=2))


def serial(value):
    if torch.is_tensor(value):
        return value.detach().cpu().tolist()
    if isinstance(value, Path):
        return str(value)
    raise TypeError(type(value).__name__)


def write(name, value):
    (OUT/name).write_text(json.dumps(value, indent=2, default=serial))


class Probe:
    def __init__(self):
        self.start = time.monotonic()
        self.training_batches = 0
        self.evaluation_batches = 0
        self.pair_number = 0
        self.captured_first = False
        self.captured_expectation = False
        self.capture_pair = False
        self.pair_rows = []
        self.last_batch = None
        self.last_trial = {}
        self.gradients = []
        self.groups_manifest = {}
        self.eval_reconstructions = []
        self.current = {}
        self.current_bands = []
        self.current_aux = []
        self.truth = {}
        self.model = None
        self.in_batch = False

    def log(self, kind, **data):
        with (OUT/'events.jsonl').open('a') as f:
            f.write(json.dumps(dict(kind=kind, seconds=time.monotonic()-self.start, **data), default=serial)+'\n')

    def opened(self, model, local):
        self.model = model
        self.in_batch = True
        self.current = {k:local[k] for k in ('train','split','batchNum','batchSize','outputTensor','what_questions')}
        self.current_bands, self.current_aux, self.truth = [], [], {}
        if self.training_batches==0 and self.evaluation_batches==0:
            self.metadata(model)
            self.groups(model)
        self.log('batch_open', train=local['train'], split=local['split'], batch=local['batchNum'],
                 size=int(local['inputTensor'].shape[0]), supplied=bool(model.inputSpace.data.has_supervised_outputs))

    def groups(self, model):
        named = list(model.named_parameters())
        names = {id(p):name for name,p in named}
        params = {id(p):p for _,p in named}
        def module_parameters(mod):
            return list(mod.parameters()) if isinstance(mod, torch.nn.Module) else []
        codes = []
        percept = module_parameters(model.inputSpace) + module_parameters(model.perceptualSpace)
        vocabulary = module_parameters(getattr(model.outputSpace, '_vocabulary', None))
        output_ids = {id(p) for p in module_parameters(model.outputSpace)}
        # InputSpace registers an OutputSpace back-reference. That does not
        # make the numeric answer head a perception parameter. The shared
        # vocabulary belongs to perception, not the reading map.
        percept = [p for p in percept if id(p) not in output_ids] + vocabulary
        predictors = module_parameters(getattr(model.symbolSpace, 'discourse', None))
        for cs in model.conceptualSpaces:
            codes += module_parameters(getattr(cs, 'similarity_codebook', None))
            percept += module_parameters(getattr(cs, 'concepts_from_percepts', None))
            percept += module_parameters(getattr(cs, 'concept_source_readout', None))
            predictors += module_parameters(getattr(cs, 'intraSentenceLayer', None))
        operation = model.symbolSpace.languageLayer.operation_layer
        ops = list(operation.ops.parameters()) + list(operation.unary_ops.parameters())
        for layer in model.symbolSpace._host_layer_registry.values():
            ops += module_parameters(layer)
        opids, codeids = {id(p) for p in ops}, {id(p) for p in codes}
        chooser = [p for p in operation.parameters() if id(p) not in opids]
        generate = model.synthesis_parameters()
        # Groups deliberately overlap when the same physical parameter serves
        # two paths. All intersections are published, never double-counted inside a group.
        vocabulary_ids = {id(p) for p in vocabulary}
        reading = [p for p in module_parameters(model.outputSpace) if id(p) not in vocabulary_ids]
        if model.answer_synthesis:
            reading += generate
        # Include the model's named shared transforms, including perceptual
        # inverses. This read-only ownership view uses no optimizer mutation.
        shared = model._shared_operator_parameter_groups(SimpleNamespace(
            param_groups=[{'params': list(params.values())}]))
        excluded = codeids | {id(p) for p in predictors + chooser + reading + generate}
        ops += [p for ps in shared.values() for p in ps if id(p) not in excluded]
        groups = dict(perception=[p for p in percept if id(p) not in codeids],
                      codes=codes, chooser=chooser, operators_and_tied_inverses=ops,
                      generate=generate, reading_map=reading,
                      expectation_predictor=predictors)
        used = {id(p) for g in groups.values() for p in g}
        groups['other'] = [p for _,p in named if id(p) not in used]
        groups = {g:list({id(p):p for p in ps}.values()) for g,ps in groups.items()}
        optimizer = getattr(model,'_sentence_optimizer',None)
        owned = {id(p) for pg in optimizer.param_groups for p in pg['params']} if optimizer else set()
        manifest = {g:[dict(name=names.get(id(p),'unregistered'), shape=list(p.shape),
                           requires_grad=p.requires_grad, optimizer_owned=id(p) in owned)
                       for p in ps] for g,ps in groups.items()}
        self.groups_manifest = manifest
        write('parameter-groups.json', manifest)
        write('codebook-ownership.json', [dict(stage=i,
            contextual_rotation_only=bool(getattr(cb,'contextual_rotation_only',False)),
            contextual_learning_rate=float(model.contextual_concept_learning_rate),
            parameters=[dict(name=n,shape=list(p.shape),requires_grad=p.requires_grad)
                        for n,p in cb.named_parameters()],
            buffers=[dict(name=n,shape=list(b.shape),requires_grad=b.requires_grad)
                     for n,b in cb.named_buffers()])
            for i,space in enumerate(model.conceptualSpaces)
            if isinstance((cb:=getattr(space,'similarity_codebook',None)),torch.nn.Module)])
        write('parameter-overlaps.json', {a+'__'+b: [names.get(id(p),'unregistered')
            for p in groups[a] if id(p) in {id(q) for q in groups[b]}]
            for a,b in itertools.combinations(groups,2)})
        return groups, names

    def gradient_report(self, model, objectives, *, scope, trial=None, active=None):
        if args.arm=='cut':
            return
        groups,names = self.groups(model)
        parameters = tuple(dict.fromkeys(p for group in groups.values() for p in group if p.requires_grad))
        versions = [(names.get(id(p),'unregistered'),p._version) for p in parameters]
        digest = hashlib.sha256(json.dumps(versions).encode()).hexdigest()
        rng_state=torch.random.get_rng_state()
        grad_buffers = tuple((id(p.grad), None if p.grad is None else p.grad._version) for p in parameters)
        pullback = getattr(model,'_sentence_pullback',None) if scope=='trial' else None
        gradients, costs, norms = {}, {}, {}
        for objective, cost in objectives.items():
            if torch.is_tensor(cost):
                if cost.ndim:
                    cost = ((cost * active.to(cost)).sum()/active.sum().clamp_min(1)
                            if active is not None else cost.mean())
                costs[objective] = float(cost.detach())
            else:
                costs[objective] = None
            if not torch.is_tensor(cost) or not cost.requires_grad:
                gs = (None,)*len(parameters)
            elif pullback is not None:
                gs = pullback.gradients(cost, parameters)
            else:
                gs = torch.autograd.grad(cost,parameters,retain_graph=True,allow_unused=True)
            gradients[objective] = {p:g.detach() for p,g in zip(parameters,gs) if g is not None}
            norms[objective] = {p:_norm(g) for p,g in gradients[objective].items()}
        report = {}
        per_parameter = {names.get(id(p), 'unregistered'): dict(
            norms={o:norms[o].get(p,0.) for o in objectives},
            unit_dots={a+'__'+b:_dot_unit(gradients[a].get(p),gradients[b].get(p),
                norms[a].get(p,0.),norms[b].get(p,0.))
                for a,b in itertools.combinations(objectives,2)}) for p in parameters}
        for group,ps in groups.items():
            totals = {o:math.hypot(*(norms[o].get(p,0) for p in ps)) for o in objectives}
            cosines = {}
            for a,b in itertools.combinations(objectives,2):
                na,nb=totals[a],totals[b]
                value = None
                if na and nb:
                    value=sum(_dot_unit(gradients[a].get(p),gradients[b].get(p),
                              norms[a].get(p,0),norms[b].get(p,0)) *
                              (norms[a].get(p,0)/na)*(norms[b].get(p,0)/nb) for p in ps)
                    value=max(-1.,min(1.,value))
                cosines[a+'__'+b]=value
            report[group]=dict(norms=totals,cosines=cosines,
                nonzero_parameters={o:[names.get(id(p),'unregistered') for p in ps if norms[o].get(p,0)>0] for o in objectives})
        rng_after=torch.random.get_rng_state()
        torch.random.set_rng_state(rng_state)
        assert versions == [(names.get(id(p),'unregistered'),p._version) for p in parameters]
        assert grad_buffers == tuple((id(p.grad),None if p.grad is None else p.grad._version) for p in parameters)
        entry=dict(scope=scope,trial=trial,pair=self.pair_number,batch=self.training_batches,
                   version_sha256=digest,versions=versions,costs=costs,groups=report,
                   per_parameter=per_parameter,
                   rng_unchanged=bool(torch.equal(rng_state,rng_after)))
        self.gradients.append(entry)
        write('gradients.json',self.gradients)
        self.log('gradient_snapshot', scope=scope,trial=trial,pair=self.pair_number,version_sha256=digest)

    def trial(self, model, local):
        active=local['active']
        B=int(active.numel())
        def rows(value):
            if value is None:
                return [None]*B
            value=value.detach()
            if value.ndim==0:
                value=value.expand(B)
            return value.cpu().tolist()
        rec=local['reconstruction'][2]
        answer=local['answer_error']
        evaluation_answer=None
        if self.in_batch and not model._sentence_training:
            # Evaluate the supplied-answer objective at the same final state,
            # without adding it to this evaluation's cost or taking a step.
            old_training=model._sentence_training
            old_target=model._sentence_supplied_answers
            old_cost=model._sentence_answer_cost
            try:
                model._sentence_training=True
                model._sentence_supplied_answers=self.current['outputTensor']
                evaluation_answer=Models.BasicModel._sentence_answer_error(model,local['state'],local['sid'],active,local['observation'])
            finally:
                model._sentence_training=old_training
                model._sentence_supplied_answers=old_target
                model._sentence_answer_cost=old_cost
        inter,contrast=local.get('inter'),local.get('contrast')
        rw=float(model.loss.reconstruction_scale)
        objectives=dict(reconstruction=local['reconstruction_cost'], expectation=local['expectation_cost'], supplied_answer=answer)
        row=dict(pair=self.pair_number,trial=model._sentence_trial,train=bool(model._sentence_training),
                 scope='batch' if self.in_batch else 'other_forward',
                 batch=self.training_batches,sid=int(local['sid']),active=active.cpu().tolist(),
                 raw=dict(reconstruction=rows(rec),expectation_inter=rows(inter),expectation_contrastive=rows(contrast),
                          supplied_answer=rows(answer),grammar_lesson=rows(local.get('lesson'))),
                 weighted={**{k:rows(v) for k,v in objectives.items()},'total':rows(local['cost'])},
                 evaluation_supplied_answer=rows(evaluation_answer),
                 grammar_terms={k:rows(v) for k,v in (local.get('objectives') or {}).items()},
                 weights=dict(reconstruction=rw, expectation_inter=float(model.inter_loss_weight),
                              expectation_contrastive=float(model.inter_contrastive_weight),
                              supplied_answer=1. if args.arm=='step5a' else 0.,
                              grammar_lesson=float(model.grammar_lesson_weight)),
                 reconstruction_enabled=bool(model._sentence_reconstruction))
        self.live_trial=(model,objectives,row,active,local['cost'])
        if model._sentence_training:
            self.pair_rows.append(row)
            self.last_trial[model._sentence_trial]=row
            if model._sentence_trial=='exploit':
                e=objectives['expectation']
                live_expectation=torch.is_tensor(e) and bool(e.detach().abs().any())
                self.capture_pair=(args.arm=='step5a' and (not self.captured_first or (live_expectation and not self.captured_expectation)))
                if live_expectation:
                    self.captured_expectation=True
                self.captured_first=True

    def after_score(self, result):
        model,objectives,row,active,base=self.live_trial
        self.live_trial=None
        if model._sentence_training and model.legacy_prediction_enabled:
            extra=result[0]-base
            objectives['expectation']=extra if objectives['expectation'] is None else objectives['expectation']+extra
            row['weighted']['expectation']=objectives['expectation'].detach().cpu().tolist()
            row['weighted']['legacy_intra']=extra.detach().cpu().tolist()
        row['weighted']['total']=result[0].detach().cpu().tolist()
        self.log('trial',**row)
        if model._sentence_training and self.capture_pair:
            self.gradient_report(model,objectives,scope='trial',trial=model._sentence_trial,active=active)
            if row.get('grammar_terms'):
                self.log('grammar_terms_present',pair=self.pair_number,trial=model._sentence_trial,
                         note='Grammar terms are separately costed; core R/E/A gradients do not absorb them.')

    def pair(self, saved_costs, wins, active):
        if len(self.pair_rows)!=2:
            return
        a,b=self.pair_rows
        assert a['trial']=='exploit' and b['trial']=='explore'
        if self.capture_pair:
            left,right=self.gradients[-2:]
            assert left['version_sha256']==right['version_sha256'], 'trials not measured at the same parameters'
        self.log('selection',pair=self.pair_number,active=active.cpu().tolist(),wins=wins.cpu().tolist(),
                 costs=saved_costs,exploit=a['weighted'],explore=b['weighted'])
        self.pair_rows=[]
        self.pair_number+=1

    def compute(self, loss, local):
        if self.model is None:
            return
        pred,target=local['pred'].detach(),local['target'].detach()
        nw,ne,nt=int(local['nWhat']),int(local['nWhere']),int(local['nWhen'])
        start=0
        parts={}
        for name,width,weight in [('what',nw,loss.what_scale),('where',ne,loss.where_scale),('when',nt,loss.when_scale)]:
            if width>0:
                raw=float((pred[...,start:start+width]-target[...,start:start+width]).square().mean())
                parts[name]=dict(raw=raw,weight=float(weight),weighted=raw*float(weight))
            start+=width
        caller=inspect.currentframe().f_back.f_back.f_code.co_name
        self.current_bands.append(dict(caller=caller,parts=parts,trial=getattr(self.model,'_sentence_trial',None)))

    def expectation_parts(self, layer, local):
        if not self.in_batch:
            return
        b=local['b']
        kind=None if local['sentence_kinds'] is None else local['sentence_kinds'][b]
        logit=local['kind_logit']
        with torch.no_grad():
            raw=dict(content_mse=float((local['pred'].detach()-local['target'].detach()).square().mean()),
                presence_bce=float(torch.nn.functional.binary_cross_entropy_with_logits(
                    local['logits'].detach(),local['occupied'].to(local['logits']))),
                kind_bce=float(layer._kind_loss(logit.detach() if torch.is_tensor(logit) else logit,
                                               kind,local['cost'].detach())))
        weight=float(self.model.inter_loss_weight)
        self.log('expectation_terms',train=bool(self.model._sentence_training),
            trial=self.model._sentence_trial,pair=self.pair_number,row=b,
            raw=raw,component_weights={key:1. for key in raw},outer_weight=weight,
            weighted={key:value*weight for key,value in raw.items()},
            accounting_residual=float(local['cost'].detach())-sum(raw.values()))

    def auxiliary(self, model, local):
        self.current_aux=[dict(name=n,raw=float(v.detach()),weight=float(w),category=c,
                               enabled=c not in local['pipeline_errors']._disabled)
                          for n,v,w,s,c in local['pipeline_errors'].terms()]

    def truth_return(self, local):
        self.truth={k:serial(v) if torch.is_tensor(v) else v for k,v in local.items()
                    if k in ('multiplier','luminosity_weight','universality_weight','truth_loss_weight',
                             'balance_weight','truth_penalty','balance')}

    def batch(self, model, local):
        rr=float(model.loss.reconstruction_scale)
        raw={}
        for key in ('lossOut','lossIn','lossRev','sbow','grammar_lesson','output_policy_loss','csbow','defsp',
                    'arma_loss','intra_loss','inter_loss','inter_contrastive','aux_total','expectation_policy_loss',
                    'selected_pol_loss','ld_loss','gate_l1','readout_l1','totalLoss'):
            value=local.get(key)
            if torch.is_tensor(value):
                raw[key]=float(value.detach())
            elif value is None:
                raw[key]=None
        weights=dict(lossOut=1-rr,lossIn=rr,lossRev=rr,sbow=float(model.loss.embedding_scale),
                     grammar_lesson=float(model.grammar_lesson_weight),output_policy_loss=float(model.output_policy_weight),
                     csbow=float(model.loss.conceptual_similarity_scale),defsp=1.,arma_loss=float(model.arma_scale),
                     intra_loss=float(model.conceptualSpace.intra_loss_weight),inter_loss=float(model.inter_loss_weight),
                     inter_contrastive=float(model.inter_contrastive_weight),aux_total=1.,
                     expectation_policy_loss=float(model.expectation_policy_weight),
                     selected_pol_loss=float(model.selected_thought_policy_weight),ld_loss=float(model.leaf_distill_weight),
                     gate_l1=1.,readout_l1=1.)
        contributions={k:v*weights[k] for k,v in raw.items() if v is not None and k in weights}
        after_truth=sum(contributions.pop(k,0.) for k in ('gate_l1','readout_l1'))
        multiplier=float(self.truth.get('multiplier',1.))
        accounted=sum(contributions.values())*multiplier+after_truth
        accounted+=float(self.truth.get('truth_penalty',0.))*float(self.truth.get('truth_loss_weight',0.))
        accounted+=float(self.truth.get('balance',0.))*float(self.truth.get('balance_weight',0.))
        self.log('batch',train=local['train'],split=local['split'],batch=self.training_batches,
                 raw=raw,weights=weights,weighted={k:v*weights[k] for k,v in raw.items() if v is not None and k in weights},
                 bands=self.current_bands,auxiliary=self.current_aux,truth=self.truth,
                 accounting_residual=raw['totalLoss']-accounted,
                 requires_grad={k:bool(local[k].requires_grad) for k in raw if torch.is_tensor(local.get(k))})
        self.last_batch=dict(raw=raw,weights=weights,train=local['train'],split=local['split'])
        if local['train']:
            if self.training_batches==0 and args.arm=='step5a':
                objectives=dict(reconstruction=local['gradient_objectives']['reconstruction'],
                    expectation=local['gradient_objectives']['expectation'],supplied_answer=multiplier*(1-rr)*local['lossOut'])
                self.gradient_report(model,objectives,scope='batch')
                # Other active objectives retain their own measured reach.
                # Gate/readout penalties already carry lambda in their value;
                # readout L1 is detached reporting for a proximal update.
                auxiliary_objectives={k: local[k]*weights[k]*(1. if k in ('gate_l1','readout_l1') else multiplier)
                    for k in weights if k not in ('lossOut','lossIn','lossRev','arma_loss','inter_loss','inter_contrastive','expectation_policy_loss')
                    and torch.is_tensor(local.get(k))}
                if auxiliary_objectives:
                    self.gradient_report(model,auxiliary_objectives,scope='batch_auxiliary')
            self.training_batches+=1
        else:
            self.evaluation_batches+=1
        self.metadata(model)
        self.in_batch = False

    def metadata(self,model):
        losskeys=('reconstruction_scale','embedding_scale','what_scale','where_scale','when_scale',
                  'conceptual_similarity_scale','definition_sparsity_scale')
        modelkeys=('inter_loss_weight','inter_contrastive_weight','inter_contrastive_temp','grammar_lesson_weight','arma_scale',
                   'output_policy_weight','expectation_policy_weight','selected_thought_policy_weight',
                   'leaf_distill_weight','gate_l1_lambda','luminosity_weight','universality_weight','truth_loss_weight',
                   'reconstruct_in_loop','detached_reverse','answer_synthesis','legacy_prediction_enabled',
                   'contextual_concept_learning_rate','contextual_situation_weight','contextual_expectation_weight')
        write('weights.json',dict(loss={k:getattr(model.loss,k,None) for k in losskeys},
              model={k:getattr(model,k,None) for k in modelkeys},
              intra_loss_weight=model.conceptualSpace.intra_loss_weight,
              concept_readout_l1=[getattr(cs.concepts_from_percepts,'l1_lambda',None) for cs in model.conceptualSpaces],
              byte_assignment_temperature=model._BYTE_ASSIGNMENT_TAU,
              trial_formulas=dict(reconstruction='reconstruction_scale * byte reconstruction, only when sentence reconstruction is enabled',
                  expectation='inter_loss_weight * next-sentence MSE + inter_contrastive_weight * InfoNCE; legacy intra is added only when enabled',
                  structured_expectation='Next-sentence cost = content MSE + presence BCE + kind BCE, each with internal weight 1; the external inter_loss_weight applies to their sum',
                  supplied_answer='1 * raw numeric MSE, or band-weighted event error for a supplied text answer; omitted in the cut arm',
                  grammar_lesson='grammar_lesson_weight * sum of enabled lesson objectives',
                  row_reduction='Each trial is averaged over active sentence rows before its optimizer step.'),
              batch_formulas=dict(primary='(1-reconstruction_scale)*lossOut + reconstruction_scale*lossIn + embedding_scale*sbow',
                  answer_numeric='lossOut uses what_scale for the bandless numeric output',
                  reconstruction=('Owned tied byte loss from the understanding' if model.reconstruct_in_loop else 'Full-percept D3 event loss'),
                  truth='Detached luminosity/universality multiplier on the assembled cost, plus independent truth/balance terms',
                  regularizers='Gate L1 follows truth modulation; readout L1 is a detached report of optimizer-owned proximal regularization'),
              configuration=args.config,training_batches=self.training_batches,evaluation_batches=self.evaluation_batches))


P=Probe()
patches=[]
def instrument(cls,name,old,new):
    function=getattr(cls,name)
    before=textwrap.dedent(inspect.getsource(function))
    assert old in before,(name,old)
    after=before.replace(old,new,1)
    namespace=dict(function.__globals__,_objective_probe=P)
    exec(compile(after,str(OUT/(name+'.instrumented.py')),'exec'),namespace)
    setattr(cls,name,namespace[name])
    (OUT/(name+'.instrumented.py')).write_text(after)
    patches.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),
                    fromfile=cls.__name__+'.'+name+'.original',tofile=cls.__name__+'.'+name+'.observed'))

instrument(Models.BasicModel,'_sentence_path_cost',
    '    return cost, reconstruction, observation, pending',
    '    _objective_probe.trial(self, locals())\n    return cost, reconstruction, observation, pending')
if args.arm=='cut':
    instrument(Models.BasicModel,'_sentence_path_cost',
        '    answer_error = BasicModel._sentence_answer_error(self, state, sid, active, observation)',
        '    answer_error = None  # Measurement arm: original cut; batch-end answer unchanged.')
instrument(Models.BasicModel,'_run_batch_once',
    '    self._sentence_answer_questions = what_questions',
    '    self._sentence_answer_questions = what_questions\n    _objective_probe.opened(self, locals())')
# Preserve the already instrumented source for a second insertion without inspect.
function=Models.BasicModel._run_batch_once
# inspect cannot read the unsaved generated path; save the exact full body, then add the next observation.
# The body is recovered from the same original source plus the first insertion.
original = (ROOT/'bin/Models.py').read_text()
import ast
module=ast.parse(original)
klass=next(n for n in module.body if isinstance(n,ast.ClassDef) and n.name=='BasicModel')
node=next(n for n in klass.body if isinstance(n,ast.FunctionDef) and n.name=='_run_batch_once')
batch_source=textwrap.dedent('\n'.join(original.splitlines()[node.lineno-1:node.end_lineno])+'\n')
batch_source=batch_source.replace('    self._sentence_answer_questions = what_questions','    self._sentence_answer_questions = what_questions\n    _objective_probe.opened(self, locals())',1)
(OUT/'_run_batch_once.instrumented.py').write_text(batch_source)
instrument(Models.BasicModel,'_run_batch_once',
    '            pipeline_errors.clear()',
    '            _objective_probe.auxiliary(self, locals())\n            pipeline_errors.clear()')
batch_source=batch_source.replace('            pipeline_errors.clear()',
    '            _objective_probe.auxiliary(self, locals())\n            pipeline_errors.clear()',1)
(OUT/'_run_batch_once.instrumented.py').write_text(batch_source)
instrument(Models.BasicModel,'_run_batch_once',
    '        # Snapshot the breakdown before the backward pass',
    '        _objective_probe.batch(self, locals())\n        # Snapshot the breakdown before the backward pass')
instrument(Layers.ModelLoss,'compute','    return loss',
    '    if not torch.compiler.is_compiling():\n        _objective_probe.compute(self, locals())\n    return loss')
prediction_source=textwrap.dedent(inspect.getsource(Layers.InterSentenceLayer.sentence_prediction_cost))
kind_line=next(line for line in prediction_source.splitlines() if 'cost = cost + self._kind_loss' in line)
kind_indent=kind_line[:len(kind_line)-len(kind_line.lstrip())]
kind_tail='None if sentence_kinds is None else sentence_kinds[b], cost)'
instrument(Layers.InterSentenceLayer,'sentence_prediction_cost',kind_tail,
    kind_tail+'\n'+kind_indent+'_objective_probe.expectation_parts(self, locals())')
import Language
instrument(Language.SymbolSubSpace,'truth_modulated_loss','        return total_loss\n',
    '        _objective_probe.truth_return(locals())\n        return total_loss\n')
instrument(Language.SymbolSubSpace,'truth_modulated_loss','\n    return total_loss\n',
    '\n    _objective_probe.truth_return(locals())\n    return total_loss\n')
if args.config == 'BasicModel_answers_tied_benchmark':
    # Keep the production endpoint pass and its predictions. Its optional
    # console rendering scans the concept bank for every padded position;
    # that rendering is not an objective measurement or an optimizer step.
    instrument(Models.BaseModel, '_reconstructionReport',
        '    if not isinstance(allIn, torch.Tensor) or allIn.numel() == 0:',
        '    if isinstance(allOut, torch.Tensor):\n'
        '        data.reconstructed_output = [x.detach().cpu() for x in allOut]\n'
        '    _objective_probe.log("endpoint_predictions_saved", split=split, rows=n_rows, console_rendering=False)\n'
        '    return\n\n'
        '    if not isinstance(allIn, torch.Tensor) or allIn.numel() == 0:')
(OUT/'instrumentation.patch').write_text(''.join(patches))
original_pair=SentenceCompose.sentence_pair
def paired(cache,compose,score,step,*,active,training=True):
    def observed_score(*args):
        result=score(*args)
        P.after_score(result)
        return result
    value=original_pair(cache,compose,observed_score,step,active=active,training=training)
    if training:
        P.pair(value[1],value[2],active)
    return value
SentenceCompose.sentence_pair=paired
original_commit=Models.BasicModel._commit_sentence
def committed(model,state,sid,active,*rest):
    if P.in_batch and not model._sentence_training and args.config=='XOR_grammar':
        with torch.no_grad():
            texts,unavailable=model.reconstruct_grammar_sentence(state,sid,active)
        P.eval_reconstructions.append(dict(texts=texts,unavailable=unavailable.cpu().tolist()))
    return original_commit(model,state,sid,active,*rest)
Models.BasicModel._commit_sentence=committed
if args.validate_only:
    write('validated.json',dict(instrumentation_installed=True,model_constructed=False))
    raise SystemExit(0)
config=Path(args.config_xml).resolve() if args.config_xml else ROOT/'data'/(args.config+'.xml')
util.init_config(path=str(config),defaults_path=str(ROOT/'data/model.xml'))
cfg=util.TheXMLConfig.data
arch=cfg.get('architecture',{})
write('plan.json',dict(config=str(config),effective=cfg,seed_applied=None,
    retained_dataset_seed=arch.get('data',{}).get('mathSeed'),
    note='No manual seed. Call existing hydrated factory body after parsing; the XML training seed is not applied.',
    device='cpu',compile=os.environ['MODEL_COMPILE'],runs=1,arm=args.arm,
    comparison='One fresh unseeded model per training arm; not paired initializations; no additional repeats.'))
try:
    results=Models.ModelFactory._run_hydrated(str(config),arch,arch.get('data',{}),arch.get('training',{}))
    model=results[0][2]
    # Native runTrial deliberately omits test passes without BASIC_RUN_TEST.
    # Observe one final pass after training, without changing any optimizer,
    # batch, configuration or training initialization. XOR already evaluates.
    endpoint_added = P.evaluation_batches == 0
    if endpoint_added:
        model.set_sigma(0)
        with torch.no_grad():
            model.runEpoch(batchSize=int(arch['training']['batchSize']), split='test')
        model.set_sigma(0.5)
    data=model.inputSpace.data
    P.groups(model)
    write('outcome.json',dict(training_batches=P.training_batches,evaluation_batches=P.evaluation_batches,
        receipt_added_endpoint=endpoint_added,
        last_training_trials=P.last_trial,last_batch=P.last_batch,grammar_reconstructions=P.eval_reconstructions,
        predictions=[serial(x) for x in data.reconstructed_output],targets=[serial(x) for x in data.test_output],
        inputs=[model._bytes_to_text(x).rstrip(chr(0)) for x in data.test_input],seconds=time.monotonic()-P.start))
    assert SOURCE==source_snapshot(ROOT)
    write('complete.json',dict(source_matched=True,seconds=time.monotonic()-P.start))
except BaseException as exc:
    write('error.json',dict(type=type(exc).__name__,message=str(exc),seconds=time.monotonic()-P.start))
    raise
