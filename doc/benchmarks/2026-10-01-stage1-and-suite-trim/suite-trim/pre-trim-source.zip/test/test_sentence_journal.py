"""Numerical compose records live for one open sentence, at global trace addresses."""
from types import SimpleNamespace

import torch

from Models import BasicModel


def test_packed_journal_reuses_one_sentence_without_colliding_with_its_closing():
    active = torch.tensor([[True] * 6 + [False] * 250,
                           [True] * 5 + [False] * 251])
    ids = torch.tensor([[0, 0, 1, 1, 1, 1] + [-1] * 250,
                        [0, 0, 0, 1, 1] + [-1] * 251])
    columns, width = BasicModel._sentence_journal_layout(active, ids, 16, 4864)
    assert width == 3 * 4 + 16
    assert columns[0, :18].tolist() == [0, 1, 2, 3, 4, 5, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
    assert columns[1, :15].tolist() == [0, 1, 2, 3, 4, 5, 6, 7, 8, 0, 1, 2, 3, 4, 5]
    # Intermediate and final global endings share the closing's local window.
    assert columns[:, 768:784].tolist() == [list(range(12, 28))] * 2
    assert columns[:, 800:816].tolist() == [list(range(12, 28))] * 2


def test_program_reads_compact_journal_by_global_address_and_keeps_value_gradients():
    active = torch.ones(1, 4, dtype=torch.bool)
    ids = torch.tensor([[0, 0, 1, 1]])
    columns, width = BasicModel._sentence_journal_layout(active, ids, 4, 28)
    frames = torch.arange(width * 12, dtype=torch.float32).reshape(1, width, 12).requires_grad_()
    refs = torch.arange(width * 2).reshape(1, width, 2)
    relations = refs.remainder(2).bool()
    trace = SimpleNamespace(_choice_values=frames, _choice_refs=refs,
        _choice_ref_relations=relations, _choice_journal_columns=columns)
    model = SimpleNamespace(_reconstruction_stack=lambda: trace,
        inputSpace=SimpleNamespace(), symbolSpace=SimpleNamespace())
    program = (torch.tensor([[2, 3]]),
        torch.tensor([[[0, -1, 0], [0, -1, 1], [1, 0, -1]]]),
        torch.tensor([[0, 1, 1]]), torch.tensor([[-1, -1, 12]]))
    entry, = BasicModel._program_entries(model, program, torch.zeros(1, 4, 4),
        torch.arange(4)[None], torch.arange(4)[None], torch.ones(1, 4), torch.zeros(1, 3, 4))
    torch.testing.assert_close(entry.operation_values[-1], frames[0, 6].reshape(3, 4), rtol=0, atol=0)
    assert entry.operation_refs[-1].tolist() == refs[0, 6].tolist()
    assert entry.operation_relations[-1].tolist() == relations[0, 6].tolist()
    # Numerical readings of a concluded field must retain this route. There
    # is no new detach at either the compact bank or program boundary.
    entry.operation_values[-1].sum().backward()
    expected = torch.zeros_like(frames)
    expected[0, 6] = 1
    torch.testing.assert_close(frames.grad, expected, rtol=0, atol=0)


def test_inactive_columns_neither_split_a_sentence_nor_alias_its_active_words():
    active = torch.tensor([[True, False, True, True]])
    ids = torch.tensor([[0, -1, 0, 1]])
    columns, width = BasicModel._sentence_journal_layout(active, ids, 4, 28)
    assert width == 3 * 2 + 4
    assert columns[0, :3].tolist() == [0, 1, 2]
    assert columns[0, 6:9].tolist() == [3, 4, 5]
    assert columns[0, 9:12].tolist() == [0, 1, 2]
