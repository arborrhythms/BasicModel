import sys
sys.path[:0]=['bin','../bin']
import torch
from Models import ModelFactory, BasicModel
from Models import TheReport
TheReport.enabled=False
original=BasicModel.reverseReconstruct
calls=0
def trace(self,u,**kw):
 global calls
 result=original(self,u,**kw)
 if calls in (0,1,10,32,64,128):
  target=kw.get('target')
  target=target.materialize() if hasattr(target,'materialize') else target
  print('INVERSE',calls, 'train',kw.get('train'),'cost',result[1], 'target',target.shape,target.detach().flatten()[:40].tolist(), 'output',result[0].shape,result[0].detach().flatten()[:35].tolist(),flush=True)
 calls+=1
 return result
BasicModel.reverseReconstruct=trace
results=ModelFactory.run('data/XOR_exact.xml')
for _,_,m in results:
 cs=m.conceptualSpaces[0]
 st=cs._concept_allocator.layer(0)
 print('FEATURES',list(zip(st.features._index,st.features.values.detach().tolist())))
 print('MEMBERS',m.wholeSpaces[0].subspace.what.primitive_properties.members.detach()[:,[0,48,49,65]])
 print('EDGES',list(zip(st._index,st.values.detach().tolist())))
 print('WEIGHT MAX',cs.similarity_codebook.getW().detach().abs().max())
