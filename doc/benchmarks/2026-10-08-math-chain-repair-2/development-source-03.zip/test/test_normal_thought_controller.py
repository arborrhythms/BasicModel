"""Selected grammatical questions execute through ordinary thought history.

These are reviewer probes for the normal boundary controller, not the legacy
``LTMSlot`` parity loop.  They exercise a real checked VP registry, the one
existing interaction-memory owner, and its shared work/cutoff accounting.
"""

from dataclasses import replace
from types import MappingProxyType, SimpleNamespace

import pytest
import torch

from Language import Grammar, OperationSelectionLayer
from Layers import MeaningExpectation, WhatInteractionMemory
from Meaning import ConceptualMeaning
from Models import BasicModel
from Queries import GrammaticalThoughtRegistry, ThoughtResult
from test_cs_symbol_table import _cs
from reading_fixtures import sentence_state
from Understanding import Understanding
from What import WhatQuestion


def _world():
    return _catalog_world()


def _catalog_world():
    """A normal-controller fixture with only the grammar-owned registry."""
    cs = _cs()
    grammar = Grammar()
    grammar.load_from_grammar_file("complete.grammar")
    registry = GrammaticalThoughtRegistry.install(cs, grammar)
    base = cs.new_concept()
    part, whole = ("sym", cs.synthesize_higher_order([("sym", base)])), ("sym", cs.new_concept())
    cs._csw_concept_row(0, part[1])
    cs._csw_concept_row(0, whole[1])
    cs.add_whole(part[1], whole)
    memory = WhatInteractionMemory(batch=1, capacity=64, detach_mode="episode")
    model = BasicModel()
    model.spaces = []
    model.shared_grammar = OperationSelectionLayer(d_model=cs.outputShape[-1], chooser='mlp')
    object.__setattr__(model, 'languageSpace', SimpleNamespace(
        language_layer=SimpleNamespace(operation_layer=model.shared_grammar)))
    model.attention_budget = 64

    object.__setattr__(model, "conceptualSpace", cs)
    object.__setattr__(model, "symbolSpace", SimpleNamespace(
        what_memory=memory, grammatical_thoughts=registry))
    object.__setattr__(model, "grammatical_thoughts", registry)
    model.what_thinking_detach = "episode"
    model.symbolSpace.languageLayer = SimpleNamespace(operation_layer=model.shared_grammar)
    with torch.no_grad():
        model.shared_grammar.chooser.mlp[-1].weight.zero_()
        model.shared_grammar.chooser.mlp[-1].bias.zero_()
    model.eval()
    return model, registry, memory, part, whole


def _with_what_wrapper(language, entry):
    """Mark a completed structural program interrogative through grammar."""
    local = next(
        index for index, rule in enumerate(language._compose_unary_rules)
        if rule.method_name == "ask")
    return replace(entry, actions=torch.cat((entry.actions, torch.tensor(
        [[2, local, -1]], dtype=entry.actions.dtype))))


def test_normal_controller_selects_a_catalog_operation_not_used_by_the_parse(monkeypatch):
    """An unparsed action enters the stream but cannot close an unrelated goal."""
    model, registry, memory, part, whole = _catalog_world()
    question = registry.form('part', part, whole)
    choices = []
    def choose(_root, _active, actions, **_kwargs):
        choices.append(actions)
        if len(choices) == 1:
            return next(a for a in actions if a is not None and a.semantic_id == 'equal')
        assert None not in actions
        return None
    monkeypatch.setattr(model, '_choose_selected_thought_action', choose)
    with model._query_boundary_scope((0,)), pytest.raises(ValueError, match='conclude'):
        model.run_selected_thought(question, work_budget=16)
    executed = [r.result for r in memory.thought_history() if r.result is not None]
    assert executed[0].semantic_id == 'equal'
    assert 'equal' in [a.semantic_id for a in choices[0]]
    assert 0. <= executed[0].support_true <= 1.
    memory.end_what_episode()


def test_catalog_refinement_preserves_selected_polarity_and_semantic_metadata(monkeypatch):
    """A later grammar candidate keeps negation, bindings and scope."""
    model, registry, memory, part, whole = _catalog_world()
    question = registry.form('part', part, whole, polarity=False,
        bindings={'variable': 'whole'}, scope={'place': 'workshop'})
    actions = registry.controller_candidates(question, question, question)
    selected = next(a for a in actions if a.semantic_id == 'equal')
    assert selected.request.polarity is False
    assert selected.request.bindings == question.bindings
    assert selected.request.scope == question.scope
    from QueryWork import QueryWorkBudget
    with model._query_boundary_scope((0,)):
        context = model._thought_grammar_context(selected.request, row=0,
            work=QueryWorkBudget(16), continuation=None)
        result = registry.execute(selected.request, context)
    assert result.semantic_id == 'equal' and result.request.polarity is False
    assert result.request.scope == question.scope


def test_selected_boundary_query_records_one_episode_and_its_actual_work():
    model, registry, memory, part, whole = _world()
    question = registry.form("isPart", part, whole)

    with model._query_boundary_scope((0,)):
        result = model.run_selected_thought(question, row=0, work_budget=16)

    assert result.evidence["support_true"] == 1
    assert result.meaning.role_refs == question.role_refs
    assert not __import__("ThoughtReferences").open_slots(result.meaning)
    assert result.work.spent == memory.thought_state().work_spent
    assert result.work.spent <= 16
    records = memory.thought_history()
    ordinary = [record for record in records if record.kind != "cutoff"]
    assert [record.kind for record in ordinary] == [
        "begin", "thought", "thought", "finish"]
    assert [record.operation for record in ordinary[1:3]] == ["isPart", "conclude"]
    assert ordinary[1].meaning.role_refs == question.role_refs
    assert ordinary[-1].support_true == 1
    assert memory.thought_state().finished
    memory.end_what_episode()


def test_selected_history_retains_the_typed_checked_result_through_restore():
    """The one history owner keeps the actual checked result, not a summary."""
    model, registry, memory, part, whole = _world()
    question = registry.form("isPart", part, whole)

    with model._query_boundary_scope((0,)):
        selected = model.run_selected_thought(question, row=0, work_budget=16)

    executed = next(
        record for record in selected.records
        if record.kind == "thought" and record.operation == "isPart")
    stored = executed.result
    assert stored is not None
    assert stored.semantic_id == selected.result.semantic_id == "isPart"
    assert stored.result_kind == selected.result.result_kind == "concept"
    assert stored.request is not selected.result.request
    assert not stored.request.roles.requires_grad
    assert stored.evidence["support_true"] == selected.evidence["support_true"]

    # Teardown and checkpoint/replay must retain the typed boundary record
    # without restoring a live reader or a second result store.
    memory.end_what_episode()
    restored = WhatInteractionMemory(batch=1, capacity=64, detach_mode="episode")
    restored.load_thought_extras(memory.thought_extras())
    replayed = next(
        record for record in restored.thought_history()
        if record.kind == "thought" and record.operation == "isPart")
    assert replayed.result is not None
    assert replayed.result.semantic_id == "isPart"
    assert replayed.result.result_kind == "concept"
    assert not replayed.result.request.roles.requires_grad


def test_typed_prediction_result_is_detached_before_history_or_checkpoint():
    """Prediction evidence stays a hard boundary inside ordinary history."""
    memory = WhatInteractionMemory(batch=1, capacity=16, detach_mode="episode")
    request = ConceptualMeaning(
        torch.ones(3, 8), torch.ones(3, dtype=torch.bool),
        mode="interrogative")
    roles = torch.randn(3, 8, requires_grad=True)
    logits = torch.randn(3, requires_grad=True)
    checked = ThoughtResult(
        semantic_id="arma", domain="discourse-prediction",
        result_kind="prediction", evidence_kind="estimate",
        request=request, evidence=MappingProxyType({
            "value": MeaningExpectation(roles, logits),
            "incomplete": (),
        }))

    memory.begin_thought_episode(request, work_budget=4)
    record = memory.commit_thought(
        request, operation="arma", result=checked,
        evidence_kind="estimate")
    memory.finish_thought(
        request, result=checked, evidence_kind="estimate")
    stored = record.result.value
    assert isinstance(stored, MeaningExpectation)
    assert not stored.roles.requires_grad
    assert not stored.presence_logits.requires_grad
    with torch.no_grad():
        roles.add_(100.0)
        logits.add_(100.0)
    assert not torch.equal(stored.roles, roles)
    assert not torch.equal(stored.presence_logits, logits)

    memory.end_what_episode()
    restored = WhatInteractionMemory(batch=1, capacity=16, detach_mode="episode")
    restored.load_thought_extras(memory.thought_extras())
    replayed = next(
        item for item in restored.thought_history()
        if item.kind == "thought" and item.operation == "arma")
    assert isinstance(replayed.result.value, MeaningExpectation)
    assert not replayed.result.value.roles.requires_grad
    assert not replayed.result.value.presence_logits.requires_grad


def test_what_subgoal_descends_executes_returns_and_causally_carries_evidence():
    model, registry, memory, part, whole = _world()
    from QueryWork import QueryWorkBudget

    inner = registry.form("isPart", part, whole)
    prior = memory.begin_thought_episode(inner, work_budget=2)
    memory.finish_thought(inner, support_true=0.0, evidence_kind="subgoal")
    memory.end_what_episode()
    with model._query_boundary_scope((0,)):
        outer = registry.form(
            "ask", memory.thought_reference(memory.thought_history()[0]),
            context=model._thought_grammar_context(
                inner, row=0, work=QueryWorkBudget(8), continuation=None),
        )
        result = model.run_selected_thought(outer, row=0, work_budget=64)

    state = memory.thought_state()
    assert state.finished and state.level == 0
    assert result.evidence["support_true"] == 1
    assert result.work.spent == state.work_spent
    records = memory.thought_history()
    latest = records[-8:]
    assert [record.kind for record in latest] == [
        "begin", "thought", "descend", "thought", "thought", "return", "thought", "finish",
    ]
    assert latest[1].meaning.role_refs == outer.role_refs
    assert latest[3].meaning.role_refs == inner.role_refs
    assert latest[5].support_true == 1
    assert any(ref[0] == "thought" for ref in latest[5].sources)
    assert [record.operation for record in latest if record.kind == "thought"] == [
        "ask", "isPart", "conclude", "conclude"]
    memory.end_what_episode()


def test_selected_controller_requires_the_completed_boundary_before_any_read():
    model, registry, _memory, part, whole = _world()
    question = registry.form("part", part, whole)
    try:
        model.run_selected_thought(question, row=0, work_budget=8)
    except RuntimeError as error:
        assert "boundary" in str(error)
    else:
        raise AssertionError("selected controller escaped the boundary guard")


def test_completed_compose_program_enters_normal_controller_before_legacy_thinking(
        monkeypatch):
    from test_selected_relation_meaning import _program_owner

    cs, grammar, _legacy_registry, language, _leaves, program, _part, _whole = (
        _program_owner(monkeypatch, interrogative=True))
    registry = GrammaticalThoughtRegistry.install(cs, grammar)
    model = BasicModel()
    model.spaces = []
    model.shared_grammar = OperationSelectionLayer(d_model=cs.outputShape[-1], chooser='mlp')
    object.__setattr__(model, 'languageSpace', SimpleNamespace(
        language_layer=SimpleNamespace(operation_layer=model.shared_grammar)))
    model.attention_budget = 64

    memory = WhatInteractionMemory(batch=1, capacity=32, detach_mode="episode")
    object.__setattr__(model, "conceptualSpace", cs)
    object.__setattr__(model, "languageSpace", language)
    object.__setattr__(model, "symbolSpace", SimpleNamespace(
        languageSpace=language, what_memory=memory,
        grammatical_thoughts=registry))
    object.__setattr__(model, "grammatical_thoughts", registry)
    model.what_thinking_detach = "episode"
    model.symbolSpace.languageLayer = SimpleNamespace(operation_layer=model.shared_grammar)
    with torch.no_grad():
        model.shared_grammar.chooser.mlp[-1].weight.zero_()
        model.shared_grammar.chooser.mlp[-1].bias.zero_()
    model.eval()

    with model._query_boundary_scope((0,)):
        selected = model._run_selected_sentence_thoughts(
            (sentence_state(language, program(), registry),), work_budget=16)

    assert len(selected) == 1
    row, result = selected[0]
    assert row == 0
    from ThoughtReferences import open_slots
    operations = [r.operation for r in result.records if r.kind == 'thought']
    assert operations[0] == 'part'
    if open_slots(result.meaning):
        assert result.work.remaining == 0 and 'conclude' not in operations
    else:
        assert operations[-1] == 'conclude'
        assert max(result.evidence['support_true'], result.evidence['support_false']) > 0
    assert memory.thought_state().finished
    memory.end_what_episode()


def test_completed_unary_concept_program_enters_the_normal_controller(
        monkeypatch):
    """A grammar-selected unary concept tool reaches its typed executor.

    The normal bridge must not assume every selected program is a binary
    truth relation.  A completed exist request owns its live signed
    leaf and grammar-native VP, enters the same ordinary episode, and retains
    the checked ``concept`` result without coercing that result into a truth or
    answer seed.
    """
    from Understanding import AnswerProgram
    from test_selected_relation_meaning import _program_owner

    cs, grammar, _legacy_registry, language, leaves, _program, _part, _whole = (
        _program_owner(monkeypatch))
    registry = GrammaticalThoughtRegistry.install(cs, grammar)
    model = BasicModel()
    model.spaces = []
    model.shared_grammar = OperationSelectionLayer(d_model=cs.outputShape[-1], chooser='mlp')
    object.__setattr__(model, 'languageSpace', SimpleNamespace(
        language_layer=SimpleNamespace(operation_layer=model.shared_grammar)))
    model.attention_budget = 64

    memory = WhatInteractionMemory(batch=1, capacity=32, detach_mode="episode")
    object.__setattr__(model, "conceptualSpace", cs)
    object.__setattr__(model, "languageSpace", language)
    object.__setattr__(model, "symbolSpace", SimpleNamespace(
        languageSpace=language, what_memory=memory,
        grammatical_thoughts=registry))
    object.__setattr__(model, "grammatical_thoughts", registry)
    model.what_thinking_detach = "episode"
    model.symbolSpace.languageLayer = SimpleNamespace(operation_layer=model.shared_grammar)
    with torch.no_grad():
        model.shared_grammar.chooser.mlp[-1].weight.zero_()
        model.shared_grammar.chooser.mlp[-1].bias.zero_()
    model.eval()
    # Exist is thought-only. The completed field carries its selected
    # request directly, without an identity compose wrapper or parse replay.
    from Understanding import SentenceEndState
    entry = SentenceEndState(ConceptualMeaning.from_description(leaves[0]),
                             query=registry.form('exist', leaves[0]))

    with model._query_boundary_scope((0,)):
        # The ordinary chooser also pays for its context reads. Give this
        # executor mechanism the normal budget through its conclusion.
        selected = model._run_selected_sentence_thoughts((entry,), work_budget=32)

    assert len(selected) == 1
    row, result = selected[0]
    assert row == 0 and result.meaning.mode == "assertive"
    assert result.result is not None
    assert result.result.semantic_id == "exist"
    assert result.result.result_kind == "concept"
    assert [record.operation for record in result.records if record.kind == "thought"] == [
        "exist", "conclude"]
    memory.end_what_episode()


def test_normal_controller_policy_sees_all_mandatory_roles_and_gets_credit():
    from ThoughtCredit import surrogate
    model, registry, memory, part, whole = _world()
    question = registry.form('equal', part, whole)
    chooser = model._selected_thought_chooser(question)
    with torch.no_grad():
        for parameter in chooser.parameters():
            parameter.fill_(.01)
    first = chooser.thought_logits(question, (question, question))
    for role in range(3):
        roles = question.roles.clone()
        roles[role].add_(.5)
        changed = replace(question, roles=roles)
        assert not torch.equal(first, chooser.thought_logits(question, (question, changed)))
        assert not torch.equal(first, chooser.thought_logits(changed, (question, question)))
    unary = registry.form('isPart', whole, open_roles=('I1',))
    padding = unary.roles.clone()
    padding[0].fill_(99.)
    torch.testing.assert_close(chooser.thought_logits(unary, (unary,)),
        chooser.thought_logits(unary, (replace(unary, roles=padding),)))
    probability = chooser.thought_logits(question, (question, changed)).softmax(-1)[0]
    loss = surrogate(dict(eligible=[True]), dict(choices=[dict(
        probability=probability[1], alternatives=1)]), 0, (1., .25))
    loss.backward()
    assert any(p.grad is not None and bool(p.grad.abs().sum()) for p in chooser.parameters())
    with pytest.raises(ValueError, match='retired'):
        model._selected_thought_policy_loss(torch.tensor(.25))


def test_normal_controller_checkpoint_rebuilds_its_width_owned_policy():
    """The ordinary grammar restores; retired policy weights are discarded."""
    source, registry, _memory, part, whole = _world()
    chooser = source._selected_thought_chooser(registry.form('part', part, whole))
    with torch.no_grad():
        chooser.chooser.mlp[-1].weight.fill_(.125)
    state = {key: value.detach().clone() for key, value in source.state_dict().items()}
    retired = 'selected_thought_choosers.8.mlp.0.weight'
    state[retired] = torch.ones(2, 2)
    restored, registry2, _memory2, p2, w2 = _world()
    restored._materialize_answer_path_from_checkpoint(state)
    assert retired not in state and retired in restored._pending_thought_policy_reset
    restored.load_state_dict(state, strict=True)
    loaded = restored._selected_thought_chooser(registry2.form('part', p2, w2))
    assert not hasattr(restored, 'selected_thought_choosers')
    for before, after in zip(chooser.parameters(), loaded.parameters()):
        torch.testing.assert_close(before, after)


def test_selected_program_resolution_releases_completed_eval_episode(monkeypatch):
    from test_selected_relation_meaning import _program_owner

    cs, grammar, _legacy_registry, language, _leaves, program, _part, _whole = (
        _program_owner(monkeypatch, interrogative=True))
    registry = GrammaticalThoughtRegistry.install(cs, grammar)
    model = BasicModel()
    model.spaces = []
    model.shared_grammar = OperationSelectionLayer(d_model=cs.outputShape[-1], chooser='mlp')
    object.__setattr__(model, 'languageSpace', SimpleNamespace(
        language_layer=SimpleNamespace(operation_layer=model.shared_grammar)))
    model.attention_budget = 64

    memory = WhatInteractionMemory(batch=1, capacity=64, detach_mode="episode")
    object.__setattr__(model, "conceptualSpace", cs)
    object.__setattr__(model, "languageSpace", language)
    object.__setattr__(model, "symbolSpace", SimpleNamespace(
        languageSpace=language, what_memory=memory,
        grammatical_thoughts=registry))
    object.__setattr__(model, "grammatical_thoughts", registry)
    model.what_thinking_detach = "episode"
    model.symbolSpace.languageLayer = SimpleNamespace(operation_layer=model.shared_grammar)
    with torch.no_grad():
        model.shared_grammar.chooser.mlp[-1].weight.zero_()
        model.shared_grammar.chooser.mlp[-1].bias.zero_()
    model.eval()
    model.reconstruct_in_loop = False
    model.eval()
    # The semantic/controller seam is the subject of this probe.  Its answer
    # carrier is deliberately ordinary, rather than a second surface path.
    monkeypatch.setattr(model, "_walk_budget", lambda: 8)
    monkeypatch.setattr(
        model, "_what_grammar_context",
        lambda questions, **kwargs: (torch.zeros(
            len(questions), 1, device=kwargs["device"], dtype=kwargs["dtype"]), ()),
    )
    monkeypatch.setattr(model, "_select_perceptual_bindings", lambda _: ())
    understanding = Understanding(sentence_states=(
        sentence_state(language, program(), registry),))
    question = WhatQuestion.present(0)

    first = model.resolveAnswer(understanding, question)
    assert len(first.selected_thoughts) == 1
    assert memory.thought_state().finished and not memory.in_episode(0)
    # A later completed sentence may start a new ordinary episode; retaining
    # the finished eval graph would otherwise make this raise before selection.
    second = model.resolveAnswer(understanding, question)
    assert len(second.selected_thoughts) == 1
    episodes = [record.episode for record in memory.thought_history()
                if record.kind == "begin"]
    assert len(episodes) == 2 and episodes[0] != episodes[1]


def test_normal_boundary_uses_selected_semantic_meaning_as_its_answer_seed(monkeypatch):
    """A completed thought's full grammar, not its trace, feeds output."""
    from test_selected_relation_meaning import _program_owner

    cs, grammar, _legacy_registry, language, _leaves, program, _part, _whole = (
        _program_owner(monkeypatch, interrogative=True))
    registry = GrammaticalThoughtRegistry.install(cs, grammar)
    model = BasicModel()
    model.spaces = []
    model.shared_grammar = OperationSelectionLayer(d_model=cs.outputShape[-1], chooser='mlp')
    object.__setattr__(model, 'languageSpace', SimpleNamespace(
        language_layer=SimpleNamespace(operation_layer=model.shared_grammar)))
    model.attention_budget = 64

    memory = WhatInteractionMemory(batch=1, capacity=64, detach_mode="episode")
    object.__setattr__(model, "conceptualSpace", cs)
    object.__setattr__(model, "languageSpace", language)
    object.__setattr__(model, "symbolSpace", SimpleNamespace(
        languageSpace=language, what_memory=memory,
        grammatical_thoughts=registry))
    object.__setattr__(model, "grammatical_thoughts", registry)
    model.what_thinking_detach = "episode"
    model.symbolSpace.languageLayer = SimpleNamespace(operation_layer=model.shared_grammar)
    with torch.no_grad():
        model.shared_grammar.chooser.mlp[-1].weight.zero_()
        model.shared_grammar.chooser.mlp[-1].bias.zero_()
    model.eval()
    model.reconstruct_in_loop = False
    model.eval()
    monkeypatch.setattr(model, "_walk_budget", lambda: 8)
    monkeypatch.setattr(
        model, "_what_grammar_context",
        lambda questions, **kwargs: (torch.zeros(
            len(questions), 1, device=kwargs["device"], dtype=kwargs["dtype"]), ()),
    )
    monkeypatch.setattr(model, "_select_perceptual_bindings", lambda _: ())

    derivation = model.resolveAnswer(
        Understanding(sentence_states=(__import__("Understanding").SentenceEndState(
            ConceptualMeaning.from_description(_leaves[0]),
            query=registry.form("equal", _part, _part)),)), WhatQuestion.present(0))

    selected = derivation.selected_thoughts[0][1]
    torch.testing.assert_close(derivation.conceptual_answer[0], selected.meaning.roles)
    assert derivation.source == "thought-concept"


def test_normal_boundary_adapts_selected_prediction_result_as_its_answer_seed(
        monkeypatch):
    """A selected ``arma`` estimate is a typed answer seed, never a fact."""
    from test_selected_relation_meaning import _program_owner

    cs, grammar, _legacy_registry, language, _leaves, program, _part, _whole = (
        _program_owner(monkeypatch, interrogative=True))
    registry = GrammaticalThoughtRegistry.install(cs, grammar)
    model = BasicModel()
    model.spaces = []
    model.shared_grammar = OperationSelectionLayer(d_model=cs.outputShape[-1], chooser='mlp')
    object.__setattr__(model, 'languageSpace', SimpleNamespace(
        language_layer=SimpleNamespace(operation_layer=model.shared_grammar)))
    model.attention_budget = 64

    memory = WhatInteractionMemory(batch=1, capacity=64, detach_mode="episode")
    object.__setattr__(model, "conceptualSpace", cs)
    object.__setattr__(model, "languageSpace", language)
    object.__setattr__(model, "symbolSpace", SimpleNamespace(
        languageSpace=language, what_memory=memory,
        grammatical_thoughts=registry))
    object.__setattr__(model, "grammatical_thoughts", registry)
    model.what_thinking_detach = "episode"
    model.symbolSpace.languageLayer = SimpleNamespace(operation_layer=model.shared_grammar)
    with torch.no_grad():
        model.shared_grammar.chooser.mlp[-1].weight.zero_()
        model.shared_grammar.chooser.mlp[-1].bias.zero_()
    model.eval()
    model.reconstruct_in_loop = False
    model.eval()
    monkeypatch.setattr(model, "_walk_budget", lambda: 8)
    monkeypatch.setattr(
        model, "_what_grammar_context",
        lambda questions, **kwargs: (torch.zeros(
            len(questions), 1, device=kwargs["device"], dtype=kwargs["dtype"]), ()),
    )
    monkeypatch.setattr(model, "_select_perceptual_bindings", lambda _: ())

    width = int(cs.outputShape[-1])
    estimate_roles = torch.arange(
        3 * width, dtype=program().leaves.dtype).reshape(3, width)
    estimate_roles.requires_grad_()
    request = ConceptualMeaning(
        torch.zeros_like(estimate_roles), torch.tensor([True, True, True]),
        mode="interrogative")
    checked = ThoughtResult(
        semantic_id="arma", domain="discourse-prediction",
        result_kind="prediction", evidence_kind="estimate",
        request=request.detached(), evidence=MappingProxyType({
            "value": MeaningExpectation(
                estimate_roles, torch.tensor([1.0, -1.0, 1.0])),
            "incomplete": (),
        }))
    selected = SimpleNamespace(
        meaning=request,
        result=checked,
        evidence={"query_signature": "arma", "support_true": 0.0,
                  "support_false": 0.0, "incomplete": (),
                  "semantic_id": "arma", "result_kind": "prediction"},
        work=SimpleNamespace(spent=4))
    monkeypatch.setattr(
        model, "_run_selected_sentence_thoughts",
        lambda programs, *, work_budget: ((0, selected),),
    )

    derivation = model.resolveAnswer(
        Understanding(sentence_states=(sentence_state(language, program(), registry),)), WhatQuestion.present(0))

    torch.testing.assert_close(
        derivation.conceptual_answer[0], estimate_roles.detach())
    assert not derivation.conceptual_answer.requires_grad
    assert derivation.source == "thought-prediction"
    assert derivation.grammar_trace[1]["result_kind"] == "prediction"


def test_normal_boundary_realizes_the_controller_selected_operation(monkeypatch):
    """A later catalog choice changes the answer meaning, not only its trace."""
    from test_selected_relation_meaning import _program_owner

    cs, grammar, _legacy_registry, language, _leaves, program, _part, _whole = (
        _program_owner(monkeypatch, interrogative=True))
    registry = GrammaticalThoughtRegistry.install(cs, grammar)
    model = BasicModel()
    model.spaces = []
    model.shared_grammar = OperationSelectionLayer(d_model=cs.outputShape[-1], chooser='mlp')
    object.__setattr__(model, 'languageSpace', SimpleNamespace(
        language_layer=SimpleNamespace(operation_layer=model.shared_grammar)))
    model.attention_budget = 64

    memory = WhatInteractionMemory(batch=1, capacity=64, detach_mode="episode")
    object.__setattr__(model, "conceptualSpace", cs)
    object.__setattr__(model, "languageSpace", language)
    object.__setattr__(model, "symbolSpace", SimpleNamespace(
        languageSpace=language, what_memory=memory,
        grammatical_thoughts=registry))
    object.__setattr__(model, "grammatical_thoughts", registry)
    model.what_thinking_detach = "episode"
    model.symbolSpace.languageLayer = SimpleNamespace(operation_layer=model.shared_grammar)
    with torch.no_grad():
        model.shared_grammar.chooser.mlp[-1].weight.zero_()
        model.shared_grammar.chooser.mlp[-1].bias.zero_()
    model.eval()
    model.reconstruct_in_loop = False
    model.eval()
    monkeypatch.setattr(model, "_walk_budget", lambda: 8)
    monkeypatch.setattr(
        model, "_what_grammar_context",
        lambda questions, **kwargs: (torch.zeros(
            len(questions), 1, device=kwargs["device"], dtype=kwargs["dtype"]), ()),
    )
    monkeypatch.setattr(model, "_select_perceptual_bindings", lambda _: ())
    choices = []

    def choose(_root, _active, actions, **_kwargs):
        choices.append(actions)
        if len(choices) == 1:
            return next(action for action in actions
                        if action is not None and action.semantic_id == "equal")
        return None

    monkeypatch.setattr(model, "_choose_selected_thought_action", choose)
    derivation = model.resolveAnswer(
        Understanding(sentence_states=(__import__("Understanding").SentenceEndState(
            ConceptualMeaning.from_description(_leaves[0]),
            query=registry.form("equal", _part, _part)),)), WhatQuestion.present(0))

    selected = derivation.selected_thoughts[0][1]
    assert registry.signature_for(selected.meaning).operation.semantic_id == "equal"
    torch.testing.assert_close(derivation.conceptual_answer[0], selected.meaning.roles)
    assert derivation.grammar_trace[1]["semantic_id"] == "equal"


def test_selected_program_precedes_the_legacy_surface_reasoner(monkeypatch):
    """A grammar-owned completed question never opens the legacy tool path."""
    from test_selected_relation_meaning import _program_owner

    cs, grammar, _legacy_registry, language, _leaves, program, _part, _whole = (
        _program_owner(monkeypatch, interrogative=True))
    registry = GrammaticalThoughtRegistry.install(cs, grammar)
    model = BasicModel()
    model.spaces = []
    model.shared_grammar = OperationSelectionLayer(d_model=cs.outputShape[-1], chooser='mlp')
    object.__setattr__(model, 'languageSpace', SimpleNamespace(
        language_layer=SimpleNamespace(operation_layer=model.shared_grammar)))
    model.attention_budget = 64

    memory = WhatInteractionMemory(batch=1, capacity=64, detach_mode="episode")
    object.__setattr__(model, "conceptualSpace", cs)
    object.__setattr__(model, "languageSpace", language)
    object.__setattr__(model, "symbolSpace", SimpleNamespace(
        languageSpace=language, what_memory=memory,
        grammatical_thoughts=registry))
    object.__setattr__(model, "grammatical_thoughts", registry)
    model.what_thinking_detach = "episode"
    model.symbolSpace.languageLayer = SimpleNamespace(operation_layer=model.shared_grammar)
    with torch.no_grad():
        model.shared_grammar.chooser.mlp[-1].weight.zero_()
        model.shared_grammar.chooser.mlp[-1].bias.zero_()
    model.eval()
    model.reconstruct_in_loop = False
    model.reasoning_iterations = 1
    model.eval()
    monkeypatch.setattr(model, "_walk_budget", lambda: 8)
    monkeypatch.setattr(
        model, "_what_grammar_context",
        lambda questions, **kwargs: (torch.zeros(
            len(questions), 1, device=kwargs["device"], dtype=kwargs["dtype"]), ()),
    )
    monkeypatch.setattr(model, "_select_perceptual_bindings", lambda _: ())

    legacy_calls = []

    def legacy_reasoner(*args, **kwargs):
        legacy_calls.append((args, kwargs))
        return {"posture": "legacy", "confidence": 1.0,
                "support_true": 1.0, "support_false": 0.0}

    monkeypatch.setattr(model, "answer_query", legacy_reasoner)
    understanding = Understanding(sentence_states=(sentence_state(language, program(), registry),))
    question = WhatQuestion.inference(0, prompt="is the part in the whole?")

    result = model.resolveAnswer(understanding, question)

    assert len(result.selected_thoughts) == 1
    assert result.source == "thought-concept"
    assert not legacy_calls
    assert memory.thought_state().finished and not memory.in_episode(0)


def test_normal_boundary_never_falls_back_to_the_legacy_surface_reasoner(
        monkeypatch):
    """An unselected parse remains unresolved; raw text cannot choose a tool."""
    from test_selected_relation_meaning import _program_owner

    cs, grammar, _legacy_registry, language, _leaves, program, _part, _whole = (
        _program_owner(monkeypatch, interrogative=False))
    registry = GrammaticalThoughtRegistry.install(cs, grammar)
    model = BasicModel()
    model.spaces = []
    model.shared_grammar = OperationSelectionLayer(d_model=cs.outputShape[-1], chooser='mlp')
    object.__setattr__(model, 'languageSpace', SimpleNamespace(
        language_layer=SimpleNamespace(operation_layer=model.shared_grammar)))
    model.attention_budget = 64

    memory = WhatInteractionMemory(batch=1, capacity=64, detach_mode="episode")
    object.__setattr__(model, "conceptualSpace", cs)
    object.__setattr__(model, "languageSpace", language)
    object.__setattr__(model, "symbolSpace", SimpleNamespace(
        languageSpace=language, what_memory=memory,
        grammatical_thoughts=registry))
    object.__setattr__(model, "grammatical_thoughts", registry)
    model.what_thinking_detach = "episode"
    model.symbolSpace.languageLayer = SimpleNamespace(operation_layer=model.shared_grammar)
    with torch.no_grad():
        model.shared_grammar.chooser.mlp[-1].weight.zero_()
        model.shared_grammar.chooser.mlp[-1].bias.zero_()
    model.eval()
    model.reconstruct_in_loop = False
    model.reasoning_iterations = 1
    model.eval()
    monkeypatch.setattr(model, "_walk_budget", lambda: 8)
    monkeypatch.setattr(
        model, "_what_grammar_context",
        lambda questions, **kwargs: (torch.zeros(
            len(questions), 1, device=kwargs["device"], dtype=kwargs["dtype"]), ()),
    )
    monkeypatch.setattr(model, "_select_perceptual_bindings", lambda _: ())
    monkeypatch.setattr(
        model, "answer_query",
        lambda *_args, **_kwargs: pytest.fail(
            "normal resolution invoked the legacy surface reasoner"),
    )

    result = model.resolveAnswer(
        Understanding(sentence_states=(sentence_state(language, program(), registry),)),
        WhatQuestion.inference(0, prompt="is the part in the whole?"),
    )

    assert result.selected_thoughts == ()
    assert result.source == "identity"
    assert memory.thought_history() == []


def test_normal_what_uses_the_selected_thought_without_a_legacy_slot(monkeypatch):
    """One grammatical boundary must not append a second legacy interaction."""
    from test_selected_relation_meaning import _program_owner

    cs, grammar, _legacy_registry, language, _leaves, program, _part, _whole = (
        _program_owner(monkeypatch, interrogative=True))
    registry = GrammaticalThoughtRegistry.install(cs, grammar)
    model = BasicModel()
    model.spaces = []
    model.shared_grammar = OperationSelectionLayer(d_model=cs.outputShape[-1], chooser='mlp')
    object.__setattr__(model, 'languageSpace', SimpleNamespace(
        language_layer=SimpleNamespace(operation_layer=model.shared_grammar)))
    model.attention_budget = 64

    memory = WhatInteractionMemory(batch=1, capacity=64, detach_mode="episode")
    object.__setattr__(model, "conceptualSpace", cs)
    object.__setattr__(model, "languageSpace", language)
    object.__setattr__(model, "symbolSpace", SimpleNamespace(
        languageSpace=language, what_memory=memory,
        grammatical_thoughts=registry))
    object.__setattr__(model, "grammatical_thoughts", registry)
    model.what_thinking_detach = "episode"
    model.symbolSpace.languageLayer = SimpleNamespace(operation_layer=model.shared_grammar)
    with torch.no_grad():
        model.shared_grammar.chooser.mlp[-1].weight.zero_()
        model.shared_grammar.chooser.mlp[-1].bias.zero_()
    model.eval()
    model.reconstruct_in_loop = False
    model.answer_synthesis = True
    model.eval()
    monkeypatch.setattr(model, "_walk_budget", lambda: 8)
    monkeypatch.setattr(
        model, "_what_grammar_context",
        lambda questions, **kwargs: (torch.zeros(
            len(questions), 1, device=kwargs["device"], dtype=kwargs["dtype"]),
            ({},) * len(questions)),
    )
    monkeypatch.setattr(model, "_select_perceptual_bindings", lambda _: ())
    understanding = Understanding(sentence_states=(sentence_state(language, program(), registry),))
    produced = torch.zeros(1, 1, 3, dtype=program().leaves.dtype)
    execution = (None, produced, produced)
    monkeypatch.setattr(model, "_capture_understanding", lambda _: understanding)
    monkeypatch.setattr(
        model, "reverseOutput", lambda _understanding, _derivation:
        SimpleNamespace(actual=produced))

    answer = model.ask(WhatQuestion.inference(0), execution=execution)

    assert answer.available and answer.ltm_slot is None
    assert len(memory.get_what_slots()) == 0
    history = memory.thought_history()
    assert history[0].kind == 'begin' and history[-1].kind == 'finish'
    assert sum(record.kind == 'begin' for record in history) == 1
    assert any(record.kind == 'thought' for record in history)


def test_selected_row_cannot_open_a_second_controller_for_another_row(monkeypatch):
    """A selected boundary is row-local, including its legacy handoff."""
    from test_selected_relation_meaning import _program_owner

    cs, grammar, _legacy_registry, language, _leaves, program, _part, _whole = (
        _program_owner(monkeypatch, interrogative=True))
    registry = GrammaticalThoughtRegistry.install(cs, grammar)
    model = BasicModel()
    model.spaces = []
    model.shared_grammar = OperationSelectionLayer(d_model=cs.outputShape[-1], chooser='mlp')
    object.__setattr__(model, 'languageSpace', SimpleNamespace(
        language_layer=SimpleNamespace(operation_layer=model.shared_grammar)))
    model.attention_budget = 64

    memory = WhatInteractionMemory(batch=2, capacity=64, detach_mode="episode")
    object.__setattr__(model, "conceptualSpace", cs)
    object.__setattr__(model, "languageSpace", language)
    object.__setattr__(model, "symbolSpace", SimpleNamespace(
        languageSpace=language, what_memory=memory,
        grammatical_thoughts=registry))
    object.__setattr__(model, "grammatical_thoughts", registry)
    model.what_thinking_detach = "episode"
    model.symbolSpace.languageLayer = SimpleNamespace(operation_layer=model.shared_grammar)
    with torch.no_grad():
        model.shared_grammar.chooser.mlp[-1].weight.zero_()
        model.shared_grammar.chooser.mlp[-1].bias.zero_()
    model.eval()
    model.what_thinking_iterations = 2
    model.reconstruct_in_loop = False
    model.eval()
    monkeypatch.setattr(model, "_walk_budget", lambda: 8)
    monkeypatch.setattr(
        model, "_what_grammar_context",
        lambda questions, **kwargs: (torch.zeros(
            len(questions), 1, device=kwargs["device"], dtype=kwargs["dtype"]), ()),
    )
    monkeypatch.setattr(model, "_select_perceptual_bindings", lambda _: ())

    selected = SimpleNamespace(
        evidence={"query_signature": "part", "support_true": 1.0,
                  "support_false": 0.0, "incomplete": ()},
        work=SimpleNamespace(spent=3))
    monkeypatch.setattr(
        model, "_run_selected_sentence_thoughts",
        lambda programs, *, work_budget: ((0, selected),),
    )
    calls = []

    def legacy_resolve(_understanding, _questions, _per_row, answer, *,
                       programs=None, excluded_rows=()):
        calls.append((tuple(programs), tuple(excluded_rows)))
        adjusted = answer.clone()
        adjusted[1, 0].fill_(0.75)
        return adjusted, (None, "legacy-row"), (
            {"operation": "legacy-row", "row": 1},), ()

    monkeypatch.setattr(model, "_resolve_step", legacy_resolve, raising=False)
    first_program = sentence_state(language, program(), registry)
    derivation = model.resolveAnswer(
        Understanding(sentence_states=(first_program, None)), WhatQuestion.present(0))

    assert calls == []
    assert derivation.step == ()
    assert not derivation.conceptual_answer[1, 0].eq(0.75).all()
