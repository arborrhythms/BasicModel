import os,sys,torch,textwrap,inspect,json,random,warnings
from pathlib import Path
root=Path.cwd(); sys.path[:0]=[str(root/'bin'),str(root/'test')]
os.environ['BASICMODEL_DEVICE']='cpu'; os.environ['MODEL_COMPILE']='eager'
import Language,Models,numpy as np
from test_hierarchical import _make_model
from util import init_device
init_device('cpu'); torch.set_num_threads(1)
if '--corrected' in sys.argv:
 source=textwrap.dedent(inspect.getsource(Language.LanguageLayer.compose))
 assert source.count('x = b_soft')==1
 scope={}; exec(source.replace('x = b_soft','x = b_hard.detach() + (b_soft - b_soft.detach())'),Language.__dict__,scope)
 Language.LanguageLayer.compose=scope['compose']
router=Language.LanguageLayer(n_input=4,n_output=4,feature_dim=1,hidden_dim=8,max_depth=3)
router.attach_layer_ops(ops=[Language.ProductLayer(nInput=1,nOutput=1)],rule_ids=[0])
layer=next(iter(router._binary_layers.values()))
with torch.no_grad(): layer.copy_anchor.zero_(); layer.reduce_anchor.fill_(1)
x=torch.tensor([2.,3.,5.,7.]).reshape(1,4,1).requires_grad_()
from types import SimpleNamespace
router.compose(x,SimpleNamespace(wholeSpace=None))
print('PRODUCT',float(router._last_root_state.detach()),'expected',float(x.detach().prod()),flush=True)
router._last_root_state.sum().backward(); print('GRAD',x.grad.flatten().tolist(),flush=True)
for seed in range(8):
 torch.manual_seed(seed);random.seed(seed);np.random.seed(seed)
 m=_make_model('MentalModel.xml')
 try:
  with Models.TheData.runtime_batch(['hello world'],[torch.tensor([0.0])]),warnings.catch_warnings():
   warnings.simplefilter('ignore'); train,_=m.inputSpace.getTrainData(); x=m.inputSpace.prepInput(train[:1])
   with torch.no_grad(): result=m.forward(x)
  def summ(x):
   if torch.is_tensor(x): return dict(shape=list(x.shape),finite=bool(torch.isfinite(x).all()),max=float(x.abs().max()) if x.numel() else 0)
   if isinstance(x,(tuple,list)): return [summ(a) for a in x]
   return type(x).__name__
  print(json.dumps(dict(seed=seed,status='pass',outputs=summ(result))),flush=True)
 except Exception as exc: print(json.dumps(dict(seed=seed,status='fail',error=str(exc))),flush=True)
 finally: m.End();m.symbolSpace.soft_reset();torch._dynamo.reset()
