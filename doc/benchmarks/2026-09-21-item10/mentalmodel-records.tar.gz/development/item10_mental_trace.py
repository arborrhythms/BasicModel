import os,sys,json,random,warnings
from pathlib import Path
root=Path(sys.argv[1]); os.environ['BASICMODEL_DEVICE']='cpu'; os.environ['MODEL_COMPILE']='eager'
sys.path[:0]=[str(root/'bin'),str(root/'test')]
import torch,numpy as np,Language,Models
from test_hierarchical import _make_model
from util import init_device
init_device('cpu'); torch.set_num_threads(1)
seed=int(sys.argv[2]) if len(sys.argv)>2 else 3
torch.manual_seed(seed); random.seed(seed); np.random.seed(seed)
def size(x):
 if not torch.is_tensor(x): return None
 return dict(max=float(x.detach().abs().max()) if x.numel() else 0,finite=bool(torch.isfinite(x).all()),shape=list(x.shape),per_slot_max=x.detach().abs().amax(-1).tolist(),max_column=int(x.detach().abs().reshape(-1,x.shape[-1]).amax(0).argmax()))
original=Language.BinaryStructuredReductionLayer._stacked_reduced
n=0
def stack(self,x,*a,**kw):
 global n
 r=original(self,x,*a,**kw); n+=1
 print(json.dumps(dict(kind='binary',n=n,input=size(x),ops={str(name):size(r[:,:,i,:]) for i,name in enumerate(self.op_names or range(self.r_reduce))})),flush=True)
 return r
Language.BinaryStructuredReductionLayer._stacked_reduced=stack
m=_make_model('MentalModel.xml')
for name,mod in m.named_modules():
 if isinstance(mod,Language.GrammarLayer):
  def hook(mod,args,out,name=name):
   a=[size(x) for x in args if torch.is_tensor(x)]; out=size(out)
   if out and (not out['finite'] or out['max']>100): print(json.dumps(dict(kind='operator',name=name,type=type(mod).__name__,inputs=a,output=out)),flush=True)
  mod.register_forward_hook(hook)
try:
 with Models.TheData.runtime_batch(['hello world'],[torch.tensor([0.0])]),warnings.catch_warnings():
  warnings.simplefilter('ignore'); train,_=m.inputSpace.getTrainData(); x=m.inputSpace.prepInput(train[:1])
  with torch.no_grad(): result=m.forward(x)
 print('PASS',flush=True)
finally:
 m.End(); m.symbolSpace.soft_reset()
