"""Conditional free-inverse backward retains exact LDU diagonal gradients."""
import torch
from Layers import InvertibleLinearLayer

def test_ldu_diagonal_cond_backward_is_dense_and_exact():
    layer=InvertibleLinearLayer(4,4)
    def forward(selected):
        return torch.cond(selected,lambda:layer._D_embed(),lambda:torch.zeros((4,4)),())
    compiled=torch.compile(forward,backend='aot_eager',fullgraph=True)
    weights=torch.arange(16,dtype=torch.float32).reshape(4,4)
    (compiled(torch.tensor(True))*weights).sum().backward()
    torch.testing.assert_close(layer.d.grad,weights.diagonal())
    layer.d.grad=None
    (compiled(torch.tensor(False))*weights).sum().backward()
    torch.testing.assert_close(layer.d.grad,torch.zeros(4))
