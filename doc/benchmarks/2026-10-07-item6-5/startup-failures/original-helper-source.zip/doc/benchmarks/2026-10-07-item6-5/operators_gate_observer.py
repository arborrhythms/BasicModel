"""Observation-only pytest plugin; no source patch, RNG calls or gate changes."""
import json
import os
from pathlib import Path
import pytest
from contextlib import contextmanager


OBSERVER = None


@contextmanager
def capture_final_derivations():
    """Observe the existing greedy evaluation before its compose trace expires."""
    from unittest.mock import patch
    from Models import BasicModel
    from derivation_probe import compose_derivations
    captured = {}
    commit = BasicModel._commit_sentence
    def observed(model, state, sid, active, *args):
        if not model._sentence_training:
            for row in compose_derivations(model, state, sid, active):
                audit=model._last_sentence_credit
                b=row['batch_row']; kept=int(audit['wins'][b])
                row.update(cost_components=dict(zip(('reconstruction','expectation','answer'),
                    audit['components'][b,kept].tolist())), selected_cost=float(audit['keep_costs'][b,kept]), credit_total=float(audit['costs'][b,kept]),
                    decision=audit['keep_decision'][b], trial='explore' if kept else 'greedy')
                captured[(row['sentence_slot'], row['batch_row'])] = row
        return commit(model, state, sid, active, *args)
    with patch.object(BasicModel, '_commit_sentence', observed):
        yield captured

def pytest_sessionstart(session):
    global OBSERVER
    path = os.environ.get('OWNERSHIP_OBSERVER_OUTPUT')
    if path is None:
        return
    import importlib.util, sys
    root = Path(__file__).resolve().parents[3]
    source = root/'test/objective_conflicts_probe.py'
    saved = sys.argv
    sys.argv = [str(source),'--config','XOR_grammar','--output',path,'--validate-only']
    spec = importlib.util.spec_from_file_location('ownership_observer', source)
    OBSERVER = importlib.util.module_from_spec(spec)
    try:
        try:
            spec.loader.exec_module(OBSERVER)
        except SystemExit as exc:
            assert exc.code == 0
    finally:
        sys.argv = saved



def save_ownership(model):
    if OBSERVER is None:
        return
    p = OBSERVER.P
    p.groups(model)
    p.geometry(model, "end")
    from derivation_probe import named_walk_observations
    OBSERVER.write('walk-audit.json',dict(counts=getattr(model,'_walk_audit',{}),
        recent=named_walk_observations(model)))
    OBSERVER.write('configured-training.json', dict(
        OBSERVER.util.TheXMLConfig.get('architecture.training')))
    OBSERVER.write('outcome.json',dict(training_batches=p.training_batches,
        evaluation_batches=p.evaluation_batches,last_training_trials=p.last_trial,
        last_batch=p.last_batch,grammar_reconstructions=p.eval_reconstructions))
    assert OBSERVER.SOURCE == OBSERVER.source_snapshot(OBSERVER.ROOT)
    OBSERVER.write('complete.json',dict(source_matched=True,
        reused='predeclared tenth shared gate training; zero additional training runs'))


def record(value):
    with Path(os.environ['ITEM7_XOR_MEASUREMENTS']).open('a') as handle:
        value['gate'] = int(os.environ['ITEM7_XOR_GATE'])
        handle.write(json.dumps(value) + '\n')


@pytest.hookimpl(hookwrapper=True, tryfirst=True)
def pytest_runtest_setup(item):
    # The shared module fixture trains during setup, before either gate call.
    module = item.module
    grammar = getattr(module, '_run_xor_grammar_in_process', None)
    if grammar is not None:
        def observed_grammar(*args, **kwargs):
            from operators_run_audit import observe_run, json_value
            from rng_replay import entry, switches
            entry(Path(os.environ['ITEM7_XOR_MEASUREMENTS']).parent)
            with switches(), observe_run() as run_audit, capture_final_derivations() as derivations:
                model = grammar(*args, **kwargs)
            destination = Path(os.environ['ITEM7_XOR_MEASUREMENTS']).parent/'run-audit.json'
            destination.write_text(json.dumps(run_audit,indent=2,default=json_value)+'\n')
            data = model.inputSpace.data
            save_ownership(model)
            if OBSERVER is not None:
                OBSERVER.write('sentence-path-ownership.json',run_audit['sentence_gradients'])
                OBSERVER.write('centroid-projection.json',run_audit['centroid'])
                OBSERVER.write('reader-weight-trajectory.json',run_audit['reader_weights'])
                OBSERVER.write('decomposition-chooser.json',run_audit['decomposition_chooser'])
            record(dict(nodeid=item.nodeid, kind='grammar',
                        storage=run_audit['storage'],
                        storage_after_training=run_audit['storage_after_training'],
                        accuracy=[float(x) for x in model.rCorrect],
                        predictions=[float(x.reshape(-1)[0]) for x in data.reconstructed_output],
                        targets=[float(x.reshape(-1)[0]) for x in data.test_output],
                        inputs=[model._bytes_to_text(x).rstrip(chr(0)) for x in data.test_input],
                        reconstructions=list(data.reconstructed_input),
                        gate_reconstructions=list(model._grammar_gate_reconstructions),
                        final_greedy_compose=[derivations[key] for key in sorted(derivations)],
                        readback_decisions=model._last_readback_decisions,
                        inventories=[dict(stage=i, capacity=int(cs.nVectors),
                            code_width=cs.similarity_codebook.mereology.code_width,
                            percept_width=cs.similarity_codebook.mereology.percept_width,
                            percept_event_width=cs.similarity_codebook.mereology.percept_event_width,
                            context_width=cs.similarity_codebook.mereology.context_width,
                            symbol_concept_rows=sorted(cs._concept_allocator.layer()._tensor_row_keys))
                            for i,cs in enumerate(model.conceptualSpaces)],
                        grammar_reconstruction_unavailable=model._grammar_gate_unavailable))
            return model
        module._run_xor_grammar_in_process = observed_grammar
    try:
        yield
    finally:
        if grammar is not None:
            module._run_xor_grammar_in_process = grammar


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_call(item):
    module = item.module
    trained = getattr(getattr(item, 'instance', None), 'trained_xor_grammar', None)
    if trained is not None:
        record(dict(nodeid=item.nodeid, kind='shared_gate_consumer', model_identity=id(trained)))
    runner = getattr(module, 'run_config', None)
    if runner is not None:
        def observed_runner(*args, **kwargs):
            result = runner(*args, **kwargs)
            record(dict(nodeid=item.nodeid, kind='reconstruction', config=args[0],
                        epochs=kwargs.get('epochs'), seed=kwargs.get('seed'),
                        **{name: float(getattr(result, name)) for name in
                           ('exact_match_rate', 'where_recovery', 'output_loss', 'recon_loss')}))
            return result
        module.run_config = observed_runner
    cli = getattr(module, '_run_cli', None)
    if cli is not None:
        def observed_cli(*args, **kwargs):
            result = cli(*args, **kwargs)
            rc, stdout, stderr = result
            record(dict(nodeid=item.nodeid, kind='cli', config=args[0],
                        returncode=rc, stdout=stdout, stderr=stderr,
                        mse=module._parse_output_mse(stdout),
                        reconstructed=module._parse_input_match_counts(stdout)))
            return result
        module._run_cli = observed_cli
    mse_forward = None
    measurement = dict(nodeid=item.nodeid, kind='mm', calls=0, best=float('inf'), trajectory=[],
        pole_handoff=dict(calls=0,changed=0,maximum=0.),owner_step_comparisons=0,
        leaf_evidence_consumer_calls=0)
    if item.name in ('test_convergence', 'test_learns_xor_signal',
                      'test_mm_grammar_learns_xor_signal'):
        import torch
        fresh=module._fresh_model
        live_model=None
        def observed_fresh(*args,**kwargs):
            nonlocal live_model
            from rng_replay import entry, switches
            entry(Path(os.environ['ITEM7_XOR_MEASUREMENTS']).parent)
            with switches():
                result=fresh(*args,**kwargs)
            live_model=result[0]
            return result
        module._fresh_model=observed_fresh
        from Models import BasicModel
        payload=BasicModel._attention_sentence_payload
        def observed_payload(model,*args,**kwargs):
            if model is live_model:
                measurement['leaf_evidence_consumer_calls']+=1
            return payload(model,*args,**kwargs)
        BasicModel._attention_sentence_payload=observed_payload
        from handoff_probe import observe_handoff
        handoff_observer=observe_handoff(measurement)
        handoff_observer.__enter__()
        mse_forward = torch.nn.MSELoss.forward
        def observed_mse(self, output, target):
            result = mse_forward(self, output, target)
            if output.numel() == 4:
                value = float(result.detach())
                reading=getattr(live_model,'_attention_words',None)
                pair=getattr(live_model,'_attention_poles',None)
                if reading is not None:
                    handed=reading.pole_changes & reading.accepted
                    net=pair[...,0]-pair[...,1]
                    row=measurement['pole_handoff'];row['calls']+=1
                    row['changed']+=int(handed.sum())
                    row['maximum']=max(row['maximum'],float(net[handed].abs().max()) if bool(handed.any()) else 0.)
                    measurement['last_narrowing_actions']=reading.actions.detach().tolist()
                    measurement['last_poles']=pair.detach().tolist()
                    measurement['owner_step_comparisons']+=len(getattr(live_model,'_sentence_credit_audits',()))
                measurement['trajectory'].append(dict(epoch=measurement['calls']+1,mse=value,
                    predictions=output.detach().cpu().flatten().tolist()))
                measurement.update(calls=measurement['calls'] + 1,
                                   best=min(measurement['best'], value), last=value,
                                   predictions=output.detach().cpu().flatten().tolist(),
                                   targets=target.detach().cpu().flatten().tolist())
            return result
        torch.nn.MSELoss.forward = observed_mse
    try:
        yield
    finally:
        if runner is not None:
            module.run_config = runner
        if cli is not None:
            module._run_cli = cli
        if mse_forward is not None:
            torch.nn.MSELoss.forward = mse_forward
            module._fresh_model=fresh
            BasicModel._attention_sentence_payload=payload
            handoff_observer.__exit__(None,None,None)
            from operators_run_audit import storage_snapshot
            if live_model is not None:
                measurement['storage']=storage_snapshot(live_model)
            measurement['landing_comparison'] = dict(baseline='round-3a landing: 10/10',
                trajectory_live=True, regression_gate=True,
                pole_consumers_reached=any(measurement['pole_consumers'].values()),
                reason='Ten unseeded raw-forward trainings, each reported once; no paired replay, retry or replacement.')
            record(measurement)


def pytest_runtest_logreport(report):
    with Path(os.environ['REVIEW17_REPORTS']).open('a') as handle:
        handle.write(json.dumps(dict(nodeid=report.nodeid, phase=report.when,
            outcome=report.outcome, seconds=report.duration,
            failure=str(report.longrepr) if report.failed else None))+'\n')
