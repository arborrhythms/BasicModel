"""Hard-path provenance and the exploration runtime transaction."""
from dataclasses import dataclass
from types import SimpleNamespace

import pytest
import torch
from torch import nn

from Models import BasicModel
from Language import LanguageSpace


def _program_fixture():
    ids = torch.full((1, 14), -1, dtype=torch.long)
    arities = torch.zeros_like(ids)
    mask = torch.zeros_like(ids, dtype=torch.bool)
    positions = torch.zeros_like(ids)
    # Push a, push b, then rewrite the older a and fold (rewrite(a), b).
    ids[0, 3:5] = torch.tensor([11, 10])
    arities[0, 3:5] = torch.tensor([1, 2])
    mask[0, 3:5] = True
    positions[0, 3] = 1
    trace = SimpleNamespace(choices=lambda: (ids, arities, mask),
                            _choice_positions=positions)
    language = SimpleNamespace(_cs_binary_rule_ids=torch.tensor([10]),
                               _cs_unary_rule_ids=torch.tensor([11]),
                               local_op_from_rule_ids=LanguageSpace.local_op_from_rule_ids)
    model = SimpleNamespace(_reconstruction_stack=lambda: trace, languageSpace=language,
        inputSpace=SimpleNamespace(_word_active_mask=torch.ones(1, 2, dtype=torch.bool)),
        conceptualSpace=SimpleNamespace(stm=SimpleNamespace(capacity=2)), _walk_budget=lambda: 16)
    return model, trace, ids


def test_older_slot_unary_is_preserved_in_the_committed_postfix_program():
    model, _, _ = _program_fixture()
    positions, actions, targets = BasicModel._derivation_program(model)
    assert positions.tolist() == [[0, 1]]
    assert actions.tolist() == [[[0, -1, 0], [2, 0, -1], [0, -1, 1], [1, 0, -1]]]
    # Unary doubling and ordered binary subtraction expose an operand swap.
    stack = []
    for kind, _, word in actions[0].tolist():
        if kind == 0:
            stack.append([3., 5.][word])
        elif kind == 2:
            stack[-1] *= 2
        else:
            right, left = stack.pop(), stack.pop()
            stack.append(left - right)
    assert stack == [1.]
    assert targets[0, :4].tolist() == [0, 2, 1, 2]


def test_invalid_unary_position_is_not_silently_dropped():
    model, trace, _ = _program_fixture()
    trace._choice_positions[0, 3] = 2
    with pytest.raises(ValueError, match='unary position'):
        BasicModel._derivation_program(model)


def test_unknown_recorded_operation_is_not_silently_dropped():
    model, _, ids = _program_fixture()
    ids[0, 3] = 99
    with pytest.raises(ValueError, match='unknown recorded operation'):
        BasicModel._derivation_program(model)


@dataclass
class Lesson:
    targets: dict


class Runtime(nn.Module):
    def __init__(self):
        super().__init__()
        self.parameter = nn.Parameter(torch.tensor(2.))
        self.memory = nn.Module()
        self.memory.register_buffer('rows', torch.tensor([3.]))
        self._concept_allocator = SimpleNamespace(_layers={}, next_id=4, identity={1: 2})
        self.taxonomy = SimpleNamespace(children={1: [2]}, priming=torch.tensor([3.]))
        self._category_learner = SimpleNamespace(pending={1: torch.tensor([4.])}, step=5)
        from Layers import RadixTrie
        self.radix_trie = RadixTrie()
        self.radix_trie.insert(b'cat', 0)
        self.inverse_table = [b'cat']
        self.teacher = SimpleNamespace(lesson=Lesson({'clean': torch.tensor([5.])}))
        self.errors = SimpleNamespace(values={'exploit': [1.]})
        self.trace = SimpleNamespace(actions=torch.tensor([1]))

    def _synthesis_state_objects(self):
        return []

    def _reconstruction_stack(self):
        return self.trace

    def _what_memory(self):
        return self.memory


def test_runtime_restore_keeps_learning_but_restores_memory_trace_and_plain_owners():
    model = Runtime()
    saved = BasicModel._compose_state_snapshot(model)
    with torch.no_grad():
        model.parameter.add_(7)
        model.memory.rows.add_(10)
    model._concept_allocator.next_id = 9
    model._concept_allocator.identity[1] = 99
    model.taxonomy.children[1].append(99)
    model.taxonomy.priming.fill_(99)
    model._category_learner.pending[1].fill_(99)
    model._category_learner.step = 99
    model.radix_trie.insert(b'car', 1)  # splits an existing mutable edge
    model.inverse_table.append(b'car')
    model.teacher.lesson.targets['clean'].fill_(99)
    model.trace.actions.fill_(99)
    model.errors.values['explore'] = [2.]
    BasicModel._restore_compose_state(saved)
    assert model.parameter.item() == 9
    assert model.memory.rows.tolist() == [3.]
    assert model._concept_allocator.next_id == 4
    assert model._concept_allocator.identity == {1: 2}
    assert model.taxonomy.children == {1: [2]}
    assert model.taxonomy.priming.tolist() == [3.]
    assert model._category_learner.pending[1].tolist() == [4.]
    assert model._category_learner.step == 5
    assert model.radix_trie.get(b'cat') == 0
    assert model.radix_trie.get(b'car') is None
    assert model.inverse_table == [b'cat']
    assert model.teacher.lesson.targets['clean'].tolist() == [5.]
    assert model.trace.actions.tolist() == [1]
    assert model.errors.values == {'exploit': [1.]}


def test_parallel_completion_guards_memory_without_serial_depths():
    model = SimpleNamespace(serial=False, symbolSpace=SimpleNamespace(languageLayer=SimpleNamespace(
        _last_derivation={'complete': torch.tensor([True, False])})))
    assert BasicModel._compose_completed_rows(model).tolist() == [True, False]
    # A previous serial sentence has a different batch width. Parallel
    # context must use its own completion mask, not the stale serial depth.
    model._stm_post_depth = torch.tensor([-2])
    assert BasicModel._compose_completed_rows(model).tolist() == [True, False]
    model.serial = True
    model._stm_post_depth = torch.tensor([-2, 1])
    assert BasicModel._compose_completed_rows(model).tolist() == [False, True]


def test_exploration_forces_one_used_round_for_each_packed_sentence():
    B, W, cap = 2, 4, 2
    actions = torch.full((B, 3 * W + W * 2 * cap), -1, dtype=torch.long)
    # Interleaved rows have distinct sets of used rounds, including both seals.
    actions[0, [0, 3, 20, 6, 9, 12]] = 2
    actions[1, [1, 21, 7, 13]] = 1
    attempted = actions >= 0
    model = SimpleNamespace(
        _reconstruction_stack=lambda: SimpleNamespace(_choice_actions=actions, _choice_attempted=attempted),
        inputSpace=SimpleNamespace(_word_active_mask=torch.ones(B, W, dtype=torch.bool),
            _packed_sentence_ids=torch.tensor([[0, 0, 1, 1], [0, 0, 1, 1]])),
        conceptualSpace=SimpleNamespace(stm=SimpleNamespace(capacity=cap)))
    model._compose_round_owners = lambda actions: BasicModel._compose_round_owners(model, actions)
    copied, forced, owners = BasicModel._exploration_constraints(model)
    assert torch.equal(copied, actions)
    assert not bool((forced & ~attempted).any())
    for sid in (0, 1):
        assert ((owners == sid) & forced).sum(1).tolist() == [1, 1]


@pytest.mark.parametrize('staged', [None, [[11], [12]]])
def test_explore_reuses_the_teachers_staged_addresses(staged):
    model = Runtime()
    model.symbolSpace = nn.Module()
    model.symbolSpace.languageLayer = nn.Module()
    model.symbolSpace.languageLayer.operation_layer = nn.Identity()
    model.when_time = torch.tensor(1.)
    model.teacher._staged_source_rows = staged
    model.teacher._staged_split = 'train'
    def stage(split, rows):
        model.teacher._staged_source_rows = rows
        model.teacher._staged_split = split
    model.teacher.stage_batch_sources = stage
    observed = []
    def once(*, train=True, split='train', exploration_trial=False, source_rows=None):
        observed.append(model.teacher._staged_source_rows)
        model.teacher._staged_source_rows = None
        model.teacher._staged_split = None
        return object(), 0
    model._run_batch_once = once
    model._compose_state_snapshot = lambda: BasicModel._compose_state_snapshot(model)
    model._restore_compose_state = BasicModel._restore_compose_state
    model._compose_completed_rows = lambda: None
    model._exploration_constraints = lambda: (None, None, None)
    # Grammar-lesson row metadata need not be Teacher corpus addresses.
    BasicModel._run_batch_pair(model, source_rows=[0, 1])
    assert observed == [staged, staged]
    assert model.teacher._staged_source_rows is None


def test_contextual_dictionary_restore_preserves_owned_storage_and_reader_aliases():
    from Spaces import Codebook
    model = Runtime()
    model.dictionary = Codebook()
    model.dictionary.W = nn.Parameter(torch.eye(3))
    model.dictionary.nVectors = 3
    model.dictionary.enable_contextual_rotation()
    model.dictionary.freeze_capacity('exploration transaction regression')
    model.reader = nn.Module()
    model.reader.storage = model.dictionary.W
    storage = model.dictionary.W
    saved = BasicModel._compose_state_snapshot(model)
    with torch.no_grad():
        storage.add_(4.)
    BasicModel._restore_compose_state(saved)
    assert model.dictionary.W is storage
    assert model.reader.storage is storage
    model.dictionary._assert_frozen_parameter_identity()
    torch.testing.assert_close(storage, torch.eye(3), rtol=0, atol=0)


def test_sparse_topology_restore_retains_shared_learning_and_exploit_only_edges():
    from Layers import SparseLayer
    model = Runtime()
    model.sparse = SparseLayer(4, 4)
    matrix = model.sparse
    matrix.add_edge(0, 1, weight=1.)
    optimizer = torch.optim.Adam([matrix.values], lr=.01)
    matrix._optimizer = optimizer
    before = BasicModel._compose_state_snapshot(model)
    def train(scale):
        optimizer.zero_grad(set_to_none=True)
        (matrix.values.sum() * scale).backward()
        optimizer.step()
    matrix.add_edge(1, 2, weight=2.)
    train(1.)
    committed = BasicModel._compose_state_snapshot(model)
    exploit_value = matrix.values[1].detach().clone()
    exploit_moment = optimizer.state[matrix.values]['exp_avg'][1].clone()
    BasicModel._restore_compose_state(before)
    assert matrix.nnz == len(matrix.values) == 1
    # This alternative reuses the rolled-back allocation id but has a
    # different meaning. Its value and optimizer history must stay ephemeral.
    matrix.add_edge(2, 3, weight=3.)
    train(2.)
    shared_value = matrix.values[0].detach().clone()
    shared_moment = optimizer.state[matrix.values]['exp_avg'][0].clone()
    BasicModel._restore_compose_state(committed, sparse_scope=before)
    assert list(zip(matrix._rows, matrix._cols)) == [(0, 1), (1, 2)]
    assert matrix.nnz == len(matrix.values) == 2
    torch.testing.assert_close(matrix.values, torch.stack((shared_value, exploit_value)))
    torch.testing.assert_close(optimizer.state[matrix.values]['exp_avg'],
                               torch.stack((shared_moment, exploit_moment)))
    owned = [p for group in optimizer.param_groups for p in group['params']]
    assert len(owned) == 1 and owned[0] is matrix.values


def test_runtime_restore_retains_warn_once_history_created_by_either_trial():
    model = Runtime()
    before = BasicModel._compose_state_snapshot(model)
    model._zeroed_channel_warned = {'exploit-warning'}
    committed = BasicModel._compose_state_snapshot(model)
    BasicModel._restore_compose_state(before)
    assert model._zeroed_channel_warned == {'exploit-warning'}
    model._zeroed_channel_warned.add('explore-warning')
    BasicModel._restore_compose_state(committed)
    assert model._zeroed_channel_warned == {'exploit-warning', 'explore-warning'}


def test_sparse_explore_only_parameter_and_optimizer_state_are_discarded():
    from Layers import SparseLayer
    model = Runtime()
    model.sparse = SparseLayer(4, 4)
    matrix = model.sparse
    optimizer = torch.optim.Adam([model.parameter], lr=.01)
    matrix._optimizer = optimizer
    committed = BasicModel._compose_state_snapshot(model)
    matrix.add_edge(0, 1, weight=1.)
    matrix.values.sum().backward()
    optimizer.step()
    BasicModel._restore_compose_state(committed, sparse_scope=committed)
    assert matrix.nnz == 0 and matrix.values is None
    owned = [p for group in optimizer.param_groups for p in group['params']]
    assert len(owned) == 1 and owned[0] is model.parameter
    assert not optimizer.state


def test_bounded_history_and_nested_values_restore_without_cross_trial_aliases():
    from collections import deque
    model = Runtime()
    model.history = deque([{'value': torch.tensor([1.])}], maxlen=2)
    model.memory.history = model.history
    before = BasicModel._compose_state_snapshot(model)
    model.history.append({'value': torch.tensor([2.])})
    committed = BasicModel._compose_state_snapshot(model)
    BasicModel._restore_compose_state(before)
    assert len(model.history) == 1
    model.history[0]['value'].add_(10.)
    model.history.append({'value': torch.tensor([99.])})
    BasicModel._restore_compose_state(committed)
    assert model.history.maxlen == 2
    assert model.history is model.memory.history
    assert [entry['value'].item() for entry in model.history] == [1., 2.]


def test_one_word_packed_sentence_has_its_own_seal_and_program():
    model, trace, ids = _program_fixture()
    model.inputSpace._sentence_pack_enabled = True
    model.inputSpace._packed_sentence_ids = torch.tensor([[0, 1]])
    ids.fill_(-1)
    _ids, arities, mask = trace.choices()
    arities.zero_(); mask.zero_(); trace._choice_positions.zero_()
    # W=2, cap=2: final group at 6, first-word intermediate group at 10.
    ids[0, 10] = 11; arities[0, 10] = 1; mask[0, 10] = True
    owners, _, _ = BasicModel._compose_round_owners(model, ids)
    assert owners[0, 6:10].tolist() == [1] * 4
    assert owners[0, 10:14].tolist() == [0] * 4
    _, first, _ = BasicModel._derivation_program(model, t=0)
    final_positions, final, _ = BasicModel._derivation_program(model, t=1)
    assert first[0, :2].tolist() == [[0, -1, 0], [2, 0, -1]]
    assert final_positions.tolist() == [[1]]
    assert final[0, :1].tolist() == [[0, -1, 0]]


@pytest.mark.parametrize('seal_budget', (0, 1))
def test_tensor_pipeline_records_both_one_word_packed_seals(tmp_path, monkeypatch, seal_budget):
    from test_compiled_word_chunk import _tiny_canonical_model
    from test_reverse_traversal import _stage_packed
    model = _tiny_canonical_model(tmp_path, monkeypatch, word_buckets='8',
                                  concept_rows=256, part_rows=128)
    model._tensor_peer_while_eager = True
    model.syntacticOrder = seal_budget
    # Unary-only rounds keep occupancy fixed and exhaust the declared budget.
    # That exposes a packed/final budget mismatch without a random STOP.
    chooser = model.languageSpace.language_layer.operation_layer.chooser
    def binary(x, candidates, *_args, **_kwargs):
        return (x.new_full((*x.shape[:2], 1), -1e6),
                x.new_full(candidates.shape[:-1], -1e6))
    def unary(x, candidates, *_args, **_kwargs):
        scores = x.new_full(candidates.shape[:-1], -1e6)
        scores[..., 0] = 0.
        return x.new_full((*x.shape[:2], 1), -1e6), scores
    chooser.score_binary, chooser.score_unary = binary, unary
    def eager_while(condition, body, values):
        while bool(condition(*values)):
            values = body(*values)
        return values
    monkeypatch.setattr(torch, 'while_loop', eager_while)
    model._install_unit_span_fn()
    try:
        _stage_packed(model, [['a', 'b']])
        with torch.no_grad():
            result = model._forward_with_compiled_sentence_state(None)
        model._publish_compiled_sentence_state(result)
        trace = model._reconstruction_stack()
        W = model.inputSpace._word_active_mask.shape[1]
        width = 2 * model.conceptualSpace.stm.capacity
        assert bool(trace._choice_attempted[0, 3 * W])
        assert bool(trace._choice_attempted[0, 3 * W + width])
        expected = min(seal_budget, width) if seal_budget > 0 else width
        assert int(trace._choice_attempted[0, 3 * W:3 * W + width].sum()) == expected
        assert int(trace._choice_attempted[0, 3 * W + width:3 * W + 2 * width].sum()) == expected
    finally:
        model.End()
        model.symbolSpace.soft_reset()
