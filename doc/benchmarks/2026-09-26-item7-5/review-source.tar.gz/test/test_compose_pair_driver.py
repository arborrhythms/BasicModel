"""Exploit/explore both train; only exploit state survives the transaction."""
import os
import re
import sys
import tempfile
import warnings

os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
os.environ.setdefault("BASICMODEL_DEVICE", "cpu")

_BIN = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "bin")
_PROJECT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _BIN not in sys.path:
    sys.path.insert(0, _BIN)

import torch

_DATA = os.path.join(_PROJECT, "data")
_GRAMMAR_CONFIG = os.path.join(_DATA, "MM_xor_loopback.xml")
_DEFAULTS = os.path.join(_DATA, "model.xml")


def _build(extra=""):
    import Models, Language
    from util import init_config, init_device
    init_device("cpu")
    with open(_GRAMMAR_CONFIG) as f:
        text = f.read()
    text = re.sub(r"\s*<learning>[^<]*</learning>\s*\n", "\n", text)
    if extra:
        text = text.replace("<architecture>", f"<architecture>\n    {extra}", 1)
    tmp = tempfile.NamedTemporaryFile(
        mode="w", suffix=".xml", delete=False)
    tmp.write(text)
    tmp.close()
    try:
        init_config(path=tmp.name, defaults_path=_DEFAULTS)
        Language.TheGrammar._configured = False
        with warnings.catch_warnings():
            warnings.filterwarnings("ignore")
            m, _ = Models.BasicModel.from_config(tmp.name)
        import Models as _M
        _M.TheData.load("xor")
        m.train()
        return m
    finally:
        try:
            os.unlink(tmp.name)
        except OSError:
            pass


def _batch(m):
    loader = m.inputSpace.data.data_loader(split="train", num_streams=4)
    inp_items, out_items = next(iter(loader))
    return (m.inputSpace.prepInput(inp_items),
            m.outputSpace.prepOutput(out_items))


def test_pair_trains_twice_and_commits_once(monkeypatch):
    m = _build()
    optimizer = torch.optim.SGD(m.parameters(), lr=0.0)
    batch = _batch(m)
    clock0 = m.present()
    steps0 = int(getattr(m, '_training_step_count', 0))
    observed = []
    backward = m._backward_training_loss
    def capture(total, *args, **kwargs):
        trace = m._reconstruction_stack()
        observed.append((bool(m.symbolSpace.languageLayer.exploration_trial), trace._choice_actions.detach().clone(),
                         m.conceptualSpace.stm._buffer.detach().clone(),
                         float(total.detach())))
        return backward(total, *args, **kwargs)
    monkeypatch.setattr(m, '_backward_training_loss', capture)
    try:
        with warnings.catch_warnings():
            warnings.filterwarnings('ignore')
            m.runBatch(train=True, batchSize=4, optimizer=optimizer, batch_override=batch)
        assert [row[0] for row in observed] == [False, True]
        assert all(torch.isfinite(torch.tensor(row[3])) for row in observed)
        assert m.present() - clock0 == 1
        assert m._training_step_count - steps0 == 1
        torch.testing.assert_close(m._reconstruction_stack()._choice_actions, observed[0][1])
        assert (observed[0][1] != observed[1][1]).any(-1).all()
        assert m._exploration_trial is False
        assert m._compose_exploit_actions is None
    finally:
        m.End()
        m.symbolSpace.soft_reset()


def test_flattened_temperature_driver_is_deleted():
    import Models
    assert not hasattr(Models.BasicModel, '_set_superposition_temperature')
