# XML Configuration Parameters

Model configuration is specified in XML files (e.g. `data/XOR_exact.xml`).
Default values are loaded from `data/model.xml` and overridden by
model-specific configs. The schema is in `data/model.xsd`.

This document is the human-facing reference for common knobs and migrations.
`data/model.xsd` is authoritative for the complete accepted element set.

## Relation to LLMs, Formal Concept Analysis, and DisCoCat

Several XML knobs expose the architecture's relation to LLMs, Formal Concept
Analysis, and DisCoCat. `dataType=embedding`, sentence prediction, and
reconstruction cover the LLM-like prediction/generation path.
`subsymbolicOrder`, `symbolicOrder`, `mereologyRaise`, `monotonic`, and the
codebook settings control the FCA-like concept order and part/whole lattice.
`serial`, `learning`, `transformChooser`, `categoryCodebook`, and grammar-layer
settings control the DisCoCat-like typed composition path.

Overlay merge order:
`data/model.xml`  $\to$  `<config>.xml`  $\to$  runtime overrides.

Note on naming: the schema and the XML configs use `nInput` / `nOutput`
(sequence-length sentinels), `nDim` (per-vector dim), `nVectors`
(codebook size), and `nInputDim` / `nOutputDim` (raw shape hints for the
LiftingLayer). Older docs sometimes call `nOutput` / `nInput` `nActive`;
treat that as the same thing as `nOutput`.

> 2026-05-28: `<nWhere>` / `<nWhen>` are retired from per-file configs.
> The band widths are architectural (`canonical_shape` in `bin/architecture.py`).
> Input, part, whole and symbol events use two quadrature pairs for `.where`
> and two for `.when`; conceptual codes and final outputs have no local band.
> A complete model shares **one** spatial ladder and **one** temporal ladder.
> The spatial long period is derived from the total input/percept/symbol
> registry capacity; the temporal long period covers the LTM allocation.
> Short periods preserve one-location resolution. Integer spatial addresses
> are decoded from the band, not saved beside it. Everything observed in one
> field shares its time; the exact clock side-band stays. Span endpoints are
> separate extent metadata. The old `wherePeriod`, `whereRungRatio`,
> `whenPeriod` and `whenRungRatio` XML knobs are retired.

---

## `<architecture>`

Core model settings. Training and data parameters are in nested
sub-elements `<training>` and `<data>` (see below).

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `data/dataType` | string | `"numeric"` | The data space-role (was the retired architecture-level `modelType`), set under `<data>`: `embedding` (LM / chat with sequence processing — PartSpace owns the byte/word lexicon) or `numeric` (dense slab, e.g. MNIST pixels). The old `simple`+`passthrough` collapsed to `numeric`; `vq` was dropped (0 configs). |
| `reconstruct` | — | — | RETIRED (A1, 2026-06-09): the `reconstructEnum` / `<reconstruct>` element no longer exists. Reconstruction is concepts-seeded; stream binding is governed separately by `conceptBinding` (`aligned` does not allocate `ConceptualCombine`, while `mixing` is the parallel learned-matrix option). There is no selectable `none` / `symbols` / `both` mode. |
| `subsymbolicOrder` | int | `1` | Maximum subsymbolic passes over native percepts and the order-0 field. Passes may retarget region or mereological level through subsymbolicLoop; they do not raise conceptual order or apply perceptual fold layers. |
| `conceptBinding` | string | `"mixing"` | PS/WS concept-formation mode. `aligned` preserves location and fuses every non-raw cumulative fold from both towers; BasicModel uses order 4, hence three PS plus three WS sources. Exact ordered paths and actual concept order ride on the concept and persist on minted META concepts. `mixing` retains the learned `ConceptualCombine` matrix as a parallel-path alternative; BasicModel's serial path is aligned. |
| `processSymbols` | bool | `false` | Apply extra symbolic processing after Sigma. |
| `monotonic` | bool | `false` | Constrain invertible Sigma / Pi to $W \ge 0$ so the lift / lower chain is order-preserving on the parthood cone. |
| `ergodic` | bool | `false` | Ergodic exploration: eligible layers use `W_eff = bias * W + var * noise`; `bias`/`var` are gradient-energy buffers, not Adam parameters. See [Ergodic.md](Ergodic.md). |
| `naive` | bool | `false` | Materialise `W_eff` densely in `InvertibleLinearLayer`. Slower; debugging only. `false` uses sequential L / D / U triangular solves. |
| `serial` | bool | derived | Forward-dispatch mode. `true` = serial / grammatical (per-word `[B, 1, D]` body); `false` = parallel (whole-slab `[B, N, D]` body). If omitted, legacy configs derive it from `symbolicOrder > 0`; new configs should set it explicitly. |
| `composeTemperature` | finite float ≥ 0 | `0` | Shared hard-choice sampling temperature for exploit and explore. Zero selects the greatest logit, with item 8's structural rule on exact ties. Positive values sample `softmax(logits / temperature)` during training. Evaluation always uses argmax. Straight-through credit always uses the untempered model softmax; this parameter never scales its gradients. |
| `modeSchedule` | string | derived from `serial` | `serial`, `parallel`, or `interleave:N` for a positive integer N. Interleaving stages the next N complete sentences, reads them in native parallel mode, then reads the same sentences in serial mode. The final shorter group is processed too. Both passes share the inventory. Context runs forward under no-grad, updating admission, participation and priming; only serial presentations train through the optimizer and advance the external clock. There is no separate label read-back. |
| `symbolicOrder` | int | `0` | Bound on symbolizations in the symbolic loop. Higher rows union the preceding order's symbols; pi edges exist only within the order-0 field. Two poles share one code. 0 disables the parallel pyramid; serial grammar dispatch is independent. |
| `conceptualPi` | bool | `false` | Enable conjunctive parts in the order-0 field before max over alternatives. The pool discovers recurring fused native parts; conceptual conjunction means co-presence inside the field bracket. Pi edges above order 0 are rejected. |
| `attentionPromotion` | bool | `false` | Enable witnessed-context discovery in the conceptual row pool at the parallel sentence boundary. Grammatical clause admission is independent of this discovery switch. |
| `conceptPoolSize` | positive int | `1` | Provisional rows reserved per conceptual order, replenished after discovery, within the fixed inventory. Exhaustion is reported; discovered rows are never recycled. |
| `conceptUseEWMA` | decimal | `0.9` | Previous-value coefficient for context, part support and participation updates; must be less than one. |
| `conceptUseFloor` | decimal | `0.5` | Raw presence must exceed this floor to count as use, before participation gates it. |
| `conceptMintThreshold` | decimal | `0.8` | Participation at or above this value gives the row a permanent concept identity and distributed code, clears use management, and fixes participation at one. |
| `conceptRecycleThreshold` | decimal | `0.2` | Reassign the least-used provisional row below this value when no free row remains. Must be below the discovery threshold. |
| `conceptMatchCos` | decimal | `0.8` | Minimum cosine between witnessed context weights for substitution. A conjunction reuses only its complete observed part set. |
| `conceptPartFloor` | decimal | `0.001` | Prune exponents weaker in magnitude than this floor when a provisional concept is discovered. |
| `subsymbolicLoop` | string | `all` | Passes on which conceptual demand may retarget perception to a region or mereological level: `all`, `off`, or comma-separated indices in `1..subsymbolicOrder-1`, e.g. `"1,3"`. Pass 0 reads the initial attended field. This selector keeps `subsymbolicOrder` as the processing bound; it adds no perceptual fold layers or identity slots. |
| `sparseReplace` | — | — | RETIRED (2026-07-02 P3 two-phase forward): phase separation makes non-replacement structural — the symbolic phase's outputs feed the SS leg, the head-side losses, and the concept table, never substituting the subsymbolic advance. Parsed only to emit a `DeprecationWarning`. |
| `routerWireSerial` | string | `"both"` | Per-word router-fire gating on the serial path: `per-word` (fire per word, boundary off), `boundary` (fire only at the sentence boundary), `both` (default — both fire), `off` (neither). The per-word fire populates `symbolSpace.current_rules` for SS dispatch. See [STM.md Section 7](STM.md#7-per-word-router-firing). |
| `transformChooser` | string | `"anchordot"` | Placement scorer for the structured grammar layers. `anchordot` = stateless cosine-to-anchor (byte-identical default, no new params); `mlp` = learned `MLPTransformChooser` (owns tool-embedding + MLP params $\to$ deliberate fresh-basin cutover). See [Language.md](Language.md). |
| `transformChooserHidden` | int | `0` | Hidden width of each grammar MLP when `transformChooser=mlp`; `0` derives `max(8, grammar feature width)`. Positive values override it. Canonical BasicModel currently derives 1024. Inert for `anchordot`. |
| `transformChooserDepth` | int | `1` | Number of hidden Linear/GELU blocks in each grammar MLP, followed by one scalar Linear head; must be positive. Not the number of grammatical reductions or thought iterations. |
| `whatThinkingHidden` | int | `16` | Positive hidden width of the sole `SelectedThoughtChooser` MLP. Its context includes masked root/active/candidate roles, semantic metadata, attended visible STM/LTM and execution state; see [SelectedMeaning](SelectedMeaning.md). |
| `whatThinkingDepth` | int | `1` | Positive number of hidden Linear/GELU blocks in the selected-thought MLP, followed by its zero-initialized scalar head. It does not change the shared work allowance or enable policy credit. |
| `selectedThoughtBudget` | non-negative int | `32` | Shared work allowance for one completed interrogative grammatical-thought episode. It covers controller choices plus the forwarded `QueryWorkBudget`; `0` permits only the defined cutoff/root-finish drain. It is independent of legacy `whatThinkingIterations`. |
| `reconstructFromIdea` | bool | `false` | Legacy evaluation selection of recovered word ideas instead of the single-slot seed. Tied mode always returns its owned completed reconstruction, independently of this flag, and never enters the free generate chart ([Models.py](../bin/Models.py)). |
| `categoryCodebook` | bool | `true` | MetaSymbol participation-category codebook for the role-collapsed grammar: a small role-space `VectorQuantize` initialized with one prototype per labelled grammar role (`op_I1`, `op_I2`, `op_O1`, ...). Unsettled MetaSymbols accumulate bounded temporary role evidence; once mass/confidence/margin/stability thresholds are met, the MetaSymbol commits to one category id and its pending row is discarded. Structured grammar layers use the role context for all `transformChooser` modes: as an input feature for `mlp`, and as a labelled-role score prior for anchordot/default routing. See [Language.md $\to$ Participation Categories](Language.md). |
| `adverbEigEdit` | bool | `false` | Legacy/direct `LiftLayer` helper flag for the adverb sparse eigenvalue edit. The live `adverb` grammar operator force-builds the same zero-init projection and calls `LiftLayer.apply_adverb`, so ordinary grammar use does not depend on this flag. When enabled for plain `LiftLayer`, an adverb modifies a composed VP by `a2 = atanh(vp) + p_vp * delta_adv`, masked by the VP's own eigen-signature. Default off keeps plain `LiftLayer` byte-identical. |
| `mereologyRaise` | bool | `false` | Enable native meronomy binding and the conceptual refine/raise decision. Beyond order-1 symbolization, a raise requires a both reading with discontiguous retained support after stalled learning; counts never trigger it. |
| `mereologyRefinePatience` | positive int | `3` | Completed optimizer updates without a strict improvement in the worst local `min(c⁺, c⁻)` reading before discontiguous support may raise an order. Pure/unknown evidence and improvement reset patience; repeated reads do not advance it. |
| `embeddingPath` | string | (empty) | gensim `KeyedVectors` path. Empty disables embedding load. |
| `weightsPath` | string | (empty) | Model weights checkpoint path. Empty falls back to `output/<name>.ckpt`. |
| `maxResponseLength` | int | `4096` | Inference token budget (characters / bytes / tokens). Caps output alongside `InputSpace.nOutput`. |
| `amp` | string | `"off"` | AMP autocast mode: `off`, `fp16`, `bf16`. |
| `truthBiasScale` | decimal | `0.1` | Strength of luminosity-based bias on concept input during forward. |
| `LuminosityWeight` | decimal | `0.1` | Multiplicative loss penalty for incoherent truths. |
| `UniversalityWeight` | decimal | `0.1` | Multiplicative loss penalty for unkind propositions. |
| `allowExcludedMiddle` | int | `1` | Catuskoti policy: `1` permits NEITHER, `-1` enforces classical LEM. |
| `allowContradiction` | int | `0` | Catuskoti policy: `0` forbids BOTH (non-contradiction), `1` permits paraconsistent BOTH. |
| `gateL1Lambda` | float | `0.0` | L1 sparsity penalty on lift / lower gates. `0` disables. |
| `loadBalanceWeight` | float | `0.0` | Sparse-MoE load-balance loss weight. Currently **inert / no-op**: the knob is read (`Models.py`) but has no consumer — the chart's sparse-MoE load-balance bookkeeping was retired with the chart itself, and the knob stands by for any future signal-router rule load-balancing. (`chartTopK` is itself retired.) |
| `l1Lambda` | decimal | `0.0` | Architecture-wide L1 penalty hook. Most configs leave this at `0` and use `WholeSpace.l1Lambda` instead. |
| `discontinuityLambda` | decimal | `0.0` | Architecture-wide discontinuity penalty hook (legacy). |
| `maxActivePerLayer` | int | `8` | Maximum active nodes per layer for reverse / mereological walks. |
| `codebookRetire` | bool | `false` | Retire codebook path where supported. Mostly a migration hook. |
| `symbolLearning.enabled` | bool | `false` | Enables runtime symbol-learning hooks. Disabled by default. |
| `mereologicalTreeSize` | int | -- | Retired compatibility knob. Values are accepted but ignored; the codebook is the meronymic structure. |
| `writeSyntax` | bool | `false` | Dump POS-labelled syntax tree at end of every `MentalModel.forward()`. |
| `syntaxOutPath` | string | -- | Output path for `writeSyntax`. |

Luminosity and universality are **multiplicative** --- they scale the total loss by

$$
(1 + \mathit{LuminosityWeight} \cdot (1 - \text{luminosity}) + \mathit{UniversalityWeight} \cdot (1 - \text{universality})).
$$

`TruthLoss` (in `<training>`, below) is **additive** --- it directly
penalises propositions that contradict the TruthSet. Both coexist. See
[Ethics.md](../../doc/Ethics.md) Section Universality and
[Reasoning.md](Reasoning.md) Section TruthLoss for details.

---

With `interleave:N`, `runEpoch` stages complete sentences in corpus order and
keeps serial batches at or below the requested `batchSize`, splitting at group
boundaries. The native context batch has N rows, so N also determines its memory
requirement. This cursor uses complete sentence inputs rather than byte slabs
or packed bricks. Direct `runBatch` callers can supply a complete group or pass
`schedule_context` with the coming group before its first serial batch; later
batches must match the unread prefix. A checkpoint preserves that prefix.
Mid-epoch resume requires the same schedule and serial batch size.
Evaluation uses its own temporary queue, preserving any unfinished training
group. A fresh training epoch starts a new queue; a resume keeps the saved one.

### `<architecture><data>`

Data loading and filtering.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `conceptLessons` | string | (empty) | Optional JSON primitive memberships and single-occurrence name lessons, resolved relative to `data/`. Runs before ordinary supervised training; unlabelled training inputs witness located conjunctions and output sigma weights start at zero. Used by `XOR_exact.xml`. |
| `dataset` | string | `"xor"` | Dataset key: `xor`, `mnist`, `tomatoes`, `text`, `inline`, `grammar`. Omit for inference-only models. |
| `numShards` | int | `1` | Shard count (streaming text datasets). |
| `maxDocs` | int | `10000` | Per-shard document cap. |
| `maxSentenceWords` | int | *(unbounded)* | Whole-sentence admission ceiling for text shards. Longer splitter records are excluded intact, never clipped. Set this no higher than `serialWordCapacity` when packed training is enabled. |
| `grammarLessons` | string | `grammar_wording.json` | Annotated text curriculum for `dataset=grammar`, resolved relative to `data/` unless absolute. Train/validation/test text enters the ordinary loader; only train annotations supply post-forward grammar loss. Use unpacked sentences. See [SelectedMeaning](SelectedMeaning.md). |
| `shardDir` | string | (empty) | Text shard directory (e.g. `data/fineweb`). Only used when `dataset=text`. |
| `minFrequency` | float | `0.0` | Vocabulary admission threshold (fraction of corpus). Words below it are held in a pending buffer until they accumulate enough occurrences. `0.0` admits everything. |
| `classificationMin` | float | -- | **Unparsed**: declared in `data/model.xml` / the schema, read by nothing in `bin/`. |
| `classificationMax` | float | -- | **Unparsed**: declared in `data/model.xml` / the schema, read by nothing in `bin/`. |

Inline-mode configs additionally accept `<input use="train|test|validation">...|...|...</input>`
and matching `<output>` elements directly inside `<data>`.

---

### `<architecture><training>`

Training loop and I/O.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `numTrials` | int | `1` | Independent training runs per invocation. |
| `numEpochs` | int | `3` | Epochs per trial. |
| `batchSize` | int | `64` | Contiguous streams through the dataset. Each batch row `b` receives the next item from stream `b`, so temporal context is coherent across steps. Capped at split length, so small eval sets yield one rectangular batch. |
| `packSentences` | bool | `false` | For self-supervised word-loop training, pack consecutive complete sentences independently in each contiguous batch row up to `serialWordCapacity`. Row-local sentence boundaries are explicit and reset softly; sentences are never split, clipped, transposed, or reordered. Under the canonical `<analysis>meronomy</analysis>` the brick budget and the row layout count the ladder's units (whitespace and digit units included), not whitespace words. Environment override: `BASIC_PACK_SENTENCES`. |
| `numWorkers` | int | `0` | DataLoader prefetch workers. `0` = synchronous in-process batch assembly. |
| `learningRate` | float | `0.001` | Adam learning rate. |
| `reconstructionScale` | float | `0.5` | Weight of reconstruction loss vs prediction loss in $[0, 1]$: $\mathcal{L}_{\text{total}} = (1-r)\,\mathcal{L}_{\text{output}} + r\,\mathcal{L}_{\text{recon}}$.  Legacy name `reverseScale` is still parsed with a one-shot deprecation warning. |
| `conceptualContextLearningRate` | float | `0.0` | Enables the context-owned ConceptualSpace dictionary updater. Each completed sentence produces one deterministic, reduced tangent rotation per observed codebook row; `similarity_codebook.W` is a persistent non-grad buffer, read through an eager compiler boundary, and never enters Adam. Mutually exclusive with `conceptualSimilarityScale`. |
| `conceptualContextSituationWeight` | unitInterval | `0.0` | Weight of bounded predictor anchors added to the sentence's distributional context. The snapshot is taken before that sentence is perceived. Zero retains sentence-local context. |
| `conceptualContextSituationAnchors` | nonnegative int | `8` | Maximum number of recent predictor frames contributing to situation context. Zero excludes situation anchors; this never searches LTM. |
| `conceptualContextExpectationWeight` | unitInterval | `0.0` | Share of the rotation step taken toward the prior estimate. The observed-context step has weight `1 − w`; at `w = 1`, arriving context contributes no update. A cold estimate supplies no substitute evidence. |
| `conceptualContextNegatives` | int | `4` | Number of deterministic detached negative prototype rows in the contextual SBOW rotation. |
| `detachedReverse` | bool | `false` | On serial grammar training, supervise the static idea-only reverse chooser from `stopgrad(S)` using detached `ReconstructionStack` rule/arity/leaf targets instead of replaying the D3 recurrence. |
| `reconstructInLoop` | bool | `false`; BasicModel `true` | One owned completed-input reconstruction. A bounded occurrence prepass, seal reversal and reverse word walk follow the identified compose derivation using shared transforms. Train/eval consume the same byte objective once; idea/event fidelity is diagnostic. Mutually exclusive with `detachedReverse`; suppresses standalone leaf distillation. Student checkpoint keys and optimizer entries are dropped while shared weights/moments survive. WORD-owned spelling candidates and a uniform null candidate score the recovered ideas ([Models.py](../bin/Models.py), [Models.py](../bin/Models.py)). |
| `reconstructionBasisLimit` | positive int | `16` | Maximum candidate prototypes per side for approximate reconstruction through the selected compose operator: at most `K*K` pairs. Independent of word, STM and field capacity. The invocation owns detached values/masks; missing candidates or inverses report incompleteness ([Language.py](../bin/Language.py)). |
| `reconstructionPlacement` | `graph` / `compiled` / `eager` | `graph`; BasicModel `compiled` | Run the traversal inside the forward graph, as a separate fullgraph call, or eagerly. The separate call promotes the `eager` backend to `aot_eager` to cache backward too. The `auto` policy resolves to its first configured backend before PyTorch lookup. `BASICMODEL_RECON_PLACEMENT` remains a diagnostic override. Placement changes execution, not the tied objective or 21-value forward state ([Models.py](../bin/Models.py)). |
| `outputInLoop` | bool | `false`; BasicModel `true` | `reverseOutput` unfolds owned answer concepts with its bounded generate walk. The chooser uses declared `<generate>` rules and stop: training samples actions; evaluation selects the highest-scoring action. It ignores input compose traces, teacher targets and reconstruction witnesses. Policy and traversal state are independent; numerical operator instances still share comprehension parameters pending the integrated specification's catalog migration. Unavailable requested operations remain pending and report bounded truncation ([Models.py](../bin/Models.py), [Models.py](../bin/Models.py)). Resolution completes before `reverseOutput` and supplies its owned `AnswerDerivation`. |
| `outputPolicyWeight` | float | `0.0`; BasicModel `1.0` | Weight of the output chooser's supervised action credit. Training samples its own output actions and credits their sequence log probability using detached realised-answer error and an EMA return baseline. Only separately supplied, available `What.supervised` numeric or text targets contribute ([Models.py](../bin/Models.py)); zero weight or missing supervision gives no policy update. The term is added to the `runBatch` total and reported as `output_policy`. `LanguageSpace.generate_policy` belongs to SymbolSpace's optimizer parameters and exists only with `outputInLoop`. Input compose choices are not output supervision. |
| `grammarLessonWeight` | float | `1.0` | Weight of supplied grammar annotations: compose-choice cross entropy plus separately annotated generate-choice/child-value loss. Added to the actual `runBatch` total after student output; no term without annotations, on evaluation splits, or on prediction-only trials. `0` disables it. Shared parameters obey reconstruction priority. |
| `whatScale` | float | `0.7` | Loss weight on the `.what` (content) channel. |
| `whereScale` | float | `0.2` | Loss weight on the `.where` (positional) channel. |
| `whenScale` | float | `0.1` | Loss weight on the `.when` (temporal) channel in general event comparisons. Per-word reconstruction excludes the field's shared timestamp. |
| `negSamples` | int | `64` | Negative samples per positive for CBOW / SBOW. Memory cost: $O(\text{batch} \cdot \text{negSamples} \cdot \text{dim})$ vs $O(\text{batch} \cdot \text{vocab})$ for full softmax. |
| `TruthLoss` | float | `0.0` | Additive penalty for propositions that contradict the TruthSet (union-norm reduction via `Basis.disjunction()`). `0.0` disables. |
| `maskRate` | float | `0.15` | Within-sentence IR Bernoulli mask rate. BERT default 0.15. |
| `trainEmbedding` | string | `"NONE"` | Embedding update mode: `NONE`, `CBOW`, `SBOW`, `BACKPROP`, `BOTH`, `JOINT`. See table below. |
| `embeddingScale` | float | `0.25` | JOINT-mode embedding loss weight $\lambda$: $\mathcal{L}_{\text{total}} = \mathcal{L}_{\text{model}} + \lambda \cdot \mathcal{L}_{\text{emb}}$. Ignored by other modes. (Older docs called this `trainEmbeddingRatio`.) |
| `autoload` | bool | `true` | Load weights from `weightsPath` at construction. Stale incompatible checkpoints fail fast. |
| `autosave` | bool | `false` | Save weights after training completes. |
| `checkpointEveryBatches` | int | `0` | Save mid-training checkpoint every N optimizer steps. `0` disables periodic checkpoints. |
| `profile` | bool | `false` | cProfile the training loop. |
| `certainty` | bool | `false` | Per-neuron certainty tracking in ergodic layers. Allows individual neurons to transition exploration $\to$ exploitation at different rates. |
| `sentenceExpectation` | bool | `true` | Enables automatic structured expectation and observed residuals. Explicit `false` bypasses the cycle while understanding and the single What memory remain available. Replaces `sentencePrediction`. |
| `sentenceExpectationScope` | string | `structured` | Predict distinct NP1/VP/NP2 vectors and occupancy from the bounded chronological observation context. `root` selects the historical single-vector benchmark. |
| `armaScale` | float | `0.0` | Loss weight for the ARMA sentence-prediction MSE. |
| `expectationGain` | float in `[0,1]` | `1` | Seal-only per-role negative image gain. Zero conceives the raw observation while leaving prediction loss and gradients unchanged. |
| `expectationPolicyWeight` | nonnegative float | `0` | Residual policy credit on the ordinary chooser before an incoming batch; requires `arma` in `<thought>` and owned LTM occurrences. Independent EMA baseline, detached trajectory replay. See [ExpectationRetention](ExpectationRetention.md). |
| `expectationQueryBudget` | nonnegative integer | `64` | Shared work allowance for each optional anticipatory episode. Later packed slots use prediction without an optional query episode. |
| `intraLossWeight` | float | `0.1` | Loss weight on the in-STM next-idea term $\mathcal{L}_\text{intra} = \mathrm{MSE}(\hat{c}_t, c_t)$ from `IntraSentenceLayer` (owned by ConceptualSpace), added to the IR-loss path. `0` disables. See [STM.md Section 6](STM.md#6-intrasentencelayer). |
| `interLossWeight` | float | `0.1` | Weight on role MSE, role-presence binary cross entropy and clause-kind binary cross entropy (`structured`), or root MSE (`root`). Uses a bounded row/document observation view: current-step source context can train its encoder, targets/durable history are detached. Consumed alongside Teacher reconstruction; `0` disables. See [STM.md Section 11](STM.md#11-inter-sentence-prediction). |

Gradient-balance defaults and validation are implemented in
[Models.py](../bin/Models.py), with the numerical contract in
[Optimizer.py](../bin/Optimizer.py). The inter-sentence training gate
is in [Models.py](../bin/Models.py).

#### `<trainEmbedding>` --- Embedding Update Modes

| Value | Embedding method | Model layers | Gradients through codebook |
|-------|------------------|--------------|---------------------------|
| `NONE` | Frozen | Trained | No |
| `CBOW` | CBOW (padded context) | Trained | No |
| `SBOW` | SBOW (leave-one-out centroid) | Trained | No |
| `BACKPROP` | Backprop only | Trained | Yes |
| `BOTH` | SBOW post-batch | Trained | Yes (two optimizers) |
| `JOINT` | Single backward | Trained | Yes ($\mathcal{L}_{\text{total}} = \mathcal{L}_{\text{model}} + \lambda \cdot \mathcal{L}_{\text{SBOW}}$) |

---

### `<architecture><server>`

HTTP server settings (used by `serve.py`).

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `host` | string | `"127.0.0.1"` | Bind address. |
| `port` | int | `8001` | Port. Override per model to run several in parallel. |
| `timeout` | int | `120` | **Unparsed**: declared in `data/model.xml`, read by nothing — `serve.py` reads only `host` and `port` from this block. |

---

## BasicModel / MentalModel Quick Reference

The two configurations that train the full P$\to$C$\to$S pipeline:

```xml
<architecture>
  <truthBiasScale>0.1</truthBiasScale>
  <LuminosityWeight>0.1</LuminosityWeight>
  <UniversalityWeight>0.1</UniversalityWeight>
  <subsymbolicOrder>1</subsymbolicOrder>
  <monotonic>false</monotonic>
</architecture>

<training>
  <TruthLoss>0.0</TruthLoss>
</training>
```

The grammar section of `MentalModel.xml` declares `lift` as an SS
binary rule:

```xml
<S>lift(S, S)</S>      <!-- lift is binary; SVO is assembled by
                            the chart-compose path S -> S VO,
                            VO -> V O, not a ternary lift -->
```

Transitive SVO is produced compositionally via typed grammar rules such
as `S -> S VO` / `VO -> V O`, or via STM `ParseState` extraction for
a subject lift over a transitive verb-phrase derivation. Grammar mode is
derived from the loaded grammar.

---

## Space sections

Every space block uses the same sentinel convention:

- `nInput = 0` --- InputSpace: derive from `TheData`; other spaces: derive from the previous space's `outputShape[0]`.
- `nOutput = 0` --- same as `nInput` for this space (passthrough count).
- `nVectors = 0` --- same as `nOutput` (used for non-codebook spaces).

Per-Space `<nWhere>` / `<nWhen>` declarations were retired on
2026-05-28 (see top-of-file note); the per-Space defaults live in
`data/model.xml` and don't need re-declaration in per-experiment configs.

### `<InputSpace>`

Lifts raw data into the model's internal representation.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `nOutput` | int | sentinel | Sequence length: max tokens per input. For XOR: 2. For text models, OOV words are spelled out as individual characters, so a single word may consume multiple slots --- a short sentence with many OOV words can exceed this limit and trigger a truncation warning suggesting a lower `<minFrequency>`. |
| `nDim` | int | `9` | Per-vector muxed EVENT width; content $\mathrm{nWhat} = \mathrm{nDim} - \mathrm{nWhere} - \mathrm{nWhen}$. Default 9 = 1 content + 4 `.where` + 4 `.when`. |
| `nInputDim` / `nOutputDim` | int | `0` | Raw shape hints. `0` defers to the loader's native dim. |
| `nVectors` | int | sentinel | Codebook size. Defaults to `nOutput`. |
| `codebook` | mode | `none` | `none`, `quantize`, or `project`. Legacy `true`/`false` are accepted as `quantize`/`none`. |

> **`<lexer>` moved to `<WholeSpace>`** (Phase 4b of the
> analysis/synthesis dual-input plan, rev. 2026-06-09): lexing is analytic
> CUTTING, owned by the analysis side. An InputSpace-side `<lexer>` now
> fails schema validation and the runtime reader. InputSpace emits the
> dual view — `forward(x) -> (percepts_in, concepts_in)`: the atom view
> (content `[B, N, 1]`) for the perceptual branch and the unity view
> (`[B, 1, N]`) for the symbolic branch.

`inputShape` uses the data's native dim (e.g. 784 for MNIST,
`inputLength` for text); `outputShape` uses `nDim` from
`TheObjectEncoding`. `LiftingLayer` bridges the two.

### `<PartSpace>`

Synthesizes recurrent ordered groups from existing parts. A group's
distributed code is the max of its constituent codes; the ordered
containment read retains the distinction between anagrams. Native
PartSpace has no `SigmaLayer` or `PiLayer`.

The current BasicModel configuration reserves 32,768 part rows. That is a
small-run setting, not a capacity estimate for the million-sentence corpus.
Rows store admitted parts, so sentence count alone does not determine the
required number. Item 3 must measure part admission on the target corpus,
raise this reserve, and record the resulting memory cost before the full run.
If the reserve fills, training stops with a capacity error; it cannot grow the
table while an optimizer owns it.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `nOutput` | int | sentinel | Number of active perceptual feature vectors. Should be $\geq$ `InputSpace.nOutput`. For XOR: 4. |
| `nDim` | int | `9` | Per-vector muxed EVENT width; content $\mathrm{nWhat} = \mathrm{nDim} - \mathrm{nWhere} - \mathrm{nWhen}$ (default 9 = 1 + 4 + 4). |
| `nVectors` | int | sentinel | Fixed physical percept-codebook capacity. Logical admission writes unused rows without changing tensor shape or optimizer ownership. Exhaustion raises an error naming this knob. Serial attention may select `nOutput` rows; parallel attention reads all active percepts. |
| `invertible` | bool | `false` | Space construction flag; native reconstruction uses retained ordered perceptual views and canonical part ids, without an inverse fold. |
| `hasAttention` | bool | `false` | DEPRECATED and INERT: the legacy boolean no longer constructs a QKV attention pass; it is kept only as a backward-compat alias. Superseded by `<attention>` (off / primer / second-order / low-rank). |
| `nonlinear` | bool | `true` | Tanh-bound output to $[-1, 1]$. |
| `synthesis` | string | `"lexicon"` | Bottom-up synthesis strategy (renamed from `<chunking>`, which is rejected loudly). `meronomy` is the only canonical mode: the PartSpace fold ladder (doc/plans/2026-09-10-meronomy-fold-ladder.md; until its Phase 1 lands it is backed by the radix store). `lexicon`, `bpe`, `mphf`, `byte`/`none` and `radix` are legacy front ends selected through `Legacy.py`. `analyse` was removed from PartSpace; top-down cuts live on WholeSpace `<analysis>`. |
| `butterfly` | bool | — | Deprecated per-space alias for the architecture-level `<sigmaPi>` enum. It does not construct a fold in native PartSpace; grammar lift/lower own their operators. |
| `wordLearning` | int | `2` | Active lexicon-growth mode. `0` = frozen codebook; `>=1` = on first sight of a new word, insert into the lexicon and tag it on the meronomy. Several trained configs override this to `0` or `1`. |

The PS `<codebook>` element was retired (the percept prototypes live on the
`.what` basis; radix's PerceptStore IS the surface codebook). See
[Architecture.md](Architecture.md) and [Philosophy.md](Philosophy.md) for
the analysis/synthesis orientation.

### `<ConceptualSpace>`

Order-0 concepts read their signed weights over native feature memberships.
PartSpace supplies located parts; WholeSpace supplies pervading properties.
The concept unions alternative percept conjunctions within an occurrence;
readout unions occurrences inside the subject's extent. The projection
admission parameter and its calibration are removed. `conceptUseFloor` remains the separate discovery
gate over measured use.

Holds the conceptual dictionary, location-aligned PS/WS binding state, and
short-term memory. Located pi is performed in the order-0 field, and sigma
unions symbols at higher orders. Grammatical lift/lower own their chart maps.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `nOutput` | int | sentinel | Active concept vectors. For XOR: 3. |
| `nDim` | int | `9` | Per-vector muxed EVENT width; content $\mathrm{nWhat} = \mathrm{nDim} - \mathrm{nWhere} - \mathrm{nWhen}$ (default 9 = 1 + 4 + 4). |
| `nVectors` | int | sentinel | Physical conceptual-codebook capacity. ConceptualSpace owns concepts, META relations, and taxonomy. Aligned property-basis stages share one table; order is metadata, not a row partition. This value is independent of `WholeSpace.nVectors`, PartSpace's physical capacity, live `nOutput`, SymbolSpace references, and STM capacity. |
| `invertible` | bool | `false` | Space construction flag. Aligned native binding retains both perceptual views for reconstruction; ConceptualSpace owns no unary chart fold. |
| `hasAttention` | bool | `false` | DEPRECATED and INERT: no longer constructs an attention pass in conceptual processing; kept only as a backward-compat alias. Superseded by `<attention>` (off / primer / second-order / low-rank). |
| `nonlinear` | bool | `true` | Tanh-bound output to $[-1, 1]$. |
| `codebook` | mode | `none` | `none`, `quantize`, or `project`. |
| `butterfly` | bool | — | **Silently ignored**: ConceptualSpace never reads a per-space `<butterfly>` — only PartSpace and WholeSpace carry the per-space read (the deprecated alias for architecture-level `<sigmaPi>`). A `<ConceptualSpace><butterfly>` element in a config has no effect. |
| `stmCapacity` | int | `8` | STM ring depth (within Miller's $7 \pm 2$ band). Per-batch buffer `[B, stmCapacity, nDim]` + depth pointers `[B]`. |

> `ConceptualSpace` owns definitions, evidence and STM/event state. The
> former per-stage `sigma_in` / `sigma_cs` layers are retired and no longer
> constructed on the live path. On aligned BasicModel, native PS
> and WS views bind by location and actual concept order is explicit
> metadata; symbolic generalization remains a separate phase.

### `<WholeSpace>`

On the canonical `propertyBasis` / `analysis=meronomy` path, each property
owns 256 learned primitive memberships alongside its distributed code.
A-priori byte examples teach the initial properties; runtime analysis reads
those parameters. Constant-signature runs keep their input brackets.
Word staging retains byte counts, and the compiled read evaluates the live
memberships. Native conceptual definitions read PartSpace containment and WholeSpace
pervasion from those memberships. The distributed codes serve similarity and
tied reconstruction, never conceptual presence. See [the membership design](Architecture.md#the-three-cognitive-operations-updated-for-11c).

The whole-percept/property side of perception and the home of top-down
analysis. WholeSpace owns primitive property memberships, the
`<analysis>` division knob, and the `<lexer>` compatibility knob. It is
upstream of ConceptualSpace and SymbolSpace and therefore owns no concept,
META, taxonomy, or symbol-prototype inventory. See
[Philosophy.md](Philosophy.md) for the design.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `nOutput` | int | sentinel | Number of simultaneously live whole-percept locations. This is a field width, not a property-inventory or symbol count. |
| `nDim` | int | `0` | Width of one whole-percept/property vector. `0` inherits the preceding compatible event width. |
| `nVectors` | int | sentinel | Fixed physical whole-percept/property capacity. BasicModel starts with eight ASCII-class properties; further admission uses unused rows inside the declared nVectors and is independent of both `ConceptualSpace.nVectors` and live `nOutput`. |
| `propertyBasis` | bool | `false` for legacy configs; `true` in BasicModel | Selects the migrated property-only ownership contract. When true, `subspace.what` is the sole WS codebook, `analysis_store`/`type_subspace` are absent, `activeVectors` does not couple to CS, and `nSymbols` remains a downstream alias of conceptual capacity. The false path exists only for unmigrated fixtures/checkpoints. |
| `codebook` | mode | `quantize` | `none`, `quantize`, or `project` for the property-percept basis. It never selects a concept or symbol codebook. |
| `analysis` | string | `"byte"` | Top-down division over the unity view. `meronomy` is the only canonical mode: the WholeSpace descending ladder (doc/plans/2026-09-10-meronomy-fold-ladder.md; until its Phase 2 lands it is the type-run cut). `byte`, `raw`, `sentence` (no division) and `word`, `grammatical` (the type-run cut) are legacy cuts dispatched through `Legacy.py`. The old `analyse` spelling is not accepted by the schema. |
| `lexer` | string | — | DEPRECATED spelling: the reader prefers the newer `<analyzer>` spelling, falling back to `<lexer>`; **both are deprecated in favor of the unified `<analysis>` knob** (its lexer-valued options `raw`/`byte`/`word`/`sentence` set the intake; `grammatical`/`meronomy` leave the lexer at `raw`). Intake granularity InputSpace executes; moved here from `<InputSpace>` (Phase 4b: lexing is analytic cutting — an InputSpace-side `<lexer>` is rejected loudly). |
| `nonlinear` | bool | `true` | Tanh-bound the activation. |
| `sortNetwork` | bool | `false` | Bitonic-sort regularizer on the codebook ordering. |
| `sortPasses` | int | `0` | Sort-network depth. `0` disables. |
| `l1Lambda` | decimal | `0.01` | L1 sparsity penalty on the symbolic activation. |
| `symbolResidualScale` | decimal | `1.0` | Symbol-residual injection scale (legacy mereology hook). |
| `outputSymbolResidualScale` | decimal | `0.0` | Output-side symbol-residual injection scale. |
| `commitmentBeta` | float | `0.25` | Space-level VQ-VAE commitment-loss $\beta$. **Asymmetric dispatch (2026-06-10)**: on the PARALLEL leg this is now INERT — the dispatch rewrite retired the space-level commitment, the VQ-internal cb_commit, and the nearest-target `symbol_residual` pull (the recon gather + STE carry the two asymmetric legs; the codebook is gradient-trained, `vq.ema_update = False`, `vq.commitment_weight = 0`). The SERIAL/grammar leg keeps the legacy coupling (this $\beta$ included) behind an explicit gate until its own asymmetric recon leg lands (D-territory). |
| `semanticArrangement` | float | `0` | Task 5 (C-13): post-sentence semantic arrangement over SS heat — pode (activated-rows centroid attraction) + antipode (rest-of-codebook repulsion), gradient on the active rows only. `0` = OFF (the default); the semantic payoff is validated under D, not XOR. |
| `decorrelationWeight` | decimal | `0.0` | `ImpenetrableLayer` decorrelation regularizer on codebook rows. |
| `spectralFlatnessWeight` | decimal | `0.0` | `ImpenetrableLayer` spectral-flatness regularizer. |
| `truthCriterion` | retired | — | Removed from the XML schema with `truth_criterion` and the relation learn-score gate. Every completed grammatical S reaches the shared seal; external provenance and later evidence determine its independent poles. |
| `trust` | unitInterval | `1.0` | **Architecture-level only** — model-level multiplier for incoming provenance. Runtime `store_truths` and static `<truthSet>` inputs supply the outer assertion through the shared clause seal. Positive and negative evidence remain separate; embedded registration grants no assertion authority and sentence content never sets its own trust. |

WholeSpace owns primitive property memberships and the native analysis
policy. It allows primitives by max and computes pervasion by min over
observed positions. It has no `PiLayer` or inverse fold. Conceptual pi
is restricted to the order-0 attentive field; grammatical operators own
their parameters independently of either perceptual tower.

### `<OutputSpace>`

Maps symbols to final predictions, or reads named conceptual positive poles.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `conceptIds` | string | (empty) | Space-separated persistent concept ids. The bound native field resolves each id per batch and reads its positive pole as one scalar in `[0,1]`; no linear projection, bias or output denormalization is applied. Requires a native conceptual field. |
| `nOutput` | int | sentinel | Output values. For XOR: 1. |
| `nDim` | int | `1` | Per-output dim. |
| `nVectors` | int | sentinel | Codebook size. Defaults to `nOutput`. |
| `invertible` | bool | `false` | Rarely set on OutputSpace. |
| `codebook` | mode | `none` | `none`, `quantize`, or `project`. |
| `nonlinear` | bool | `false` | OutputSpace is linear by default; rescales via `Data.denormalize`. |
| *(readout — retired 2026-06-19)* | — | — | The OutputSpace regression head (backlog #11): with `nVectors == 1` (or no codebook) it is an unquantised linear `nInputDim -> nOutputDim` plus a learned scalar intercept. The former `<readout>` enum (`identity` \| `sigmoid`) was retired — the unbound regression head is linear+bias. Named concept outputs read native evidence instead. Ignored by quantised heads. |

`LinearLayer` with `(bias, temp)` support for ergodic mode.

---

## `<SymbolSpace>`

Grammar infrastructure (SyntacticLayers, TruthLayer). Lives outside
`<architecture>` as a top-level sibling.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `syntacticHiddenDim` | int | `64` | SyntacticLayer MLP hidden size. |
| `truthMaxEntries` | int | `1024` | TruthLayer SS-codebook capacity. |
| `ltmCapacity` | int | `1024` | Long-term-memory (LTM) chain capacity on `InterSentenceLayer`: the per-row bounded `deque` of STM end-states (the AR sequence feeding inter-sentence prediction) is capped at this many entries. Also sizes the model's shared `.when` ladder. Item 3 must set it for the intended million-row run and record the resulting clock range. Separate from `truthMaxEntries`. See [STM.md Section 10](STM.md#10-ltm-as-the-chain-of-stm-end-states). |
| `parserBackend` | — | — | RETIRED (Stage 3 cleanup, 2026-05-27): the chart backend is gone and the signal router (`LanguageLayer`) is now the sole, fixed parser. The element is rejected — leaving it in an XML config raises a loud `ValueError` at load time (`Language._assert_retired_chart_knobs_absent`). |
| `routerKind` | — | — | RETIRED (Stage 3 cleanup, 2026-05-27): there is no longer a selectable router; the signal router is fixed. Rejected with a loud `ValueError` if present in a config. |
| `chartCollapse` | string | `"root"` | **Unparsed**: declared in `data/model.xml` / the schema, read by nothing in `bin/` (the writeback contract it described rode out with the chart). |
| `chartTau` | — | — | RETIRED (Stage 3 cleanup, 2026-05-27) alongside the chart. Rejected with a loud `ValueError` if present in a config. |
| `wMax` | — | — | RETIRED: the legacy STM-capacity alias is no longer read. STM depth comes from `<stmCapacity>` (or the `DEFAULT_CAPACITY = 8` fallback). A config that still sets `<SymbolSpace><wMax>` now raises a loud `ValueError`. |
| `chartTopK` | — | — | RETIRED (Stage 3 cleanup, 2026-05-27) alongside the chart. Rejected with a loud `ValueError` if present in a config. |
| `chartNoiseEps` | — | — | RETIRED (Stage 3 cleanup, 2026-05-27) alongside the chart. Rejected with a loud `ValueError` if present in a config. |
| `iterationsPerWord` | int | `1` | **Unparsed**: declared in `data/model.xml` / the schema, read by nothing in `bin/`. |
| `downwardGeneration` | bool | `false` | Emit a codebook head via `SymbolSpace.reconstruct()` and stash on `self._predicted_head`. |
| `language.interpretation` | float | `0.5` | Soft-interpolation weight between forward and generation directions. |

The `<language><grammar>` block contains space-role-scoped rules in
`<compose>` and `<generate>` sections, each holding `<percepts>` /
`<concepts>` / `<symbols>` sub-blocks of `<rule>` elements. Per the
2026-05-07 rollback, the grammar XML is the sole source of truth for
which rule fires at each space-role (no code-level `default_rule` fallback).
Legacy bare-space-role elements like `<P>P = sigma(P)</P>` directly under
`<grammar>` are still accepted.

---

## Additional parsed knobs (2026-07 audit)

Knobs that are parsed and live in `bin/` but were previously undocumented
here. Every default below was verified against its read-site; `data/model.xsd`
carries the full schema commentary. Site names are module + owning
symbol (line anchors drift).

### `<architecture>` level

| Knob | Where read | Default | Purpose |
|------|-----------|---------|---------|
| `meronomy` (attr `dMaxStable`) | `Layers.py` (`meronomy_enabled` / `meronomy_d_max_stable`) | code `off`; `data/model.xml` ships `on` with `dMaxStable="4.0"` $\Rightarrow$ effectively **ON** | Binds the meronymic slots (PS.sigma / WS.pi) directly to `[0,1]` membership kernels; `dMaxStable` bounds the complete learned fold's inverse gain. |
| `sigmaPi` | `Models.py` (BaseModel init) + `Spaces.py` (PS/WS fold builders) | `butterfly` | Fold span enum `last` \| `butterfly` \| `full`; the per-space `<butterfly>` boolean is its deprecated alias (PS/WS only). |
| `conceptBinding` | `Models.py` (serial word loop) + `Spaces.py` (`ConceptualSpace`) | `mixing`; BasicModel sets `aligned` | Selects historical learned mixing or strict same-location fusion over all non-raw PS/WS folds. |
| `syntacticOrder` | `Models.py` (BaseModel init) | `0` | Parse-tree depth cap for the serial reduce sweep; `0` = unbounded. Inert in parallel mode. |
| `sentenceProtocol` | `Models.py` (BaseModel init) | = `serial` | Whole-sentence gist prelude (parallel `subsymbolicOrder` pumps, intent-only commit) before the serial per-word loop. |
| `truthSet` (`<truth>` rows: text, `trust` / `kind` attrs) | `Models.py` (`provision_ltm`) | (none) | Config-provisioned trusted truths run through the real forward and appended to the consolidated LTM at load; row trust $\times$ `architecture.trust`. Admitted by the shared grammatical clause seal with external provenance. |
| `thinkingBudget` | `Models.py` (BaseModel init; `think_about`) | `0` | Shared work allowance for the explicit `think_about` API on the normal grammatical controller. Choices, reads, traversal and child execution all spend it; `0` disables this API. It adds no second result to `answer_query`. |
| `answerSynthesis` | `Models.py` (BaseModel init; `what()` / `reverseOutput()`) | `false`; `data/BasicModel.xml` ships `true` | Resolve the owned row program into full-width conceptual ideas, apply thinking and one conceptual conditioner, and realize the answer through the selected output mode ([Models.py](../bin/Models.py), [Models.py](../bin/Models.py)). Without `outputInLoop`, concepts enter `ConceptualSpace.synthesize_idea`, the shared reverse body and perceptual inverse, dedicated perceptual synthesis, then `OutputSpace.from_percepts`. New adapters use the forward-equivalent rectangular LDU readout over all generated percept coordinates; old checkpoint adapters keep their layout ([Spaces.py](../bin/Spaces.py)). Topologies without row programs retain dense synthesis compatibility. Training scores only separately supplied desired answers; automatic temporal targets remain evaluation metrics ([Models.py](../bin/Models.py)). |
| `synthesisBindings` | `Models.py` (`_select_perceptual_bindings`) | `0`; BasicModel `4` | Number of most-salient perceptual context slots a derivation may NAME as bindings for answer synthesis; they ride in the derivation trace. `0` keeps perceptual context out of the answer. |
| `whatCurriculum` | `Models.py` (`_curriculum_questions`) | `none`; BasicModel `full` | `none` \| `present` \| `temporal` \| `full`: a Bresenham fraction (`whatCurriculumRatio`) of training batches asks past/future (`temporal`) or also inference (`full`) questions instead of the default family. `none` is byte-identical. |
| `whatCurriculumDistance` | `Models.py` (`_curriculum_questions`) | `1` | Presentation offset of the past/future curriculum questions. |
| `whatCurriculumRatio` | `Models.py` (`_curriculum_questions`) | `0.25` | Fraction of training batches that are curriculum trials. |
| `whatThinkingDetach` | `Models.py` (`_what_memory` applies it to the slot owner) | `slot` | Episode credit boundary (mathematical thinking spec 8.2): `slot` detaches every interaction value at append (established); `episode` keeps values appended between `begin_what_episode` / `end_what_episode` live until the episode ends. |
| `whatThinkingIterations` | `Models.py` (compatibility configuration) | `1` | Retained configuration metadata and optional serving-summary gate; `think()` performs one presentation and the normal controller uses `selectedThoughtBudget`. The lexical ANSWER/OPEN parity selector is retired. `whatThinkingPrimitives` remains rejected at load. |
| `whatThinkingPressure` | `Models.py` (`_thinking_pressure`) | `linear` | Retained numerical schedule utility (`linear`, `quadratic`, `step`). The normal controller derives pressure from shared work; this setting does not change its execution. |
| `reasoningIterations` | `Models.py` (BaseModel init; public reasoning APIs) | `1` | Shared work allowance for explicit `reason_about` / `answer_query`; `0` disables those APIs. Normal `resolveAnswer` uses `selectedThoughtBudget`. A selected completed meaning grants execution; raw prompt words do not. |
| `queryReasoning` | `Models.py` (BaseModel init) | `false` | DEPRECATED alias: `true` $\Rightarrow$ `reasoningIterations = 10`. Read only when `<reasoningIterations>` is absent. |
| `ltmConsolidation` | retired compatibility input | ignored | The shared `TernaryTruthStore` is unconditional; this input selects no alternate path. |
| `stateless` | `Models.py`, `Language.py` | `true` | Request-scoped user TruthSet rows: on state-dict load the consolidated LTM is revived without `ORIGIN_USER` rows. `false` = stateful deployment. |
| `globalAttention` | `Models.py` (BaseModel init) | `false` | Typed addressable attention over input window / STM / LTM / codebook; the soft-read is parked on `_global_attention_obs`. |
| `globalAttentionConsume` | `Models.py` (BaseModel init) | `false` | Feeds the parked soft-read back into the head (`Finish`) as a zero-init gated residual. Requires `<globalAttention>`. |
| `readingAttention` | `Models.py` (BaseModel init) | `false` | Learned `.where` scope producer at each $t>0$ subsymbolic pass (feeds the `<mereologyRaise>` handoff). |
| `relevance` | `Models.py` (BaseModel init) | `false` | Relevance-integration gate (Architecture.md sec C). |
| `primingDecay` | `Models.py` (BaseModel init) | `0.9` | Priming-energy decay per prime event. |
| `primingSpread` | `Models.py` (BaseModel init) | `0.25` | Fraction of a connected row's standing energy diffused to neighbors per prime event (live by default; `0` = pure decay+bump). |
| `serialWordCapacity` | `Models.py` (BaseModel init) | legacy fallback: `stmCapacity` | Hard maximum surface words staged for one outer serial loop. Independent of PS/WS/CS field width and STM depth; BasicModel sets 256 while keeping those fields/workspace at 8. The tensor loop executes only through the final live column. |
| `serialResidualPartCapacity` | `Models.py` / `InputSpace` | `16` | Fixed compiler-visible integer radix/subword-ID extent for one cold spelling. It is not a dense percept-vector axis; the masked PS fold reduces those IDs into PS's configured live field. BasicModel uses 64. |
| `serialWordBuckets` | `Models.py` / `InputSpace` | one bucket equal to `serialWordCapacity` | Comma-separated staging capacities. The largest value must equal `serialWordCapacity`; an overlong sentence fails rather than clipping. BasicModel uses only `256`, because its compiled `torch.while_loop` has a runtime trip count and therefore needs neither padding execution nor separate 16/32/64/128 graphs. Multiple buckets remain a compatibility/performance option for the static scheduler. |
| `radialStmReduce` | `Models.py` (`_create_per_stage`) | `false` | STM idea folds use the radial (signed-safe) radmin/radmax kernels. |
| `symbolicPriming` | `Language.py` (`attach_knowledge` $\to$ `configure_priming`) | `false` | Taxonomy forward heat production (symbolic-heat retrieval). |
| `symbolTower` | `Models.py` (BaseModel init) | `false` | 3-stream CS bind (PS + WS + SS): SymbolSpace becomes the symbol tower with its own codebook stream. |
| `serialObjectMeta` | `Models.py` (BaseModel init) | `false` | Serial word-loop mereology path: InputSpace presents every residual constituent of word $w$, PartSpace sigma-synthesizes it inside iteration $w$, all configured PS/WS folds bind by location in CS, and exactly one actual-order word concept commits to STM. Legacy non-word-major inputs retain the hard same-word-span fallback. |
| `conceptIndexRead` | `Models.py` (BaseModel init) | `false` | Serial per-word idea reads through the index to the concept's `similarity_codebook` row instead of the computed percept-binding event. |
| `ideaDecode` | `Models.py` (BaseModel init) | `false` | Chart-free reverse: generate the surface from the idea alone (no `generate_rules` rebuild). |
| `verbSpectrum` | `Language.py` (`LiftLayer` init) | `false` | Verb eig-spectrum operator on the composed VP (VP parameterization). |
| `predictionTrialRatio` | `Models.py` (ModelLoss wiring) | `0.0` | Fraction of training batches run as pure next-idea prediction (recon terms zeroed). |
| `overlapWhereTiling` | `Models.py` (BaseModel init) | `false` | Experimental overlapping PS/WS `.where` lattice; requires `<mereologyRaise>true</mereologyRaise>` (loud `ValueError` otherwise). |
| `continuityNorm` | `Mereology.py` (contemplative mixin) | `'inf'` | Norm for the continuity measure (`'l2'` available). |
| `continuityRatioTarget` | `Mereology.py` | `1.0` | Target ratio for the continuity measure. |
| `continuitySharpness` | `Mereology.py` | `1.0` | Sharpness of the continuity squash. |
| `TetralemmaPolicy` block (+ per-space `tetralemmaOverride`) | `util.py` (`tetralemma_policy`) | `allowExcludedMiddle=1`, `allowContradiction=0`, `neitherThreshold=0.1` | Shared catuskoti policy under `<architecture>`; a space sets `<tetralemmaOverride enabled="true">` + its own `<TetralemmaPolicy>` to override. Legacy top-level `<TetralemmaPolicy>` still read as fallback. |

### `<architecture><training>` level

| Knob | Where read | Default | Purpose |
|------|-----------|---------|---------|
| `seed` | `Models.py` (run entry; env `BASIC_SEED` overrides) | unset | RNG pin (torch/python/numpy) for reproducible single-CLI runs; the `XOR_exact` gates rely on it. |
| `answerLossWeight` | `Models.py` (BaseModel init) | `0.0` | Retired; nonzero values are rejected. Use the one `selectedThoughtPolicyWeight` objective. |
| `predictNextLossWeight` | `Models.py` (BaseModel init) | `0.0` | Retired; nonzero values raise at configuration load. The separate next-idea proposal/scoring route is deleted. |
| `thinkingLossWeight` | `Models.py` (BaseModel init) | `0.0` | Migration alias for `selectedThoughtPolicyWeight`; the maximum of this, `whatThinkingPolicyWeight` and the selected weight enables one normal controller objective. No trace-cloning head remains. |
| `whatThinkingPolicyWeight` | `Models.py` (BaseModel init) | `0.0` | Migration alias for the one `selectedThoughtPolicyWeight` objective. The former parity policy and its separate report/credit path are retired. |
| `selectedThoughtPolicyWeight` | `Models.py` (`_selected_thought_policy_loss`, runBatch hook) | `0.0` | One normal controller REINFORCE term: `G = -L_answer - 0.01 * actual_shared_work`, including all child/read costs, with one EMA baseline. Positive values sample during training. Only eligible supplied-answer rows receive credit; reports use `what_report()["policy"]["selected_thought"]`. Residual policy credit remains separate work. |
| `branchDiagnosticsEvery` | `Models.py` (BaseModel init; `branch_gradient_diagnostics`) | `0` | Every N training batches, log state-branch norms plus weighted reconstruction/output/expectation norms and cosines per shared operator (codebooks excluded). Checkpoint the negative-cosine streak; unused samples preserve it. Diagnostic failures warn and never stop training. `0` = off; BasicModel uses `100`; the supplied-answer tied benchmark uses `1`. See [GradientFlow](GradientFlow.md). |
| `leafDistillWeight` | `Models.py` (BaseModel init) | `0.0` | With `detachedReverse`, weight the reverse chooser's bounded exact-leaf surface term. Explicit legacy D3 mode uses the standalone root-to-leaf distillation head. Tied reconstruction suppresses that independent head regardless of this weight. |
| `interContrastiveWeight` | `Models.py` (ModelLoss), `Language.py` (discourse layer) | `0.0` | InfoNCE next-idea contrastive term weight; `0` = MSE-only. |
| `interContrastiveTemp` | same | `0.1` | InfoNCE temperature. |
| `conceptualSimilarityScale` | `Models.py` (ModelLoss wiring) | `0.0` | Legacy autograd SBOW weight for non-serial experimental configurations. It cannot be combined with `conceptualContextLearningRate`. |
| `conceptualContextLearningRate` | `Models.py` (BaseModel init) | `0.0` | Detached post-sentence update rate for the shared serial ConceptualSpace dictionary. Positive values convert `similarity_codebook.W` from its construction Parameter into a persistent non-grad buffer, then rotate reduced contextual evidence directly on its initial unit sphere. |
| `conceptualContextNegatives` | `Models.py` (BaseModel init) | `4` | Deterministic negative rows per observed concept in the context-owned SBOW reducer. |

### `<architecture><data>` math dataset

| Knob | Default | Purpose |
|------|---------|---------|
| `mathStage` | `1` | `0` = direct arithmetic (`a op b` in, its value out, split by unseen pairs); `1` = dependency chains; `2` = simultaneous linear constraints. |
| `mathOperators` | `add` | Stage-0 operators, comma list of `add` / `sub` / `mul`. |
| `mathRange` | `64` | `R`: answers are one-hot over `[0, R)`; `OutputSpace.nOutput` must equal it. |
| `mathDepths` / `mathTestDepths` | `1,2,3` / `4,5,6` | Trained / held-out chain depths (stage 1); comma lists (the XML loader evaluates `1-3`). |
| `mathDistractors` | `2` | Maximum distractor premises. |
| `mathSeed` / `mathProblems` | `0` / `256` | Generator seed and problem count (use thousands for stage 0). |

### Per-space

| Knob (space) | Where read | Default | Purpose |
|------|-----------|---------|---------|
| `attention` (PartSpace / ConceptualSpace / WholeSpace) | `Spaces.py` (each space init) | `off` | Symbolic-retrieval attention mode enum: `off` \| `primer` \| `second-order` \| `low-rank`. Replaces the inert `hasAttention` booleans. |
| `attentionPromotion` (ConceptualSpace) | `Spaces.py` (CS init) | `false` | Enable the row pool; its context/use parameters and `conceptualPi` also accept per-space overrides. |
| `wordStore` (PartSpace) | `Spaces.py`, `Language.py` | `false` | The percept store's WORD collection becomes the reverse recommenders' candidate basis. |
| `chunkPromotionThreshold` (PartSpace) | `Spaces.py` (PS init) | `4` | Radix chunk promotion: recurrence count bar on the PerceptStore gate. |
| `chunkPromotionMinLength` (PartSpace) | `Spaces.py` (PS init) | `2` | Radix chunk promotion: minimum chunk length. |
| `demuxed` (InputSpace) | `Models.py` (`_make_perceptual_space`) | `false` | Routes what/where/when through the demuxed `ModalSpace` composite instead of the muxed PartSpace. |
| `lrScale` (OutputSpace) | `Models.py` (`getOptimizer`) | `1.0` | Puts OutputSpace params in their own Adam group at `learningRate * lrScale`. |
| `definitionFreeSize` (ConceptualSpace) | `Spaces.py` (CS init) | `2` | Symbols a concept's definition may use for free (genus + differentia); the rank-ordered soft-L0 penalizes only surplus ranks. |
| `lbgThreshold` (WholeSpace) | `Spaces.py` (`record_lbg_pull` / `maybe_split_lbg`) | `0.5` | LBG auto-granularity: a WS row splits along its mean-displacement direction when the max per-coordinate assignment variance of the codes bound to it exceeds this (see Mereology.md, "Automatic analysis: dividing wholes"). Today gated off under `propertyBasis`; the fold-ladder plan lifts the gate. |
| `lbgMinCount` (WholeSpace) | same | `8` | LBG: minimum hit count before a row may split. |
| `lbgEpsilon` (WholeSpace) | same | `0.1` | LBG: split displacement magnitude. |
| `divideWithinWhole` (WholeSpace) | `Spaces.py` (WS init + tiling site) | `true` | Divides unattested type-runs into attested concepts by greedy longest-match tiling; explicit `false` keeps the undivided span. |
| `digitWholes` (WholeSpace) | `Spaces.py` (WS init + `stage_analysis_spans`) | `false` | Every digit byte is a whole by itself at the analysis cut (`12` -> `1`, `2`, each with its own `.where`), so the multi-digit numeral is a whole over digit parts rather than one type-run. Default off, byte-identical. |
| `boundaryTypes` (WholeSpace) | `Spaces.py` (WS init; `_build_boundary_predicates`) | `canonical` | Initialisation of the learned boundary weights over the atomic wholes (one column per byte value) and the property rows (fold-ladder plan, contract 3): `canonical` turns on the begins / ends of the whitespace, punctuation and pad rows and, under `digitWholes`, the digit row's atom level; `none` starts every weight off (the cold start is the atomic tiling). The weights are parameters (`begins_weight`, `ends_weight`, `atom_level`, logits thresholded at 0.5 in the cut). |
| `whitespaceUnits` (WholeSpace) | `Spaces.py` (WS init; `_predicate_masks`) | `false` | Present whitespace runs as units whose grammatical operation is `null` (the identity), instead of discarding them as a boundary-only class. |
| `boundaryLearningRate` (WholeSpace) | `Spaces.py` (`_update_boundary_predicates`) | `0` | Step of the boundary learner's score update at the presentation boundary: a property row's logit moves by the difference between its candidate tiling's score (recurrence of the wholes it yields minus the density penalty) and the current tiling's. `0` freezes the predicates. |
| `boundaryDensityWeight` (WholeSpace) | same | `0.05` | Weight of the wholes-per-presentation penalty in the boundary learner's score (the working-memory pressure). |
| `boundaryUpdateEvery` (WholeSpace) | same | `32` | Presentations accumulated before one boundary score update (recurrence is measured over that window, the epoch's counts of contract 4). |
| `boundaryTypeWeight` (WholeSpace) | same | `0.25` | Weight of the distinct-wholes-per-occurrence penalty in the boundary learner's score (the long-term-memory pressure: a tiling that memorises sentences pays here). |
| `utilitySmoothing` (ConceptualSpace) | `Spaces.py` (CS init; `category_utility`) | `1.0` | Laplace smoothing of the category-utility counts (doc/plans/2026-09-10-meronomy-fold-ladder.md, contract 4). |
| `utilityMinCount` (ConceptualSpace) | same | `4` | Minimum presentations of a concept before its utility is trusted. |
| `admissionCount` (ConceptualSpace) | same | `2` | Recurrences of a chunked phrase before it is admitted as a concept of its own (contract 7). |
| `admissionRadius` (ConceptualSpace) | `Spaces.py` (CS init) | `sqrt(lbgThreshold)` | Nearest-row identity radius for admission; defined from the LBG variance threshold (the standard deviation along the split axis) so one geometry setting governs identity and division; overridable. |
| `utilityPriorRate` (ConceptualSpace) | same | `1.0` | Step of the score update that moves the `chunk` structural prior by the admitted phrase's utility gain (contract 7); 0 freezes the prior. |
| `gradientMode` (WholeSpace) | `Spaces.py` (WS init) | `"ste"` | Codebook gradient coupling: `snap` \| `ste` \| `rotation` (invalid values raise). |
| `useStackRouter` (WholeSpace) | `Spaces.py` (WS init) | `false` | Gates WS's stack-rewrite LanguageLayer dispatch; `false` keeps the legacy forward path. |
| `initScale` (any space) | `Spaces.py` (`_read_init_scale`) | unset | Per-row seed magnitude for the space's codebooks; small values ($\approx 0.02$) keep the sigma/pi folds in their linear regime. Unset/0 = legacy unit prefill. |
| `impenetrableOverlap` (WholeSpace) | `Spaces.py` (WS init) | `0.0` | ImpenetrableLayer separation penalty on codebook rows: overlap scaled by the absolute trust difference (replaces the legacy antisymmetry+transitivity pair). |
| `impenetrableVariance` (WholeSpace) | `Spaces.py` (WS init) | `0.0` | ImpenetrableLayer variance regularizer. |
| `commitmentDecay` (PS/CS/WS) | `Models.py` (VQ override loop) | unset ($\to$ VQ default `0.9`) | VQ-VAE EMA decay override; higher = slower, more stable assignment. |
| `codebookEmaDeadThreshold` (PS/CS/WS) | same | unset ($\to$ VQ default: `1` if `codebookRetire` else `0`) | Dead-code retire: EMA `cluster_size` below this replaces the slot with a fresh row. |
| `codebookGrowthEpsilon` (PS/CS/WS) | same | `0.0` | Stashed as `vq.growth_epsilon`; `runBatch` consults it for codebook growth. |
| `activeVectors` (ConceptualSpace) | `Models.py`, `Layers.py` | `nVectors` | Initially selectable prefix of the physically preallocated shared conceptual codebook. Prefix growth updates a fixed-shape mask in place, so reserve activation cannot replace the optimizer-owned Parameter. WholeSpace properties use their own small inventory and lifecycle. |

### `<SymbolSpace>` level

| Knob | Where read | Default | Purpose |
|------|-----------|---------|---------|
| `armaP` | `Language.py` (InterSentenceLayer build) | `5` | ARMA AR order for inter-sentence prediction. |
| `armaQ` | same | `2` | ARMA MA order. |
| `armaHiddenDim` | same | unset (auto) | ARMA predictor hidden width. |
| `language.useGrammar` | `Language.py` (grammar load) | — | DEPRECATED: still read, but only to warn loudly and force `default.grammar`. |
| `language.start` | `Language.py` (grammar load) | `"S"` | Accepted completed-derivation shapes (start patterns); named starts tag `relative_truth` / `absolute_truth` sets. |

**Config-only orphan**: `useSubspaceActivation` appears in the schema and
in test fixtures (`test_basicmodel.py`) but is parsed nowhere in `bin/` —
setting it in a config has no effect.

---

## `InvertibleLinearLayer` (programmatic)

The LDU-factorised invertible linear primitive used internally by
`SigmaLayer(invertible=True)` and `PiLayer(invertible=True)`. Not set
via XML directly.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `naive` | bool | `false` | `false`: apply L, D, U sequentially via triangular solves (no $W$ materialisation). `true`: materialise dense $W_{\text{eff}}$ and the dense LDU inverse for the reverse pass. Slower; debug-only. |
| `stable` | bool | `false` | Clamps each diagonal entry $d_i$ to magnitude $[\epsilon, 1]$ with sign preserved before the ergodic blend. Keeps $W_{\text{eff}}$ bounded away from singularity. |
| `ergodic` | bool | `false` | Factor-level noise injection. Registers `noise_raw_L`, `noise_raw_U`, `noise_d` buffers; resamples at the start of each `forward()` and end of each `reverse()`. |

**Class renames and removals.**

| Old name | New name / status |
|----------|------------------|
| `LULayer` | Renamed to `InvertibleLinearLayer` |
| `InvertibleLinearLayer` (SVD-based) | Removed; replaced by LDU factorisation |
| `InvertibleSigmaLayer` | Merged into `SigmaLayer(invertible=True)` |
| `InvertiblePiLayer` | Merged into `PiLayer(invertible=True)` |

See [Architecture.md](Architecture.md) for the LDU factorisation and
factor-level noise injection.

---

## Example: XOR Configuration

```xml
<model>
  <architecture>
    <data><dataType>embedding</dataType></data>

    <training>
      <numEpochs>400</numEpochs>
      <learningRate>0.01</learningRate>
      <autoload>false</autoload>
      <trainEmbedding>JOINT</trainEmbedding>
      <embeddingScale>0.05</embeddingScale>
    </training>
  </architecture>

  <InputSpace>
    <nVectors>8</nVectors>
    <nDim>10</nDim>
    <nOutput>8</nOutput>
    <nOutputDim>10</nOutputDim>
  </InputSpace>

  <PartSpace>
    <nInput>8</nInput>
    <nVectors>1000</nVectors>
    <nDim>10</nDim>
    <nOutput>8</nOutput>
    <hasAttention>false</hasAttention>
    <invertible>true</invertible>
    <synthesis>lexicon</synthesis>
  </PartSpace>

  <ConceptualSpace>
    <nInput>8</nInput>
    <nVectors>8</nVectors>
    <nDim>10</nDim>
    <nOutput>8</nOutput>
    <invertible>true</invertible>
    <codebook>quantize</codebook>
  </ConceptualSpace>

  <WholeSpace>
    <nInput>8</nInput>
    <nVectors>8</nVectors>
    <nDim>2</nDim>
    <nOutput>8</nOutput>
    <codebook>quantize</codebook>
  </WholeSpace>

  <OutputSpace>
    <nOutput>1</nOutput>
    <nVectors>1</nVectors>
  </OutputSpace>
</model>
```

Everything not listed inherits from `data/model.xml`.

---

## Example: Embedding / Chatbot Configuration

```xml
<model>
  <architecture>
    <data>
      <dataType>embedding</dataType>
      <shardDir>data/fineweb</shardDir>
      <minFrequency>0.00001</minFrequency>
    </data>
    <weightsPath>BasicModel.ckpt</weightsPath>
    <embeddingPath>BasicModel.kv</embeddingPath>
    <training>
      <numEpochs>2</numEpochs>
      <batchSize>128</batchSize>
      <reconstructionScale>0.1</reconstructionScale>
      <trainEmbedding>BACKPROP</trainEmbedding>
      <autosave>true</autosave>
      <checkpointEveryBatches>500</checkpointEveryBatches>
      <sentenceExpectation>true</sentenceExpectation>
      <armaScale>0.1</armaScale>
    </training>
  </architecture>

  <!-- space definitions inherit from model.xml -->
</model>
```

Key points:

- `<data><dataType>embedding</dataType>` activates the embedding-based input pipeline alongside the neural model.
- `trainEmbedding=BACKPROP` trains model layers with gradients flowing through the codebook.
- XML config defines the architecture. `weightsPath` stores the neural model checkpoint.
- `minFrequency` gates vocabulary admission; words below it are buffered until they exceed the threshold.

### Consolidated evidence metadata (September 16)

The shared clause store persists role presence, grammatical mode, polarity,
evidence kind, stable occurrence identity and metadata fingerprints in the
existing truth store. Its structural sidecar retains bindings, scope,
constituent references and source text. This adds no configuration switch,
learned parameter or loss. Legacy conversation rows migrate as unverified;
missing required metadata cannot silently become empty scope.
[Store and migration](../bin/Layers.py),
[checkpoint sidecar](../bin/Models.py),
[details](ExistenceEvidence.md).

### Conceptual-taxonomy query bounds

The invocation reader defaults to 256 scanned concepts and 1024 native
reference records. Traversal defaults to 8 links and 1024 edge examinations;
public predicate evaluation uses `beam * max_steps` as its edge limit. These
are explicit call bounds, distinct from STM capacity or a shared episode
budget. Limits/unavailable references report incomplete evidence. No new
configuration switch, checkpoint schema or learned parameters were added.
[Capture](../bin/Taxonomy.py),
[traversal](../bin/Taxonomy.py),
[public evaluation](../bin/reasoning.py).

### Checked thought call bounds and native VP setup

`ThoughtGrammarContext` validates a row address and local limits: 256 concepts, 1024
records, 8 path steps and 1024 edge examinations by default. These are call
limits, not a new episode allowance; the selected normal controller supplies
its one episode meter when it invokes a completed grammatical question.
At explicit setup, each `<thought>`-selected executable operation/domain uses one
existing aligned concept row and named handle. No new parameter tensor or configuration switch
is introduced. A missing native binding cannot be lazily recreated by
candidate formation or execution.
[Context](../bin/Queries.py),
[setup](../bin/Queries.py),
[contract](QueryContracts.md).

### Ordinary thought-history bounds

`begin_thought_episode` takes an explicit `work_budget` (API default 32).
Every ordinary event charges positive work; pressure is cumulative and no child
gets a refreshed allowance. A cutoff permits only its bounded return drain and
one root finish. Capacity reserves those transitions and rejects eviction of
active or referenced records. `selectedThoughtBudget` wires this API into the
normal completed-grammatical-question controller; it forwards one meter and
records exact deltas. The separate policy weight remains default-off and is not
residual credit or learned-utility evidence. See [ordinary thought
history](ThoughtHistory.md).

### Query phase state

Query permission introduces no configured, learned, or checkpointed parameter.
The model initializes transient host flags before compilation; a resolution
temporarily identifies completed rows while sentence work disables execution.
No semantic feature contains these administrative flags. See
[Query phases](QueryPhases.md).

Item 7.5 retires `architecture.learning`, `exploreTemperature`, `stmReduceTau`,
`SymbolSpace.signal.temperature`, and `training.forwardGrammarWeight`.
At each sentence seal, training runs two hard compose derivations and two
optimizer steps, sharing one cached perception. Each row commits the strictly
lower sentence loss before the next sentence; ties keep exploit. Batch-end
answer loss has its own backward and stays outside that comparison. The public
batch clock and training counter advance once. Evaluation runs only exploit,
without an optimizer. `architecture.composeTemperature` controls both training
draws; it replaces the 90/10 mixture and never tempers model credit.
Word-major sentence training uses the tied traversal even when a configuration
keeps the older continuous event metric (`reconstructInLoop=false`). That event
metric is then reporting only; it cannot replace the sentence objective with
zero or add a third reconstruction update. Explicit detached-student and
numerical compatibility configurations retain their separate objectives.
See [Language](Language.md#one-operation-per-round-item-75).

Decision 7 adds `architecture.reducePressure`, finite and nonnegative, default
**1.0**. Declared before the correction's measurements: each binary logit gets
`reducePressure * (d / a + max(0, d - a) / r)`, zero on an empty stack. Here `d`
is the whole STM depth, `a = K - 1` during online rounds, and `a` is one for an
absolute sentence or three for a relative sentence at the seal. `r` counts the
current round and the remaining rounds in that phase. This fixed load prior
clamps divisors to at least one for numerical safety; deadline masking uses
the actual allowance and remaining-round count. The prior
enters the model's softmax and straight-through credit, before the sampling
temperature. It adds no learned parameter and gives every binary operator the
same bonus. Unary operations remain available while there is slack; when
`r <= max(0, d - a)`, only binary operations are eligible. STOP additionally
requires the sentence to fit its row and, online, to leave the next-word slot
free (relevant when a relative row is wider than a small STM's allowance).
Online depth is measured after depositing
the current word, so a pre-deposit depth of `K - 1` becomes `K` and requires one
reduction before the next word. An unfused NP VP is never a two-slot allowance.

### Two-truths seal (item 7)

`truth_criterion` and the multiplicative relation learn-score gate are
retired. The grammatical seal writes all completed clauses; provenance and
later evidence determine the independent positive and negative poles.
There is no reduction-versus-description switch or alternative relation
store. The situation weight, anchor bound and expectation weight above are
the three amendments from todo item 7; they do not grant compose LTM access.
