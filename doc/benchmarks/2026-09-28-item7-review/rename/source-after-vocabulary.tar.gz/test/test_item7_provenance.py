"""TruthSet ingestion must use the same selected clause closing as observations."""
from test_ltm_consolidation import _make_model_provisioned, _SERIAL_CONFIG
from test_item7_storage import clause_store, part_clause
from ClauseRow import Clause
import pytest


def test_provisioning_retains_real_selected_derivations_and_shared_row_ids():
    model = _make_model_provisioned(_SERIAL_CONFIG)
    store = model.symbolSpace.ltm_store
    assert len(store) == 3
    for row in range(len(store)):
        assert store.clause_derivation(row) is not None
        assert int(store.row_ids[row]) > 0
        assert store.row(row)['kind'] == 'fact'


def test_truthset_asserts_only_outer_ends_including_deduplicated_roots():
    store, _ = clause_store()
    child = part_clause()
    outer = Clause(child.meaning, relation='operator', refs=(4, 3, ('clause', 0)),
                   children=(child,))
    with store.clause_assertions(trust=.7, origin=store.ORIGIN_USER,
                                text='he said cats are animals', relation='operator') as rows:
        assert store.write_clause(outer) == 1
    assert rows == [1]
    assert store.row(0)['kind'] == 'unverified'
    assert store.row(0)['evidence'] == (0., 0.)
    assert store.row(1)['kind'] == 'fact'
    assert store.row(1)['evidence'] == pytest.approx((.7, 0.))
    with store.clause_assertions(trust=.8, origin=store.ORIGIN_USER,
                                text='cats are animals', relation='part') as rows:
        assert store.write_clause(child) == 0
    assert rows == [0] and len(store) == 2
    assert store.row(0)['evidence'] == pytest.approx((.8, 0.))


def test_xml_kind_cannot_retag_a_different_grammatical_closing():
    store, _ = clause_store()
    with store.clause_assertions(trust=1., origin=store.ORIGIN_PROVISIONED,
                                text='cats are animals', relation='implies'):
        with pytest.raises(ValueError, match='kind disagrees'):
            store.write_clause(part_clause())
    assert len(store) == 0
