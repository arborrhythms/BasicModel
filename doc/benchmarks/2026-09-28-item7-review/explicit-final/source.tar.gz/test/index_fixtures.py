"""Forced numerical unfolding for inverted-index mechanism tests."""
import torch


def one_hot_unfold(value, limit, **kwargs):
    row = int(value.argmax())
    expected = torch.zeros_like(value)
    expected[row] = 1
    return ((row,), 1, True) if limit and torch.equal(value, expected) else ((), 0, False)


def append_indexed(store, meaning, *, terms, **kwargs):
    """Supply a forced grammar for this write; retain only inverted postings."""
    prior = store._index_unfold
    mapping = {tuple(value.detach().tolist()): tuple(codes)
               for value, live, codes in zip(meaning.roles, meaning.role_mask, terms) if live}
    def unfold(value, limit, **_kwargs):
        codes = mapping.get(tuple(value.detach().tolist()), ())
        return codes, min(1, limit), bool(limit)
    store._index_unfold = unfold
    try:
        return store.append_meaning(meaning, **kwargs)
    finally:
        store._index_unfold = prior or one_hot_unfold
