"""Reconstruction keep, unbiased reader exposure, and inherited form order."""
from types import SimpleNamespace
import torch


def test_reader_trains_on_both_trials_all_active_rows():
    from SentenceCompose import sentence_pair
    active = torch.tensor([True, True, False])
    seen = []
    sentence_pair(None, lambda _, prior: prior is not None,
        lambda other, _: (torch.tensor([1., 0., 0.] if other else [0., 1., 0.]),
                          torch.full((3,), float(other))),
        lambda _: None, active=active, before_step=lambda rows: seen.append(rows.clone()))
    assert len(seen) == 2
    assert all(torch.equal(rows, active) for rows in seen)


def test_pole_only_handoff_preserves_magnitude_and_native_reference_evidence():
    from ModelAttention import pole_activation, reference_evidence
    activation = torch.tensor([[[.3], [-.6], [.8], [-.4]]], requires_grad=True)
    pair = torch.tensor([[[0., 1.], [1., 0.], [.5, .5], [1., 0.]]])
    changed = torch.tensor([[True, True, True, False]])
    actual = pole_activation(activation, pair, changed)
    torch.testing.assert_close(actual, torch.tensor([[[-.3], [.6], [.8], [-.4]]]))
    torch.testing.assert_close(actual.abs(), activation.abs(), rtol=0, atol=0)
    model = SimpleNamespace(_attention_poles=pair,
                            _attention_words=SimpleNamespace(pole_changes=changed))
    evidence = reference_evidence(model, activation, 'commit_word_reference_slab:whole_slab')
    torch.testing.assert_close(evidence, torch.tensor([[[0., .3], [.6, 0.], [.8, 0.], [0., .4]]]))
    assert not evidence.requires_grad
    model._attention_words.pole_changes.zero_()
    native = torch.stack((activation.squeeze(-1).clamp(0, 1),
                         (-activation.squeeze(-1)).clamp(0, 1)), -1)
    torch.testing.assert_close(reference_evidence(model, activation,
        'commit_word_reference_slab:per_word'), native, rtol=0, atol=0)


def test_inherited_parts_form_partial_order_and_before_after_audit():
    from test_review13_subspaces import fixture, word
    cs, cb, ps, _ = fixture()
    with torch.no_grad():
        ps.W[4] = torch.tensor([.2, .2, .2])
        ps.W[7] = torch.tensor([.8, .3, .2])
        ps.W[8] = torch.tensor([.3, .8, .2])
    a = word(cs, [(4, 1.)])
    ab = word(cs, [(4, 1.), (7, 1.)])
    ac = word(cs, [(4, 1.), (8, 1.)])
    codes = dict(zip((a, ab, ac), cb.lookup_rows(torch.tensor([a, ab, ac]))))
    assert (codes[a][:3] <= codes[ab][:3]).all()
    assert (codes[a][:3] <= codes[ac][:3]).all()
    assert not (codes[ab][:3] <= codes[ac][:3]).all()
    assert not (codes[ac][:3] <= codes[ab][:3]).all()
    audit = cb.mereology.containment_audit()
    assert audit['before'] == audit['after'] == dict(pairs=2, violating_pairs=0, coordinates=0, largest=0.)
    displaced = {row: code.clone() for row, code in codes.items()}
    displaced[a][0] = 1.
    audit = cb.mereology.containment_audit(before=displaced, after=codes)
    assert audit['before']['violating_pairs'] == 2
    assert audit['before']['largest'] > .6 and audit['after']['largest'] == 0
