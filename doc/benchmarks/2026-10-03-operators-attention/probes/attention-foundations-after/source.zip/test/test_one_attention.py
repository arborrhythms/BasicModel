"""6.8's typed brackets, one chooser, level expectation and fixed word whole."""
import pytest
import torch


def test_word_extent_is_letters_and_numeric_percepts_remain_separate():
    import Meronomy
    raw=b'abc123 cat-dog 01 A1B'
    assert [raw[a:b] for a,b in Meronomy.word_spans(raw)] == [b'abc',b'cat',b'dog',b'A',b'B']
    assert [raw[a:b] for a,b in Meronomy.number_spans(raw)] == [b'123',b'01',b'1']
    assert [raw[a:b] for a,b in Meronomy.percept_spans(raw)] == [b'abc',b'123',b'cat',b'dog',b'01',b'A',b'1',b'B']


def test_word_whole_membership_is_fixed_while_other_properties_can_learn():
    from PerceptProperties import PrimitiveProperties
    props=PrimitiveProperties(12)
    props.define_word(8)
    before=props.coefficients().detach().clone()
    assert before[8,ord('A')] == 1 and before[8,ord('0')] == 0
    optimizer=torch.optim.SGD(props.parameters(),lr=.5)
    props.coefficients().sum().backward();optimizer.step()
    torch.testing.assert_close(props.coefficients()[8],before[8])
    assert not torch.equal(props.coefficients()[0],before[0])
    assert not props.coefficients()[8].requires_grad or props.members.grad[8].count_nonzero() == 0


def test_bracket_table_is_bounded_typed_and_shares_one_meter():
    from Attention import BracketTable, SPACE_INPUT, SPACE_SYMBOL
    table=BracketTable.open(torch.tensor([11,9]),budget=4)
    assert table.intervals.shape == (2,4,2)
    assert table.valid.sum(1).tolist() == [1,1]
    assert table.space[:,0].tolist() == [SPACE_INPUT,SPACE_INPUT]
    table=table.split(torch.tensor([0,0]),torch.tensor([5,4]),space=torch.tensor([SPACE_INPUT,SPACE_SYMBOL]))
    assert table.valid.sum(1).tolist() == [2,2]
    assert table.spent.tolist() == [1,1]
    assert table.remaining.tolist() == [3,3]
    assert table.space[1,:2].tolist() == [SPACE_SYMBOL,SPACE_SYMBOL]
    assert table.intervals[0,:2].tolist() == [[0,5],[5,11]]


def test_pooling_keeps_both_poles_and_unknown_neither_exactly_zero():
    from Attention import pooled_read
    poles=torch.tensor([[[[1.,0.],[0.,1.],[0.,0.]]],[[[0.,0.],[0.,0.],[0.,0.]]]])
    spans=torch.tensor([[[0,2],[2,4],[4,5]]])
    reading=pooled_read(poles,spans,torch.tensor([[[0,4],[4,5]]]))
    assert reading.poles.tolist() == [[[[1.,1.],[0.,0.]],[[0.,0.],[0.,0.]]]]
    assert reading.both.tolist() == [[True,False]]
    assert reading.neither.tolist() == [[False,True]]
    assert not reading.pure.any()


def test_pinned_masks_known_word_never_descends_and_wide_never_glosses():
    from Attention import narrowing_mask
    pure=torch.tensor([[True,False,False,True]])
    both=torch.tensor([[False,True,False,False]])
    neither=torch.tensor([[False,False,True,False]])
    word=torch.tensor([[True,False,True,False]])
    mask=narrowing_mask(pure,both,neither,singular=pure,word=word,can_split=~word,has_parts=torch.ones_like(word))
    assert mask.tolist() == [[[False,False,True],[True,True,False],[False,True,False],[False,True,False]]]
