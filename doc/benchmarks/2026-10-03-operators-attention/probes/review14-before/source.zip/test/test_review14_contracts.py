"""§14 ownership, net-evidence interval and deterministic room projection."""
from types import SimpleNamespace
import torch
from torch import nn
from test_review13_subspaces import fixture, word


def towers():
    from Spaces import Codebook
    cs, cb, ps, alloc = fixture()
    ws = Codebook()
    ws.W = nn.Parameter(torch.tensor([[.7,.8,.9], [.6,.7,.8]]))
    cs._model.wholeSpace = SimpleNamespace(subspace=SimpleNamespace(what=ws))
    return cs, cb, ps, ws, alloc


def test_net_evidence_interval_and_detached_native_sources():
    cs, cb, ps, ws, alloc = towers()
    row = word(cs, [(4,.75),(4,-.25),(7,.25)])
    cs.add_concept_feature(row, 'ws', 0, .5)
    cs.add_concept_feature(row, 'ws', 0, -.25)
    lower = torch.maximum(.5*ps.W[4], .25*ps.W[7])
    upper = 1-.25*(1-ws.W[0])
    expected = (.75*lower+.25*upper)
    result = cb.lookup_rows(row)
    torch.testing.assert_close(result[:3], expected)
    assert not result.requires_grad
    assert not result[3:].any()
    assert ps.W.requires_grad and ws.W.requires_grad and alloc.layer().features.values.requires_grad


def test_against_alone_is_not_negative_form_and_no_wholes_means_lower():
    cs, cb, ps, ws, alloc = towers()
    row = word(cs, [(4,.5),(7,-.5)])
    torch.testing.assert_close(cb.lookup_rows(row)[:3], .5*ps.W[4])


def test_room_projection_reports_before_after_and_moves_extremal_rows():
    cs, cb, ps, ws, alloc = towers()
    row = word(cs, [(7,1.)])
    cs.add_concept_feature(row, 'ws', 1, 1.)
    before_ps, before_ws = ps.W.detach().clone(), ws.W.detach().clone()
    report = cb.mereology.project_room(margin=.1)
    assert report['before']['count'] == 1
    assert abs(report['before']['largest']-.3) < 1e-6
    assert report['after']['largest'] < 1e-6
    torch.testing.assert_close(ps.W[7,0], before_ps[7,0]-.15)
    torch.testing.assert_close(ws.W[1,0], before_ws[1,0]+.15)
    torch.testing.assert_close(ps.W[4], before_ps[4])
    assert ps.W.grad is None and ws.W.grad is None


def pair(parent, bank):
    from Language import LanguageSpace
    class Product:
        @staticmethod
        def compose(x,y):
            return x*y
    B = len(parent)
    return LanguageSpace._bounded_binary_reconstruction(Product(), parent,
        torch.zeros_like(parent), torch.zeros(B,dtype=torch.bool),
        torch.zeros(B,dtype=torch.bool), bank,
        torch.ones(bank.shape[:2],dtype=torch.bool), bank.shape[1])


def test_pair_pullback_is_parent_only_and_relative_under_product_scaling():
    bank = torch.tensor([[[.2,.4],[.7,.3]]], requires_grad=True)
    parent = torch.tensor([[.11,.13]], requires_grad=True)
    left,right,ok = pair(parent,bank)
    gradient = torch.autograd.grad((left+2*right).sum(), (parent,bank), allow_unused=True)
    assert ok.all() and gradient[0].norm()>0
    assert gradient[1] is None
    scaled = (parent.detach()*.01).requires_grad_()
    l,r,_ = pair(scaled,bank.detach()*.1)
    other = torch.autograd.grad((l+2*r).sum(),scaled)[0]
    torch.testing.assert_close(other*.1, gradient[0])


def test_byte_scorer_bank_is_constant_leaf_is_live():
    from Models import BasicModel
    bank = torch.tensor([[[.2,.6],[.7,.3]]], requires_grad=True)
    leaf = torch.tensor([[.3,.5]], requires_grad=True)
    owner = SimpleNamespace(_BYTE_ASSIGNMENT_TAU=.1, _readback_percept_width=2)
    cost = BasicModel._byte_word_cost(owner, leaf, 0, bank,
        torch.tensor([[[65,0],[66,0]]]), torch.ones(1,2,2,dtype=torch.bool),
        torch.tensor([[[65,0]]]), torch.ones(1,1,2,dtype=torch.bool),True)
    a,b = torch.autograd.grad(cost.sum(),(leaf,bank),allow_unused=True)
    assert a.norm()>0 and b is None
