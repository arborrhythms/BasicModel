"""Compound selection is a native sigma case read, never a learned new map."""
import pytest
import torch


def _bank():
    from CaseSelection import CaseBank
    # Head 10 has cases 20 and 30. Modifier 40 selects 20; 50 selects 30.
    # Native addresses are beside the numerical codes, not inferred from them.
    ids=torch.tensor([10,20,30,40,50])
    codes=torch.tensor([[.5,.5],[1.,0.],[0.,1.],[.2,.8],[.8,.2]])
    cases=torch.zeros(5,5,2)
    cases[0,1:3,0]=1
    observed=torch.zeros_like(cases)
    observed[torch.arange(5),torch.arange(5),0]=1
    observed[3,1,0]=1
    observed[4,2,0]=1
    return CaseBank(ids,codes,cases,observed)


def test_modifier_selects_the_heads_cases_and_refolds_only_those_cases():
    from CaseSelection import select_cases, fold_cases
    bank=_bank()
    selection=select_cases(bank,torch.tensor([40,50]),torch.tensor([10,10]))
    value=fold_cases(selection)
    torch.testing.assert_close(value,torch.eye(2))
    assert selection.available.tolist() == [True,True]
    assert not list(value.shape) == []
    # Reversing the compound cannot silently treat the modifier as its head.
    assert not select_cases(bank,torch.tensor([10]),torch.tensor([40])).available.any()


def test_case_selection_preserves_negative_evidence_and_silent_absence():
    from CaseSelection import select_cases, fold_cases
    bank=_bank()
    bank.cases[0,1]=torch.tensor([0.,.8])
    bank.observed[3,1]=torch.tensor([0.,.6])
    selected=select_cases(bank,torch.tensor([40,-1]),torch.tensor([10,10]))
    torch.testing.assert_close(fold_cases(selected),torch.tensor([[-.6,0.],[0.,0.]]))
    assert selected.available.tolist() == [True,False]


def test_case_fold_keeps_existing_code_and_membership_gradients():
    from CaseSelection import select_cases, fold_cases
    bank=_bank()
    bank.codes.requires_grad_();bank.observed.requires_grad_()
    value=fold_cases(select_cases(bank,torch.tensor([40]),torch.tensor([10])))
    value.sum().backward()
    assert bank.codes.grad[1].abs().sum() > 0
    assert bank.observed.grad[3,1].abs().sum() > 0
    assert bank.codes.grad[[0,2,3,4]].count_nonzero() == 0


def test_case_selector_and_fold_compile_as_one_tensor_body():
    from CaseSelection import select_cases, fold_cases
    bank=_bank()
    def run(modifier,head):
        selected=select_cases(bank,modifier,head)
        return fold_cases(selected), selected.available
    compiled=torch.compile(run,backend='aot_eager',fullgraph=True)
    actual=compiled(torch.tensor([40,50]),torch.tensor([10,10]))
    torch.testing.assert_close(actual[0],torch.eye(2))
    assert actual[1].all()


def test_native_case_staging_uses_existing_sigma_and_allocates_nothing():
    from CaseSelection import stage_case_bank, select_cases, fold_cases
    from test_cs_sparse_weights import _cs, _mint_row
    cs=_cs()
    # Native test rows are allocated explicitly; sigma already holds the edges.
    first=_mint_row(cs,0,101)
    second=_mint_row(cs,0,102)
    head=_mint_row(cs,1,103)
    modifier=_mint_row(cs,1,104)
    cs.add_concept_edge(head,first,1.)
    cs.add_concept_edge(head,second,1.)
    cs.add_concept_edge(modifier,second,1.)
    before=dict(cs._concept_allocator.placement)
    bank=stage_case_bank(cs,torch.tensor([103,104]),limit=8)
    assert cs._concept_allocator.placement == before
    selected=select_cases(bank,torch.tensor([104]),torch.tensor([103]))
    assert selected.available.all()
    expected=cs.similarity_codebook.lookup_rows(torch.tensor([second]))
    torch.testing.assert_close(fold_cases(selected),expected)
