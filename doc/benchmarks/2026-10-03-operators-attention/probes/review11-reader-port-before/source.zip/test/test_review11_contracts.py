"""Review §11: an affine numeric answer and support-governed decoding."""
from types import MethodType, SimpleNamespace

import pytest
import torch


def test_numeric_head_does_not_call_learned_retrieval():
    from Models import BasicModel
    from Spaces import SubSpace
    shape = (3, 2)
    value = torch.tensor([[[1., 2.], [0., 0.], [0., 0.]]])
    sub = SubSpace.from_tensor(value, inputShape=shape, outputShape=shape,
                              nInputDim=2, nOutputDim=2)
    class Head:
        concept_ids = ()
        inputShape = shape
        def __call__(self, carrier):
            return carrier
    def forbidden(*args, **kwargs):
        raise AssertionError('the numeric head called nonlinear retrieval')
    model = SimpleNamespace(outputSpace=Head(), word_brackets=True,
        answer_synthesis=False, answer_attention=object(), answer_record_reader=None,
        _answer_attention_step=forbidden, perceptualSpace=SimpleNamespace(subspace=sub))
    state = (value[:, 0], value, torch.ones(1, dtype=torch.long))
    result = BasicModel._forward_head(model, sub, sentence_state=state)
    torch.testing.assert_close(result.materialize(), value)


def decoder():
    from Language import LanguageSpace
    from Models import BasicModel
    class Sum:
        inverse_kind = 'search'
        @staticmethod
        def compose(left, right):
            return left + right
    policy = torch.nn.Linear(2, 2)
    with torch.no_grad():
        policy.weight.zero_()
        policy.bias.copy_(torch.tensor([0., 20.]))
    language = SimpleNamespace(_generate_binary_ops=(Sum(),), _generate_unary_ops=(),
        generate_policy=policy, _generate_policy_width=2)
    for name in ('generate_policy_logits', 'reverse_binary_step', '_reverse_of_binary_op'):
        setattr(language, name, MethodType(getattr(LanguageSpace, name), language))
    language._bounded_binary_reconstruction = LanguageSpace._bounded_binary_reconstruction
    language.choose_generate = lambda logits: logits.argmax(-1)
    model = SimpleNamespace(languageSpace=language)
    model._output_generate_walk = MethodType(BasicModel._output_generate_walk, model)
    return model, policy


@pytest.mark.parametrize('chunk_in_bank', [False, True])
def test_supported_compound_cannot_stop_even_with_a_chunk_code(monkeypatch, chunk_in_bank):
    import util
    monkeypatch.setattr(util, 'TheCompileBackend', 'none')
    model, _ = decoder()
    event = torch.tensor([[[1., 1.], [0., 0.], [0., 0.]]])
    bank = torch.tensor([[[1., 0.], [0., 1.], [1., 1.]]])
    valid = torch.tensor([[True, True, chunk_in_bank]])
    out, count, truncated, _, actions = model._output_generate_walk(
        event, 6, basis=bank, basis_valid=valid, return_trace=True)
    assert count.tolist() == [2]
    assert not truncated.any()
    assert actions.tolist() == [[0, 1, 1, -1, -1, -1]]
    torch.testing.assert_close(out[:, :2], bank[:, :2])


def test_single_symbol_cannot_be_split_by_a_large_undo_logit(monkeypatch):
    import util
    monkeypatch.setattr(util, 'TheCompileBackend', 'none')
    model, policy = decoder()
    with torch.no_grad():
        policy.bias.copy_(torch.tensor([20., 0.]))
    event = torch.tensor([[[1., 0.], [0., 0.], [0., 0.]]])
    bank = torch.tensor([[[1., 0.], [0., 1.]]])
    out, count, truncated, _, actions = model._output_generate_walk(
        event, 6, basis=bank, basis_valid=torch.ones(1, 2, dtype=torch.bool), return_trace=True)
    assert count.tolist() == [1]
    assert not truncated.any()
    assert actions.tolist() == [[1, -1, -1, -1, -1, -1]]
    torch.testing.assert_close(out[:, 0], event[:, 0])


def test_no_shortlist_support_is_unavailable_not_a_pseudo_terminal(monkeypatch):
    import util
    monkeypatch.setattr(util, 'TheCompileBackend', 'none')
    model, _ = decoder()
    event = torch.tensor([[[1., 1.], [0., 0.]]], requires_grad=True)
    out, count, truncated, _, actions = model._output_generate_walk(
        event, 4, basis=event, basis_valid=torch.zeros(1, 2, dtype=torch.bool), return_trace=True)
    assert count.tolist() == [0]
    assert truncated.all()
    assert actions.tolist() == [[-1, -1, -1, -1]]
    assert torch.isfinite(out).all()
