import torch, pytest

def test_probe_eligibility_internals(tmp_path, monkeypatch, eager_reading):
    from test_compiled_word_chunk import _tiny_canonical_model
    torch.manual_seed(613)
    model = _tiny_canonical_model(tmp_path, monkeypatch, word_buckets="16", input_width=16)
    model._tensor_peer_while_eager = True
    model._chart_compose_per_word = lambda: None
    model.conceptualSpace.intra_loss_weight = 0.0
    model.inter_loss_weight = 0.0
    optimizer = model.getOptimizer(lr=1e-3)
    words = ["a b c d e", "f g h i j"]
    inputs = model.inputSpace.prepInput(words)
    model.inputSpace.data.has_supervised_outputs = False
    import Language
    real = Language.LanguageSpace.decoder_eligibility
    calls = []
    def spy(parent, lefts, rights, available, binary_ops, basis, basis_valid, *, case_bank=None):
        out = real(parent, lefts, rights, available, binary_ops, basis, basis_valid, case_bank=case_bank)
        try:
            if len(calls) < 3 and basis is not None:
                bank = basis.detach(); value = parent.detach()
                valid = basis_valid & bank.square().sum(-1).gt(0)
                den = bank.square().sum(-1).clamp_min(1e-30)
                act = (value[:, None] * bank).sum(-1) / den
                res = (value[:, None] - act[..., None] * bank).square().mean(-1).masked_fill(~valid, float('inf'))
                best = res.amin(-1)
                info = dict(parent_norm=[round(x,4) for x in value.norm(dim=-1).tolist()], best=[round(x,6) for x in best.tolist()],
                            singular_count=(valid & res.eq(best[:, None])).sum(-1).tolist(), available=available.long().tolist(),
                            bank_valid=valid.long().sum(-1).tolist(), n_binary=len(binary_ops))
                for i, w in enumerate(binary_ops):
                    op = getattr(w, 'gl', w)
                    kind = getattr(op, 'inverse_kind', None)
                    l, r = lefts[i].detach(), rights[i].detach()
                    if kind == 'case_search':
                        info[f'op{i}'] = ('case_search', type(op).__name__); continue
                    folded = l if getattr(op, 'reconstructs_left', False) else op.compose(l, r)
                    pe = [round(x,6) for x in ((folded - value).square().mean(-1)).tolist()]
                    rd = ((valid & (bank == l[:, None]).all(-1)).any(-1).tolist(), (valid & (bank == r[:, None]).all(-1)).any(-1).tolist())
                    prog = (l.ne(value).any(-1) & r.ne(value).any(-1)).tolist()
                    info[f'op{i}'] = (type(op).__name__, 'pair_error', pe, 'readable', rd, 'progress', prog, 'lnorm', [round(x,3) for x in l.norm(dim=-1).tolist()])
                info['legal_out'] = out.long().tolist()
                calls.append(info)
        except Exception as e:
            calls.append({'error': repr(e)[:200]})
        return out
    monkeypatch.setattr(Language.LanguageSpace, 'decoder_eligibility', staticmethod(spy))
    from reading_fixtures import capture_readings
    try:
        with capture_readings(model):
            model.runBatch(train=True, batchNum=0, batchSize=2, split="train", optimizer=optimizer,
                           batch_override=(inputs, torch.empty(2, 0)))
    finally:
        print("\nELIGIBILITY INTERNALS:", len(calls))
        for c in calls:
            for k, v in c.items(): print("   ", k, v)
            print("   ---")
        model.inputSpace.data.has_supervised_outputs = True
        model.End(); model.symbolSpace.soft_reset()
