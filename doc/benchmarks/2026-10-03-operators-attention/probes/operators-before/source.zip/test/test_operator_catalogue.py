"""Decided operator semantics; fixed examples are not training seeds."""
import torch
import pytest


def test_intersection_is_idempotent_symmetric_and_silence_preserving():
    from Language import IntersectionLayer
    op = IntersectionLayer()
    noun = torch.tensor([[.7, -.6, .4, 0., -.5]], requires_grad=True)
    adjective = torch.tensor([[.5, -.8, 0., -.3, .4]], requires_grad=True)
    expected = torch.tensor([[.5, -.6, .4, -.3, 0.]])
    value = op.compose(noun, adjective)
    torch.testing.assert_close(value, expected, rtol=0, atol=0)
    torch.testing.assert_close(op.compose(adjective, noun), value, rtol=0, atol=0)
    torch.testing.assert_close(op.compose(noun, noun), noun, rtol=0, atol=0)
    torch.testing.assert_close(op.compose(value, value), value, rtol=0, atol=0)
    value.sum().backward()
    assert noun.grad.isfinite().all() and adjective.grad.isfinite().all()
    assert noun.grad.norm() > 0 and adjective.grad.norm() > 0


def test_non_excludes_without_affirming_or_claiming_an_inverse():
    from Language import NonLayer
    poles = torch.tensor([[.7, .2, 19.], [0., .8, 3.]])
    op = NonLayer(representation='poles')
    torch.testing.assert_close(op(poles), torch.tensor([[0., .2, 19.], [0., .8, 3.]]))
    assert not op.invertible
    with pytest.raises((RuntimeError, NotImplementedError)):
        op.reverse(poles)
    code = NonLayer()
    torch.testing.assert_close(code(torch.tensor([[.5, -.4]])), torch.zeros(1, 2))


def test_sum_is_a_mean_and_witness_inverse_is_exact():
    from Language import SumLayer, LanguageSpace
    from types import SimpleNamespace, MethodType
    op = SumLayer()
    left, right = torch.tensor([[.2, -.8]]), torch.tensor([[.6, .4]])
    parent = op.compose(left, right)
    torch.testing.assert_close(parent, (left+right)/2)
    owner = SimpleNamespace()
    for name in ('_reverse_of_binary_op', '_finish_binary_inverse', 'reverse_binary_step'):
        setattr(owner, name, MethodType(getattr(LanguageSpace, name), owner))
    a,b,bad = owner.reverse_binary_step(parent, torch.tensor([0]), torch.tensor([True]),
        right, ops=[op], return_status=True)
    assert not bad.any()
    torch.testing.assert_close(a,left)
    torch.testing.assert_close(b,right)


def test_adverb_is_a_repeatable_gain_with_an_exact_witness_inverse():
    from Language import AdverbLayer
    op = AdverbLayer(nInput=4, nOutput=4)
    with torch.no_grad():
        op._adv_edit.weight.copy_(torch.eye(4)*.5)
        op._adv_edit.bias.zero_()
    verb = torch.tensor([[.2, -.3, 0., .4]], requires_grad=True)
    modifier = torch.ones(1,4)
    once = op.compose(verb,modifier)
    twice = op.compose(once,modifier)
    # Gains compose multiplicatively in the verb's existing chart.
    gain = torch.atanh(once)/torch.where(verb==0, 1., torch.atanh(verb))
    expected = torch.tanh(torch.atanh(verb)*gain.square())
    torch.testing.assert_close(twice, expected)
    assert (twice.abs()[verb!=0] > once.abs()[verb!=0]).all()
    recovered, witness = op.reverse(once, adverb_what=modifier)
    torch.testing.assert_close(recovered, verb)
    torch.testing.assert_close(witness, modifier)
    once.sum().backward()
    assert op._adv_edit.weight.grad.norm() > 0
