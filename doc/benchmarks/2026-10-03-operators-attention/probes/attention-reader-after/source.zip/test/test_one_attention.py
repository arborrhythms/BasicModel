"""6.8's typed brackets, one chooser, level expectation and fixed word whole."""
import pytest
import torch


def test_word_extent_is_letters_and_numeric_percepts_remain_separate():
    import Meronomy
    raw=b'abc123 cat-dog 01 A1B'
    assert [raw[a:b] for a,b in Meronomy.word_spans(raw)] == [b'abc',b'cat',b'dog',b'A',b'B']
    assert [raw[a:b] for a,b in Meronomy.number_spans(raw)] == [b'123',b'01',b'1']
    assert [raw[a:b] for a,b in Meronomy.percept_spans(raw)] == [b'abc',b'123',b'cat',b'dog',b'01',b'A',b'1',b'B']


def test_word_whole_membership_is_fixed_while_other_properties_can_learn():
    from PerceptProperties import PrimitiveProperties
    props=PrimitiveProperties(12)
    props.define_word(8)
    before=props.coefficients().detach().clone()
    assert before[8,ord('A')] == 1 and before[8,ord('0')] == 0
    optimizer=torch.optim.SGD(props.parameters(),lr=.5)
    (-props.coefficients().sum()).backward();optimizer.step()
    torch.testing.assert_close(props.coefficients()[8],before[8])
    assert not torch.equal(props.coefficients()[0],before[0])
    assert not props.coefficients()[8].requires_grad or props.members.grad[8].count_nonzero() == 0


def test_bracket_table_is_bounded_typed_and_shares_one_meter():
    from Attention import BracketTable, SPACE_INPUT, SPACE_SYMBOL
    table=BracketTable.open(torch.tensor([11,9]),budget=4)
    assert table.intervals.shape == (2,4,2)
    assert table.valid.sum(1).tolist() == [1,1]
    assert table.space[:,0].tolist() == [SPACE_INPUT,SPACE_INPUT]
    table=table.split(torch.tensor([0,0]),torch.tensor([5,4]),space=torch.tensor([SPACE_INPUT,SPACE_SYMBOL]))
    assert table.valid.sum(1).tolist() == [2,2]
    assert table.spent.tolist() == [1,1]
    assert table.remaining.tolist() == [3,3]
    assert table.space[1,:2].tolist() == [SPACE_SYMBOL,SPACE_SYMBOL]
    assert table.intervals[0,:2].tolist() == [[0,5],[5,11]]


def test_pooling_keeps_both_poles_and_unknown_neither_exactly_zero():
    from Attention import pooled_read
    poles=torch.tensor([[[[1.,0.],[0.,1.],[0.,0.]]],[[[0.,0.],[0.,0.],[0.,0.]]]])
    spans=torch.tensor([[[0,2],[2,4],[4,5]]])
    reading=pooled_read(poles,spans,torch.tensor([[[0,4],[4,5]]]))
    assert reading.poles.tolist() == [[[[1.,1.],[0.,0.]],[[0.,0.],[0.,0.]]]]
    assert reading.both.tolist() == [[True,False]]
    assert reading.neither.tolist() == [[False,True]]
    assert not reading.pure.any()


def test_pinned_masks_known_word_never_descends_and_wide_never_glosses():
    from Attention import narrowing_mask
    pure=torch.tensor([[True,False,False,True]])
    both=torch.tensor([[False,True,False,False]])
    neither=torch.tensor([[False,False,True,False]])
    word=torch.tensor([[True,False,True,False]])
    mask=narrowing_mask(pure,both,neither,singular=pure,word=word,can_split=~word,has_parts=torch.ones_like(word))
    assert mask.tolist() == [[[False,False,True],[True,True,False],[False,True,False],[False,True,False]]]


def test_normal_field_answer_reaches_every_binding_and_keeps_first_word():
    from test_mm_xor import _fresh_model
    model,_,_= _fresh_model()
    model.train()
    value=model.inputSpace.prepInput(['hello world','hello there','loving world','loving there'])
    _,_,output,_=model.forward(value)
    output.square().sum().backward()
    for space in model.conceptualSpaces:
        parameters=list(space.combine.parameters())
        assert any(p.grad is not None and p.grad.abs().sum()>0 for p in parameters), [(name,p.requires_grad,None if p.grad is None else p.grad.abs().sum().item()) for name,p in space.combine.named_parameters()]
    carrier=model._combine_last_cs_sub.materialize()
    assert (carrier[:,0].norm(dim=-1)>0).all()


def test_narrowing_uses_the_shared_operation_chooser_and_compiles():
    from Language import OperationSelectionLayer
    from Attention import narrow_words
    chooser=OperationSelectionLayer(d_model=4)
    keys=torch.tensor([[[1.,0.,0.,0.],[0.,1.,0.,0.]]])
    spans=torch.tensor([[[0,5],[6,11]]])
    known=torch.tensor([[True,False]])
    def run(keys,known):
        return narrow_words(chooser,keys,spans,known,budget=8)
    value=run(keys,known)
    compiled=torch.compile(run,backend='aot_eager',fullgraph=True)(keys,known)
    torch.testing.assert_close(compiled.table.intervals,value.table.intervals)
    assert value.accepted.tolist()==[[True,True]]
    assert value.descended.tolist()==[[False,True]]
    assert value.table.spent.tolist()==[4]
    assert value.table.remaining.tolist()==[4]
    value.values.sum().backward()
    assert chooser.bracket_anchor.grad is not None


@pytest.mark.parametrize('name',['subsymbolicOrder','symbolicOrder','subsymbolicLoop','serial','modeSchedule','readingAttention','globalAttention','globalAttentionConsume','selectedThoughtBudget'])
def test_old_attention_controls_are_rejected_at_ingestion(name):
    from util import XMLConfig
    with pytest.raises(ValueError,match='retired'):
        XMLConfig._apply_legacy_renames({'architecture':{name:1}},'probe.xml')


def test_attention_modules_retire_after_the_answer_reader_takes_their_contract():
    import Spaces
    from Attention import PrimedSymbolReader
    assert not hasattr(Spaces,'ReadingAttention') and not hasattr(Spaces,'GlobalAttention')
    reader=PrimedSymbolReader()
    keys=torch.tensor([[[1.,0.],[0.,1.]]],requires_grad=True)
    result=reader(concept_q=torch.ones(1,2),symbol_q=None,
                  spaces=[{'id':0,'keys':keys}])
    base=torch.ones(1,2)
    torch.testing.assert_close(reader.consume(base,result['content']),base)
    reader.consume_gate.data.fill_(.5)
    reader.consume(base,result['content']).square().sum().backward()
    assert keys.grad is None
    assert any(p.grad is not None for p in reader.scorer.parameters())
