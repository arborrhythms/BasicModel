import torch

def test_probe_extra_row():
    from test_mm_xor import _fresh_model
    model, _, _ = _fresh_model('data/MM_grammar.xml')
    try:
        with torch.no_grad():
            model.forward(model.inputSpace.prepInput(['hello world', 'hello there', 'loving world', 'loving there']))
        owner = model._concept_owner()
        rows = model.inputSpace._ar_grammar_object_rows
        word_rows = sorted(set(rows[rows >= 0].tolist()))
        layer = owner._concept_allocator.layer()
        keys = sorted(layer._tensor_row_keys)
        print("\nWORD ROWS:", word_rows, " ALLOCATED KEYS:", keys)
        extra = [k for k in keys if k not in word_rows]
        for k in extra:
            surface = owner.word_surface_for_row(k) if hasattr(owner, 'word_surface_for_row') else None
            print("  extra row", k, "surface:", surface)
            for attr in ('_tensor_row_kinds', '_row_kind', '_tensor_row_sources', '_row_provenance'):
                v = getattr(layer, attr, None)
                if v is not None:
                    try: print("   ", attr, v[k] if not torch.is_tensor(v) else v[k].tolist())
                    except Exception as e: print("   ", attr, 'err', e)
        # try to show surfaces of all rows
        for k in keys:
            try: print("  row", k, "->", owner.word_surface_for_row(k))
            except Exception as e: print("  row", k, "surface err", e)
        st = getattr(owner, 'stm', None)
        print("  allocator next_id:", getattr(owner._concept_allocator, 'next_id', None))
    finally:
        model.End(); model.symbolSpace.soft_reset(); torch._dynamo.reset()
