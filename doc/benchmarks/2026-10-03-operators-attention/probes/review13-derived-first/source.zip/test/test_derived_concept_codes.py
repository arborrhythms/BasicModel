"""§13.4: parts determine word codes; occurrence wholes are detached."""
from types import SimpleNamespace
import torch
from torch import nn
from test_cs_sparse_weights import _cs


def fixture():
    from MereologicalCodes import MereologicalCodes
    from Spaces import Codebook, _concept_alloc_of
    cs = _cs(nS=32, order=0)
    cb = Codebook()
    cb.W = nn.Parameter(torch.arange(96, dtype=torch.float32).reshape(32, 3) / 100)
    cs.similarity_codebook = cb
    cb.enable_derived_codes(cs, basis_capacity=16)
    cs._online_learning_frozen = False
    return cs, cb, _concept_alloc_of(cs)


def word(cs, parts):
    cid = cs.new_concept()
    row = cs._csw_concept_row(0, cid)
    for pid, weight in parts:
        cs.add_concept_feature(row, 'ps', pid, weight)
    return row


def test_code_is_signed_sum_of_lookup_locations_without_a_word_parameter():
    cs, cb, alloc = fixture()
    row = word(cs, [(4, .75), (7, -.25)])
    basis = cb.mereology
    with torch.no_grad():
        basis.locations[0].copy_(torch.tensor([1., 2., 3.]))
        basis.locations[1].copy_(torch.tensor([3., 2., 1.]))
    value = cb.lookup_rows(torch.tensor([row]))
    torch.testing.assert_close(value, torch.tensor([[0., 1., 2.]]))
    assert not isinstance(cb.W, nn.Parameter) and not cb.W.requires_grad
    assert set(dict(cb.named_parameters())) == {'mereology.locations'}
    assert len(basis.entries()) == 2
    assert all(cs.concept_id_at_row(r) == cid for _, _, cid, r in basis.entries())
    value.sum().backward()
    gradient = basis.locations.grad.to_dense()
    torch.testing.assert_close(gradient[:2], torch.tensor([[.75]*3, [-.25]*3]))
    assert alloc.layer().features.values.grad is not None
    before = value.detach().clone()
    with torch.no_grad():
        basis.locations[0].add_(1.)
        cb.W.fill_(99.)
    torch.testing.assert_close(cb.lookup_rows(torch.tensor([row])), before + .75)


def test_shared_percept_is_one_lookup_and_group_members_are_independent_locations():
    cs, cb, _ = fixture()
    first = word(cs, [((4, 7), .5)])
    second = word(cs, [(7, 1.)])
    assert len(cb.mereology.entries()) == 2
    expected = .5 * cb.mereology.locations[:2].sum(0)
    torch.testing.assert_close(cb.lookup_rows(first), expected)
    torch.testing.assert_close(cb.lookup_rows(second), cb.mereology.locations[1])


def test_occurrence_context_uses_signed_evidence_recency_and_no_durable_gradient():
    from Layers import TernaryTruthStore
    from Meaning import ConceptualMeaning
    cs, cb, _ = fixture()
    a, b = word(cs, [(4, 1.)]), word(cs, [(7, 1.)])
    store = TernaryTruthStore(3, capacity=8)
    cs.symbolSpace = SimpleNamespace(ltm_store=store)
    root = torch.tensor([2., 4., 6.], requires_grad=True)
    roles = torch.stack((root, root*0, root*0))
    row = store.append_meaning(ConceptualMeaning(roles, torch.tensor([True,False,False]),
        mode='assertive', sentence_kind='idea'), evidence=(.8,.2))
    store._append_leaf_terms(row, ((a,b),(),()), (True,True,True))
    initial = cb.mereology.locations[:2].detach().clone()
    codes = cb.lookup_rows(torch.tensor([a,b]))
    torch.testing.assert_close(codes-initial, (.6*root.detach()).expand(2,-1))
    codes.sum().backward()
    assert root.grad is None and not store.slots.requires_grad
    store._next_ts.add_(1)
    torch.testing.assert_close(cb.lookup_rows(a)-initial[0], .3*root.detach())
    assert len(store) == 1


def test_rows_conduct_to_other_words_without_crossing_batch_streams():
    from Layers import TernaryTruthStore
    from Meaning import ConceptualMeaning
    cs, cb, _ = fixture()
    a, b, c = [word(cs, [(p, 1.)]) for p in (4, 7, 8)]
    store = TernaryTruthStore(3, capacity=8)
    cs.symbolSpace = SimpleNamespace(ltm_store=store)
    row = store.append_meaning(ConceptualMeaning(torch.eye(3), torch.tensor([True,False,False]),
        mode='assertive', sentence_kind='idea'), evidence=(1.,0.))
    store._append_leaf_terms(row, ((a,b),(),()), (True,True,True))
    cs._priming_spread = .25
    surface = cs.prime_seen(torch.tensor([[a],[c]]))
    assert surface[0,b] > 1 and surface[1,b] == 1
    assert cs._last_occurrence_priming['activated_competitors'] > 0
    assert len(store) == 1


def test_frozen_lookup_does_not_admit_basis_concepts():
    cs, cb, alloc = fixture()
    row = word(cs, [(4, 1.)])
    before = alloc.next_id, tuple(cb.mereology.entries())
    cs._online_learning_frozen = True
    cb.lookup_rows(torch.tensor([row, 20]))
    assert (alloc.next_id, tuple(cb.mereology.entries())) == before


def test_actual_serial_leaf_has_derived_codes_and_reconstruction_owns_the_basis():
    from test_mm_xor import _fresh_model
    model, _, _ = _fresh_model('data/XOR_grammar.xml')
    model.train()
    model.forward(model.inputSpace.prepInput(['hello world', 'hello there']))
    owner = model._concept_owner()
    cb = owner.similarity_codebook
    assert not isinstance(cb.W, nn.Parameter)
    assert cb.mereology.entries()
    rows = model.inputSpace._ar_grammar_object_rows
    atoms = model.inputSpace._ar_grammar_object_atoms
    torch.testing.assert_close(atoms[rows>=0], cb.lookup_rows(rows[rows>=0]))
    opt = model.getOptimizer(lr=.01)
    groups = model.objective_parameter_groups(opt)
    assert any(p is cb.mereology.locations for p in groups['reconstruction'])
    assert all(p is not cb.mereology.locations for p in groups['output'])
