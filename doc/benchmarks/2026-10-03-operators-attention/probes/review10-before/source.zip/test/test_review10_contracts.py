"""Review §10: departures sample, and frozen interpretation cannot admit."""
from copy import deepcopy
from types import SimpleNamespace

import pytest
import torch


def high_draw(*shape, **kwargs):
    if len(shape) == 1 and isinstance(shape[0], (tuple, list)):
        shape = shape[0]
    return torch.full(shape, .999, **kwargs)


@pytest.mark.parametrize('kind', ['compose', 'input'])
def test_departure_can_choose_below_second_rank_and_preserves_credit(monkeypatch, kind):
    from Language import OperationSelectionLayer
    chooser = OperationSelectionLayer(d_model=2)
    logits = torch.tensor([[3., 2., 1., -torch.inf], [3., 2., 1., -torch.inf]], requires_grad=True)
    monkeypatch.setattr(torch, 'rand', high_draw)
    action, probability, legal = chooser.select_logits(logits, structural=None,
        masked_action=torch.tensor([0, -1]), replay_action=torch.tensor([-1, -1]))
    assert action.tolist() == [2, 0]
    assert legal.all()
    torch.testing.assert_close(probability, logits.softmax(-1))
    probability[0, 2].backward()
    assert logits.grad[0, 0] != 0  # exclusion changes the draw, not policy credit


@pytest.mark.parametrize('kind', ['thought', 'anticipation'])
def test_thought_departure_samples_remaining_actions_and_replay_wins(monkeypatch, kind):
    from Language import SelectedThoughtChooser
    chooser = SelectedThoughtChooser(context_dim=2)
    logits = torch.tensor([3., 2., 1., -torch.inf], requires_grad=True)
    monkeypatch.setattr(chooser, 'logits', lambda *a: logits)
    monkeypatch.setattr(torch, 'rand', high_draw)
    selected, credit = chooser.choose(torch.ones(4, 2), torch.zeros(4), excluded=0)
    assert selected == 2
    torch.testing.assert_close(credit, logits.log_softmax(-1)[2])
    replayed, _ = chooser.choose(torch.ones(4, 2), torch.zeros(4), excluded=0, forced=1)
    assert replayed == 1


def test_decoder_departure_samples_lower_rank_and_keeps_greedy_suffix(monkeypatch):
    from test_decoder_exploration import decoder
    import util
    monkeypatch.setattr(util, 'TheCompileBackend', 'none')
    model, _ = decoder()
    monkeypatch.setattr(torch, 'rand', high_draw)
    event = torch.tensor([[[1., 2.], [0., 0.], [0., 0.]]])
    greedy = model._output_generate_walk(event, 4, basis=event, return_candidates=True)
    explored = model._output_generate_walk(event, 4, basis=event,
        exploit_actions=greedy[4], departure=torch.tensor([0]), return_trace=True)
    assert greedy[4].tolist() == [[2, -1, -1, -1]]
    assert explored[4].tolist() == [[1, 2, -1, -1]]


def test_frozen_interpretation_reads_known_without_learning_or_reserving():
    from test_word_interpretation import _operator
    from Spaces import _concept_alloc_of
    from eval_nanochat_grammar import frozen_online_learning
    cs, interpret = _operator()
    word = interpret.lookup_word([7], [1], form='known')
    obj = interpret.forward(word)
    pending = interpret.lookup_word([8], [], form='pending')
    before = deepcopy(cs.definitions.description(word))
    identities = dict(_concept_alloc_of(cs).placement)
    definitions = len(cs.definitions._store())
    reservations = deepcopy(interpret._pending)
    model = SimpleNamespace(conceptualSpaces=[cs])
    with frozen_online_learning(model):
        assert interpret.lookup_word([9], [], form='novel') is None
        assert interpret.lookup_word([10], [2], form='known') == word
        assert interpret.forward(word, occurrence=(99, 0)) == obj
        assert interpret.forward(pending) is None
        assert interpret.define(pending, obj) is None
        assert len(cs.definitions._store()) == definitions
        assert dict(_concept_alloc_of(cs).placement) == identities
        assert interpret._pending == reservations
        assert cs.definitions.description(word) == before
    assert not cs._online_learning_frozen
