import torch

def test_probe_extra_row_identity():
    from test_mm_xor import _fresh_model
    model, _, _ = _fresh_model('data/MM_grammar.xml')
    try:
        with torch.no_grad():
            model.forward(model.inputSpace.prepInput(['hello world', 'hello there', 'loving world', 'loving there']))
        owner = model._concept_owner()
        alloc = owner._concept_allocator
        layer = alloc.layer()
        print("\nROW KEYS:", dict(layer._tensor_row_keys))
        for row, key in sorted(layer._tensor_row_keys.items()):
            cid = key[-1] if isinstance(key, tuple) else key
            recs = None
            try: recs = alloc.records(cid)
            except Exception as e: recs = f'err {e}'
            print(f"  row {row} key {key} records: {recs}")
            for attr in ('singletons', 'retired', 'reference_orders'):
                v = getattr(alloc, attr, None)
                if v is not None and (cid in v if hasattr(v, '__contains__') else False):
                    print(f"     in {attr}", (v[cid] if isinstance(v, dict) else ''))
        # which concepts exist beyond rows
        print("  next_id", alloc.next_id, " all concept ids with records:", sorted(k for k in range(alloc.next_id) if alloc.records(k)))
        for k in range(alloc.next_id):
            print("   concept", k, "records:", alloc.records(k))
    finally:
        model.End(); model.symbolSpace.soft_reset(); torch._dynamo.reset()
