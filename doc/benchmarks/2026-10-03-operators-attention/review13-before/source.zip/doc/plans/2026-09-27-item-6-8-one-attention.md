# Item 6.8: one attention — brackets, narrowing, and expectation at every bracket

**Status.** Decided in direction by Alec, 2026-09-27; plan by Claude.
Codex implements landing 6.8-1 after items 7.5, 7 and 6.9 and the
operators update; there is no conference freeze (Alec, 2026-10-03). Claude
reviews before commit.
Landing 6.8-2 (the dynamic stop) is recorded in
[FutureWork](../FutureWork.md#the-dynamic-stop-glossing-above-words-descending-at-novelty-item-68-2)
and is not scheduled. The todo entry is item 6.8.

## 1. The simplification

Attention is one mechanism: a **bracket** over the input, and a rule for
narrowing it. Everything the architecture now calls parallel mode, serial
mode, the subsymbolic loop, the symbolic loop and the boundary predictor
is this one mechanism seen at different bracket widths.

- **Open awareness** is the bracket set to the whole input. The field
  reads it: every active percept's presence and observed complement,
  pooled over the bracket (item 9b entry 4c).
- **The field's operations are the order-independent ones**, and only
  those: and, or, not, on pooled presences. This is the criterion, not a
  list: an operation belongs to the field exactly when it is commutative
  and associative over the bracket's contents, because a pooled reading
  has no order to offer. Everything order-dependent — lift, lower, verb,
  adverb, preposition, part, equal — is the grammar, and it acts
  **between** brackets, over the sequence of readings that narrowing
  produces. The 11c mode exclusion stops being a rule and becomes a
  theorem: field operations within a bracket, grammar operations across
  brackets.
- **Narrowing is the reading policy the four corners already give**
  (11c entries 5–6; 9b entry 4c): a bracket whose pair reads *true-only*
  or *false-only* is pure — move on; *both* — divide the bracket;
  *neither* — look closer: descend to the bracket's parts, and if nothing
  is there, `interpret` mints (9b entry 5). Serial reading is "narrow
  until each bracket's encoding is pure".
- **What narrowing does on text.** A known word is one fused part and
  reads purely at its word bracket, so narrowing stops there. An unknown
  word reads *neither* at its bracket, so narrowing continues to bytes and
  `interpret` mints a provisional object. A known multi-word unit reads
  purely at the wider bracket and is **glossed** as one symbol. This is
  speed reading that slows at novelty.
- **Parallel-first falls out.** The open read is the first bracket of any
  input; the context pass of 9b (7a) is not a schedule but the first
  thing attention does. `interleave:N` was the open bracket's width in
  sentences.
- **Expectation at every bracket (Alec, 2026-09-27: call it expectation,
  in line with mathematical expectation, not "prediction").** We expect
  something in a past, current or future frame, and the expectation is
  applied with the opposite sign so that what is processed is mostly
  surprise. There is an expectation for any subject of attention — a
  whole sentence, the next concept, a past frame recalled — so the one
  mechanism is the expectation of the reading at the current bracket: the next byte inside a word,
  the next word inside a sentence, the next sentence inside a document,
  the next row in the chain. Same ARMA machinery, same negative image,
  same surprise column ([expectation §2.6](../specs/2026-09-20-accessible-mind-subsystems.md#26-expectation)),
  with the level as an argument. Consequences: a training target at every
  bracket rather than one per sentence, which closes most of the
  supervision-density gap against a token model; and the pilot's next-word
  gate becomes this predictor at the word bracket, not a separate scorer
  ([LLMEquivalence](../LLMEquivalence.md), condition 2).

## 2. Why after 7.5 and 7, before 6.5

- **7.5 supplies the chooser.** One softmax over every candidate operation
  at every location, fixed rounds with an eligible STOP, exploit plus one
  explore path, straight-through learning
  ([spec](../specs/2026-09-26-one-operation-per-round.md)). Narrowing is
  not a second policy: **divide**, **descend**, **gloss** (stop at this
  bracket) are candidates in that softmax at the bracket's location,
  chosen and credited the same way as the grammar's operators. Built
  before 7.5, the policy would need a chooser 7.5 replaces.
- **7 supplies the terminal encoding.** The closing makes the sentence
  bracket's reading a row with its `.where` and `.when`
  ([two truths §3.1](../specs/2026-09-16-two-truths-ideas-and-relations.md#31-idea-rows-decided)),
  which the level-indexed predictor needs at the row level and which pins
  the order of readings across the open bracket.
- **6.5 continues it.** Identity binding — bind to a column in the
  recency buffer or cued frames, or mint — enters the same softmax as
  further candidates, and the inter-frame predictor's sources go live
  ([spec](../specs/2026-09-26-independent-components.md)). 6.8 puts the
  bracket candidates and the level-indexed predictor in place first, so
  6.5 adds to one chooser and one predictor rather than two.

## 3. Landing 6.8-1: the fast loop is kept

**The stop is pinned at words.** Narrowing always proceeds to the word
bracket and never below it unless the reading is *neither* (unknown word
→ bytes → mint) and never above it. The compiled per-word step therefore
keeps its shape: 7.5's one-softmax reducer over the two-slot window is
its inner body, and 6.8-1 adds to that layer the bracket candidates and,
before the sentence, the open read. Nothing else changes in the inner
loop. The open read is amortised over the group it covers.

**What is added.**

1. *Bracket candidates in the 7.5 softmax*: `divide` (split the current
   bracket at its heterogeneity, i.e. between the occurrences whose poles
   disagree), `descend` (read the bracket's parts), `gloss` (accept this
   bracket's pure reading as one symbol; STOP at this level). With the
   stop pinned, `gloss` above the word bracket is masked and `descend`
   below it is eligible only on *neither*. The candidates are declared in
   the grammar file like any operator and carry no predefined surface.
2. *One narrowing budget*: the number of bracket operations an input may
   cost, replacing `subsymbolicOrder` and `symbolicOrder`. It bounds the
   7.5 rounds spent on bracket candidates. Name it in Params; the old
   knobs are rejected by the schema.
3. *Expectation at every bracket* (the "level-indexed predictor" of
   earlier drafts): the existing inter-sentence expectation generalised by
   a bracket-level argument, with the **word** and **sentence**
   levels live in 6.8-1 (byte and row levels declared, off by default,
   measured in 6.8-2 and item 6.5 respectively). The word-level prediction
   is a discrete choice from the candidate bank, so it is a distribution,
   not a point (LLMEquivalence, condition 2). Its surprise feeds the same
   column and the same negative image at its level. The word level is the
   NanoChat gate's evaluator (item 4).
4. *The open read as the first bracket*: the 9b context pass, re-expressed
   as bracket width; no gradient step, as decided (9b (i)).

**Compiled shape (Alec's question, 2026-09-27: without the loop over
words, will this compile in a GPU-friendly way?).** Yes, on the same
terms 7.5 already meets, and 6.8-1 does not remove the word loop: with
the stop pinned, narrowing *is* the per-word `while_loop` with its static
bound (`serialWordCapacity`). The general form keeps three static
properties: (i) **brackets are a padded table**, `[B, K, 2]` intervals
with a validity mask, `K = attentionBudget`; `divide` writes two intervals
into free slots, `descend` writes the children from the fold ladder's
retained witness, `gloss` marks a slot done — all tensor writes, no
Python over rows; (ii) **rounds are a static budget with early STOP**, as
7.5's rounds are, inside the existing `while_loop` autograd pattern; (iii)
**per-bracket work is batched over the reading axis** the field already
has (`[percept, batch, reading, pole]`, containment by mask), so the open
read and every narrowed read are one batched field read. What would not
compile is the same as today: host-side Python over rows or edges (item
1's islands) and data-dependent recursion; the design has neither. The
grammar's sequence of pure readings is variable-length under a static
cap, which is what 7.5's rounds already consume. Batching across
sentences remains the throughput lever (item 1).

**What is deleted**, per the no-legacy rule, not gated:

- `modeSchedule` and `serial` as a mode: the bracket schedule with its
  pinned stop is the serial loop; `parallel` is the open bracket alone.
- The subsymbolic-versus-symbolic loop distinction and `subsymbolicLoop`:
  narrowing is the loop; encoding (symbolization) is what a pure bracket
  does.
- The two order budgets, replaced by the narrowing budget.
- The boundary-only sentence predictor as a separate object; it is the
  sentence level of the one predictor. Its knobs (`interLossWeight`,
  `armaScale`, `interContrastiveWeight`) become per-level.

**What stays.** The grammar catalogs and their faces; `interpret`; the
closing; STM; the tied reconstruction; the field's folds; the where registry
and the two-rung ladders; every 9b contract.

## 3a. The word whole (Alec, 2026-09-29; taken up with this item)

"We can predefine a word whole that is a cut of non-white space letters
if that would help our certainty with Lexing words." It was offered
during the review of item 7
([two truths §17.7](../specs/2026-09-16-two-truths-ideas-and-relations.md#177-a-word-is-a-concept-its-object-replaces-it-and-no-row-is-added))
and placed here the same day: "Waiting for 6.8 is fine, as long as it's
written down. That's next anyway." Item 7 builds none of it.

**What it is.** A whole, predefined in WholeSpace, whose extent is a
word by the common definition: a maximal run of letters. **Decided
(Alec, 2026-09-29):** "In the word whole, punctuation and digits also
separate words; use the common definition." White space, punctuation and
digits all separate; a word then has one whole that is its own extent.

**Why it belongs to this item.** 6.8-1 pins its stop at the word bracket
(§3). The word whole is the property whose run is that bracket, so the
bracket a word is read at and the whole a word has are one extent.

**What it is for.**

- *A whole that learning does not move.* The wholes a word has today are
  the character classes that hold on its surface. WholeSpace names eight
  of them, `letter`, `digit`, `whitespace`, `punctuation`, `capital`,
  `control`, `high_byte` and `pad`, and their memberships are learned, so
  a word's wholes can change while it is being learned ("hello" has
  `letter`; "abc123" has `letter` and `digit`). Measured in the item 7
  review: the property rows of one word read as `(1, 9)`, `(1, 8, 9)`,
  `(8, 9)`, `(9,)` and `()` over one training run.
- *One cut.* WholeSpace cuts its field where a learned property changes,
  and the reader cuts words by a fixed rule (`Meronomy.word_spans`). The
  word whole makes the two agree.

**To settle in this item** (Claude's notes; nothing here is decided).

1. *The reader's rule changes with it.* `Meronomy.word_spans` separates
   at white space and punctuation and not at digits, so today "abc123"
   is read as one word and "01" as a word. By the decision above
   "abc123" holds the word "abc" and a run of digits, and "01" is not a
   word. One rule is to serve the reader and WholeSpace both.
2. *The proofs of XOR read digits.* XOR_exact and the grounded XOR read
   "00", "01", "10" and "11". When digits separate words these are runs
   of digits and not words, so what reads a run of digits, and what
   concept it is given, has to be said before the word whole is built,
   and every proof of XOR is measured before and after it
   (two truths §15.1; they run in every receipt).
3. *Fixed or learned.* "Predefine" is read as fixed: the word whole's
   membership is not a learned coefficient. The other eight stay
   learned.
4. *It does not say where a word is.* Every word has the word whole, so
   it cannot by itself keep a word from being read where only its whole
   is. Item 7 requires that of the read: a word is evidenced only where
   its part is read (two truths §17.7, test 29).

**Tests, proposed.** On every sentence of the evaluation corpus the runs
of the word whole are the reader's word brackets; the word whole's
membership is the same after training as before it; and a word's
definition holds the word whole beside its other wholes.

## 4. Tests and measurements

Mechanism tests, unconditional: (1) the field admits only order-independent
operations — a test that a grammar file declaring `lift` as a field
operation is rejected and that `and`/`or`/`not` are rejected between
brackets; (2) a pure bracket is not divided, a *both* bracket is, a
*neither* bracket descends, and with the stop pinned a known word never
descends and a wider bracket never glosses; (3) an unknown word descends
to bytes and mints exactly once, and its second occurrence reads purely at
the word bracket; (4) the open read precedes the sentence and takes no
gradient; (5) the word-level predictor produces a distribution over the
candidate bank and its surprise reaches the column; (6) the deleted knobs
are rejected by the schema and absent from every shipped config; (7) the
XOR gate and exact-zero controls are unchanged; (8) the serial
reconstruction baseline is within the reviewed-9b tolerance of its
current values.

Measurements, recorded not gated: the open pass's cost against item 1's
per-word throughput baseline, taken before 6.8-1 starts; the both-rate and
categorical-discrimination index per level (item 4's fields), since the
policy turns on the field's *both*; and the word-level predictor's top-1
and reciprocal rank on the frozen NanoChat item manifest with the
shuffled-prefix control. Learning gates follow item 9's million-sentence
prerequisite: ordered word-level prediction against shuffled and
context-free controls at equal updates, three seeds, declared in advance,
re-declared from item 9 at the word bracket.

## 5. Documentation after landing

- [Architecture](../Architecture.md): the three-operations section becomes
  "one attention": bracket, field criterion, narrowing policy, level-indexed
  predictor; the mode-exclusion paragraph becomes the theorem; the pump
  section describes the open read and narrowing budget.
- [Params](../Params.md): the narrowing budget; the per-level predictor
  knobs; removed knobs listed as rejected.
- [Language](../Language.md): the bracket candidates in the operator
  catalog with their three faces (`divide`/`descend`/`gloss` have no
  generate face; their reverse is the closing's bracket).
- [Accessible mind spec](../specs/2026-09-20-accessible-mind-subsystems.md):
  §2.2–2.4 restated as bracket widths; §4's table gains the bracket
  candidates' row.
- [NanoChatGrammarPilot](../NanoChatGrammarPilot.md): the gate is scored by
  the word-level predictor.
- [LLMEquivalence](../LLMEquivalence.md): condition 2 notes the word-level
  predictor as the discrete distribution.
- [FutureWork](../FutureWork.md): 6.8-2, already recorded.
- [Testing](../Testing.md) and a receipt under `doc/benchmarks/`.

**The conceptual counterpart of the bracket (Alec, 2026-09-28).** "Words are
a formula for narrowing attention." The bracket narrows the input; the words
narrow the **domain of discourse**, Boole's universe of discourse, which the
situation seeds and each word restricts. They are two attentions that meet
in one chooser:
`divide`, `descend` and `gloss` choose the next bracket, and the
restrictors — nouns, adjectives, verbs and adverbs, one kind of operator,
each a projection onto a smaller subspace — choose the next domain, all as
candidates in the 7.5 softmax. The criterion of this plan, that the field's
operations are the order-independent ones, is derived from the
representation in
[accessible mind §2.0](../specs/2026-09-20-accessible-mind-subsystems.md#20-fields-codes-and-ideas),
and the language mechanics are in
[§2.0.1](../specs/2026-09-20-accessible-mind-subsystems.md#201-words-are-a-formula-for-narrowing-attention).
Expectation at every bracket has a counterpart at every index — the next
thing, the next time, the next alternative — of which only the first two
have machinery
([FutureWork](../FutureWork.md#modality-as-the-third-index-noted-2026-09-28)).
**`attentionBudget` does not meter the words** *(Alec, 2026-09-28)*: "words
do narrow attention, but I think the main use of the attention budget is
prior to grammatical analysis, so they would not figure in." The budget is
the number of bracket operations an input may cost (§3); the words'
narrowing of the domain is grammatical analysis and has no budget of
attention; 7.5's static round count is the shape of a compiled loop. Nor must a reading narrow the domain at all: "percepts are not
necessarily limiting because they may direct us to the symbol 'everything',
which has no narrowing effect" — the conceptual counterpart of the open
read.
**What the budget does cover** *(Alec, 2026-09-28)*: "we regard symbols as
percepts. So perceptual attention may exclude perception or higher order
thought; and there is good evidence that both of those do share a single
attentional budget." A bracket may therefore be over the input or over
symbols, and both draw on `attentionBudget`. "The conceptual narrowing is
different, and probably needs a Ground in order to make its Figure
meaningful": perceptual attention discards what it excludes, while the
words keep the domain they elect from
([accessible mind §2.0.1](../specs/2026-09-20-accessible-mind-subsystems.md#201-words-are-a-formula-for-narrowing-attention)).
**The budget is for percepts** *(Alec, 2026-09-28)*: "I think there is a
budget for percepts, not for conceptual space (although thoughts do shape
the latter)." *Claude's reading, to confirm:* the thought work budget
(accessible mind 2.8) and `attentionBudget` are then one meter, since a
thought operation attends to symbols and symbols are percepts. They are
separate today, the first built and the second not; this item is where they
would be joined.

## 6. Questions for Alec (none blocking 6.8-1) — 6a and 6b answered 2026-09-27

**6a, decided (Alec, amended 2026-09-27).** Some operators require a
**single prominent symbol** to operate on. **All Boolean operators** —
`and`, `or`, `not` — **operate on a field of concepts at one time**: a
plural bracket is aggregated by them directly (a union of the field's
concepts is a temporary whole — *symbolic*, not conceptual, since it is a
superposition of symbol values; corrected 2026-09-28,
[accessible mind §2.0](../specs/2026-09-20-accessible-mind-subsystems.md#20-fields-codes-and-ideas))
and no separate
multi-argument operator is declared for it. The non-Boolean
(order-dependent) operations of a grammar are operable only once a
single concept has been identified.
Applied to the parallel activation of the whole field they would produce
a field of concepts that would then have to be aggregated or attentionally
eliminated before anything could proceed. The decision is made as
follows:

- *Operand kinds are declared.* Every operator declares the kind of each
  operand: **field** (a pooled reading over a bracket) or **symbol** (one
  identified concept). The Boolean operations `and`/`or`/`not` and the
  bracket candidates `divide`/`descend`/`gloss` take field operands; every
  order-dependent operator takes symbol operands. The parser rejects a
  grammar file that gives an order-dependent operator a field operand.
  This is static, checked at load, and it is the whole of the enforcement.
- *A bracket yields a symbol when it is pure and singular.* Pure: exactly
  one pole of its pair is nonzero after pooling, with the minor pole at
  the existing exact-zero tolerance. Singular: exactly one concept
  identity has support in the bracket, so the projection to a code is
  unambiguous ([accessible mind §2.0](../specs/2026-09-20-accessible-mind-subsystems.md#20-fields-codes-and-ideas),
  a code is the nearest-row projection of a field). Both tests are crisp;
  `gloss` is the candidate that performs the projection, and it is
  eligible only when both hold.
- *Otherwise only field and bracket candidates are eligible.* A bracket
  that is impure (*both*) or plural (several identities) offers `and`/`or`
  (aggregate the field of concepts into a kind or a conjunction), `not`
  (attentional elimination, non-affirming exclusion), `divide` and
  `descend`. The 7.5 softmax masks the ineligible candidates at that
  location; everything graded — how impure, how plural — goes into the
  logits, so the chooser learns when to gloss a nearly pure bracket or
  divide a barely heterogeneous one, while the mask alone forbids a
  grammar operator on a non-symbol.

**6b, decided (Alec).** The narrowing budget is `attentionBudget`.

**6c, decided (2026-09-27; the conference freeze dropped 2026-10-03).**
Until 6.8-1 lands, the NanoChat gate is scored by the existing
`IntraSentenceLayer` held prediction, an untrained point predictor in idea
space used only for evaluation, stated as such; the trained, distributional
word-level expectation is part of 6.8-1 and does not reintroduce the retired
within-sentence cursor loop (one expectation read per word inside the
existing per-word step).

- **6a.** The field's `and`/`or`/`not`: keep them declared in `<compose>`
  as today, with the field-versus-grammar criterion enforced by the parser
  (recommended), or make them the field's built-ins outside the grammar
  file?
- **6b.** The narrowing budget's name: `attentionBudget` (recommended), or
  keep `symbolicOrder` with the new meaning?
- **6c.** For the conference checkpoint, is the word-level predictor pulled
  forward as evaluator only (recommended; no training-loop change before
  the freeze), or also trained at the word level before the freeze?

## 7. What reading attention and global attention carry into 6.8 (Alec, 2026-10-02)

Alec, on the configuration review: "Reading attention: if 6.8 replaces it,
great, but let's make sure we aren't deleting useful functionality."
"Global attention: same; let's make sure we are not dropping features with
the 6.8 integration."

Both modules stay until 6.8 lands, and they retire within it once every
capability below has its home. They are `ReadingAttention` and
`GlobalAttention` in `Spaces.py`, with the flags `readingAttention`,
`globalAttention` and `globalAttentionConsume`. Their four configurations
remain the reference until then: `MM_reading`, `MM_global`, `MM_qa` and
`matrix/MM_20M_grammar_reading`. Before then, two things make them usable:

- the 6.9 defect in the mixing leaf staging is fixed;
- `MM_qa`'s TruthSet input is repaired.

Their weekly tests crash on the first and the second keeps `MM_qa` from
building.

| Capability today | In this plan | To add |
|---|---|---|
| **Reading attention** | | |
| A learned choice of where to read next, from the previous pass's concept and the STM symbols | The narrowing candidates (`divide`, `descend`, `gloss`) in the 7.5 chooser; 6.8-1 pins the stop at words | — |
| **Priming steers reading.** A span scores high when its content lies near a prototype the intent has primed: `max over v of cos(key, row_v) · boost_v`, the codebook-retrieval prior | Not here | The priming surface enters the logits of the bracket candidates. This is the same surface that item 6.9's §15.3 uses for the answer's context. |
| Supervision on the next word: cross-entropy on the next span | The word-level expectation predicts the next word as a distribution over the candidate bank (§3, item 3) | — |
| Teacher forcing: the true next span in training, its own prediction at inference | Not stated | State it for the word-level expectation |
| A shift bootstrap: at initialization it reads exactly one word per pass | 6.8-1's stop pinned at words | — |
| The scope it writes drives the top-down mereology handoff (`_passback_scope_where`) | The bracket is the scope | The handoff reads the bracket table |
| **Global attention** | | |
| One registry of addressable spaces: the input window, STM, LTM and the part, whole and symbol codebooks (`_addressable_spaces`, which the reasoner also reads) | "A bracket may be over the input or over symbols" (§5); the spaces are not named | Name the spaces a bracket may cover, from the existing registry. Keep the registry. |
| One choice across all the spaces, with a learned prior for each. Recall and reading are one mechanism; the type tag says which. | One attentional budget for both (§5); no choice across spaces | A space choice among the 7.5 candidates, under `attentionBudget` |
| A typed `.where`: which space, and the interval within it | Brackets are intervals over the input | The bracket table carries a space tag |
| **A learned read trained by the answer.** The read enters the answer through a gate initialized at zero, so retrieval that lowers the answer's error is rewarded. The keys are detached. | Thought's hard reads, which have no parameters. Since 6.9 §15.3, the primed symbols are also in the answer's context. | A learned reader of the primed symbols, owned by the answer. 6.9 §15.3 may already provide it if the answer reads the bank through this module's scorer and consume gate. |
| Temperature on the explore pass, so that task error shapes where attention lands | 7.5's explore trial | — |

## 8. Acceptance test carried from item 6.9: XOR of two words (Alec, 2026-10-02)

Alec: "Yes, option B, we'll get it working in the next stage."

MM_xor's `test_convergence` must pass, with its bar unchanged (loss below
.20 within 200 epochs), while the words are read as words.

Until the 6.9 migration, this test passed by a shortcut. The radix reading
promoted chunks that cross the word boundary (`hello wo`, `hello th`,
`loving w`, `loving t`), which gave one percept per sentence, so XOR was a
lookup of four codes. Meronomy promotes words only. Now the test needs the
open read to compose two words nonlinearly before the answer reads them.
Measured in the 6.9 receipt of 2026-10-02 (6.9 plan §17), three things stand
in the way:

1. **No live recurrence.** Each parallel binding re-reads the original
   percepts, and the WholeSpace carrier between bindings returns a neutral
   field. So only the last of MM_xor's three bindings learns from the
   answer.
2. **A linear reading of words.** The numeric head reads the word slots
   linearly, which gives a sum of per-word contributions. A sum cannot be
   XOR, and its best is one half everywhere (6.9 plan §3.3).
3. **The first word drops out.** In failed runs the first word's six content
   numbers fall to zero.

The field's `and`/`or`/`not` over the open bracket (§1) is the
order-independent nonlinear operation this test needs. XOR_exact already
shows it on primitive memberships.

## 9. Carried from item 6.9 (Alec, 2026-10-03)

Item 6.9 closed on 2026-10-03 as the baseline of grammatical learning
([6.9 plan §25.3, §26](2026-09-29-item-6-9-xor-grammar.md#26-review-of-the-closing-round-claude-2026-10-03)).
Two of Alec's closing comments are this item's work.

**9.1 Exploit and explore for compose, think and generate.** "Compose,
think, and generate all need exploit and explore trials." Item 7.5 gave
compose a greedy derivation and an explore derivation that departs from it at
one round, both costed under the same parameters, the explore kept only on
strictly lower cost of the objective that owns the choice. 6.9's closing run
showed why generate needs the same: its walk, a hard argmax trained through
a straight-through surrogate, chose STOP at the first step in all 3,200
decodes and never discovered that undoing the binary operation would yield
the missing word, because the missing-word penalty does not depend on the
transition not taken. So:

- each of the three grammars' walks has an exploit path and one explore path;
- both are costed under the same parameters before either trains;
- the explore path is kept only on strictly lower cost of the walk's owner:
  reconstruction for generate as the decoder, the answer for generate as
  output (a choice, not a gradient, so ownership stands), the thought
  controller's return for think;
- the record keeps which path was kept, and the audit reports the fraction
  of walks where explore won and the derivation stability per sentence, as
  for compose.

This is the §3 chooser extended, not a second policy: `divide`, `descend`
and `gloss` already sit in that softmax, and the explore path is how any of
the three grammars finds an action the greedy path never takes.

**9.2 Codes need not converge all the way.** "Yes, but if they don't
converge all the way, that's fine." The codes may drift partly together
under reconstruction (6.9 §26.1: mean squared off-diagonal cosine .07 → .37
in the closing run). The antipode term keeps them from collapsing; the gates
read the answer and the read-back, not the geometry. Code geometry stays in
the audit as a diagnostic, not as a bar.

**Acceptance tests carried over** (with §8): MM_xor's word-level XOR; and
6.9's two XOR_grammar gates, which may only improve against the closing
record (the no-regression rule), with the decoder's inferred operations
expected to match the compose derivations once it explores.

## 10. Review of the first 6.8 round, with the decoder exploration and the operators update (Claude, 2026-10-04)

[Receipt](../benchmarks/2026-10-03-operators-attention/README.md). One
uncommitted round carried 6.9 §26.3 (the decoder's explore walk), the
operators update (the catalogue's §12 implementation) and 6.8-1 with §§7–9.
Not accepted yet; held for the measurement below, not for a found regression.

### 10.1 What landed

- The default suite is green: 4,829 passed, 0 failed, 285 skipped, 124 s.
- XOR_exact, grounded XOR and the 46 retained reading/global capability
  tests pass. The four reference configurations pass their mechanism checks.
- **MM_xor passed its unchanged word-level XOR bar (.183 against .20)**, §8's
  acceptance test, in one run.
- Operators: operand kinds, faces, the effect ledger; `sum` as a mean,
  intersection as the signed minimum, compound case selection, `non`
  without a faithful inverse; `exist`, `true`, `lookup` retired.
- Attention: the typed bracket table and one budget, the open read without
  a gradient step, divide/descend/gloss eligibility from the paired
  evidence, the fixed word whole (maximal letter runs), word and sentence
  expectation, one registry over input, STM, LTM and the three codebooks,
  the priming prior in the chooser, the answer-owned learned reader behind a
  zero gate. The old modes, orders and budgets are rejected.
- Exploit and explore for input narrowing, compose, thought, anticipation and
  the decoder (§9.1), with zero selection violations.

### 10.2 The two "blockers", read

**The class comparison (.321 against the closing record's .115).** One
unseeded run against one. This round's five single trainings gave .0013,
.031, .040, .321 and .875. By 6.9 §20.5 a run between the bands is a moving
representation, and five changes to the reading went in at once. The
comparison that can show a regression is the ten-run gate with both bars
against §22's 9/10 and 5/10.

**Reconstruction 0/4: the decoder emits one word.** The generate walk, not
attention. In the audit's last 128 decoder walks greedy chose STOP first in
91. The explore walk was kept in 37; in 32 of those it tried "undo the
binary, then stop" and cost .33 against greedy's 7.3: both words recovered.
In the other 91 the alternative was mostly `not`, cost about 16, and greedy
was kept. Two things follow:

1. Exploration is deterministic where it should sample: the departure
   "excludes greedy's choice and follows the best available suffix", so with
   a one-step greedy walk it is always the second-ranked action. When that is
   `not`, undo is never tried in that row that epoch.
2. After 400 epochs the policy still ranks STOP first despite 32 large wins
   for undo. Either the straight-through gradient barely moves the
   STOP-versus-undo margin under momentum SGD, or it moves it too slowly for
   the budget. The audit records actions and costs, not the margin, so it
   cannot say which; "more training" helps only in the second case.

Alec, 2026-10-04: the two-word walk "is an interesting finding that may
eventually speed everything up", though it "would have to incorporate a bit
of the grammatical tree over the two words". The walk is the tree run
backwards: one undo per node, the operation inferred from the root and the
pair searched in the shortlist. What the root does not yet carry is the
order of the pair (6.9 §24.5: product and mean are commutative), so a glossed
two-word unit decodes to the right words in an arbitrary order until order
is bound in (MAP's permutation, or a surface marker; catalogued). With that,
a known multi-word unit is what 6.8-2's dynamic stop wants: read as one
symbol above the word bracket and decoded exactly in one undo, the tree
inside the unit carried by the root rather than walked.

### 10.3 Also noted

- The forward is 2.6× slower with the open read (.141 s against .055 s whole
  forward). Alec: "the slowdown will have to be addressed." Item 1's
  territory; recorded there.
- The decoder's kept path flips between the one-word and two-word walks
  (stability .51), which feeds the moving target.
- The fresh-model NanoChat scoring filled the definition store at item 136:
  frozen-learning evaluation still mints definitions. Item 4's trained
  evaluator needs evaluation not to admit. No capacity change.

### 10.4 Asked of Codex (Alec agreed, 2026-10-04)

1. The ten-run XOR_grammar gate, one training per run with both bars and
   the §20.5 bands; MM_xor ×10 (the §8 acceptance); the sum control ×10.
2. The explore departure sampled among the eligible actions, not the
   second-best, for all walks.
3. In the audit, the decoder's STOP-versus-undo margin per step.
4. Evaluation does not admit definitions (for item 4; noted now).

## 11. Review of the §10 measurement (Claude, 2026-10-04)

[Receipt](../benchmarks/2026-10-03-operators-attention/README.md). The three
changes of §10.4 are in: sampled exploration for every walk, the decoder's
margin in the audit, frozen evaluation that admits nothing. The measurement
is complete: thirty trainings, no retries. Not accepted; two findings, one of
them about the gate itself.

### 11.1 The counts

| | This round | §22 |
|---|---|---|
| XOR_grammar class | 7/10: seven at 0 (four below 1e-3), one between (.065), two above ¼ (1.05, 3.04) | 9/10 |
| XOR_grammar reconstruction | 0/10 | 5/10 |
| MM_xor | 10/10 | red by 6.9 §17 |
| Sum control | **0/10** | 10/10 |

### 11.2 The control is red, so the class gate no longer measures composition

The sum-only grammar learned XOR: three runs at 0 (.0013, .0007, .017) and
checkerboard contrasts up to −2.0 in nine of ten. By 6.9 §20.5 an affine
reader over an additive composition cannot leave ¼; so the answer path is no
longer affine. Codex found the cause and the code confirms it: §7's "learned
read trained by the answer" was built as `PrimedSymbolReader`
(`Attention.py`), an MLP scorer over cosine features with a softmax read and
a learned consume gate, and `BasicModel` installs it in every numeric head's
path (`answer_attention`, applied in `_forward_head` whenever the output has
no concept ids). Its keys are the echoic shortlist, which holds the
sentence's own words. A nonlinear reader over the bag of words is a hidden
layer over word presence, and XOR of two words is learnable from it with no
composition at all. In §22 the shortlist entered the head as an affine
feature (the priming-weighted code sum) and the control held at 10/10.

So the class 7/10 is not evidence of grammatical learning, and MM_xor's
10/10 is suspect for the same reason unless its head bypasses the reader.
The control did its job.

**The rule, made explicit:** the answer's reader on the XOR gates is affine.
The understanding's context may include the shortlist, as Alec required, but
as affine features; the learned attention read (the migrated GlobalAttention
consumer) is retrieval for thought and generation, not part of the numeric
head. Where the control passes, the class gate measures composition; where
it does not, nothing the class gate says counts.

### 11.3 Reconstruction 0/10: the margin moves, too slowly for the budget

The audit answers §10.2's question. The decoder's first-step margin of STOP
over "undo the binary" falls from 1.99 to 1.43 over 400 epochs, −.0006 per
update, positive at every observed parent; greedy chose STOP in all 3,200
walks. At that rate the margin crosses zero after roughly 2,300 more updates,
three times the budget. Meanwhile the explore walk, now sampled, is kept in
1,030 of 3,200 decodes with cost .33 against greedy's 7.3: a large,
systematic advantage that the straight-through gradient transmits at
−.0006 per step, because that gradient flows through the chosen action's
value and not through the choice.

Alec's "more training" would work in principle and is the wrong fix: the
budget is the bar. The right one is the mechanism the thought and generate
policies already have, explicit credit: reconstruction credits the decoder
chooser with the kept walk's advantage (its log-probability times greedy
cost minus kept cost), owned by reconstruction like the rest of the decoder.
Compose never needed it because its choices change the root continuously;
STOP versus undo is a discrete structural choice whose cost gap the
surrogate cannot see.

### 11.4 Also

- Two class runs diverged (MSE 1.05, 3.04): the reader's gate and scorer
  moving under a moving representation. They should disappear with 11.2.
- Kept-path stability of the decoder .61 (was .51); compose .94; input
  narrowing .99.
- Zero ownership conflicts; 161 complete test ports; suite green in the
  previous round, not re-run here.

### 11.5 Asked of Codex

1. The numeric head's reader is affine (11.2): remove `answer_attention`
   from the numeric head's path; the shortlist enters as the affine
   priming-weighted code sum of §22. The learned reader stays for the
   generate walk and thought where retrieval over memory spaces is its job.
   State which configurations route the answer through it.
2. Decoder policy credit (11.3): reconstruction credits the decoder chooser
   with the kept walk's advantage; the audit records the margin as now.
3. Re-measure the three tens on the frozen source: the control must be
   10/10 before the class count means anything; comparison §22 (9/10, 5/10)
   and MM_xor 10/10.

### 11.6 The decoder's stop is §6a run backwards (Alec, 2026-10-04)

Alec: "So we need a mode that will force attention to break at spaces? The
best idea would be to have the grammar learn that it needs to further analyze
the compound if it consists of two meaningful wholes (which are preferable to
a larger chunk, assuming the meaning can be computed)."

No forced mode. Reading already breaks at words (6.8-1 pins the stop at the
word bracket; the audit's compose derivations are over two leaves). The
failure is the decoder's, and the rule is §6a's criterion applied to
decoding:

- The decoder **emits** (glosses) only when the current top is **singular**:
  one shortlist symbol accounts for it.
- When the undo yields two children that are both **meaningful**, two
  symbols with support in the shortlist, the top is a compound and the undo
  is the only eligible move. "The meaning can be computed" is "both children
  are readable", which the pair search already computes.
- The policy keeps what it should learn: which operation to undo, inferred
  from the root. STOP versus undo is no longer learned at −.0006 per update
  (§11.3); it is eligibility.

Consequences: 6.9 §17's shortcut is closed at its root, since a chunk whose
parts are meaningful is never glossed as one symbol; and 6.8-2's glossing is
confined to compounds whose parts do not compute (idioms such as
`MM_ladder_idiom`'s "kick the bucket"). Two meaningful wholes are preferred
to a larger chunk.

This replaces §11.3's policy-credit proposal. §11.5 item 2 becomes: the
decoder's eligibility mirrors §6a. Items 1 and 3 stand.

## 12. Review of the §11 measurement (Claude, 2026-10-04)

[Receipt](../benchmarks/2026-10-03-operators-attention/README.md). The three
asks of §11.5 with §11.6 are in: the numeric head is affine (no
`PrimedSymbolReader` in `_forward_head`; the learned reader stays with
generation and thought), the decoder's eligibility mirrors §6a (emit only
when singular; undo when two meaningful wholes), the three tens measured
once. Not accepted yet.

| | §11 round | §10 | §22 |
|---|---|---|---|
| Class | 2/10: two at 0, five at ¼, three between | 7/10 (contaminated) | 9/10 (frozen codes) |
| Reconstruction | 6/10 | 0/10 | 5/10 |
| Both bars in one run | 2/10, the first time | 0 | — |
| MM_xor | 10/10, affine head, so real: §8's acceptance | 10/10 (suspect) | red |
| Sum control | 10/10, every run at exactly ¼ | 0/10 | 10/10 |

**What worked.** STOP masked in all 6,400 first-step observations; the
decoder undoes to both words; reconstruction 0 → 6; two runs meet both bars;
MM_xor's word-level XOR passes ten of ten with an affine reader; zero
ownership conflicts.

**Why the class gate fell.** Five runs at exactly .2500 are the affine floor,
reached only over an additive composition. Mean is additive (6.9 §22.2), and
the compose chooser, trained by reconstruction alone, has no reason to prefer
conjunction: product and mean are both exactly invertible by search, so
about half the runs settle on the linear one. In §22 the operators were
`min` and `max`, both nonlinear, so any derivation was readable and §3.11's
property held ("any of the four operations and the same choices for every
sentence"). With mean as OR that property is gone and the gate contains a
coin flip. The three runs between the bands are the moving target: in the
audited run two sentences switched derivation once around epoch 200, and the
decoder's kept path is unstable (.34) under sampled exploration among the
eligible undos, so the codes' gradient changes direction. To confirm from
the saved observations: the final compose operator per run against its band
(the run-10 audit records rule ids without names).

**Recommendation.** Disjunction becomes the probabilistic sum, a + b − ab,
in conjunction's form (certainties combined, identity normalized): nonlinear
and invertible by search, so every derivation is XOR-readable and the class
gate measures stability, not the chooser's choice of operator. Mean stays in
the catalogue as `sum`, the control's operator. Then the three tens again.
If mean stays as OR, the gate's reading must change instead, since half its
runs sit on the floor by construction.

Also for the audit: rule names beside rule ids; per-run final compose
derivations.

### 12.1 The composition gate, not a grammar gate (Alec, 2026-10-04)

Alec: "The xor test, as we've written it, is kind of meaningless for grammar
(on an untrained model)." Agreed. On four sentences with no corpus nothing
says which operation a construction calls for, which is what grammar is;
under reconstruction-first the chooser is indifferent between equally
invertible operations, and the class gate then measures a coin.

What the fixture measures is the machinery: two words compose nonlinearly
into one understanding; the understanding decodes back to the words; an
affine reader reads a nonlinear function of the pair from it; one objective
owns each weight; none of it regresses. The sum control keeps that honest.
So the XOR table (XOR_exact, MM_xor, XOR_grammar's two bars, the sum
control) is the **composition gate**, read by 6.9 §20.5, under the standing
no-regression rule. To take the coin out: every binary operator nonlinear
(disjunction = probabilistic sum; mean stays catalogued as `sum`, the
control's operator), so any derivation is readable and the gate measures
stability and decoding.

**Grammatical learning** is which operation, learned from what the
composition is for. Its supervised form is measured now by the grammar
lessons in `MM_grammar_wording` (the compose-choice lesson; the bounded
wording gate of 2026-09-20). Its unsupervised form, operator choice shaped by
expectation over a corpus, is measured by item 9's evaluation, which is
complete and reviewed, on the checkpoint item 0's run produces: "item 9
should be complete: we are at 6.8 and descending." No four-sentence fixture
stands in for it. Item 6.9's "baseline of grammatical learning" is renamed
accordingly: the baseline of the composition mechanism.

## 13. Review of the §12 measurement (Claude, 2026-10-04)

[Receipt](../benchmarks/2026-10-03-operators-attention/README.md).
Disjunction is the probabilistic sum; `sum` keeps the mean; derivations
carry rule names; the thirty trainings ran once. Class **0/10** (nine
between, one at ¼), reconstruction **7/10**, both bars 0/10, MM_xor 10/10,
control 10/10. Not accepted.

### 13.1 Correction to §12

The retrospective confirmed the mean only for §11's run 10; the other
quarter-band runs have no saved derivation. And with OR nonlinear no run
reached 0. So the §12 reading, that the ¼ floor came from the mean, was
wrong or at most a minor cause. The saved roots say what did.

### 13.2 The second word has vanished from the understanding

Computed from the audited runs' saved roots (`geometry-end.json`):

| Run | hw·ht cosine | lw·lt cosine | centered singular values | affine weight norm for an exact fit |
|---|---:|---:|---|---:|
| §11 run 10, end | 1.000 | .884 | .727, .015, 0 | 8×10⁷ |
| §12 run 10, end | 1.000 | 1.000 | 2.607, .021, .013 | 77 |
| either run, start | −.15 / .71 | .59 / .72 | three nonzero | 2.5 / 17.5 |

Four roots have collapsed to two directions, one per first word, with
opposite labels inside each pair. Identical roots for labels 0 and 1 force
an affine reader to ½: the ¼ floor, with no linear operator needed. The
1 to 2 percent residue of the second word lets the reader hedge toward the
labels with enormous weights, which is "between" with all four labels right.

The roots coincide because `world` and `there` merged again, as in §24. The
mechanism is §24.3 and §25.4, still present: the echoic prior tells the
read-back which words were in the sentence, so reconstruction succeeds
whether or not the codes are distinct; the soft pair search blends the
competitors into the recovered leaf and trains the true code toward the
blend. The antipode term as implemented does not hold them apart.
Reconstruction's 7/10 is largely echoic: the words come from the prior, not
from conceptual space. The decoder's flip-flop (stability .009) is a likely
symptom: with merged codes both undos explain the parent equally. MM_xor's
10/10 is unaffected (the field path).

### 13.3 Two ways out

- **(B, recommended) Keep echoic memory; remove the merging channel.** The
  pair search selects hard; the recovered operand is the operator's exact
  inverse given the selected partner (division for the product, the
  corresponding inverse for the probabilistic sum); the gradient flows
  through the exact inverse and the byte cross-entropy, never through a
  softmin blend. Nothing then pulls `world` toward `there`; the antipode
  spreads the codes; product's invertibility, the reason it was chosen, does
  the work.
- **(A)** The prior from before the sentence's own write (§24.4, withdrawn):
  identity must then come from the codes.

Then the three tens again, with reconstruction's count annotated by how
often the read-back's winner was decided by priming rather than by code.

### 13.4 Perceptual space is the basis of zero-order conceptual space (Alec, 2026-10-04)

Alec: "The mereological towers are designed so that their parts and wholes
are the organizing principle within their space. If this is not currently the
case, it should be restored ... a poset of codes for each tower, parts
growing from nothing [0,0,0,…] and wholes shrinking from everything
[1,1,1,…]. Order zero concepts are a collection of positive evidence and
negative evidence, collected from these parts and wholes ... Concepts of
subsequent orders can be determined by using the connectionist strategy
already discussed, leveraging the symbol activations. ... collapse at the
higher-order stage is permissible ... 'world' and 'there' are separated by
their parts, even though they are united by their larger wholes (which, in
this test corpus, is in fact an identical context). Concepts, if they are of
a different size than percepts, might blend the conceptual locations of the
relevant percepts ... if a concept has a basis in percepts, and those basis
vectors have associated concepts, then the weights within that basis can be
applied to create a structured conceptual space which is not necessarily the
mereological space of percepts. ... perceptual space is the basis of
zero-order conceptual space."

**State verified.** The towers keep their poset (percepts in the unit cube;
properties as member sets). The field path computes an order-zero concept
from its 11b definition, evidence over parts and wholes, and does not merge
`world` and `there` (MM_xor 10/10). The serial path's leaf is the word's
dictionary row, `conceptualSpaces.1.layers.3.W`: a free parameter, randomly
initialized, trained by reconstruction since 6.9 §20; its definition sits
beside it and does not determine its location. That free row is the writer
that merged (§13.2).

**The rule.**

- Each basis element, a part percept or a whole property, has an associated
  conceptual location: its own row in conceptual space, learned, shared by
  every concept that uses it (under the shared index, the percept's
  concept).
- An order-zero concept's code is the evidence-weighted sum of those
  locations: parts and wholes with their evidence for; evidence against
  subtracting. Derived at each forward; no free word row.
- Conceptual space keeps its own dimension and metric; the percept basis
  structures it.
- Higher orders by co-activation (the catalogue's distributional pressure),
  where merging of identical contexts is permissible.

The precedent is sub-word compositional embedding (fastText, Bojanowski et
al. 2017: a word vector as the sum of its character n-grams' vectors), in
mereological form: evidence as weights, wholes in the basis.

**Consequences.** `world` and `there` share no letters, so their codes differ
by construction; merging them would merge letter rows every other word
shares. Reconstruction trains the letter and property rows and the evidence
weights. The echoic prior may stay: identity comes from parts. Shared wholes
supply the common component ("partly context, partly parts" by
construction).

**For XOR_grammar.** The association is a lookup, one row per percept, not a
linear map: its percepts carry two content numbers, and a linear image of a
two-dimensional fold cannot put four roots in general position; a table of
letter rows can. The inventory gains the letter concepts: a declared
capacity change.

Supersedes §13.3's (A) and (B). The fold ladder and the 11b evidence tables
compute the weights already; the serial leaf takes the derived code in place
of the dictionary row.

**The context half (Alec, 2026-10-04).** "Two words that mean the same thing
should have a difference in parts but an identity in context, and a
similarity space in the word2vec sense has much of its utility in virtue of
that latter metric. ... the context in the BOW models is lacking in
WholeSpace, but an obvious integration might do something like create wholes
out of parts, which is the mereological equivalent of an association
strength."

- In the derived code, parts give identity and wholes give similarity.
  Synonyms differ in their parts term and, where their contexts are wholes
  they belong to, coincide in their wholes term: different in parts,
  identical in context. The permissible higher-order collapse is the wholes
  term merging while the parts term does not. On the XOR corpus `hello` and
  `loving` share every whole and no letter.
- WholeSpace holds properties read off the input, not the contexts a word
  occurs in. The integration: a whole minted from parts that co-activate
  recurrently, membership weight as association strength. This is the sigma
  fold over the activation field (the set one order above its members,
  decided 2026-09-28), the rule chunk promotion already applies one level
  down (letters that recur together become a word). The store's weighted
  edges are the association structure; priming diffusion already runs over
  them.
- The catalogue's distributional pressure (6.9 §20.3) becomes membership
  weights in context wholes, not a pull between word codes: word2vec's
  pointwise mutual information is the association strength of a word in a
  context whole, and the word's code inherits the whole's location in
  proportion. Co-activation trains the context term, reconstruction the
  parts term; they write different things. Second-order similarity comes
  from overlapping whole sets.

This belongs to the operators update's distributional item; this round's
fix (the derived order-zero code) stands as written above.

**The wholes already exist (Alec, 2026-10-04).** "I'm wondering if we have
that higher order concepts? In which case, there may be a concept minted from
co-occurring parts that is active at the same time as its parts, whose
activation provides the distributional pressure necessary to provide BOW
implicitly." We do: item 7 writes one row per sentence at the closing, its
slots referencing its constituents' rows, and identity is its occurrences. A
word's context wholes are the rows it occurs in; their locations are their
roots; the two-way lookup gives them. No BOW minting is needed: the memory
is the bag of words, by reference. The gap: spreading activation runs over
the concept store's part edges and rows do not conduct, which is why the
primed bank found no activated competitor. Rows conducting (a word primes
its rows, a row its constituents) makes "the words those words activate"
true. Alec: the update in this round, if possible. Hand-off given
2026-10-04: the derived code (parts live, wholes from occurrence rows
detached), rows conducting, the three tens with root geometry and the
priming-versus-code annotation.

**Fallback (Alec, 2026-10-04: "if it's a big change, ok to wait for a future
round… I guess we would temporarily ignore the collapse?").** If the derived
code does not fit the round, the interim is §13.3 (B): hard pair selection
and the operator's exact inverse given the selected partner, so no gradient
flows through a blend; the derived code moves to the next round. Meanwhile
the class gate is recorded red with its known cause (§13.2) and the fix
dated, not tuned around; MM_xor, the control and reconstruction carry the
mechanism evidence, and the no-regression rule applies to those three until
the class gate is sound again.
