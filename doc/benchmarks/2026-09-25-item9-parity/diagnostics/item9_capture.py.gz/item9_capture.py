import sys
from pathlib import Path
sys.path.insert(0, 'doc/benchmarks/2026-09-21-item10')
import probe
import parity
import torch
original = parity.measure

def measure(model, mode):
    records = []
    recon_records = []
    reconstruct = model._reconstruct_sentences
    def capture_recon(*args, **kwargs):
        record = {'arguments': [x.detach().cpu().clone() if torch.is_tensor(x) else x for x in args]}
        for name in ('_staged_unit_parent', '_staged_unit_clause', '_staged_word_primitive_counts', '_staged_word_property_spans'):
            value = getattr(model.wholeSpace, name, None)
            if torch.is_tensor(value): record[name] = value.detach().cpu().clone()
        result = reconstruct(*args, **kwargs)
        recon_records.append(record)
        return result
    model._reconstruct_sentences = capture_recon
    run = model.runBatch
    def capture(*args, **kwargs):
        result = run(*args, **kwargs)
        isp = model.inputSpace
        row = {}
        for owner_name, owner in [('input', isp), ('whole', model.wholeSpace)]:
            for name, value in vars(owner).items():
                if torch.is_tensor(value) and (name.startswith(('_ar_', '_packed_', '_word_', '_staged_'))):
                    row[owner_name + '.' + name] = value.detach().cpu().clone()
        for name in ('_tensor_pushed_ideas', '_tensor_sentence_roots_live', '_tensor_sentence_roots_depth', '_tensor_final_end_slots', '_tensor_final_end_depth', '_recon_ideas', '_recon_sentence_costs'):
            value = getattr(model, name, None)
            if torch.is_tensor(value): row[name] = value.detach().cpu().clone()
        row['trace'] = [x.detach().cpu().clone() for x in model._reconstruction_stack().choices()]
        row['word_texts'] = model.perceptualSpace._forward_input.get('word_texts')
        records.append(row)
        return result
    model.runBatch = capture
    try:
        report = original(model, mode)
        torch.save(records, Path('output') / ('item9-' + mode + '-capture2.pt'))
        torch.save(recon_records, Path('output') / ('item9-' + mode + '-recon.pt'))
        return report
    finally:
        model.runBatch = run
parity.measure = measure
probe.main()
