"""Real supplied-label and missing-label Adam steps over generation owners."""
from pathlib import Path
import sys
ROOT=Path('/Users/arogers/github/WikiOracle/basicmodel')
for directory in (ROOT/'bin',ROOT/'test'):
    if str(directory) not in sys.path: sys.path.insert(0,str(directory))
import torch
import pytest
from What import What
from util import init_compile_backend
from test_output_path_supervised import _native_answer_model

@pytest.mark.parametrize('output_loop',[False,True])
def test_real_supplied_and_unlabelled_adam_steps_respect_generation_ownership(tmp_path, output_loop):
    init_compile_backend('none')
    m=_native_answer_model(tmp_path,True)
    parameters=tuple(m.languageSpace.generation_ops.parameters())
    assert parameters
    opt=m.getOptimizer(lr=1e-3)
    original=m._backward_training_loss
    observed=[]
    data=m.inputSpace.data
    supplied=data.has_supervised_outputs
    def capture(total,objectives,optimizer,amp_scaler=None):
        grads=torch.autograd.grad(total,parameters,retain_graph=True,allow_unused=True)
        observed.append(tuple(None if g is None else g.detach().clone() for g in grads))
        return original(total,objectives,optimizer,amp_scaler)
    m._backward_training_loss=capture
    def step():
        before=tuple(p.detach().clone() for p in parameters)
        torch.manual_seed(11)
        batch=(m.inputSpace.prepInput(['1 plus 2','3 plus 4']),torch.zeros(2,1,1))
        m.runBatch(train=True,batchSize=2,split='train',optimizer=opt,
                   batch_override=batch,questions=(What.supervised(0),What.supervised(1)))
        return tuple(not torch.equal(p,b) for p,b in zip(parameters,before))
    try:
        changed=step()
        assert any(g is not None and bool(g.abs().sum()) for g in observed[-1]), 'supplied answer reaches no generation transform'
        assert any(changed), 'generation transforms were not stepped'
        assert any(opt.state.get(p) for p in parameters)
        data.has_supervised_outputs=False
        m.output_in_loop=output_loop
        changed=step()
        assert not any(changed), 'unlabelled Adam moved a generation transform'
        assert all(g is None for g in observed[-1]), 'unlabelled total reaches generation'
    finally:
        data.has_supervised_outputs=supplied
        m._backward_training_loss=original
        m.End();m.symbolSpace.soft_reset();torch._dynamo.reset()
