"""Publish an already reviewed, exactly owned, fully validated stage and gitlink."""
from pathlib import Path
import argparse, hashlib, json, os, subprocess

p=argparse.ArgumentParser()
p.add_argument('slug')
p.add_argument('paths',type=Path)
p.add_argument('message',type=Path)
p.add_argument('parent_label')
a=p.parse_args()
root=Path('/Users/arogers/github/WikiOracle/basicmodel')
parent=root.parent
env=dict(os.environ,DEVELOPER_DIR='/Library/Developer/CommandLineTools')
trailer='Co-Authored-By: Claude Fable 5.1 <noreply@anthropic.com>'
def git(where,*args):
 return subprocess.check_output(['git',*args],cwd=where,env=env,text=True).strip()
def remote_head(where):
 line=git(where,'ls-remote','--exit-code','--heads','origin','main')
 parts=line.split()
 assert len(parts)==2 and parts[1]=='refs/heads/main',line
 return parts[0]

def unchanged_protected():
 for name,digest in json.loads(Path('/tmp/full-spec-unowned-after-tied.json').read_text()).items():
  assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name

paths=a.paths.read_text().splitlines()
assert paths and len(paths)==len(set(paths))
for name in paths:
 assert not Path(name).is_absolute() and '..' not in Path(name).parts,name
 assert (root/name).is_file(),name
 assert name not in json.loads(Path('/tmp/full-spec-unowned-after-tied.json').read_text()),name
 assert not name.startswith(('doc/specs/2026-07-27-','doc/specs/2026-09-09-','doc/specs/2026-09-11-'))
assert trailer in a.message.read_text()
assert 'PENDING' not in a.message.read_text()
for where in (root,parent):
 assert git(where,'branch','--show-current')=='main'
 assert not git(where,'diff','--cached','--name-only'),where
 assert git(where,'rev-parse','HEAD')==remote_head(where),where
assert git(parent,'rev-parse','HEAD:basicmodel')==git(root,'rev-parse','HEAD')
unchanged_protected()
base=git(root,'rev-parse','HEAD')
parent_base=git(parent,'rev-parse','HEAD')
# No path expansion, shell interpolation or staging of unrelated files.
subprocess.run(['git','add','--',*paths],cwd=root,env=env,check=True)
staged=git(root,'diff','--cached','--name-only').splitlines()
assert set(staged)==set(paths),(set(paths)-set(staged),set(staged)-set(paths))
subprocess.run(['git','diff','--cached','--check','--','.',':!*.log'],cwd=root,env=env,check=True)
subprocess.run(['git','commit','--file',str(a.message)],cwd=root,env=env,check=True)
head=git(root,'rev-parse','HEAD')
assert set(git(root,'diff-tree','--no-commit-id','--name-only','-r',head).splitlines())==set(paths)
assert trailer in git(root,'log','-1','--format=%B')
unchanged_protected()
subprocess.run(['git','push','origin','main'],cwd=root,env=env,check=True)
assert remote_head(root)==head
assert git(parent,'rev-parse','HEAD')==parent_base
assert not git(parent,'diff','--cached','--name-only')
subprocess.run(['git','add','--','basicmodel'],cwd=parent,env=env,check=True)
assert git(parent,'diff','--cached','--name-only')=='basicmodel'
assert git(parent,'rev-parse',':basicmodel')==head
message=f'Bump basicmodel to {head[:7]} ({a.parent_label})\n\n{trailer}\n'
msg=Path('/tmp/full-spec-'+a.slug+'-parent-commit-message.txt');msg.write_text(message)
subprocess.run(['git','commit','--file',str(msg)],cwd=parent,env=env,check=True)
parent_head=git(parent,'rev-parse','HEAD')
assert git(parent,'diff-tree','--no-commit-id','--name-only','-r',parent_head)=='basicmodel'
subprocess.run(['git','push','origin','main'],cwd=parent,env=env,check=True)
assert remote_head(parent)==parent_head
assert git(parent,'rev-parse','HEAD:basicmodel')==head
unchanged_protected()
receipt=dict(stage=a.slug,basicmodel_base=base,basicmodel=head,parent_base=parent_base,
             WikiOracle=parent_head,basicmodel_remote_verified=True,parent_remote_verified=True,
             protected_files_unchanged=True,owned_paths=paths)
Path('/tmp/full-spec-'+a.slug+'-push-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='owned_paths'},indent=2))
