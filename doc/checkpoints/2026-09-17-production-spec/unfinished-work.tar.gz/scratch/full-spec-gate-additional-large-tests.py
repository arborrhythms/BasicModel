from pathlib import Path
import ast, hashlib, json
root=Path('/Users/arogers/github/WikiOracle/basicmodel')
manifest=Path('/tmp/full-spec-test-mode-selections.json')
backup=Path('/tmp/full-spec-test-mode-pre-additional-large-selections.json')
assert not backup.exists()
prior=json.loads(manifest.read_text())
new=json.loads(Path('/tmp/full-spec-additional-large-selections.json').read_text())
for item in json.loads(Path('/tmp/full-spec-global-large-fixture-audit.json').read_text()):
 new.setdefault(item['file'],[]).append(item['function'])
assert sum(map(len,new.values()))==111
for name,digest in json.loads(Path('/tmp/full-spec-unowned-after-tied.json').read_text()).items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
base={}; pending={}
for name,names in new.items():
 p=root/name; before=p.read_text(); tree=ast.parse(before)
 functions={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
 assert set(names)<=set(functions),name
 assert not set(names)&set(prior.get(name,[])),name
 lines=before.splitlines(True);patches=[]
 for name_ in names:
  node=functions[name_]
  assert not any(ast.unparse(d)=='pytest.mark.slow' for d in node.decorator_list)
  index=min([node.lineno,*[d.lineno for d in node.decorator_list]])-1
  patches.append((index,' '*node.col_offset+'@pytest.mark.slow\n'))
 for index,line in sorted(patches,reverse=True):lines.insert(index,line)
 earliest=min(i for i,_ in patches)+1
 if not any(isinstance(n,ast.Import) and any(a.name=='pytest' and a.asname is None for a in n.names) and n.lineno<earliest for n in tree.body):
  offset=0
  for n in tree.body:
   if isinstance(n,ast.Expr) and isinstance(n.value,ast.Constant) and isinstance(n.value.value,str) and offset==0:offset=n.end_lineno
   elif isinstance(n,ast.ImportFrom) and n.module=='__future__':offset=n.end_lineno
   else:break
  lines.insert(offset,'\nimport pytest\n')
 after=''.join(lines); changed=ast.parse(after)
 # Only imports/decorators change; every function body and assertion is exact.
 for node in changed.body:
  if isinstance(node,ast.FunctionDef):
   assert ast.dump(ast.Module(body=node.body,type_ignores=[]))==ast.dump(ast.Module(body=functions[node.name].body,type_ignores=[])),(name,node.name)
 pending[name]=after;base[name]=hashlib.sha256(p.read_bytes()).hexdigest()
backup.write_text(manifest.read_text())
for name,after in pending.items():
 (root/name).write_text(after);prior[name]=prior.get(name,[])+new[name]
manifest.write_text(json.dumps(prior,indent=2)+'\n')
Path('/tmp/full-spec-additional-large-applied.json').write_text(json.dumps(new,indent=2)+'\n')
Path('/tmp/full-spec-additional-large-base.json').write_text(json.dumps(base,indent=2)+'\n')
p=root/'doc/Testing.md';s=p.read_text().replace('30 epochs. 120 long-running functions','30 epochs. 231 long-running functions')
old='checkpoint and compiled-kernel checks remain in the default suite. Their short layer-level lifecycle, loss,\nprojection and runtime-inference checks remain in the default suite.'
newtext='''checkpoint and compiled-kernel checks remain in the default suite.
The subsequent profile completed 1,246 of 4,458 cases in 25.8 minutes before
another explicit stop. A fixture audit found additional 16,000–65,000-row legacy
configurations in global attention, reading, masked semantics, word storage and
serial reconstruction. Their full-model checks now use the same slow gate;
small layer-level lifecycle, loss, projection and runtime-inference checks stay
in the default suite. All assertions and reasoning methods are retained.'''
assert old in s;s=s.replace(old,newtext);p.write_text(s)
print('Added',sum(map(len,new.values())),'gates across',len(new),'files; total',sum(map(len,prior.values())),'across',len(prior),'files.')
