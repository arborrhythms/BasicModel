"""Apply one-time existence-to-taxonomy source links and owned documentation."""
from pathlib import Path
import hashlib
import json
import re

root=Path('/Users/arogers/github/WikiOracle/basicmodel')
candidate=Path('/tmp/full-spec-taxonomy-candidate')
receipt=Path('/tmp/full-spec-taxonomy-doc-remap-applied.json')
assert not receipt.exists(), 'Do not remap links twice'
assert not (root/'doc/TaxonomyQueries.md').exists()
for name,digest in json.loads((candidate/'validation-manifest.json').read_text()).items():
    assert hashlib.sha256((root/'bin'/name).read_bytes()).hexdigest()==digest,name
maps=json.loads(Path('/tmp/full-spec-taxonomy-line-maps.json').read_text())
anchors=json.loads((candidate/'source-anchors.json').read_text())
names=['doc/Architecture.md','doc/GradientFlow.md','doc/Language.md','doc/Params.md',
       'doc/Training.md','doc/STM.md','doc/ExistenceEvidence.md',
       'doc/plans/2026-09-15-next-sentence-as-the-production-objective.md']
changes=[]
# Only local current-source links move. Fixed-commit URLs never move.
pattern=re.compile(r'\[([^\]]+)\]\(((?:\.\./)+bin/(Layers\.py|Models\.py|reasoning\.py|thinking\.py))#L(\d+)\)')
def remap(match):
    label,target,filename,line=match.groups()
    mapping=maps.get(filename,{}).get(line)
    assert mapping is not None,(filename,line)
    new=str(mapping['line'])
    changes.append({'file':filename,'old':int(line),**mapping})
    return '['+label.replace(filename+':'+line,filename+':'+new)+']('+target+'#L'+new+')'
def render(text,prefix='../bin/'):
    return re.sub(r'@@([^@]+)@@',lambda m:prefix+m[1].split(':',1)[0]+'#L'+str(anchors[m[1]]),text)
outputs={}
for name in names:
    text=(root/name).read_text()
    if '/plans/' in name:
        chunks=re.split(r'(?=^## |^### )',text,flags=re.M)
        protected=False; rebuilt=[]
        for chunk in chunks:
            if chunk.startswith('## '):
                protected=chunk.startswith(('## 6.','## 7.','## 11.'))
            if chunk.startswith('### 11.6 '): protected=False
            rebuilt.append(chunk if protected else pattern.sub(remap,chunk))
        text=''.join(rebuilt)
    else:
        text=pattern.sub(remap,text)
    outputs[name]=text

outputs['doc/TaxonomyQueries.md']=render(Path('/tmp/full-spec-taxonomy-documentation.md').read_text())
architecture=outputs['doc/Architecture.md']
old='foundation does not complete grammatical VP dispatch, conceptual-taxonomy\nqueries or levelled thought history.'
assert old in architecture
architecture=architecture.replace(old,'foundation does not complete grammatical VP dispatch or levelled thought\nhistory. Conceptual-taxonomy evidence is implemented separately below.',1)
addition=render('''### Conceptual-taxonomy query evidence

Public `PartOf` queries read bounded conceptual reference records, preserving
native proof sources. Perceptual edges, vector overlap and world-relation rows
cannot certify this domain. Converse aliases share the canonical direction;
unsupported domains fail explicitly. The derived read view adds no memory or
learned parameters. The checked grammatical VP registry and ordinary levelled
controller remain separate work. See [Taxonomy queries](TaxonomyQueries.md).
[Reader](@@Taxonomy.py:capture_taxonomy@@),
[query dispatch](@@reasoning.py:TruthGroundedReasoner.evaluate@@),
[model entry](@@Models.py:BasicModel.reason_about@@).

''')
assert '\n## Sigma and Pi Layers\n' in architecture
outputs['doc/Architecture.md']=architecture.replace('\n## Sigma and Pi Layers\n','\n'+addition+'## Sigma and Pi Layers\n',1)
outputs['doc/GradientFlow.md']+=render('''
## Conceptual-taxonomy reads

`PartOf` traverses native concept references and returns hard structural
evidence with provenance. There is no derivative through reference or path
selection, and no added trainable parameter. Existing legacy operation-head
behavior cloning now uses native taxonomy paths; it does not establish
learned question utility or residual policy credit. Continuous semantic
payloads and discrete policy decisions retain the architecture-wide credit
contract above. [Taxonomy queries](TaxonomyQueries.md) documents the limits.
[Evidence](@@reasoning.py:TruthGroundedReasoner.taxonomy_evidence@@),
[curriculum](@@thinking.py:traces_from_store@@),
[operation loss](@@thinking.py:next_op_loss@@).
''')
old='The typed VP registry, canonical linguistic/internal query agreement and\nconceptual-taxonomy `PartOf` migration remain open.'
assert old in outputs['doc/Language.md']
outputs['doc/Language.md']=outputs['doc/Language.md'].replace(old,
    'The typed VP registry and canonical linguistic/internal query agreement\nremain open. Public `PartOf` now reads native conceptual-taxonomy references\n([Taxonomy queries](TaxonomyQueries.md)); this evidence reader does not\ncomplete the grammatical migration.',1)
outputs['doc/Params.md']+=render('''
### Conceptual-taxonomy query bounds

The invocation reader defaults to 256 scanned concepts and 1024 native
reference records. Traversal defaults to 8 links and 1024 edge examinations;
public predicate evaluation uses `beam * max_steps` as its edge limit. These
are explicit call bounds, distinct from STM capacity or a shared episode
budget. Limits/unavailable references report incomplete evidence. No new
configuration switch, checkpoint schema or learned parameters were added.
[Capture](@@Taxonomy.py:capture_taxonomy@@),
[traversal](@@Taxonomy.py:ConceptualTaxonomyView.part_of@@),
[public evaluation](@@reasoning.py:TruthGroundedReasoner.evaluate@@).
''')
outputs['doc/Training.md']+=render('''
## Conceptual-taxonomy queries (September 16)

The legacy operation-head curriculum uses bounded native two-link taxonomy
paths. Successful queries preserve their native proof sources and cannot
materialize world facts. Old geometric/world-row experiments remain under
explicit `legacy_...` helpers and `run_legacy_world`; their optional policy
objectives are not the default sentence-expectation controller. No new loss
or learned parameters were added. These mechanics do not establish learned
question utility. See [Taxonomy queries](TaxonomyQueries.md).
[Curriculum](@@thinking.py:traces_from_store@@),
[legacy experiment](@@reasoning.py:NeuralToolUser.run_legacy_world@@),
[read-only close](@@thinking.py:ThinkingKernel._materialize_close@@).
''')
outputs['doc/STM.md']+=render('''
## Taxonomy evidence and memory ownership (September 16)

Conceptual-taxonomy queries capture a bounded read view of the existing
allocator's reference records. The view owns no durable state and is rebuilt
after restore. Proof sources identify actual native edges; successful paths
and numeric testimony cannot append world-fact lemmas. This does not migrate
the legacy frame/parity controller to ordinary levelled history.
[Reader](@@Taxonomy.py:capture_taxonomy@@),
[testimony](@@thinking.py:ThinkingKernel.incorporate@@),
[write boundary](@@thinking.py:ThinkingKernel._materialize_close@@),
[details](TaxonomyQueries.md).
''')
exist=outputs['doc/ExistenceEvidence.md']
exist=exist.replace('The typed VP registry, conceptual-taxonomy\nPartOf, grammatical query route and ordinary thought controller remain separate\nwork in the integrated specification.',
    'The typed VP registry, grammatical query route and ordinary thought\ncontroller remain separate work. [Conceptual-taxonomy PartOf](TaxonomyQueries.md)\nnow has its own evidence reader.')
exist=exist.replace('Grammatical routing, taxonomy\nqueries, ordinary thought history, nested retention and residual policy credit\nremain open.',
    'Grammatical routing, ordinary thought history, nested retention and\nresidual policy credit remain open. Taxonomy evidence is documented separately\nin [Taxonomy queries](TaxonomyQueries.md).')
outputs['doc/ExistenceEvidence.md']=exist
specname=names[-1]; spec=outputs[specname]
start=spec.index('The full-description `Exist` evidence foundation now checks accepted facts')
end=spec.index('### 2.1 Nested clauses and phrases',start)
spec=spec[:start]+render('''The full-description `Exist` evidence foundation checks accepted facts with
graded support, conflict and occurrence provenance (§15). Public `PartOf`
now reads conceptual-taxonomy references, preserving native proof sources and
rejecting unsupported perceptual domains (§16). Grammatical VP dispatch,
linguistic/internal meaning agreement and the ordinary levelled controller
remain open. The evidence readers do not complete those migrations.
[Exist lookup](@@reasoning.py:TruthGroundedReasoner.existence_evidence@@),
[taxonomy query](@@reasoning.py:TruthGroundedReasoner.taxonomy_evidence@@).

''',prefix='../../bin/')+spec[end:]
spec=spec.replace('This is the evidence foundation. The typed grammatical VP registry,\nconceptual-taxonomy PartOf, ordinary levelled controller, nested traversal,',
    'This is the existence evidence foundation; taxonomy evidence follows in §16.\nThe typed grammatical VP registry, ordinary levelled controller, nested traversal,',1)
spec+=render('''
## 16. Conceptual-taxonomy PartOf evidence (in progress)

`PartOf` now reads native conceptual reference records, including reified
relations without endpoint mutation. Typed concept handles remain addresses;
perceptual edges, vector overlap, sparse weights and LTM world rows do not
establish taxonomic inclusion. Proofs preserve their source owners and roles.
Known paths support inclusion; missing paths are unknown, including at a zero
posture threshold. Negated requests retain the opposite support channel.
[Capture](@@Taxonomy.py:capture_taxonomy@@),
[query](@@reasoning.py:TruthGroundedReasoner.evaluate@@).

The public model/reasoner entries use this source without initializing the
old vector-proposal route. The legacy kernel admits child evidence only via
a real native hop toward the same goal/polarity; unrelated true children or
numeric testimony cannot certify inclusion. Results preserve unknown and
incomplete-read diagnostics. Successful proofs do not write world facts.
[Model entry](@@Models.py:BasicModel.reason_about@@),
[kernel step](@@thinking.py:ThinkingKernel.execute@@),
[write boundary](@@thinking.py:ThinkingKernel._materialize_close@@).

Capture and traversal have explicit node/record/edge limits. The derived
view adds no authoritative memory, checkpoint schema, trainable parameter or
gradient objective. Existing structural checkpoint ownership preserves source
records; hard path selection has no ordinary derivative. Legacy operation-head
training now draws its two-link examples from native taxonomy paths. The old
geometric/world-row experiments remain explicitly named compatibility paths.
[Curriculum](@@thinking.py:traces_from_store@@),
[legacy proposal](@@reasoning.py:NeuralToolUser.run_legacy_world@@).

Repository validation is pending. The isolated candidate passed 271 focused
and affected cases, and 33 output/boundary cases; these preparation runs do
not replace repository validation. The original public-routing probes failed
before implementation, as did the additional bound/provenance/entry/policy/
testimony/helper/unknown probes before their respective fixes.
See [Taxonomy queries](../TaxonomyQueries.md) for contracts and evidence.

The checked grammatical VP registry, surface/sense agreement, causal answer
adapter, ordinary levelled controller, nested retention, anticipation isolation,
residual policy credit and learned-utility gates remain open. The separate
two-truths spec remains reserved for the next session.
''',prefix='../../bin/')
outputs[specname]=spec
for name,text in outputs.items():
    assert '@@' not in text,name
    (root/name).write_text(text)
receipt.write_text(json.dumps(changes,indent=2)+'\n')
owned=Path('/tmp/full-spec-taxonomy-owned-paths.txt')
owned.write_text('\n'.join(sorted(set(owned.read_text().splitlines())|set(outputs)))+'\n')
print('Updated',len(outputs),'documents;',len(changes),'local source links remapped once.')
print('Definition fallbacks:',[x for x in changes if x['kind']=='definition'])
