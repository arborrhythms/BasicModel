"""Catalog migration and ordinary inverse dispatch must preserve ownership."""
from pathlib import Path
import sys

ROOT = Path('/Users/arogers/github/WikiOracle/basicmodel')
for path in (ROOT / 'bin', ROOT / 'test'):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

import pytest
import torch
from test_meronomy_ladder import _build_ladder_variant


def _model(tmp_path):
    return _build_ladder_variant(tmp_path, 'catalog_boundary', [])


def test_unscoped_inverse_keeps_comprehension_when_model_has_generate_catalog(tmp_path):
    from types import SimpleNamespace
    from Language import TheGrammar
    from test_subspace_what_stm_contract import (
        _make_stack_subspace_with_where, _make_minimal_signal_router)
    m = _model(tmp_path)
    try:
        source = m.symbolSpace.subspace._resolve_rule_layer('CS', 'lift')
        generated = m.languageSpace.resolve_generation_op('CS', 'lift')
        source.reverse = lambda parent, **kwargs: (parent + 0.1, parent - 0.1)
        generated.reverse = lambda parent, **kwargs: (parent + 0.8, parent - 0.8)
        router = _make_minimal_signal_router(D=8)
        sub = _make_stack_subspace_with_where(B=1, K=4, D=8, W=2)
        rule = next(i for i, r in enumerate(TheGrammar.rules_upward) if r.method_name == 'lift')
        router.shift(sub, torch.zeros(1, 8), where_id=TheGrammar.where_id_for_rule(rule))
        syntactic = SimpleNamespace(space_role='CS', _word_space=m.symbolSpace.subspace,
                                    _by_name={'lift': source})
        router.unreduce(sub, syntactic, grammar=TheGrammar)
        torch.testing.assert_close(sub.materialize(mode='what')[0, 0], torch.full((8,), 0.1))
    finally:
        m.End()


def test_legacy_checkpoint_initializes_generate_from_saved_comprehension(tmp_path):
    m = _model(tmp_path)
    fresh = None
    try:
        source = m.symbolSpace.subspace._resolve_rule_layer('CS', 'lift')
        m._materialize_answer_path()
        with torch.no_grad():
            for parameter in source.parameters():
                parameter.add_(0.03125)
        checkpoint = tmp_path / 'pre_catalog.ckpt'
        m.save_weights(str(checkpoint))
        saved = torch.load(checkpoint, weights_only=False)
        assert 'state_dict' in saved
        saved['state_dict'] = {key: value for key, value in saved['state_dict'].items()
                               if '.generation_ops.' not in key}
        torch.save(saved, checkpoint)
        fresh = _model(tmp_path)
        assert fresh.load_weights(str(checkpoint), strict=True, require_match=True)
        composed = fresh.symbolSpace.subspace._resolve_rule_layer('CS', 'lift')
        generated = fresh.languageSpace.resolve_generation_op('CS', 'lift')
        expected = dict(source.named_parameters())
        for name, parameter in generated.named_parameters():
            assert parameter is not dict(composed.named_parameters())[name]
            torch.testing.assert_close(parameter, expected[name], rtol=0, atol=0)
    finally:
        m.End()
        if fresh is not None:
            fresh.End()
        torch._dynamo.reset()


def test_output_catalog_scope_selects_generation_and_restores_on_error(tmp_path):
    from types import SimpleNamespace
    from Language import TheGrammar, use_generation_catalog
    from test_subspace_what_stm_contract import (
        _make_stack_subspace_with_where, _make_minimal_signal_router)
    m = _model(tmp_path)
    try:
        source = m.symbolSpace.subspace._resolve_rule_layer('CS', 'lift')
        generated = m.languageSpace.resolve_generation_op('CS', 'lift')
        source.reverse = lambda parent, **kwargs: (parent + 0.1, parent - 0.1)
        generated.reverse = lambda parent, **kwargs: (parent + 0.8, parent - 0.8)
        router = _make_minimal_signal_router(D=8)
        rule = next(i for i, r in enumerate(TheGrammar.rules_upward) if r.method_name == 'lift')
        syntactic = SimpleNamespace(space_role='CS', _word_space=m.symbolSpace.subspace,
                                    _by_name={'lift': source})

        def read():
            sub = _make_stack_subspace_with_where(B=1, K=4, D=8, W=2)
            router.shift(sub, torch.zeros(1, 8), where_id=TheGrammar.where_id_for_rule(rule))
            router.unreduce(sub, syntactic, grammar=TheGrammar)
            return sub.materialize(mode='what')[0, 0]

        @use_generation_catalog
        def output(model):
            torch.testing.assert_close(read(), torch.full((8,), 0.8))
            raise RuntimeError('probe output failure')

        with pytest.raises(RuntimeError, match='probe output failure'):
            output(m)
        torch.testing.assert_close(read(), torch.full((8,), 0.1))
    finally:
        m.End()
