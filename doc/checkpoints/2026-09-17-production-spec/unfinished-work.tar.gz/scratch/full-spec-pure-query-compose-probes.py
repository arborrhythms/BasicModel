"""A selected grammatical question represents its relation without answering it."""
from types import SimpleNamespace
import pytest
import torch
import Language
from test_basicmodel import _populate_test_config
from test_ispart_query_dispatch import _ispart_grammar, _load


@pytest.mark.parametrize("name", ["isPart", "isEqual"])
def test_question_rule_dispatches_the_same_pure_compose_face(name, monkeypatch, tmp_path):
    grammar=_load(_ispart_grammar("true").replace("isPart",name),monkeypatch,tmp_path)
    rule=next(r for r in grammar.rules_upward if r.method_name==name)
    assert rule.query
    assert Language._dispatch_method_name_for_rule(rule)==name
    monkeypatch.setattr(Language,"_parthood_geometric",lambda *a:pytest.fail("answered during composition"))
    left,right=torch.randn(2,3,8),torch.randn(2,3,8)
    selected=Language.GRAMMAR_LAYER_CLASSES[Language._dispatch_method_name_for_rule(rule)]()
    pure=Language.GRAMMAR_LAYER_CLASSES[name]()
    torch.testing.assert_close(selected.compose(left,right),pure.compose(left,right))


def test_language_owns_the_rule_meaning_for_each_local_compose_action(monkeypatch):
    _populate_test_config(inputDim=8,perceptDim=8,conceptDim=8,symbolDim=8,
        wordDim=8,outputDim=8,nWhere=0,nWhen=0)
    grammar=Language.Grammar();grammar.load_from_grammar_file("complete.grammar")
    binary=tuple(i for i,r in enumerate(grammar.rules_upward) if r.space_role=="CS" and r.arity==2)
    unary=tuple(i for i,r in enumerate(grammar.rules_upward) if r.space_role=="CS" and r.arity==1)
    assert binary and unary
    grammar.rules_upward[binary[0]]=grammar.rules_upward[binary[0]]._replace(query=True)
    monkeypatch.setattr(Language,"TheGrammar",grammar)
    layer=SimpleNamespace(_binary_rule_ids={"CS":binary},_unary_rule_ids={"CS":unary})
    owner=Language.LanguageSpace(SimpleNamespace(subspace=SimpleNamespace(languageLayer=layer)))
    captured=owner._compose_binary_rules
    assert isinstance(captured,tuple)
    assert captured==tuple(grammar.rules_upward[i] for i in binary)
    assert owner._compose_unary_rules==tuple(grammar.rules_upward[i] for i in unary)
    assert captured[0].query
    # Reconfiguring the process-global grammar for another model must not
    # reinterpret a held model's integer local actions or question mode.
    grammar.configure({"compose":{"S":["sum(S,S)"]}})
    assert owner._compose_binary_rules is captured
    assert captured[0].method_name=="part" and captured[0].query
