# Existence evidence and grammatical descriptions

Draft for the next bounded migration. Apply after the prepared-answer commit
cycle, refresh source anchors, and record repository validation before marking
this implementation verified. The typed VP registry, conceptual-taxonomy
PartOf, grammatical query route and ordinary thought controller remain separate
work in the integrated specification.

## What the lookup establishes

`Exist` asks whether the referent of a complete conceptual description is
supported by accepted LTM facts. Its input retains all occupied NP1/VP/NP2
roles, explicit presence, bindings, semantic scope and constituent references.
Matching NP1 alone cannot establish a relation. A different VP, NP2, binding,
scope or explicit constituent reference changes the requested description.
The lookup rejects unequal widths; it does not flatten or truncate roles.
[Full lookup](@@reasoning.py:TruthGroundedReasoner.existence_evidence@@).

Every occupied role must clear `tau_id` under the existing signed-magnitude
identity score. The minimum role score multiplies the fact's signed trust.
For an exact match, the original degree is preserved. Matching facts contribute
to separate positive and negative support values by maximum, never addition:
repeating a source cannot increase its supported degree. Proposition polarity
determines whether a stored degree supports or refutes the request.
[Matching and support](@@reasoning.py:TruthGroundedReasoner.existence_evidence@@).

The result includes both degrees and each matching fact's stable occurrence,
origin, source text, bindings, scope and references. No match means unknown.
Low support remains visible even below the posture threshold; strong positive
and negative support yields `BOTH`. Missing required metadata is reported as
incomplete evidence. The legacy kernel retains these sources through its final
result, including missing-context diagnostics.
[Posture](@@reasoning.py:TruthGroundedReasoner.evaluate@@),
[kernel lookup](@@thinking.py:ThinkingKernel.lookup@@),
[kernel aggregation](@@thinking.py:ThinkingKernel._frame_interval@@).

`exist()` and `is_true()` retain a scalar compatibility view, positive minus
negative support. That scalar loses conflict information. Checked evaluation
and the kernel use the rich evidence result. Neither path consults model
activation as a substitute for a fact.
[Compatibility view](@@reasoning.py:TruthGroundedReasoner.exist@@).

## Meaning ownership and storage

`ConceptualMeaning` is an owned value, not another memory or planner. Roles are
`[3, D]`, with a separate Boolean presence mask, grammatical mode and polarity;
bindings, scope and typed references are immutable metadata. A live clone keeps
its current-step gradient. The explicit adapter converts STM order to infix
NP1/VP/NP2 order; depth three uses `[1, 2, 0]`, and depth two uses `[1, 0]`.
The predictor and observation writers share that adapter. A two-role input
retains its VP in the store and the legacy chain reader.
[Value](@@Meaning.py:ConceptualMeaning@@),
[adapter](@@Meaning.py:canonical_role_payload@@),
[prediction adapter](@@Layers.py:InterSentenceLayer._canonical_meaning@@),
[observation writer](@@Models.py:_append_observed_meaning@@).

`TernaryTruthStore` remains the owner of role vectors and fact evidence. Fixed
buffers add role presence, grammatical mode, polarity, record kind, occurrence
identity and the required-metadata flag. Supported kinds are `fact`, `question`,
`estimate`, `observation` and `unverified`. Only assertive facts qualify for
Exist. Recording an external input records an observation; explicit TruthSet
admission can accept it as a fact. Setting writer origin alone does not accept
a fact. A question or estimate cannot certify its own referent.
[Store](@@Layers.py:TernaryTruthStore@@),
[admission](@@Layers.py:TernaryTruthStore.accept_fact@@),
[write boundary](@@Layers.py:TernaryTruthStore.append_meaning@@).

Durable occurrence references contain a store namespace and a monotonically
allocated ID. Row positions may change during compaction; those references do
not. Reset clears records without reusing their occurrence IDs. This migration
compares retained constituent-reference identities; it does not yet implement
arbitrary nested-meaning traversal or claim its separate acceptance gate.
[Occurrence identity](@@Layers.py:TernaryTruthStore.occurrence_of@@),
[compaction](@@Layers.py:TernaryTruthStore.clear_origin@@),
[reset](@@Layers.py:TernaryTruthStore.reset@@).

## Checkpoints

Role vectors and scalar/enum columns remain tensor state. A versioned
`truth_semantics` entry in the model's existing structural sidecar preserves
bindings, scope, constituent references and source text. Restore checks the
store namespace and occurrence IDs before attaching that metadata. A tensor
fingerprint binds each occurrence to its sidecar content; removing scope,
replacing it or swapping metadata between records cannot restore a different
description under the original occurrence ID. Source-text updates cannot
replace missing required metadata.
There is no dictionary-valued PyTorch `_extra_state` entry.
[Save](@@Models.py:BaseModel._collect_structural_extras@@),
[restore](@@Models.py:BaseModel._restore_structural_extras@@),
[metadata validation](@@Layers.py:TernaryTruthStore.load_semantic_extras@@).

A bare tensor-state restore can lack the sidecar. Its required-metadata flag
makes scoped/source-bearing evidence unavailable until the matching metadata
is restored. Missing metadata cannot silently mean empty scope. A partially
saved set of the new semantic columns is rejected even by a non-strict load.
[Guarded read](@@Layers.py:TernaryTruthStore.meaning_of@@),
[checkpoint migration](@@Layers.py:TernaryTruthStore._load_from_state_dict@@).

Older checkpoints lack all these columns. Explicit provisioned/user TruthSet
origins may retain fact status; unclassified conversation rows become
unverified. Old nonzero slots provide a best-effort presence mask. A legacy
relation with no recoverable VP is unverified, rather than certified from NP1.
Old missing scope/source text is not reconstructed from model activation.
[Legacy migration](@@Layers.py:TernaryTruthStore._load_from_state_dict@@).

## Testimony and predictions

Registered addressees declare whether a result is testimony, estimate, question
or observation. ARMA is an estimate. Estimate values cannot become truth
intervals or accepted facts, even when scalar and highly trusted. Tensor
content, unparsed text and non-finite values do not become a positive truth
assertion by conversion failure. Accepted numeric testimony about an Exist
description retains the complete description, scope and named source.
The legacy Part testimony/materialization adapter has no grammatical VP;
those rows remain `unverified` for Exist until the structured-query migration.
[Evidence kind](@@thinking.py:Testimony@@),
[registration](@@thinking.py:ThinkingKernel.register_addressee@@),
[admission](@@thinking.py:ThinkingKernel.incorporate@@).
[Legacy materialization](@@reasoning.py:TruthGroundedReasoner.materialize@@).

## Gradients

The meaning-value clone preserves live representation gradients, while durable
store writes detach them. Fact lookup, metadata matching, thresholding and
support aggregation are hard operations with scalar evidence; they provide no
ordinary derivative through their choices. Later learned query selection needs
its declared policy credit. This migration adds no learned parameters or new
loss, and does not itself train useful questioning. The architecture-wide
gradient budget remains documented in [GradientFlow](GradientFlow.md).
[Owned value](@@Meaning.py:ConceptualMeaning@@),
[detached write](@@Layers.py:TernaryTruthStore.append_meaning@@),
[hard lookup](@@reasoning.py:TruthGroundedReasoner.existence_evidence@@).

## Evidence to record before the commit

Keep original failing probes, follow-up provenance/ingestion failures, the
passing affected files, the full-suite result and the frozen source manifest.
Temporary-candidate results are preparation evidence, not a substitute for the
repository's own full-suite gate. Report grammatical routing, taxonomy queries,
ordinary thought history, nested retention and residual policy credit as open.
