from pathlib import Path
import hashlib,importlib,json,sys
root=Path('/tmp/full-spec-phase-worktree').resolve()
history=Path('/tmp/full-spec-thought-worktree').resolve()
registry=Path('/tmp/full-spec-registry-worktree').resolve()
owners={name:(root if name in ('Models','Queries') else history if name in ('Thoughts','Layers') else registry)
        for name in ('Thoughts','Layers','Queries','Language','reasoning','Understanding','Models')}
modules={name:importlib.import_module(name) for name in owners}
manifests={path:json.loads((path/'validation-manifest.json').read_text()) for path in set(owners.values())}
for name,module in modules.items():
    expected=owners[name]/'bin'/(name+'.py')
    assert Path(module.__file__).resolve()==expected,(name,module.__file__)
    print('CANDIDATE',name,module.__file__,flush=True)
def check():
    for name,owner in owners.items():
        relative='bin/'+name+'.py'
        assert hashlib.sha256((owner/relative).read_bytes()).hexdigest()==manifests[owner][relative],relative
check()
class OwnershipCheck:
    def pytest_runtest_setup(self,item):
        for name,module in modules.items():
            assert sys.modules[name] is module,name
import pytest
status=pytest.main(sys.argv[1:],plugins=[OwnershipCheck()])
check()
raise SystemExit(status)
