"""Render query-work documentation and remap current-source links exactly once."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import re

root=Path('/Users/arogers/github/WikiOracle/basicmodel')
work=Path('/tmp/full-spec-query-work-worktree')
base=Path('/tmp/full-spec-query-work-base')
receipt=Path('/tmp/full-spec-query-work-doc-remap-applied.json')
assert not receipt.exists(), 'Do not remap links twice'
assert not (root/'doc/QueryWork.md').exists()
for name,digest in json.loads((work/'validation-manifest.json').read_text()).items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name

def definitions(text):
    found={}
    def visit(node,path=()):
        if isinstance(node,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)):
            path=path+(node.name,)
            found['.'.join(path)]=(node.lineno,node.end_lineno)
        for child in ast.iter_child_nodes(node):
            visit(child,path)
    visit(ast.parse(text))
    return found

maps={}; anchors={}
for name in ('Thoughts.py','Queries.py','Language.py','Layers.py','Models.py','Understanding.py','reasoning.py','Spaces.py','Taxonomy.py','QueryWork.py'):
    new=(root/'bin'/name).read_text()
    new_defs=definitions(new)
    anchors.update({name+':'+key:value[0] for key,value in new_defs.items()})
    if not (base/'bin'/name).exists():
        continue
    old=(base/'bin'/name).read_text()
    old_defs=definitions(old)
    old_lines,new_lines=old.splitlines(),new.splitlines()
    mapping={}
    for op,i,j,a,b in difflib.SequenceMatcher(None,old_lines,new_lines,autojunk=False).get_opcodes():
        for index in range(i,j):
            if op=='equal':
                mapping[index+1]={'line':a+(index-i)+1,'kind':'exact'}
                continue
            enclosing=[(hi-lo,key) for key,(lo,hi) in old_defs.items()
                       if lo<=index+1<=hi and key in new_defs]
            if enclosing:
                _,key=min(enclosing)
                mapping[index+1]={'line':new_defs[key][0],'kind':'definition','name':key}
            else:
                mapping[index+1]={'line':min(len(new_lines),a+1),'kind':'adjacent'}
    maps[name]=mapping

names=['doc/Architecture.md','doc/GradientFlow.md','doc/Language.md','doc/Params.md',
       'doc/Training.md','doc/QueryContracts.md','doc/QueryPhases.md','doc/ThoughtHistory.md','doc/STM.md','doc/ExistenceEvidence.md','doc/TaxonomyQueries.md','doc/SymbolFirewall.md','doc/ArbitrarySymbols.md','doc/NestedRetention.md',
       'doc/plans/2026-09-15-next-sentence-as-the-production-objective.md',
       'doc/plans/2026-09-17-bounded-fixture-reuse.md']
pattern=re.compile(r'\[([^\]]+)\]\(((?:\.\./)+bin/(Queries\.py|Layers\.py|Thoughts\.py|Taxonomy\.py|reasoning\.py))#L(\d+)\)')
changes=[]
def remap(match):
    label,target,filename,line=match.groups()
    mapping=maps[filename][int(line)]
    new=str(mapping['line'])
    changes.append({'file':filename,'old':int(line),**mapping})
    return '['+label.replace(filename+':'+line,filename+':'+new)+']('+target+'#L'+new+')'
def render(text,prefix='../bin/'):
    return re.sub(r'@@([^@]+)@@',lambda m:prefix+m[1].split(':',1)[0]+'#L'+str(anchors[m[1]]),text)
outputs={}
for name in names:
    text=(root/name).read_text()
    if '/plans/' in name:
        protected=False; parts=[]
        for part in re.split(r'(?=^## |^### )',text,flags=re.M):
            if part.startswith('## '):
                protected=part.startswith(('## 6.','## 7.','## 11.'))
            if part.startswith('### 11.6 '):
                protected=False
            parts.append(part if protected else pattern.sub(remap,part))
        text=''.join(parts)
    else:
        text=pattern.sub(remap,text)
    outputs[name]=text

def replace_once(name,old,new):
    assert old in outputs[name],(name,old)
    outputs[name]=outputs[name].replace(old,new,1)



outputs['doc/QueryWork.md']=render(Path('/tmp/full-spec-query-work-documentation.md').read_text())
sections={
'doc/Architecture.md': """
### Shared accounting for selected queries

A transient work meter spans selected VP/operand preparation, executor reads
and traversal. Local caps tighten the allowance; they cannot replenish it.
The ordinary thought history remains the episode owner and must record actual
spent cost once. Normal controller integration remains open.
[Meter](@@QueryWork.py:QueryWorkBudget@@),
[dispatch](@@Queries.py:GrammaticalQueryRegistry.execute@@).
See [Query work](QueryWork.md) for cost units and exhaustion behavior.
""",
'doc/GradientFlow.md': """
### Query cost does not change continuous credit

The shared meter counts host-side work and owns no parameters or loss. Live
thought/operand reads preserve the current episode's gradients; durable reads
remain detached. Hard choices and evidence traversal need explicit policy
credit when trained. Exhaustion preserves available signed evidence and reports
incompleteness; it does not create a successful answer or a derivative through
a hard operation. The existing aggregate reconstruction-priority rule is
unchanged by accounting.
[Live read](@@Thoughts.py:LevelledThoughtHistory.resolve_thought@@),
[checked execution](@@Queries.py:QuerySignature.invoke@@),
[Query work](QueryWork.md).
""",
'doc/QueryContracts.md': """
## One meter through preparation and execution

`QueryContext.work` optionally carries the same remaining episode allowance to
selected VP validation, native/occurrence operand reads and the executor.
Taxonomy capture reserves work for proof traversal. Exist retains partial signed
evidence; exhausted Quantize and ARMA preparation cannot perform later reads.
Standalone readers retain their explicit local limits when no meter is supplied.
The normal controller still needs to supply this meter throughout each selected
path and commit actual cost once. No reasoning method is removed.
[Context](@@Queries.py:QueryContext@@),
[preparation](@@Queries.py:GrammaticalQueryRegistry.execute@@),
[allocation](@@QueryWork.py:capture_limits@@), [Query work](QueryWork.md).
""",
'doc/ThoughtHistory.md': """
## Actual executor cost

[Query work](QueryWork.md) supplies a transient meter for the remaining root
allowance. The controller must pass one object through selected reads and nested
callbacks, then record its actual spent cost once in this existing history.
Neither local query caps nor nested contexts create another allowance. The
history's ordinary-work cutoff and `d_cut + 1` termination drain remain the
execution contract; accounting alone does not implement the learned controller.
[Meter](@@QueryWork.py:QueryWorkBudget@@),
[live occurrence read](@@Thoughts.py:LevelledThoughtHistory.resolve_thought@@).
"""}
for name,section in sections.items():outputs[name]+=render(section)
outputs['doc/plans/2026-09-15-next-sentence-as-the-production-objective.md']+=render("""
## 21. Shared selected-query work accounting (in progress)

Selected VP and operand preparation, native payload reads, executor invocation,
fact/occurrence scans, taxonomy capture/traversal and prediction-context reads
can debit one ephemeral meter. Taxonomy capture reserves room for proof work.
Local caps cannot replenish it. Exhaustion preserves available partial evidence
and reports incompleteness rather than establishing falsity or resolution.
[Meter](@@QueryWork.py:QueryWorkBudget@@),
[registry](@@Queries.py:GrammaticalQueryRegistry.execute@@),
[taxonomy allocation](@@QueryWork.py:capture_limits@@).

The existing ordinary history remains the episode owner. Accounting creates no
learned parameter or loss and does not detach live thought operands. Its caller
must supply the remaining episode allowance throughout nested work and commit
actual cost once. The normal learned-controller integration is still open.
[Live reads](@@Thoughts.py:LevelledThoughtHistory.resolve_thought@@).

Primary validation is pending. Thirteen reviewer cases cover shared limits,
preparation reads, partial evidence, nested callbacks and prediction reservation.
The isolated affected run passed 154 tests with one skip. [Query work](../QueryWork.md)
documents the API and its limits.

Linguistic integration, causal ordinary-controller use, owned estimates,
anticipation isolation, residual credit and learned utility remain open.
Unused reasoning methods remain available for the user's grammar-query review;
the separate two-truths specification remains reserved for the next session.
""",prefix='../../bin/')
for name,text in outputs.items():
    assert '@@' not in text,name
    for target,line in re.findall(r'\]\(((?:\.\./)+bin/[^)#]+\.py)#L(\d+)\)',text):
        file=((root/name).parent/target).resolve()
        assert file.is_file() and 1<=int(line)<=len(file.read_text().splitlines()),(name,target,line)
for name,text in outputs.items():
    (root/name).write_text(text)
receipt.write_text(json.dumps(changes,indent=2)+'\n')
Path('/tmp/full-spec-query-work-line-maps.json').write_text(json.dumps(maps)+'\n')
(work/'source-anchors.json').write_text(json.dumps(anchors,indent=2)+'\n')
owned=Path('/tmp/full-spec-query-work-owned-paths.txt')
owned.write_text('\n'.join(sorted(set(owned.read_text().splitlines())|set(outputs)))+'\n')
print('Updated',len(outputs),'documents;',len(changes),'local source links remapped once.')
print('Definition/adjacent fallbacks:',[x for x in changes if x['kind']!='exact'])
