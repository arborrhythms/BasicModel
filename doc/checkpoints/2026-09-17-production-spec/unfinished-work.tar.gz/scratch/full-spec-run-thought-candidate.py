from pathlib import Path
import hashlib,importlib,json,sys
root=Path('/tmp/full-spec-thought-worktree').resolve()
registry=Path('/tmp/full-spec-registry-worktree').resolve()
manifest=json.loads((root/'validation-manifest.json').read_text())
registry_manifest=json.loads((registry/'validation-manifest.json').read_text())
own=('Thoughts','Layers','Models','Queries')
modules={name:importlib.import_module(name) for name in ('Thoughts','Layers','Queries','Language','reasoning','Understanding','Models')}
for name,module in modules.items():
    expected=(root if name in own else registry)/'bin'/(name+'.py')
    assert Path(module.__file__).resolve()==expected,(name,module.__file__)
    print('CANDIDATE',name,module.__file__,flush=True)
def check():
    for name,digest in manifest.items():
        assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
    for name in ('Language','reasoning','Understanding'):
        path='bin/'+name+'.py'
        assert hashlib.sha256((registry/path).read_bytes()).hexdigest()==registry_manifest[path],path
check()
class OwnershipCheck:
    def pytest_runtest_setup(self,item):
        for name,module in modules.items():
            assert sys.modules[name] is module,name
import pytest
status=pytest.main(sys.argv[1:],plugins=[OwnershipCheck()])
check()
raise SystemExit(status)
