"""Sentence masks cover query preparation, legacy entry points and nested work."""
from contextlib import nullcontext
from dataclasses import replace
from types import SimpleNamespace

import pytest
import torch

from Models import BasicModel
from Queries import GrammaticalQueryRegistry, QueryContext
from Understanding import Understanding
from What import What
from reasoning import TruthGroundedReasoner
from test_cs_symbol_table import _cs


def _model():
    model = BasicModel()
    model.spaces = []
    object.__setattr__(model, 'conceptualSpace', _cs())
    model.reconstruct_in_loop = False
    return model


def _understanding(*completed):
    # Completion is independent of vector magnitude. An occupied zero-valued
    # representation remains completed; absent batch rows do not.
    programs = tuple(SimpleNamespace(leaves=torch.zeros(1, 8)) if ready else None
                     for ready in completed)
    return Understanding(answer_program=programs)


def test_operand_occurrence_reads_require_permission_before_preparation(monkeypatch):
    import Queries
    from Meaning import ConceptualMeaning
    model = _model()
    registry = GrammaticalQueryRegistry.install(
        model.conceptualSpace,
        SimpleNamespace(query_signatures={'exist': Queries.BUILTIN_QUERIES['exist']},
                        rules_upward=()))
    vp = registry._reference(('ltm-facts', 'exist'))
    meaning = ConceptualMeaning(torch.ones(3, 8), torch.tensor([True, True, False]),
                                mode='interrogative', role_refs=(('ltm', 'missing', 0), vp, None))
    reads = []
    monkeypatch.setattr(Queries, '_occurrence_description',
                        lambda *args: reads.append(args) or (_ for _ in ()).throw(
                            AssertionError('occurrence read before boundary permission')))
    context = QueryContext(TruthGroundedReasoner(model))
    with pytest.raises(RuntimeError, match='boundary'):
        registry.execute(meaning, context)
    assert reads == []


@pytest.mark.parametrize('entry', ['answer_query', 'reason_about', 'think_about'])
def test_legacy_query_entry_points_are_masked_inside_forward(monkeypatch, entry):
    model = _model()
    model.reasoning_iterations = model.thinking_budget = 0
    # Explicit compatibility calls remain harmless with their experiment off.
    assert getattr(model, entry)(None) is None
    monkeypatch.setattr(model, '_forward_per_stage', lambda *args: getattr(model, entry)(None))
    with pytest.raises(RuntimeError, match='sentence|query|queries'):
        model.forward(torch.zeros(1, 1, 8))
    assert getattr(model, entry)(None) is None


def test_reconstruction_completion_masks_queries_before_surface_recovery(monkeypatch):
    import Queries
    model = _model()
    model.reconstruct_in_loop = True
    model._recon_completed = True
    model._recon_ideas = torch.zeros(1, 1, 8)
    carrier = SimpleNamespace(set_event=lambda *args: None)
    object.__setattr__(model, 'conceptualSpace', SimpleNamespace(
        outputShape=(1, 8), subspace=SimpleNamespace(carrier_like=lambda: carrier)))
    monkeypatch.setattr(model, '_synthesis_guard', nullcontext)
    calls = []
    signature = replace(Queries.BUILTIN_QUERIES['isEqual'],
                        executor=lambda *args: calls.append(args) or {})
    context = QueryContext(TruthGroundedReasoner(model))
    monkeypatch.setattr(model, '_reverse_input_surface', lambda *args:
                        signature.invoke(context, torch.ones(8), torch.ones(8)))
    with pytest.raises(RuntimeError, match='sentence|query|queries'):
        model._complete_input_reconstruction()
    assert calls == []


def test_nested_boundary_cannot_make_an_unready_row_executable(monkeypatch):
    model = _model()
    outer, inner = _understanding(True, False), _understanding(False, True)

    def resolve(understanding, *args):
        if understanding is inner:
            model._assert_query_boundary(1)
        else:
            model._assert_query_boundary(0)
            with pytest.raises(RuntimeError, match='row|boundary'):
                model.resolveAnswer(inner, What.inference(1))
            model._assert_query_boundary(0)
            with pytest.raises(RuntimeError, match='row|boundary'):
                model._assert_query_boundary(1)
        return 'complete'

    monkeypatch.setattr(model, '_resolve_answer', resolve)
    assert model.resolveAnswer(outer, What.inference(0)) == 'complete'
    with pytest.raises(RuntimeError, match='boundary'):
        model._assert_query_boundary(0)


def test_failed_nested_sentence_restores_only_the_outer_completed_boundary(monkeypatch):
    model = _model()
    calls = []

    def forward(*args):
        calls.append('forward')
        model._assert_query_boundary(0)

    def resolve(*args):
        model._assert_query_boundary(0)
        with pytest.raises(RuntimeError, match='sentence|query|queries'):
            model.forward(torch.zeros(1, 1, 8))
        model._assert_query_boundary(0)
        return 'complete'

    monkeypatch.setattr(model, '_forward_per_stage', forward)
    monkeypatch.setattr(model, '_resolve_answer', resolve)
    assert model.resolveAnswer(_understanding(True), What.inference(0)) == 'complete'
    assert calls == ['forward']
    with pytest.raises(RuntimeError, match='boundary'):
        model._assert_query_boundary(0)


def test_dense_uncommitted_or_empty_program_rows_do_not_open_queries(monkeypatch):
    model = _model()
    empty = SimpleNamespace(leaves=torch.zeros(0, 8))
    for understanding in (Understanding(conceptual_state=torch.ones(2, 3, 8)),
                          Understanding(answer_program=(empty, None))):
        monkeypatch.setattr(model, '_resolve_answer', lambda *args: model._assert_query_boundary(0))
        with pytest.raises(RuntimeError, match='boundary'):
            model.resolveAnswer(understanding, What.inference(0))


def test_held_completed_understanding_owns_readiness_after_later_staging(monkeypatch):
    model = _model()
    held = _understanding(True, False)
    model._last_understanding = _understanding(False, True)
    monkeypatch.setattr(model, '_resolve_answer', lambda *args: model._assert_query_boundary(0))
    assert model.resolveAnswer(held, What.inference(0)) is None


def test_fullgraph_forward_restores_phase_after_compiled_execution(monkeypatch):
    model = _model()
    # Match normal pre-staging. The existing lazy Start flag otherwise changes
    # from absent to False on the first run, independently of the query mask.
    model._spaces_started_for_forward = False
    monkeypatch.setattr(model, '_forward_per_stage', lambda value: value.sin() + value)
    value = torch.tensor([[[.1, .2]]], requires_grad=True)
    graphs = []

    def backend(graph, inputs):
        graphs.append(graph)
        return graph.forward

    compiled = torch.compile(model.forward, backend=backend, fullgraph=True, dynamic=True)
    try:
        for _ in range(2):
            actual = compiled(value)
            torch.testing.assert_close(actual, value.sin() + value)
            assert model._query_sentence_depth == 0
        assert len(graphs) == 1
        gradient, = torch.autograd.grad(actual.sum(), value)
        torch.testing.assert_close(gradient, value.cos() + 1)
    finally:
        torch._dynamo.reset()


@pytest.mark.parametrize('eager_island', [False, True])
def test_compiled_input_cannot_execute_queries_during_trace_or_eager_island(monkeypatch, eager_island):
    import Queries
    model = _model()
    model._spaces_started_for_forward = False
    model._query_ready_rows = (0,)
    calls = []
    # A zero-operand checked test signature avoids an unrelated tensor-to-bool
    # graph break hiding a missing query guard.
    signature = replace(Queries.BUILTIN_QUERIES['isEqual'], argument_roles=(),
                        argument_kinds=(), occupied_roles=(1,),
                        executor=lambda *args: calls.append(args) or {})
    context = QueryContext(TruthGroundedReasoner(model))

    def body(value):
        signature.invoke(context)
        return value.sin()

    if eager_island:
        body = torch.compiler.disable(body)
    monkeypatch.setattr(model, '_forward_per_stage', body)
    compiled = torch.compile(model.forward, backend='eager', fullgraph=not eager_island)
    try:
        # The normal host entry wraps supplied compiled executors too.
        with pytest.raises(Exception, match='queries cannot execute inside a sentence path'):
            model.understand(torch.ones(1, 1, 8), executor=compiled)
        assert calls == []
        assert model._query_sentence_depth == 0
    finally:
        torch._dynamo.reset()
