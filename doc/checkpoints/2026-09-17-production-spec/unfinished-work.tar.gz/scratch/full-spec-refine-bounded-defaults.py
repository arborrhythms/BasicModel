from pathlib import Path
root=Path('/Users/arogers/github/WikiOracle/basicmodel')
p=root/'test/bounded_tests.py';s=p.read_text()
assert s.count('batch_size=64, max_files=4')==2
s=s.replace('batch_size=64, max_files=4','batch_size=256, max_files=16')
s=s.replace('"--batch-size", type=int, default=64','"--batch-size", type=int, default=256')
s=s.replace('"--max-files", type=int, default=4','"--max-files", type=int, default=16')
p.write_text(s)
p=root/'doc/Testing.md';s=p.read_text()
s=s.replace('One worker at a time. Each receives at most 64 selected cases from four files;',
 'One worker at a time. Each receives at most 256 selected cases from 16 files;')
s=s.replace('## Limits and isolation','''## Fast regression and slow experiments

Long convergence, memorization and performance experiments use `@pytest.mark.slow`.
The central collection hook skips them before fixture setup unless `RUN_SLOW=1`.
`RUN_SLOW=0` stays fast. The older per-test `RUN_SLOW` gates remain supported.
A slow check keeps its assertions and any explicit expected-failure status;
skipping it in the default run is not evidence that its learning gate passed.

```sh
make test_all TEST_ARGS='test/test_output_path_supervised.py -k memorizes --timeout 1800'
```

The initial timing audit found a 119-second isolated compiler test, a 72-second
XOR training test and 130 seconds of repeated 20M-model blind-decoder training.
Two unmarked expected-failure arithmetic experiments also trained for 40 and
30 epochs. Eighteen long-running functions now use the central slow gate.
Small numerical training tests and ordinary forward/backward, ownership,
checkpoint and query regressions stay in the default suite.

Memory-triggered recycling permits larger case batches (256 cases / 16 files)
without retaining a worker past its memory boundary. This reduces repeated
Python/PyTorch imports while retaining the same hard cap and one-worker policy.
Per-case timings in the durable receipt identify further expensive checks;
a timeout is a failure that needs investigation, never an automatic slow mark.

## Limits and isolation''',1)
p.write_text(s)
p=root/'Makefile';s=p.read_text()
s=s.replace('# skipped via the RUN_SLOW gate (see test/*.py `_RUN_SLOW`). `make test_all`',
 '# skipped via RUN_SLOW (central slow marker and existing per-test gates). `make test_all`')
p.write_text(s)
p=root/'doc/plans/2026-09-15-next-sentence-as-the-production-objective.md';s=p.read_text()
old='cannot satisfy the gate.\n\n1. **Establish'
assert old in s
s=s.replace(old,'cannot satisfy the gate. Long convergence, memorization and performance checks\nrun under `RUN_SLOW=1`; default regression completion and optional learning-gate\nresults must be reported separately. The September 17 user instruction also\nrequires removing superseded legacy code together with its obsolete tests.\n\n1. **Establish',1)
p.write_text(s)
