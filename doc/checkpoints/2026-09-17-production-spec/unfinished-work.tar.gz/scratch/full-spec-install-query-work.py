"""Install shared query work accounting after history, phase and nested stages."""
from pathlib import Path
import hashlib,json,shutil,subprocess
root=Path('/Users/arogers/github/WikiOracle/basicmodel')
work=Path('/tmp/full-spec-query-work-worktree')
assert not subprocess.check_output(['git','diff','HEAD','--','bin','test','data'],cwd=root)
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).strip()
assert head==subprocess.check_output(['git','rev-parse','origin/main'],cwd=root).strip()
assert head==subprocess.check_output(['git','rev-parse','HEAD:basicmodel'],cwd=root.parent).strip()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root.parent)==subprocess.check_output(['git','rev-parse','origin/main'],cwd=root.parent)
for name,digest in json.loads(Path('/tmp/full-spec-unowned-after-tied.json').read_text()).items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
base=json.loads((work/'base-manifest.json').read_text())
for name,digest in base.items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
validated=json.loads((work/'validation-manifest.json').read_text())
for name,digest in validated.items():
 assert hashlib.sha256((work/name).read_bytes()).hexdigest()==digest,name
assert not (root/'bin/QueryWork.py').exists()
probes={'full-spec-query-work-probes.py':'test_query_work_budget.py',
        'full-spec-query-work-boundary-probes.py':'test_query_work_boundaries.py'}
for name in probes.values():assert not (root/'test'/name).exists(),name
snapshot=Path('/tmp/full-spec-query-work-base');assert not snapshot.exists()
for name in base:
 target=snapshot/name;target.parent.mkdir(parents=True,exist_ok=True)
 shutil.copyfile(root/name,target)
owned=[]
for name in validated:
 shutil.copyfile(work/name,root/name);owned.append(name)
for source,name in probes.items():
 target='test/'+name;shutil.copyfile(Path('/tmp')/source,root/target);owned.append(target)
Path('/tmp/full-spec-query-work-owned-paths.txt').write_text('\n'.join(sorted(owned))+'\n')
print('Applied',len(owned),'source/test paths; docs and primary affected/full validation are required.')
