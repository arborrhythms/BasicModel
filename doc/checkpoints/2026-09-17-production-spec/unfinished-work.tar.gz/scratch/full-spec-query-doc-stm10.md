## 10. LTM as the chain of STM end-states

LTM retains external sentence observations. `<ltmConsolidation>` selects the
legacy per-row deque or the consolidated ternary store; storage alone does
not certify that a described referent exists.
[Observation path](@@Layers.py:InterSentenceLayer.observe_stm_end_state@@),
[consolidated observation writer](@@Models.py:_append_observed_meaning@@).

**Legacy backing mode.** `InterSentenceLayer._stm_end_states` is a bounded
per-row deque of `(depth, payload, trust)` values. The root-only compatibility
path retains physical newest-first STM payloads. The structured production
path instead stores canonical `[3, D]` payloads here and retains explicit
occupancy in its separate bounded prediction view. This deque is transient
host state; its legacy tuple API does not preserve all grammatical metadata.
An explicit adapter converts physical STM to NP1/VP/NP2: three slots use
`[1, 2, 0]`, two use `[1, 0]`. Occupancy is metadata; a zero-valued occupied
role is not padding.
[Observation storage](@@Layers.py:InterSentenceLayer.observe_stm_end_state@@),
[canonical adapter](@@Meaning.py:canonical_role_payload@@).

**Consolidated mode.** `symbolSpace.ltm_store` is the existing
`TernaryTruthStore`, with `[capacity, 3, D]` infix NP1/VP/NP2 values. Its
tensor columns retain role presence, relation tag, grammatical mode,
polarity, signed trust, timestamp, evidence kind, writer origin and stable
occurrence identity. A two-role observation retains NP1 and VP. Forward
writers record `observation` with unspecified grammatical mode; explicit
TruthSet admission may accept the observation as a fact. An origin tag alone
does not do so, and questions/estimates cannot certify their own referents.
[Store schema](@@Layers.py:TernaryTruthStore@@),
[observation write](@@Models.py:_append_observed_meaning@@),
[fact admission](@@Layers.py:TernaryTruthStore.accept_fact@@).

The consolidated legacy `get_stm_chain` view returns infix payloads up to the
highest occupied role, including depth two. It reads global timestamp order
and ignores `b`; it is not the production expectation view. Sentence
expectation uses its own bounded row/document-scoped observation view, so a
different stream, an internal thought or a provisioned fact cannot become
an external predecessor merely through this legacy recency reader.
[Legacy read](@@Layers.py:InterSentenceLayer.get_stm_chain@@),
[structured observation](@@Layers.py:InterSentenceLayer._observe_meanings@@).

Role tensors and scalar columns ride `state_dict`; bindings, semantic scope,
constituent references and source text ride the versioned `truth_semantics`
entry in the existing structural sidecar. Restore checks occurrence identity
and its content fingerprint. Required metadata missing from a tensor-only
restore makes that evidence unavailable until restored. Missing or swapped
scope cannot silently become a different fact. Stable occurrence IDs survive
row compaction and are not reused after reset.
[Sidecar](@@Models.py:BaseModel._collect_structural_extras@@),
[validated restore](@@Layers.py:TernaryTruthStore.load_semantic_extras@@),
[guarded read](@@Layers.py:TernaryTruthStore.meaning_of@@).

External observation is independent of `truthCriterion`. The legacy deque
evicts its oldest entry at capacity; the consolidated append returns `-1`
when full. This is the observation/evidence store contract, not the future
levelled thought-history retention contract.
[Capacity and evidence writes](@@Layers.py:TernaryTruthStore.append_meaning@@),
[observation storage](@@Layers.py:InterSentenceLayer.observe_stm_end_state@@).

`Exist` compares the full occupied description, bindings, scope and references
against assertive fact records, retaining positive/negative degrees and
provenance separately. Conversation observations, questions, estimates and
unverified legacy rows are ineligible. The degree belongs to evidence about
the referent; model activation alone cannot establish it.
See [Existence evidence](ExistenceEvidence.md) for legacy migration, testimony,
matching and gradient boundaries, and
[the implemented lookup](@@reasoning.py:TruthGroundedReasoner.existence_evidence@@).

---
