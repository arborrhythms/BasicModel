"""Archive the isolated full proof only after primary has its identical snapshot."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess

root=Path('/Users/arogers/github/WikiOracle/basicmodel')
exit_record=json.loads(Path('/tmp/full-spec-history-full-exit.json').read_text())
assert exit_record['exit_code']==0
log=Path(exit_record['log'])
summary=re.findall(r'^\d+ passed[^\n]* in [^\n]+$',log.read_text(),flags=re.M)[-1]
assert 'failed' not in summary and 'error' not in summary
manifest=Path('/tmp/full-spec-history-checkout-frozen.json')
frozen=json.loads(manifest.read_text());assert len(frozen)==585
for name,digest in frozen.items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
for name,digest in json.loads(Path('/tmp/full-spec-unowned-after-tied.json').read_text()).items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root)
assert Path('/tmp/full-spec-thought-history-doc-remap-applied.json').exists()
# A primary affected run after applying the exact validated snapshot is also required.
affected_exit=json.loads(Path('/tmp/full-spec-history-primary-affected-exit.json').read_text())
assert affected_exit['exit_code']==0
affected=Path(affected_exit['log'])
affected_summary=re.findall(r'^\d+ passed[^\n]* in [^\n]+$',affected.read_text(),flags=re.M)[-1]
folder='doc/benchmarks/2026-09-16-thought-history-data'
target=root/folder;assert not target.exists();target.mkdir(parents=True)
sources={
    'levelled-red.log':'/tmp/full-spec-levelled-thought-red.log',
    'boundaries-red.log':'/tmp/full-spec-thought-history-boundaries-red.log',
    'live-query-red.log':'/tmp/full-spec-live-query-occurrences-red.log',
    'legacy-red.log':'/tmp/full-spec-thought-legacy-boundaries-red.log',
    'reservation-red.log':'/tmp/full-spec-thought-reservation-red.log',
    'checkpoint-credit-red.log':'/tmp/full-spec-thought-checkpoint-credit-red.log',
    'candidate-affected-green.log':'/tmp/full-spec-thought-history-affected-v8.log',
    'isolated-affected-green.log':'/tmp/full-spec-history-checkout-affected-v1.log',
    'isolated-full-green.log':str(log),
    'primary-affected-green.log':str(affected),
    'validation-manifest.json':str(manifest),
    'validation-provenance.json':'/tmp/full-spec-history-checkout-provenance.json',
    'source-ownership-guard.py':'/tmp/full_spec_history_source_guard.py',
    'parent-and-cli-fixtures-green.log':'/tmp/full-spec-history-checkout-cli-fixtures-green.log',
    'candidate-base-manifest.json':'/tmp/full-spec-thought-worktree/base-manifest.json',
}
owned=set(Path('/tmp/full-spec-thought-history-owned-paths.txt').read_text().splitlines())
for name,source in sources.items():
    shutil.copyfile(source,target/name);owned.add(folder+'/'+name)

def evidence(prefix):
    base=prefix+'2026-09-16-thought-history-data/'
    return f'''The 33 new reviewer cases cover level replay, row/sibling isolation,
scope/bindings, capacity and shared drain limits, live occurrence queries,
checkpoint/credit restoration, and legacy prompt/reservation boundaries.
The isolated affected run passed **145 tests with one skip in 60.37 seconds**.
The full suite in the independent basicmodel worktree passed with exit zero:
**{summary}**. After applying this candidate, all **585** runtime/test/configuration
files in the primary checkout matched that validated snapshot byte for byte.
The primary affected run then passed with exit zero: **{affected_summary}**.

The isolated worktree used the same Python runtime and a copy of the existing
parent `doc/Ethics.md` needed by a relative documentation link. Two earlier runs
stopped on those missing harness fixtures; they are recorded in the provenance.
The source guard verified module ownership and frozen hashes before/after the
successful full run. No application source was taken from the primary checkout.

[Initial red]({base}levelled-red.log),
[credit red]({base}checkpoint-credit-red.log),
[affected]({base}isolated-affected-green.log),
[isolated full green]({base}isolated-full-green.log),
[primary affected]({base}primary-affected-green.log),
[source manifest]({base}validation-manifest.json),
[provenance]({base}validation-provenance.json),
[source guard]({base}source-ownership-guard.py).

Full-suite command, from the isolated basicmodel worktree:

```sh
DEVELOPER_DIR=/Library/Developer/CommandLineTools OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \\
  PYTHONPATH=/tmp:/tmp/full-spec-history-checkout/bin:/tmp/full-spec-history-checkout/test \\
  .venv/bin/python -m pytest test -q -x -p no:cacheprovider \\
  -p full_spec_history_source_guard
```'''

p=root/'doc/ThoughtHistory.md';s=p.read_text()
old='''Record actual repository validation after installation. Reviewer probes cover
level replay, sibling isolation, immutable inputs, shared work/drain limits,
capacity, references, real model save/load, restored live credit, legacy
compatibility, prompt/trace detachment and complete live query operands.'''
assert old in s;s=s.replace(old,evidence('benchmarks/'),1)
old_header='Implementation reference, September 16. Repository validation is in progress.'
assert old_header in s
s=s.replace(old_header,'Implementation reference, verified September 16.',1)
p.write_text(s)
p=root/'doc/plans/2026-09-15-next-sentence-as-the-production-objective.md';s=p.read_text()
old='''Repository validation is pending. Reviewer probes failed before the corresponding
history, checkpoint and credit fixes. [Thought history](../ThoughtHistory.md)
documents behavior and limits. This API adds no learned module or trained loss.'''
assert old in s;s=s.replace(old,evidence('../benchmarks/')+'\n\n[Thought history](../ThoughtHistory.md) documents the APIs and limits.\nThis API adds no learned module or trained loss.',1)
s=s.replace('## 18. Ordinary thought-history and live occurrence APIs (in progress)',
            '## 18. Ordinary thought-history and live occurrence APIs (verified September 16)',1)
p.write_text(s)
Path('/tmp/full-spec-thought-history-owned-paths.txt').write_text('\n'.join(sorted(owned))+'\n')
Path('/tmp/full-spec-thought-history-commit-message.txt').write_text(f'''Add levelled thought history and live occurrence reads

Store ordinary structured thoughts and explicit begin/descend/return/cutoff/finish transitions in the existing WhatInteractionMemory deque. Replay exact current and suspended contexts, preserve sibling and batch-row isolation, and enforce one episode budget with a bounded termination drain and reference-safe retention.

Keep current episode meanings live through the same owner, then detach on explicit finish/credit release. Persist detached history through the existing structural sidecar and validate restore atomically. Preserve legacy reservation, prompt and trace behavior without reintroducing a second authoritative stack.

Validation: 33 new reviewer cases; 145 affected tests with one skip. Isolated full suite: {summary}. Verified an identical 585-file runtime/test/configuration snapshot in the primary checkout; primary affected: {affected_summary}. Normal controller integration and learned utility remain separate work.

Co-Authored-By: Claude Fable 5.1 <noreply@anthropic.com>
''')
print(summary)
print('History evidence archived;',len(owned),'exact owned paths.')
