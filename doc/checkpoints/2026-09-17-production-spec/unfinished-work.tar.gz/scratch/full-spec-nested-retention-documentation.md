# Retaining referenced grammatical occurrences

Implementation reference. Repository installation and full validation are pending.
This supplies occurrence retention and bounded traversal. The normal linguistic
writer and controller integrations remain separate gates.

## Existing owners and bounded reads

`TernaryTruthStore` remains the durable owner of full role payloads, stable
occurrence IDs, semantic context and evidence. `read_structure` derives a
bounded view from those records. It adds no semantic store or learned parameter.
Ordered role edges retain repeated references; a shared node is read once.
Every row keeps its own grammatical mode, polarity, bindings, scope and evidence.
Supporting a reporting clause does not certify the reported clause or an
embedded question. [Reader](@@Layers.py:TernaryTruthStore.read_structure@@).

Node count, syntactic depth and scanned-record limits are independent. A limit,
cycle, unavailable owner/reference or missing metadata produces an explicit
`incomplete` reason. Unvisited structure is not silently flattened. Appends
reject missing or forward local references; checkpoint restoration validates
the constituent graph before replacing semantic metadata. Binding and scope
references also retain their addressed occurrences and reject missing local
referents; they do not become syntactic child edges or change syntactic depth.
[Append guard](@@Layers.py:TernaryTruthStore._validate_local_references@@),
[graph validation](@@Layers.py:TernaryTruthStore._validate_constituent_graph@@),
[restore](@@Layers.py:TernaryTruthStore.load_semantic_extras@@).

## Withdrawal and retention

Clearing an origin first computes the transitive closure of surviving rows and
roots supplied by retained thoughts. Only unreferenced rows are removed.
Referenced content keeps its occurrence ID, slots, context and source text.
Its origin loses evidential authority: accepted facts become unverified and
all affected records receive zero trust. Questions and estimates retain those
provenance kinds. The truth view includes accepted facts only.
[Retention](@@Layers.py:TernaryTruthStore.clear_origin@@),
[withdrawal](@@Layers.py:TernaryTruthStore.withdraw_origin@@),
[truth view](@@Layers.py:TruthLayer.sync_from_ltm@@).

Thought roots are derived from the existing per-row history, including roles,
bindings, scope and recorded sources. This adds no reference-count database.
Normal TruthSet replacement supplies those roots, so it cannot discard content
still needed by a live or retained thought.
[History roots](@@Thoughts.py:LevelledThoughtHistory.retained_ltm_occurrences@@),
[normal replacement](@@Models.py:BasicModel._store_truths_into_ltm@@).

## Checkpoint ordering

Stateless restore withdraws request-scoped authority immediately. Physical
pruning waits until semantic records and thought owners have been restored.
A tensor-only restore with missing ownership metadata retains zero-trust
content until the structural sidecar is available. A complete restore then
prunes orphans while preserving the referenced closure. Invalid structure
fails explicitly; missing metadata is not evidence that there are no readers.
[Tensor hook](@@Language.py:SymbolSubSpace._revive_ltm_post_load@@),
[final pruning](@@Language.py:SymbolSubSpace._finish_ltm_restore@@),
[restore order](@@Models.py:BaseModel._restore_structural_extras@@).

## Gradients

| Path | Gradient contract |
|---|---|
| Durable `read_structure` | Detached owned copies, as for other durable LTM reads |
| Retained live episode thoughts | Existing continuous paths stay live until the episode step |
| Root discovery and retention | Read addresses and metadata; no tensor detach or learned parameter |
| Checkpoint | Detached durable copies; no prior optimizer graph is restored |

The nested-retention change adds no objective or optimizer owner. Live episode
credit is checked through normal TruthSet replacement. Existing reconstruction
and downstream gradient balancing are unchanged.
[Live owner](@@Thoughts.py:LevelledThoughtHistory.retained_ltm_occurrences@@),
[durable reader](@@Layers.py:TernaryTruthStore.read_structure@@).
See [Gradient flow](GradientFlow.md) for the architecture-wide contract.

## Validation and open gates

The 23 new reviewer cases cover repeated/deep references, independent limits,
cycles and missing metadata, evidence isolation, withdrawal, physical row
compaction, thought roots, live credit and checkpoint ordering. An earlier
isolated affected run passed 257 tests; the context-reference follow-up passed
all 23 focused cases. Primary affected/full validation is pending installation.

This foundation does not yet derive full typed linguistic nodes from every
compose path or run the ordinary learned controller. Those integrations,
expectation ownership, residual credit and learned utility remain required.
The separate September 16 two-truths design remains reserved for the next session.
