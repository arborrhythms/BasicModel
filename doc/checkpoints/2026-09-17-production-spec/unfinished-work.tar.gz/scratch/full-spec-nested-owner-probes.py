"""Normal TruthSet replacement and restore must retain thought-owned roots."""
from types import SimpleNamespace

import torch

from Layers import TernaryTruthStore, WhatInteractionMemory
from Meaning import ConceptualMeaning
from test_ltm_consolidation import _make_model, _ON_CONFIG


def _seed(model):
    store = model.symbolSpace.ltm_store
    store.reset()
    width = store.nDim
    meaning = ConceptualMeaning(torch.ones(3, width), torch.ones(3, dtype=torch.bool),
                                scope={'source': 'reported'})
    row = store.append_meaning(meaning, trust=.75)
    store.set_origin(row, store.ORIGIN_USER, text='a reported claim')
    return store, store.occurrence_of(row)


def _pin(model, ref):
    memory = model.symbolSpace.what_memory
    memory.detach_mode = 'episode'
    roles = torch.ones(3, model.symbolSpace.ltm_store.nDim, requires_grad=True)
    question = ConceptualMeaning(roles, torch.ones(3, dtype=torch.bool),
        mode='interrogative', role_refs=(ref, None, None), bindings={'claim': ref})
    memory.begin_thought_episode(question, work_budget=8)
    return memory, roles


def test_normal_truthset_replacement_keeps_live_thought_constituents_and_credit(monkeypatch):
    model = _make_model(_ON_CONFIG)
    store, ref = _seed(model)
    memory, roles = _pin(model, ref)
    model._ltm_provisioned = True
    monkeypatch.setattr(model, '_ltm_ingest_truth_texts', lambda *args: [])
    model._store_truths_into_ltm(store, model.symbolSpace.truth_layer, [], [])
    assert len(store) == 1, 'normal replacement deleted a live thought constituent'
    assert store.occurrence_of(0) == ref and store.row(0)['kind'] == 'unverified'
    assert int(model.symbolSpace.truth_layer.count) == 0
    memory.thought_state().contexts[0].meaning.roles.square().sum().backward()
    assert roles.grad is not None and roles.grad.abs().sum() > 0


def test_full_checkpoint_restores_occurrence_owners_before_stateless_withdrawal(tmp_path):
    model = _make_model(_ON_CONFIG)
    store, ref = _seed(model)
    _pin(model, ref)
    path = tmp_path / 'nested.ckpt'
    model.save_weights(path)
    restored = _make_model(_ON_CONFIG)
    assert restored.load_weights(path)
    restored_store = restored.symbolSpace.ltm_store
    assert len(restored_store) == 1 and restored_store.occurrence_of(0) == ref
    assert restored_store.row(0)['kind'] == 'unverified'
    assert restored_store.read_structure(ref)['incomplete'] == ()
    current = restored.symbolSpace.what_memory.thought_state().contexts[0].meaning
    assert current.role_refs[0] == ref and not current.roles.requires_grad


def test_full_checkpoint_still_removes_unreferenced_request_scoped_content(tmp_path):
    model = _make_model(_ON_CONFIG)
    _seed(model)
    path = tmp_path / 'unreferenced.ckpt'
    model.save_weights(path)
    restored = _make_model(_ON_CONFIG)
    assert restored.load_weights(path)
    assert len(restored.symbolSpace.ltm_store) == 0
    assert int(restored.symbolSpace.truth_layer.count) == 0


def test_truth_view_excludes_retained_withdrawn_content():
    model = _make_model(_ON_CONFIG)
    store, ref = _seed(model)
    store.clear_origin(store.ORIGIN_USER, retained_occurrences=(ref,))
    model.symbolSpace.truth_layer.sync_from_ltm()
    assert len(store) == 1
    assert int(model.symbolSpace.truth_layer.count) == 0


def test_tensor_only_restore_with_unknown_references_defers_pruning_but_withdraws_authority():
    model = _make_model(_ON_CONFIG)
    store, ref = _seed(model)
    parent = ConceptualMeaning(torch.ones(3, store.nDim), torch.ones(3, dtype=torch.bool),
                               role_refs=(ref, None, None))
    store.append_meaning(parent, kind='observation')
    restored = _make_model(_ON_CONFIG)
    restored.load_state_dict(model.state_dict())
    s = restored.symbolSpace.ltm_store
    assert len(s) == 2 and s.occurrence_of(0) == ref
    assert s.row(0)['kind'] == 'unverified' and s.row(0)['trust'] == 0
    assert s.read_structure(s.occurrence_of(1))['incomplete'] == ('unavailable_metadata',)
    assert int(restored.symbolSpace.truth_layer.count) == 0
