"""Record a user-authorized incomplete checkpoint; never manufacture full green."""
from pathlib import Path
from collections import Counter
import ast,hashlib,json,shutil,subprocess
from full_spec_bounded_evidence import verified_run,archive_run
root=Path('/Users/arogers/github/WikiOracle/basicmodel')
protected=json.loads(Path('/tmp/full-spec-unowned-after-tied.json').read_text())
for name,digest in protected.items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root)
latest=verified_run('/tmp/full-spec-checkpoint-tooling-v1',root)
folder=root/'doc/benchmarks/2026-09-17-bounded-test-data'
assert not folder.exists();folder.mkdir(parents=True)
tree=ast.parse(Path('/tmp/full-spec-finalize-bounded-tests.py').read_text())
files=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='files' for t in n.targets))
files.update({
 'mixed-device-red.log':'/tmp/full-spec-mixed-device-red-v1.log',
 'mps-training-audit.json':'/tmp/full-spec-sequence-gpu-v2-audit.json',
 'mps-training-audit-plugin.py':'/tmp/full_spec_gpu_training_audit.py',
 'mps-stack-excerpt.txt':'/tmp/full-spec-sequence-gpu-v2-stack-excerpt.txt',
 'legacy-slow-routing-audit.json':'/tmp/full-spec-legacy-slow-routing-audit.json',
})
for name,source in files.items():shutil.copyfile(source,folder/name)
checks=[('/tmp/full-spec-checkpoint-tooling-v1','checkpoint-tooling',latest)]
for path,prefix in [
 ('/tmp/full-spec-bounded-affected-v4','tooling-affected'),
 ('/tmp/full-spec-slow-gates-affected-v1','slow-affected'),
 ('/tmp/full-spec-slow-switch-affected-v2','switch-affected'),
 ('/tmp/full-spec-compiler-slow-gates-affected-v2','compiler-affected'),
 ('/tmp/full-spec-production-slow-affected-v2','production-affected'),
 ('/tmp/full-spec-additional-large-affected-v1','additional-large-affected'),
 ('/tmp/full-spec-time-device-affected-v3','time-device-affected'),
 ('/tmp/full-spec-sequence-gpu-v2','mps-training')]:
 checks.append((path,prefix,verified_run(path)))
for path,prefix,result in checks:archive_run(path,folder,prefix,result)
v4=json.loads(Path('/tmp/full-spec-bounded-fast-full-v4/result.json').read_text())
assert v4['exit_code']==124 and len(v4['completed'])==2907
calls=[r for w in v4['workers'] if w['exit_code']==0 for r in w['reports'] if r['phase']=='call' and r['outcome']=='passed']
byfile=Counter()
for r in calls:byfile[r['nodeid'].split('::')[0]]+=r['duration']
profile=dict(scope='Partial timed-out run: completed passing call phases only. Not a full-suite result; does not isolate imports, allocation or compilation.',
 elapsed_seconds=v4['elapsed_seconds'],completed_cases=len(v4['completed']),selected_cases=len(v4['selected']),exit_code=v4['exit_code'],
 longest_calls=[dict(nodeid=r['nodeid'],seconds=r['duration']) for r in sorted(calls,key=lambda r:r['duration'],reverse=True)[:40]],
 call_seconds_by_file=dict(byfile.most_common()))
(folder/'partial-call-profile.json').write_text(json.dumps(profile,indent=2)+'\n')
summary=dict(status='checkpoint; full validation incomplete',authorization='On September 17 Alec requested a pushed checkpoint for an OS update, deferring the full-suite-green requirement and making completion of this session/spec the next task.',
 latest_tooling=latest['summary'],latest_full_attempt=dict(exit_code=124,completed=2907,selected=4458,elapsed_seconds=v4['elapsed_seconds']),
 evidence=[dict(prefix=prefix,summary=r['summary']) for _,prefix,r in checks],
 next='Finish the session and canonical spec; validate each remaining item, then full default suite before normal implementation commits.')
(folder/'checkpoint-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
p=root/'doc/Testing.md';text=p.read_text()
text=text.replace('`RUN_SLOW=1` tests and defaults to an available GPU.', '`RUN_SLOW=1` tests, assigning marked slow cases to an available GPU and ordinary cases to CPU.')
old='Significant training belongs in the explicit slow run and uses the available\naccelerator. `RUN_SLOW=1` defaults to `BASICMODEL_DEVICE=gpu`; on this machine\nthat resolves to the Apple M4 Max\'s MPS device. A GPU request fails explicitly\nwhen no accelerator is available. The quick regression gate defaults to CPU.'
new='Significant training belongs in the explicit slow run and uses the available\naccelerator. With `RUN_SLOW=1` and no explicit device, marked `slow` cases run\non the available GPU and ordinary cases run on CPU in separate sequential\nworkers. On this machine the GPU resolves to the Apple M4 Max\'s MPS device.\nA GPU request fails explicitly when no accelerator is available. The quick\nregression gate defaults to CPU. Older manual slow gates without a `slow`\nmarker still need the marker audit listed in the checkpoint; request MPS\nexplicitly for their significant training until that audit is complete.'
assert old in text;text=text.replace(old,new)
old='Full-suite evidence will\nbe recorded after the bounded background run completes.'
assert old in text
new='The checkpoint tooling selection passed **'+latest['summary']+'**\n(20 resource/coverage cases, six device cases and three slow-switch cases).\nEarlier affected-file runs and their tested source hashes are archived separately;\nthose earlier runs do not validate later runner revisions.\n\n**Full validation is incomplete.** The last full default attempt exited 124\nafter 5,136 seconds, with 2,907 of 4,458 selected cases completed. It is not green.\nOn September 17 Alec requested this checkpoint for an OS update and explicitly\ndeferred the full-suite-green requirement. No replacement full run was started.\nFinish this session and the integrated spec next, including the full gate.\n\nThe actual MPS sequence-training check passed: 877.81 seconds in `runEpoch`\nfor two batches, 1.24 seconds for construction and a 2.54 GiB peak aggregate\nfootprint. All 137 parameter tensors, including the predictor, were on MPS.\nThis used the current `eager` backend and was slower than an earlier 280-second\nCPU test call under different run conditions. It is not a controlled speedup\ncomparison, a held-out utility result or a current supervised-answer throughput\nmeasurement. GPU performance tuning remains open.\n\n[Checkpoint summary](benchmarks/2026-09-17-bounded-test-data/checkpoint-summary.json),\n[latest tooling receipt](benchmarks/2026-09-17-bounded-test-data/checkpoint-tooling-result.json),\n[timed-out full receipt](benchmarks/2026-09-17-bounded-test-data/reconstruction-profile-result.json),\n[MPS measurement](benchmarks/2026-09-17-bounded-test-data/mps-training-audit.json),\n[partial timing profile](benchmarks/2026-09-17-bounded-test-data/partial-call-profile.json).'
text=text.replace(old,new)
text+='\n## Future work: bounded fixture reuse\n\nEvaluate compatible preallocated fixture reuse with complete reset checks and\nseparate construction/compilation counters. Existing fixed-capacity contracts\nremain in place. [Assessment and acceptance criteria](plans/2026-09-17-bounded-fixture-reuse.md)\nrecord the follow-up; comparative speedups remain unmeasured.\n'
p.write_text(text)
future=Path('/tmp/full-spec-fixed-capacity-future-work.md').read_text().replace('[complete default call profile](../benchmarks/2026-09-17-bounded-test-data/full-call-profile.json)', '[partial default call profile](../benchmarks/2026-09-17-bounded-test-data/partial-call-profile.json)').replace('The latter counts passing call phases by test and file.', 'The latter counts passing call phases by test and file from the incomplete,\ntimed-out run; it is not a full-suite completion record.')
future+='\n## MPS measurement at the checkpoint\n\nThe sequence-training check measured 1.24 seconds for construction and 877.81\nseconds for two training batches on MPS with the current `eager` backend. This\ncase therefore does not support construction time as the dominant cost. Record\nwarmed step timings and backend/dispatch costs before choosing the optimization.\n[Measured phases and parameter devices](../benchmarks/2026-09-17-bounded-test-data/mps-training-audit.json).\n'
(root/'doc/plans/2026-09-17-bounded-fixture-reuse.md').write_text(future)
p=root/'doc/plans/2026-09-15-next-sentence-as-the-production-objective.md';text=p.read_text()
heading='## 10. Consolidated implementation and verification order\n'
assert heading in text
text=text.replace(heading,heading+'\n**September 17 OS checkpoint:** implementation of this spec is unfinished.\nAlec requested a pushed checkpoint, deferring the full-suite-green gate for this\ncheckpoint only. Completing this session and this spec is the next task in\n[todo.md](../../todo.md), before the separately reserved September 16 work.\nThe latest full run timed out; [Testing](../Testing.md#validation) records the\npassing focused evidence and incomplete full validation. Resume the item order\nbelow and its ordinary test/commit/push gates; do not treat this checkpoint as\ncompletion or a general relaxation of those gates.\n',1)
p.write_text(text)
owned=['Makefile','test/bounded_tests.py','test/pytest_worker.py','test/test_report.py',
 'test/test_bounded_test_runner.py','test/test_bounded_test_recycling.py','test/test_training_device.py','doc/Testing.md',
 'test/conftest.py','test/slow_tests.py','test/test_test_modes.py','test/test_config_matrix.py',
 'doc/plans/2026-09-14-answer-path-ownership-and-training.md',
 'doc/plans/2026-09-15-next-sentence-as-the-production-objective.md',
 'doc/plans/2026-09-17-bounded-fixture-reuse.md']
owned+=list(json.loads(Path('/tmp/full-spec-test-mode-selections.json').read_text()))
owned += [str(p.relative_to(root)) for p in folder.iterdir()]
owned=sorted(set(owned));assert not set(owned)&set(protected)
Path('/tmp/full-spec-os-resource-owned-paths.txt').write_text('\n'.join(owned)+'\n')
Path('/tmp/full-spec-os-resource-commit-message.txt').write_text(
 'Checkpoint bounded tests before OS upgrade\n\n'
 'Use sequential resource-limited workers, live progress receipts and memory/time recycling. Preserve explicit devices and route marked slow training to GPU, including MPS, while ordinary checks remain on CPU. Gate 245 costly test functions and retain assertions and production-width variants. Record fixed-capacity fixture reuse as future work.\n\n'
 'Validation: '+latest['summary']+'. Actual MPS sequence training passed; archived earlier affected runs retain their own source hashes. The full default attempt timed out (exit 124, 2907/4458 completed in 5136 seconds); full validation is incomplete.\n\n'
 'Alec explicitly requested this checkpoint for an OS update and deferred the full-suite-green gate. The integrated spec remains unfinished and is the next task. No reasoning methods were removed.\n\n'
 'Co-Authored-By: Claude Fable 5.1 <noreply@anthropic.com>\n')
print(json.dumps({'owned_paths':len(owned),'latest':latest['summary'],'full_status':'incomplete, user-authorized checkpoint'},indent=2))
