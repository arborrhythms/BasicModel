# New user steering, September 17

1. At the END of this run, prepend the updated canonical integrated-spec link
   and actual remaining open items to basicmodel/todo.md, preserving all existing
   user content. This explicitly authorizes that edit. If committing, stage only
   the new section relative to HEAD, not the pre-existing user modifications.
2. Speed up development/testing without bogging down the machine. Add enforced
   memory limits and timed termination to test tasks. This is current priority
   before restarting any long suite. Use fresh bounded workers and one heavy run
   at a time, retaining complete full-suite coverage and honest failure status.

Primary registry log completed: 4371 passed, 51 skipped, 7 xfailed, 184 warnings,
4 subtests passed in 7222.95s (2:00:22). After the deliberate conversation
interruption/restart, write_stdin session 53030 is unknown and no pytest process
remains. Thus we have the full passing pytest summary and unchanged 579-source
manifest, but have NOT recovered an explicit tool exit status. Do not fabricate
a verified exit-code receipt. A guarded rerun can supply fresh exit proof.
History/phase full attempts remain explicitly interrupted (143), not green.

3. Latest explicit user instruction: ensure work AND todo.md are committed and
pushed before declaring done, because the OS upgrade may remove machine access.
This authorizes committing todo.md, including the existing user entries while
preserving them. It does not authorize committing the originally excluded docs.

Registry was committed/pushed as 639034c, parent 2e4aec0. Complete passing
summary + unchanged source archived; completion receipt explicitly records that
managed exit status was unavailable rather than inventing one.

New bounded runner: 16 probes green, then 76 affected cases (75 passed, 1 skipped),
managed session 68328 exit 0. Full run now /tmp/full-spec-bounded-full-v1,
8 GiB aggregate/default 1800s worker/10800s suite, one sequential worker at a time.
Do not edit primary source/docs while running. Future work may use isolated
checkouts, but no concurrent heavy pytest runs.

Bounded full v1 STOPPED as designed at 8.04 GiB, managed session12697 exit137.
Fixed-batch accumulation in test_blind_decode exposed the need to recycle
at completed-test boundaries. New test_recycling probe first FAILED (memory137)
then passed after a half-cap recycle request; full original failed attempt
is preserved and is not proof. A test still exceeding the hard cap fails.

Current runner has 18 probes. Real recycling+blind tests: 7 passed,1 skipped,
237.70s, peak5.40GiB; session18098 exit0. Final affected 4 files:77passed,1skipped,
116.60s, peak0.47GiB; session86615 exit0. New full v2 now running at
/tmp/full-spec-bounded-full-v2 (logs same path+.log). PRIMARY FROZEN AGAIN.

Registry/parent pushed:639034c/2e4aec0. Resource changes remain uncommitted
pending full green. Exact stage finalizer /tmp/full-spec-finalize-bounded-tests.py
expects v2 and preserves resource-stop/recycling evidence. Generic future proof
helper /tmp/full_spec_bounded_evidence.py; new history/phase primary bounded
finalizer /tmp/full-spec-finalize-bounded-stage.py with config
/tmp/full-spec-bounded-stage-config.json. Prefer primary install -> affected ->
full -> commit/push/bump, sequentially, instead of old isolated full attempts.

New nested templates/installer prepared, NOT RUN:
/tmp/full-spec-nested-retention-documentation.md
/tmp/full-spec-install-nested-retention.py
/tmp/full-spec-install-nested-retention-docs.py
The existing nested runtime candidate remains unchanged/257 affected green.
