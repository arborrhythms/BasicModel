from pathlib import Path
import shutil,json,hashlib
root=Path('/Users/arogers/github/WikiOracle/basicmodel')
work=Path('/tmp/full-spec-query-work-worktree');assert not work.exists();(work/'bin').mkdir(parents=True)
parents={'bin/Queries.py':Path('/tmp/full-spec-phase-worktree/bin/Queries.py'),
         'bin/Thoughts.py':Path('/tmp/full-spec-nested-worktree/bin/Thoughts.py'),
         'bin/Layers.py':Path('/tmp/full-spec-nested-worktree/bin/Layers.py'),
         'bin/Taxonomy.py':root/'bin/Taxonomy.py','bin/reasoning.py':root/'bin/reasoning.py'}
for source in (root/'bin').iterdir():
 if source.name=='__pycache__':continue
 name='bin/'+source.name
 if name in parents:shutil.copyfile(parents[name],work/name)
 else:
  chosen=Path('/tmp/full-spec-nested-worktree')/name
  (work/name).symlink_to(chosen if chosen.exists() else source,target_is_directory=source.is_dir())
shutil.copyfile(parents['bin/Thoughts.py'],work/'bin/Thoughts.py')
(work/'base-manifest.json').write_text(json.dumps({name:hashlib.sha256(p.read_bytes()).hexdigest() for name,p in parents.items()},indent=2)+'\n')
def edit(name,old,new):
 p=work/name;s=p.read_text();assert s.count(old)==1,(name,old[:100],s.count(old));p.write_text(s.replace(old,new,1))
(work/'bin/QueryWork.py').write_text('''"""Ephemeral shared query cost, charged before selected reads or execution.

A boundary controller supplies the remaining episode allowance. This object
has no semantic state, reset, child allowance or checkpoint owner; committed
thought history records its actual spent cost.
"""
from collections import Counter
from types import MappingProxyType

class QueryWorkExhausted(RuntimeError):
    pass

class QueryWorkBudget:
    def __init__(self, limit):
        if type(limit) is not int or limit < 0:
            raise ValueError("query work limit must be a non-negative integer")
        self._limit, self._spent = limit, 0
        self._counts = Counter()

    @property
    def remaining(self):
        return self._limit - self._spent

    @property
    def spent(self):
        return self._spent

    @property
    def counts(self):
        return MappingProxyType(dict(self._counts))

    def consume(self, kind, units=1):
        if not isinstance(kind, str) or not kind:
            raise ValueError("query work requires a named cost")
        if type(units) is not int or units < 0:
            raise ValueError("query cost must be a non-negative integer")
        if units > self.remaining:
            return False
        self._spent += units
        if units:
            self._counts[kind] += units
        return True

    def require(self, kind, units=1):
        if not self.consume(kind, units):
            raise QueryWorkExhausted("shared query work_budget exhausted")
''')
edit('bin/Taxonomy.py','def part_of(self, part, whole, *, max_steps=8, max_expansions=1024):','def part_of(self, part, whole, *, max_steps=8, max_expansions=1024, work=None):')
edit('bin/Taxonomy.py','                for edge in outgoing:\n','                for index in range(len(outgoing)):\n')
edit('bin/Taxonomy.py','                    result["edges_expanded"] += 1\n','                    if work is not None and not work.consume("expansion"):\n                        incomplete.append("work_budget")\n                        stopped = True\n                        break\n                    edge = outgoing[index]\n                    result["edges_expanded"] += 1\n')
edit('bin/Taxonomy.py','def capture_taxonomy(conceptual_space, *, max_nodes=256, max_records=1024, focus=()):','def capture_taxonomy(conceptual_space, *, max_nodes=256, max_records=1024, focus=(), work=None):')
edit('bin/Taxonomy.py','        visited.add(cid)\n        nodes += 1\n','        if work is not None and not work.consume("node"):\n            incomplete.append("work_budget")\n            break\n        visited.add(cid)\n        nodes += 1\n')
edit('bin/Taxonomy.py','        source = layer.iter_constituents(cid)\n        for _index in range(take):\n            role, reference = next(source)\n','        source = None\n        for _index in range(take):\n            if work is not None and not work.consume("record"):\n                incomplete.append("work_budget")\n                break\n            if source is None:\n                source = layer.iter_constituents(cid)\n            role, reference = next(source)\n')
# Stop once any required record could not be read; scanning another node cannot renew the allowance.
edit('bin/Taxonomy.py','        if take < count:\n','        if "work_budget" in incomplete:\n            break\n        if take < count:\n')
edit('bin/reasoning.py','def existence_evidence(self, description, *, max_records=None):','def existence_evidence(self, description, *, max_records=None, work=None):')
edit('bin/reasoning.py','            scanned = len(store) if max_records is None else min(len(store), max_records)\n            if scanned < len(store):','            count = len(store) if max_records is None else min(len(store), max_records)\n            if count < len(store):')
edit('bin/reasoning.py','            for i in range(scanned):\n','            for i in range(count):\n                if work is not None and not work.consume("record"):\n                    diagnostics.append("work_budget")\n                    break\n                scanned += 1\n')
edit('bin/reasoning.py','                          max_nodes=256, max_records=1024, max_expansions=1024):','                          max_nodes=256, max_records=1024, max_expansions=1024, work=None):')
edit('bin/reasoning.py','                                focus=(part, whole))\n','                                focus=(part, whole), work=work)\n')
edit('bin/reasoning.py','                            max_expansions=max_expansions)\n','                            max_expansions=max_expansions, work=work)\n')
edit('bin/Queries.py','from Meaning import ConceptualMeaning\n','from Meaning import ConceptualMeaning\nfrom QueryWork import QueryWorkBudget, QueryWorkExhausted\n')
edit('bin/Queries.py','    max_expansions: int = 1024\n','    max_expansions: int = 1024\n    work: QueryWorkBudget | None = None\n')
edit('bin/Queries.py','    def __post_init__(self):\n        for name in (\'row\',','    def __post_init__(self):\n        if self.work is not None and not isinstance(self.work, QueryWorkBudget):\n            raise TypeError("query work requires one shared QueryWorkBudget")\n        for name in (\'row\',')
edit('bin/Queries.py','        result = self.executor(context, by_role)\n','        try:\n            if context.work is not None:\n                context.work.require("operation")\n            result = self.executor(context, by_role)\n        except QueryWorkExhausted:\n            result = _work_exhausted()\n')
edit('bin/Queries.py','def _concept_space(context):\n','def _work_exhausted():\n    return {"value": None, "support_true": 0.0, "support_false": 0.0,\n            "candidates": (), "incomplete": ("work_budget",)}\n\n\ndef _concept_space(context):\n')
edit('bin/Queries.py','    space = _concept_space(context)\n    row = _existing_row(space, value)\n','    if context.work is not None:\n        context.work.require("payload")\n    space = _concept_space(context)\n    row = _existing_row(space, value)\n')
edit('bin/Queries.py','    return context.reasoner.existence_evidence(arguments[0], max_records=context.max_records)\n','    return context.reasoner.existence_evidence(arguments[0], max_records=context.max_records,\n                                               **({"work": context.work} if context.work is not None else {}))\n')
edit('bin/Queries.py','        max_expansions=context.max_expansions)\n','        max_expansions=context.max_expansions,\n        **({"work": context.work} if context.work is not None else {}))\n')
edit('bin/Queries.py','                            max_records=context.max_records, focus=(reference,))\n','                            max_records=context.max_records, focus=(reference,), work=context.work)\n')
edit('bin/Queries.py',"    return {'value': [{'reference': edge.whole if role == 0 else edge.part,\n                       'source': edge, 'trust': 1.0} for edge in edges],\n            'incomplete': view.incomplete, 'nodes_scanned': view.nodes_scanned,\n            'records_scanned': view.records_scanned}\n","    values, incomplete = [], list(view.incomplete)\n    for index in range(len(edges)):\n        if index >= context.max_expansions:\n            incomplete.append('traversal_limit')\n            break\n        if context.work is not None and not context.work.consume('expansion'):\n            incomplete.append('work_budget')\n            break\n        edge = edges[index]\n        values.append({'reference': edge.whole if role == 0 else edge.part,\n                       'source': edge, 'trust': 1.0})\n    return {'value': values, 'incomplete': tuple(dict.fromkeys(incomplete)),\n            'nodes_scanned': view.nodes_scanned, 'records_scanned': view.records_scanned,\n            'edges_expanded': len(values)}\n")
edit('bin/Queries.py','    for index in range(count):\n        row = store.row(index)\n','    scanned = 0\n    for index in range(count):\n        if context.work is not None and not context.work.consume("record"):\n            incomplete.append("work_budget")\n            break\n        scanned += 1\n        row = store.row(index)\n')
edit('bin/Queries.py',"    return {'value': tuple(found), 'records_scanned': count,\n","    return {'value': tuple(found), 'records_scanned': scanned,\n")
edit('bin/Queries.py','    basis = _basis(space)\n    if basis.shape[1] != vector.numel():\n        raise ValueError(\'query quantize requires the full conceptual width\')\n','    basis = None\n')
edit('bin/Queries.py','        scanned += 1\n        if concept_id in allocator.retired:\n','        if context.work is not None and not context.work.consume("node"):\n            incomplete.append("work_budget")\n            break\n        scanned += 1\n        if basis is None:\n            basis = _basis(space)\n            if basis.shape[1] != vector.numel():\n                raise ValueError("query quantize requires the full conceptual width")\n        if concept_id in allocator.retired:\n')
edit('bin/Queries.py','    value = discourse.expect_next_meaning(context.row, record=False)\n','    value = discourse.expect_next_meaning(context.row, record=False,\n        **({"work": context.work} if context.work is not None else {}))\n')
edit('bin/Queries.py','        return memory.resolve_thought(reference, b=context.row, max_records=context.max_records)\n','        return memory.resolve_thought(reference, b=context.row, max_records=context.max_records,\n                                      work=context.work)\n')
edit('bin/Queries.py','    for index in range(min(len(store), context.max_records)):\n        if int(store.occurrence_id[index])','    for index in range(min(len(store), context.max_records)):\n        if context.work is not None:\n            context.work.require("record")\n        if int(store.occurrence_id[index])')
# The registry must retain the full proposition when operand resolution exhausts work.
old='''        arguments, resolved = [], 0
        for role, kind in zip(signature.argument_roles, signature.argument_kinds):
            reference = meaning.role_refs[role]
            if kind == 'description':
                value, scanned = _occurrence_description(context, reference)
                resolved += scanned
            elif reference is not None:
                _existing_row(self.space, reference)
                value = reference
            elif kind == 'concept':
                value = meaning.roles[role]
            else:
                raise ValueError('query operand requires a grounded conceptual reference')
            arguments.append(value)
        evidence = signature.invoke(context, *arguments)
'''
new='''        arguments, resolved = [], 0
        try:
            for role, kind in zip(signature.argument_roles, signature.argument_kinds):
                reference = meaning.role_refs[role]
                if kind == 'description':
                    value, scanned = _occurrence_description(context, reference)
                    resolved += scanned
                elif reference is not None:
                    if context.work is not None:
                        context.work.require("reference")
                    _existing_row(self.space, reference)
                    value = reference
                elif kind == 'concept':
                    value = meaning.roles[role]
                else:
                    raise ValueError('query operand requires a grounded conceptual reference')
                arguments.append(value)
            evidence = signature.invoke(context, *arguments)
        except QueryWorkExhausted:
            evidence = dict(_work_exhausted(), result_kind=signature.result_kind,
                evidence_kind=signature.evidence_kind, semantic_id=signature.semantic_id,
                domain=signature.domain)
'''
edit('bin/Queries.py',old,new)
edit('bin/Thoughts.py','def resolve_thought(self, reference, *, b=0, max_records=1024):','def resolve_thought(self, reference, *, b=0, max_records=1024, work=None):')
edit('bin/Thoughts.py','        for index, record in enumerate(self._what_slots[self._thought_row(b)]):\n            if index >= max_records:\n                break\n','        records = self._what_slots[self._thought_row(b)]\n        iterator = iter(records)\n        for index in range(min(len(records), max_records)):\n            if work is not None:\n                work.require("record")\n            record = next(iterator)\n')
edit('bin/Layers.py','def expect_next_meaning(self, b=0, *, record=True):','def expect_next_meaning(self, b=0, *, record=True, work=None):')
edit('bin/Layers.py','        b = int(b)\n        chain = list(self._inter_context[b])\n','        b = int(b)\n        if work is not None:\n            work.require("record", len(self._inter_context[b]))\n        chain = list(self._inter_context[b])\n')
print(work)
