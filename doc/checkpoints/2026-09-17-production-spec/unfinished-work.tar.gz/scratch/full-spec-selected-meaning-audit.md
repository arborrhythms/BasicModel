# Selected linguistic meaning: next integration audit

This is a design/work note, not a completion claim. The phase candidate is
being validated separately; do not modify any frozen primary/history/phase
checkout during its tests. Read the standing invariants after compaction.

## Verified source constraints (registry snapshot)

- `AnswerProgram` owns signed live leaves, native concept IDs, chronological
  actions and physical end-state (`Understanding.py:26`; `_capture_answer_programs`
  at `Models.py:12073`, `_program_entries` and `_replay_program` below it).
  The actions identify local operations, not arbitrary grammar names. Binary
  orientation is older left/newer right. Capture semantic products once; do not
  re-read later staging or a later-mutated global grammar to interpret a held
  understanding.
- `LanguageSpace.__init__` captures local-to-rule maps but still reads the
  process-global `TheGrammar` (`Language.py:14106`). A semantic adapter must own
  the selected rule's meaning/argument permutation at model construction or
  capture. The local numerical layer bank is the actual compose implementation.
- `PartLayer.forward` returns the right operand; `WholeLayer` returns the left
  (`Language.py:4228,4296`). Root vectors alone cannot recover both operands.
  Query flags currently select geometric `queryPart/queryEqual` numerical
  layers through `_dispatch_method_name_for_rule` (`Language.py:4419`). That
  legacy alias must become pure representation, with execution only at the
  checked boundary. Keep its explicit legacy experiment API separate if needed.
- Registry relation identity lives in the existing named conceptual rows
  (`Queries.py:GrammaticalQueryRegistry`). `form` constructs from native refs;
  a linguistic adapter must retain the actual signed operand payloads from its
  derivation, not silently replace them with a fresh unit dictionary lookup.
  Native IDs are addresses, never semantic feature magnitudes.
- The three observation writers still consume physical slots before owned
  Understanding capture: pending compiled, packed host, eager sink. Route all
  of them through the same completed canonical meaning before their one
  observation, with explicit infix masks. Preserve physical reconstruction
  state, compiled arity, row masks, chronological packed order and once-only
  observation. `InterSentenceLayer.predict_and_observe_stm_end_state` already
  accepts `layout='infix'` and `role_masks` (`Layers.py:10362`).
- Current registry formation is an explicit API; no normal model setup installs
  it yet. Wiring named VPs must happen before compiled staging, use the existing
  conceptual checkpoint/row owner, and preserve WORD versus selected OBJECT.
  `mint_frozen_concept` is `Spaces.py:18963`.
- The current Anchors map is one operator per surface (`Language.py:1092`) and
  its word-whole consumer is `Spaces.py:17605`. Multiword paraphrases and
  polysemous 'has' cannot be implemented by treating every literal string 'has'
  as parthood. Use selected grammar/lexical senses and a declared converse
  permutation; retain surface order independently for reconstruction.

## Nested ownership must be concrete

Do not add an independent semantic AST store. The spec requires using existing
conceptual/occurrence owners. A transient interpretation of the owned compose
actions is allowed, but every retained compound argument must resolve through
an actual owner with bounds, scope, row isolation and checkpoint retention.
`TernaryTruthStore` already owns full meanings and monotonic occurrence IDs;
`WhatInteractionMemory` owns live episode records. The current store returns
-1 at capacity and `clear_origin` can remove referenced records, so merely
writing references does not satisfy nested retention. Fix those contracts with
tests before claiming arbitrary nesting.

The new two-truths spec is explicitly reserved for the next session. Do not
adopt its collapse-vs-reference policy here despite its superseding note.

## Verification targets

1. Actual selected part/whole/equal/exist compose operations, native middle VP,
   argument order, signed operand gradients, mode and negation; identity must
   survive another model/grammar being constructed.
2. Assertions and quoted/embedded questions never execute during any sentence
   path. The complete selected boundary question agrees with the internal
   registry form without a raw-text classifier.
3. All three normal observation writers receive the same canonical roles,
   including mixed/packed rows, before target detach and durable write. No
   duplicate external observation or prediction pair.
4. Nested occurrence limits, repeated occurrences, unavailable/cyclic refs,
   scope/evidence noninheritance, row isolation, trimming and checkpoint restore.
5. Real linguistic recognition/generation of declared paraphrases and distinct
   senses, followed by causal normal-controller use. An API-only adapter does
   not establish that linguistic gate or useful learned reasoning.

After this adapter, implement the semantic ordinary controller, mandatory roles
outside optional R/K attention, actual shared work accounting, owned estimates,
prior-view isolation (including dictionary/staging and unseen packed input),
residual policy credit, catalog separation and learned-utility/throughput gates.
