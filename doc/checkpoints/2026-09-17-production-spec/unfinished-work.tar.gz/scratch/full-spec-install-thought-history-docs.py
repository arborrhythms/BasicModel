"""Render ordinary history documentation and remap current-source links exactly once."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import re

root=Path('/Users/arogers/github/WikiOracle/basicmodel')
work=Path('/tmp/full-spec-thought-worktree')
base=Path('/tmp/full-spec-thought-history-base')
receipt=Path('/tmp/full-spec-thought-history-doc-remap-applied.json')
assert not receipt.exists(), 'Do not remap links twice'
assert not (root/'doc/ThoughtHistory.md').exists()
for name,digest in json.loads((work/'validation-manifest.json').read_text()).items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name

def definitions(text):
    found={}
    def visit(node,path=()):
        if isinstance(node,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)):
            path=path+(node.name,)
            found['.'.join(path)]=(node.lineno,node.end_lineno)
        for child in ast.iter_child_nodes(node):
            visit(child,path)
    visit(ast.parse(text))
    return found

maps={}; anchors={}
for name in ('Thoughts.py','Queries.py','Language.py','Layers.py','Models.py','Understanding.py','reasoning.py','Spaces.py','exact.py'):
    new=(root/'bin'/name).read_text()
    new_defs=definitions(new)
    anchors.update({name+':'+key:value[0] for key,value in new_defs.items()})
    if not (base/'bin'/name).exists():
        continue
    old=(base/'bin'/name).read_text()
    old_defs=definitions(old)
    old_lines,new_lines=old.splitlines(),new.splitlines()
    mapping={}
    for op,i,j,a,b in difflib.SequenceMatcher(None,old_lines,new_lines,autojunk=False).get_opcodes():
        for index in range(i,j):
            if op=='equal':
                mapping[index+1]={'line':a+(index-i)+1,'kind':'exact'}
                continue
            enclosing=[(hi-lo,key) for key,(lo,hi) in old_defs.items()
                       if lo<=index+1<=hi and key in new_defs]
            if enclosing:
                _,key=min(enclosing)
                mapping[index+1]={'line':new_defs[key][0],'kind':'definition','name':key}
            else:
                mapping[index+1]={'line':min(len(new_lines),a+1),'kind':'adjacent'}
    maps[name]=mapping

names=['doc/Architecture.md','doc/GradientFlow.md','doc/Language.md','doc/Params.md',
       'doc/Training.md','doc/QueryContracts.md','doc/STM.md','doc/ExistenceEvidence.md','doc/TaxonomyQueries.md','doc/SymbolFirewall.md',
       'doc/plans/2026-09-15-next-sentence-as-the-production-objective.md',
       'doc/plans/2026-09-17-bounded-fixture-reuse.md']
pattern=re.compile(r'\[([^\]]+)\]\(((?:\.\./)+bin/(Layers\.py|Models\.py|Queries\.py))#L(\d+)\)')
changes=[]
def remap(match):
    label,target,filename,line=match.groups()
    mapping=maps[filename][int(line)]
    new=str(mapping['line'])
    changes.append({'file':filename,'old':int(line),**mapping})
    return '['+label.replace(filename+':'+line,filename+':'+new)+']('+target+'#L'+new+')'
def render(text,prefix='../bin/'):
    return re.sub(r'@@([^@]+)@@',lambda m:prefix+m[1].split(':',1)[0]+'#L'+str(anchors[m[1]]),text)
outputs={}
for name in names:
    text=(root/name).read_text()
    if '/plans/' in name:
        protected=False; parts=[]
        for part in re.split(r'(?=^## |^### )',text,flags=re.M):
            if part.startswith('## '):
                protected=part.startswith(('## 6.','## 7.','## 11.'))
            if part.startswith('### 11.6 '):
                protected=False
            parts.append(part if protected else pattern.sub(remap,part))
        text=''.join(parts)
    else:
        text=pattern.sub(remap,text)
    outputs[name]=text

def replace_once(name,old,new):
    assert old in outputs[name],(name,old)
    outputs[name]=outputs[name].replace(old,new,1)

draft=Path('/tmp/full-spec-thought-history-documentation.md').read_text()
draft=draft.replace('Draft implementation reference. Repository installation and validation are\npending the checked-query commit cycle.',
                    'Implementation reference, September 16. Repository validation is in progress.')
outputs['doc/ThoughtHistory.md']=render(draft)
sections={
'doc/Architecture.md': '''
## Ordinary thought-history owner (September 16)

`SymbolSpace.what_memory` remains the single interaction owner. Its existing
per-row deque now accepts ordinary structured thoughts and explicit level and
termination transitions. Replay derives active/suspended contexts; these views
do not own a second planner stack. Native occurrence references, scope, evidence
and the one root budget survive checkpoint restore. A closed legacy prefix is
retained through an explicit compatibility adapter.
[Owner](@@Layers.py:WhatInteractionMemory@@),
[replay](@@Thoughts.py:replay_thoughts@@),
[history contract](ThoughtHistory.md).

Normal learned selection, linguistic integration and causal answer construction
remain subsequent work. These APIs have not replaced the legacy production loop.
''',
'doc/GradientFlow.md': '''
## Live ordinary episode history

Episode-mode writes clone complete meanings without detaching their continuous
computation. Description queries can resolve that live value from a `thought`
occurrence in the same owner. Durable `ltm` reads remain detached. Addresses,
hard evidence matches and context transitions have no ordinary derivative.
[Write](@@Thoughts.py:LevelledThoughtHistory._store_thought_events@@),
[query read](@@Queries.py:_occurrence_description@@).

Explicit finish is required before `end_what_episode` releases ordinary credit.
The caller must perform its single optimizer step first; release then detaches
retained meanings, legacy prompts and trace tensors. Checkpoints detach copies
without cutting the live training graph. Restore preserves detached past values
and permits fresh credit for new computations under the remaining budget.
[Credit end](@@Layers.py:WhatInteractionMemory.end_what_episode@@),
[restore](@@Thoughts.py:LevelledThoughtHistory.load_thought_extras@@).

No parameter or loss is added. Controller optimizer ownership, policy credit,
residual attribution and learned utility remain separate gates. Permitted
downstream feedback stays subject to the aggregate gradient rule above.
See [Thought history](ThoughtHistory.md).
''',
'doc/Params.md': '''
### Ordinary thought-history bounds

`begin_thought_episode` accepts an explicit `work_budget` (API default 32).
Only root begin declares it; each ordinary event charges positive work. Pressure
is cumulative work divided by `max(1, budget)`. Cutoff freezes the active level
and permits at most `d_cut` returns plus one root finish. Capacity reserves the
drain and cannot evict active or referenced occurrences. These are API bounds;
the normal controller still must account for actual executor work.
[Begin](@@Thoughts.py:LevelledThoughtHistory.begin_thought_episode@@),
[accounting](@@Thoughts.py:LevelledThoughtHistory._thought_event@@),
[retention](@@Thoughts.py:LevelledThoughtHistory._retain_thought_history@@).

The existing slot/episode detachment setting applies. No XML switch or parameter
is added. Checkpoint migration and limits are in [Thought history](ThoughtHistory.md).
''',
'doc/Training.md': '''
## Ordinary history and live query credit (September 16)

Ordinary history supports same-level continuation, strict nested descent/return,
explicit finish and one budget. Episode-mode meanings and query reads remain
live until the caller steps the optimizer and ends the finished episode.
Restore retains detached past values and permits new computation credit without
refreshing budget or pressure. No new objective or optimizer parameter is added.
[Write](@@Thoughts.py:LevelledThoughtHistory._store_thought_events@@),
[restore](@@Thoughts.py:LevelledThoughtHistory.load_thought_extras@@),
[credit end](@@Layers.py:WhatInteractionMemory.end_what_episode@@).

Controller selection, residual reward and causal learned-utility tests remain
open. A live selected read does not establish useful thinking.
[Thought history](ThoughtHistory.md) documents the mechanism.
''',
'doc/STM.md': '''
## Ordinary levelled thoughts (September 16)

The existing interaction deque accepts ordinary `ThoughtRecord` values with
execution levels and separate transitions. Contexts are recovered from history,
retaining exact parent meaning, scope and child results. Root level alone is
not completion. Only a closed legacy prefix may precede ordinary records.
[Records](@@Thoughts.py:ThoughtRecord@@),
[replay](@@Thoughts.py:replay_thoughts@@).

Stable row-local `thought` references resolve complete live episode meanings.
Capacity preserves active contexts and referenced occurrences. The existing
structural sidecar persists this owner with validated IDs, levels and budget.
[Reader](@@Thoughts.py:LevelledThoughtHistory.resolve_thought@@),
[retention](@@Thoughts.py:LevelledThoughtHistory._retain_thought_history@@),
[sidecar](@@Models.py:BaseModel._collect_structural_extras@@).

The legacy production loop remains until controller integration. These APIs do
not establish arbitrary nested grammatical retention or learned utility.
[Thought history](ThoughtHistory.md) describes the migration.
'''}
for name,section in sections.items():
    outputs[name]+=render(section)
replace_once('doc/QueryContracts.md',
    'A description-valued argument references an existing LTM occurrence.',
    'A description-valued argument references an existing durable LTM or live\nordinary-thought occurrence.')
replace_once('doc/QueryContracts.md',
    'detached by their existing owners; the current occurrence reader therefore\nreturns a detached description. Live episode occurrences will need the same\nowner\'s live read path before controller integration can claim episode credit.',
    'detached by their existing owners. A `thought` occurrence instead resolves\nthrough the one WhatInteractionMemory owner and preserves its live episode\nmeaning. [Thought history](ThoughtHistory.md) describes that boundary; normal\ncontroller integration remains open.')
replace_once('doc/GradientFlow.md',
    'return detached descriptions; the later episode controller must provide a live\nread from its existing owner to retain within-episode credit.',
    'return detached descriptions. Ordinary `thought` occurrences now provide the\nsame interaction owner\'s live read path, described below; the later controller\nstill must integrate that path.')
replace_once('doc/STM.md',
    'The current occurrence reader is a bounded durable read and does not provide\nlive episode memory. Ordinary levelled history, nested retention, shared work\naccounting and the normal linguistic observation adapter remain open.',
    'Durable LTM reads remain detached; ordinary `thought` occurrences now provide\nbounded live episode reads as described below. Normal controller integration,\nnested retention, actual executor work accounting and the linguistic observation\nadapter remain open.')
outputs['doc/plans/2026-09-15-next-sentence-as-the-production-objective.md']+=render('''
## 18. Ordinary thought-history and live occurrence APIs (in progress)

The one WhatInteractionMemory owner now stores ordinary structured thoughts and
explicit level/termination transitions in its existing chronological deque.
Replay recovers current/suspended contexts, exact meanings, scope and returned
child results without a second authoritative stack. Same-level continuation and
root finish are distinct; sibling re-entry creates a fresh context. Invalid
levels, overlapping episodes and width changes fail.
[Owner](@@Layers.py:WhatInteractionMemory@@),
[replay](@@Thoughts.py:replay_thoughts@@).

Each root declares one work budget. Positive ordinary charges accumulate across
all levels; cutoff freezes `d_cut` and permits only its bounded LIFO drain plus
one root finish. Capacity reserves those transitions and rejects eviction of
active or referenced records. Known support requires its complete proposition.
Stable row-local occurrence IDs are not reused on reset.
[Accounting](@@Thoughts.py:LevelledThoughtHistory._thought_event@@),
[retention](@@Thoughts.py:LevelledThoughtHistory._retain_thought_history@@).

Episode-mode records and query reads preserve live continuous gradients.
Explicit finish is required before post-step detachment. Structural checkpoints
save detached copies; restore validates all rows atomically and resumes remaining
budget/pressure with fresh computation credit. Legacy prompt and trace tensors
cannot keep the finished graph alive.
[Query read](@@Queries.py:_occurrence_description@@),
[checkpoint](@@Thoughts.py:LevelledThoughtHistory.load_thought_extras@@),
[credit end](@@Layers.py:WhatInteractionMemory.end_what_episode@@).

Repository validation is pending. Reviewer probes failed before the corresponding
history, checkpoint and credit fixes. [Thought history](../ThoughtHistory.md)
documents behavior and limits. This API adds no learned module or trained loss.

Normal learned control, semantic chooser features, actual executor cost accounting,
phase isolation, canonical linguistic observation and causal answer construction
remain open. Nested retention, owned expectations, anticipation isolation,
residual credit, catalog separation and learned utility are still required.
The separate two-truths spec remains next-session work.
''',prefix='../../bin/')
assert not (root/'doc/ArbitrarySymbols.md').exists()
outputs['doc/ArbitrarySymbols.md']=render(Path('/tmp/full-spec-arbitrary-symbol-documentation.md').read_text())
outputs['doc/SymbolFirewall.md'] += """

## Arbitrary addresses and arithmetic grammar tests

A numeral's native symbol ID, dictionary row or answer-class index is an
arbitrary address. Runtime grammar, prediction, reasoning and output may not
interpret that address or the surface numeral as a numerical operand for a
formula evaluator. Arithmetic must be learned over symbol-attached meanings.
Dataset generators and evaluation utilities can compute gold labels; their
solvers, intermediate bindings and fallback numeral codes cannot enter the
learner's runtime context or query menu. Tensor algebra and evidential support
retain their declared roles and cannot act as numerical operand shortcuts.
[Audit, source references and required renumbering/isolation tests](ArbitrarySymbols.md).
"""
outputs['doc/GradientFlow.md'] += """

### Arbitrary-symbol boundary

Numeral concepts use arbitrary addresses. Losses may train their semantic
representations and selected grammar/query policies through the documented
paths; there is no authorized shortcut through a host arithmetic solver or
numeric symbol-ID features. Exact dataset/evaluation targets remain outside
runtime context. Renumbering references consistently must preserve semantic
results and policy features. The current static call-site audit and pending
runtime/learning controls are recorded in [Arbitrary symbols](ArbitrarySymbols.md).
"""
key='doc/plans/2026-09-15-next-sentence-as-the-production-objective.md'
old='Codes address symbol-attached\nsemantic payloads; their arbitrary numeric values are not semantic features.'
new=old+""" Arithmetic is a
formal-grammar learning task over arbitrary symbols. Runtime paths may not
convert numeral surfaces, symbol IDs or row/class indices into numerical
operands and evaluate formulas. Dataset/evaluation solvers may supply targets
only; their bindings, gold subgoals and fallback numeral codes cannot enter
the learner's context or query menu. See
[the arbitrary-symbol contract and audit](../ArbitrarySymbols.md)."""
assert old in outputs[key];outputs[key]=outputs[key].replace(old,new,1)
old='capacity, and verify the documented adapter/MLP shapes.'
new=old+""" Consistent
   renumbering of native IDs/rows must preserve semantic results and chooser
   features. After dataset construction, failing spies on exact evaluators and
   numeral-code helpers must remain silent through understanding, reconstruction,
   query execution, output and training. Include consistently renamed nonnumeric
   numeral/operator vocabularies in the held-out learning controls."""
assert old in outputs[key];outputs[key]=outputs[key].replace(old,new,1)
for name,text in outputs.items():
    assert '@@' not in text,name
    for target,line in re.findall(r'\]\(((?:\.\./)+bin/[^)#]+\.py)#L(\d+)\)',text):
        file=((root/name).parent/target).resolve()
        assert file.is_file() and 1<=int(line)<=len(file.read_text().splitlines()),(name,target,line)
for name,text in outputs.items():
    (root/name).write_text(text)
receipt.write_text(json.dumps(changes,indent=2)+'\n')
Path('/tmp/full-spec-thought-history-line-maps.json').write_text(json.dumps(maps)+'\n')
(work/'source-anchors.json').write_text(json.dumps(anchors,indent=2)+'\n')
owned=Path('/tmp/full-spec-thought-history-owned-paths.txt')
owned.write_text('\n'.join(sorted(set(owned.read_text().splitlines())|set(outputs)))+'\n')
print('Updated',len(outputs),'documents;',len(changes),'local source links remapped once.')
print('Definition/adjacent fallbacks:',[x for x in changes if x['kind']!='exact'])
