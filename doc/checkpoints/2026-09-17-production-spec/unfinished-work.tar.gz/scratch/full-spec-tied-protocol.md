# Tied completed-sentence reconstruction protocol

Prepared before the ordered reconstruction item begins. This is an execution
note, not a claim of implementation or measured success. Deferred two-truths
fusion/collapse is excluded. Install probes only after item 4 is green,
committed/pushed, and its parent submodule bump is pushed.

## Mechanical and fidelity gates

1. Execute the reviewer probes in /tmp/full-spec-reconstruction-review-probes.py
   against the unchanged baseline; fix fixture errors before interpreting a red
   result. Cover valid pre/push/post/unary/seal reversal, distinct occurrences of
   one concept row, affine bias after learning, the real verb spectral operation,
   selected-op dispatch, owned reconstruction after restaging, no free generate,
   and exactly one completed traversal even when recovered values are zero.
2. Distinguish inverse recomposition from input fidelity. Exact sum witnesses
   and unsaturated tied linear transforms have numerical round-trip tolerances;
   lossy merges have separately reported child/surface error and incomplete
   outcomes. Perturb a sealed state with witnesses fixed: complete-sentence error
   must notice the damage. Include one-word, no-fold, unary and final-seal cases.
3. Verify actual selected compose transforms and the live representation producer
   receive declared gradients. No independent reconstruction decoder parameters.
   Scoring targets and dictionary snapshots cannot carry a target-derived decode
   input; hard rule selection has only its declared existing credit.
4. Run mixed/packed rows, padding, empty rows, retained dictionary values after a
   same-shape update, multiple optimizer calls, and eager/fullgraph comparisons.
   Check every packed sentence once and no cross-row/boundary witness reuse.
5. Train and evaluation use the same tied input objective without an extra D3 or
   reverse student term. Test legacy checkpoint migration and unchanged permitted
   downstream gradient balancing. Report the changed objective explicitly.

## Native operating points

Retain the item 4 raw detached-student measurements as the before baseline.
Use the same source/data/model widths and actual configured MPS backend (eager
capture: bin/util.py:472). Identify exact source/config hashes, seed, device,
AMP, optimizer, losses, sentence counts and cold starts in every new record.
A different reconstruction loss is not a directly comparable scalar quality
score; report the same held-out surface/idea fidelity on both paths where
supported, separately from each optimized objective.

- Two warmup plus at least five full measured optimizer steps per timed run.
- Time staging, composition, reconstruction, downstream work, backward,
  balancing, optimizer and cleanup; report first compile/warmup, observed graphs,
  peak RSS and sampled MPS tensor/driver allocation. No concurrent pytest or
  benchmarks; retain the allocator's existing cap.
- Supplied-answer fixture: batch sizes 1 and 2, three-word inputs, distinct
  supervised labels. FineWeb: canonical 256-word capacity at batch 1. Include a
  longer controlled sentence workload and explicit basis limits 8 and 16 when
  bounded search is introduced; report actual words/candidates and actual
  output lengths, not configured capacity as observed work.
- Report byte/idea reconstruction fidelity, truncation counts, selected shared
  parameter/source-gradient evidence and predictor/output objectives. A speed
  gain with broken fidelity or missing gradients cannot pass the migration.
- Retain failed memory/compile runs and their exact configuration. Do not raise
  the MPS memory cap to hide a failure or call eager capture Inductor codegen.

After affected tests and measurements, freeze runtime/tests, run the full suite
in the background, then commit/push basicmodel with the required co-author,
bump/push WikiOracle. Phase-controller/query migrations follow separately.
