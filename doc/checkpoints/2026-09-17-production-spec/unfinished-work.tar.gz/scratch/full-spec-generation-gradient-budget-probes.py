"""Catalog ownership must leave the joint representation budget in force."""
from pathlib import Path
import sys

ROOT = Path('/Users/arogers/github/WikiOracle/basicmodel')
for path in (ROOT / 'bin', ROOT / 'test'):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

import pytest
import torch
from test_meronomy_ladder import _build_ladder_variant


@pytest.mark.parametrize('detached', [False, True])
def test_model_budget_protects_live_comprehension_and_leaves_generation_gradients_ordinary(tmp_path, detached):
    m = _build_ladder_variant(tmp_path, 'catalog_budget', [])
    try:
        language = m.languageSpace
        composed = m.symbolSpace.subspace._resolve_rule_layer('CS', 'lift')
        generated = language.resolve_generation_op('CS', 'lift')
        # The projection is checked near exact orthogonality; use float64 for
        # this diagnostic rather than treating float32 cancellation as conflict.
        composed.double()
        generated.double()
        source = tuple(composed.parameters())
        output = tuple(generated.parameters())
        assert source and output and not set(map(id, source)) & set(map(id, output))
        optimizer = m.getOptimizer(lr=.001)
        protected = set(map(id, m._reconstruction_priority_parameters(optimizer)))
        assert set(map(id, source)) <= protected
        assert not set(map(id, output)) & protected
        width = int(m.conceptualSpace.stm.concept_dim)
        left = torch.linspace(-.4, .2, width, dtype=torch.float64).reshape(1, width)
        right = torch.linspace(.1, .5, width, dtype=torch.float64).reshape(1, width)
        parent = composed.compose(left, right)
        reconstruction = parent.square().mean() + 1.
        a, b = generated.reverse(parent.detach() if detached else parent)
        generation = (a + b).square().mean()
        # An adversarial auxiliary gradient isolates the aggregation contract;
        # this is a mechanics probe, not a claimed production training loss.
        auxiliary = generation if detached else generation - 10 * (reconstruction - 1.)
        parameters = source + output
        r = torch.autograd.grad(reconstruction, parameters, retain_graph=True, allow_unused=True)
        q = torch.autograd.grad(auxiliary, parameters, retain_graph=True, allow_unused=True)
        if not detached:
            dot = sum((x * y).sum() for x, y in zip(r[:len(source)], q[:len(source)])
                      if x is not None and y is not None)
            assert dot < 0, 'the live test must exercise an opposing downstream gradient'
        m.output_gradient_ratio = .5
        m.reconstruction_loss_tolerance = 1e-8
        m._backward_training_loss(reconstruction + auxiliary,
                                  {'reconstruction': reconstruction, 'output': auxiliary}, optimizer)
        for p, expected in zip(output, q[len(source):]):
            if expected is None:
                assert p.grad is None
            else:
                torch.testing.assert_close(p.grad, expected)
        if detached:
            for p, expected in zip(source, r[:len(source)]):
                if expected is not None:
                    torch.testing.assert_close(p.grad, expected)
        else:
            for p, reference in zip(source, r[:len(source)]):
                if reference is None or not reference.square().sum():
                    continue
                downstream = p.grad - reference
                assert (downstream * reference).sum() >= -1e-10
    finally:
        m.End()
        m.symbolSpace.soft_reset()
        torch._dynamo.reset()
