from pathlib import Path
import hashlib,json
root=Path('/Users/arogers/github/WikiOracle/basicmodel');work=Path('/tmp/full-spec-fast-fixture-worktree')
work.mkdir(exist_ok=False);(work/'test').mkdir()
for name in ('bin','data','.venv'): (work/name).symlink_to(root/name,target_is_directory=True)
p=root/'test/test_output_path_supervised.py';s=p.read_text()
a=s.index('def _native_answer_model(');b=s.index('\n\n@pytest.mark.parametrize',a)
part=s[a:b]
part=part.replace('def _native_answer_model(tmp_path, output_loop):','def _native_answer_model(tmp_path, output_loop, *, concept_width=264):')
part=part.replace('Real aligned 136-wide peers and 1032-wide concepts, bounded storage.', 'Distinct concept/percept widths; production width is an explicit slow case.')
part=part.replace('    src = (_DATA', '    if concept_width <= 136:\n        raise ValueError("native fixture requires concepts wider than percepts")\n    src = (_DATA',1)
part=part.replace('f"<{tag}>1032</{tag}>"','f"<{tag}>{concept_width}</{tag}>"')
part=part.replace('"<nInputDim>1032</nInputDim>"','f"<nInputDim>{concept_width}</nInputDim>"')
part=part.replace('== 1032','== concept_width')
s=s[:a]+part+s[b:]
(work/'test/test_output_path_supervised.py').write_text(s)
(work/'base-manifest.json').write_text(json.dumps({'test/test_output_path_supervised.py':hashlib.sha256(p.read_bytes()).hexdigest()},indent=2)+'\n')
Path('/tmp/full-spec-native-fixture-helper.txt').write_text(part)
