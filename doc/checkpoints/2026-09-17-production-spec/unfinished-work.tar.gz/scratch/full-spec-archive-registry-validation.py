"""Archive registry reviewer probes and completed affected runs once."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess

root=Path('/Users/arogers/github/WikiOracle/basicmodel')
folder='doc/benchmarks/2026-09-16-checked-query-data'
target=root/folder
assert not target.exists()
sources={
    'declarations-red.log':'full-spec-query-registry-declarations-red.log',
    'executors-red.log':'full-spec-query-executors-red.log',
    'contract-boundaries-red.log':'full-spec-query-contract-boundaries-red.log',
    'loader-red.log':'full-spec-query-loader-red.log',
    'copy-red.log':'full-spec-query-copy-red.log',
    'native-ids-red.log':'full-spec-query-native-ids-red.log',
    'native-id-selection-red.log':'full-spec-query-native-id-selection-red.log',
    'native-id-type-red.log':'full-spec-query-native-id-type-red.log',
    'grammatical-vp-red.log':'full-spec-grammatical-vp-red-v2.log',
    'vp-boundaries-red.log':'full-spec-query-vp-boundaries-red-v2.log',
    'owner-width-red.log':'full-spec-query-owner-width-red.log',
    'focused-green.log':'full-spec-registry-repository-focused-v1.log',
    'affected-green.log':'full-spec-registry-repository-affected-v1.log',
    'final-affected-green.log':'full-spec-registry-repository-final-affected-v2.log',
}
for file in sources.values():
    assert Path('/tmp',file).is_file(),file
assert '353 passed, 5 skipped' in Path('/tmp/full-spec-registry-repository-affected-v1.log').read_text()
assert '138 passed, 1 skipped' in Path('/tmp/full-spec-registry-repository-final-affected-v2.log').read_text()
frozen=json.loads(Path('/tmp/full-spec-registry-validation-frozen.json').read_text())
assert len(frozen)==579
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in frozen.items())
target.mkdir(parents=True)
owned=set(Path('/tmp/full-spec-registry-owned-paths.txt').read_text().splitlines())
for name,source in sources.items():
    shutil.copyfile(Path('/tmp',source),target/name)
    owned.add(folder+'/'+name)
shutil.copyfile('/tmp/full-spec-registry-worktree/base-manifest.json',target/'candidate-base-manifest.json')
owned.add(folder+'/candidate-base-manifest.json')
def validation(prefix):
    path=prefix+'2026-09-16-checked-query-data/'
    return '''The 53 new reviewer cases cover declarations, effects, loader/copy behavior,
native leaf identities, shared VP/checkpoint identity and width/occurrence bounds.
The initial focused run passed 57 tests; the 36-file affected run passed
353 tests with five skips in 366.32 seconds, including output, reconstruction
and compiled word paths. After the final direct-call width guard, 18 affected
files passed 138 tests with one skip in 13.31 seconds. Each managed run exited
zero. The background full suite is running with all 579
runtime/test/configuration files frozen.

'''+f'[Initial focused]({path}focused-green.log),\n[affected]({path}affected-green.log),\n[final affected]({path}final-affected-green.log),\n[declaration red]({path}declarations-red.log),\n[VP red]({path}grammatical-vp-red.log),\n[width red]({path}owner-width-red.log).'

path=root/'doc/QueryContracts.md'
text=path.read_text()
old='''Record actual repository validation after installation. Original declaration
probes and executor/limit/loader/copy/native-identity regressions failed before
their corresponding fixes; temporary candidate results are preparation only.'''
assert old in text
path.write_text(text.replace(old,validation('benchmarks/'),1))
path=root/'doc/plans/2026-09-15-next-sentence-as-the-production-objective.md'
text=path.read_text()
old='''Repository validation is pending. The temporary candidate passed 304 affected
cases with one skip, including native VP checkpoint identity, and previously
passed 98 output/reconstruction/compiled cases with four skips. The new
reviewer probes failed before their corresponding changes. These preparation
runs do not replace the required repository full suite.'''
assert old in text
path.write_text(text.replace(old,validation('../benchmarks/'),1))
Path('/tmp/full-spec-registry-owned-paths.txt').write_text('\n'.join(sorted(owned))+'\n')
Path('/tmp/full-spec-registry-commit-message.txt').write_text('''Check grammatical query contracts and bind native VP identities

Validate grammar declarations and provide checked executors for every supported boundary query, including full-description what(Q). Preserve canonical NP1/VP/NP2 roles, absent/open operands, mode, scope and evidence; compose/query aliases and converse forms share one native conceptual VP.

Keep candidate formation read-only and derive execution from the completed middle VP. Reject unsupported domains, foreign widths and unavailable occurrences before effects. Preserve native OBJECT/WORD IDs on captured leaf programs and keep full prediction reads separate from pending external observations.

Fix compact grammar expansion splitting query/anchor strings into characters. Use existing conceptual payload and checkpoint owners, with no new embedding table, planner store or learned parameter. Normal linguistic dispatch, phase control and the ordinary controller remain subsequent integration work; contracts and gradient boundaries are documented.

Validation: 53 new reviewer cases; 353 affected tests with five skips, followed by 138 final affected tests with one skip after the width guard. FULL_SUITE_PENDING

Co-Authored-By: Claude Fable 5.1 <noreply@anthropic.com>
''')
print('Archived',len(sources),'probe/affected logs; whitelist contains',len(owned),'paths.')
