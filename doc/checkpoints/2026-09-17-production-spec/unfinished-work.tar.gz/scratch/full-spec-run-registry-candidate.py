"""Validate the temporary registry while the taxonomy repository stays frozen."""
from pathlib import Path
import hashlib
import importlib
import json
import sys

root = Path('/tmp/full-spec-registry-worktree').resolve()
manifest = json.loads((root/'validation-manifest.json').read_text())
modules = {name: importlib.import_module(name) for name in ('Layers', 'Queries', 'Language', 'reasoning', 'Understanding', 'Models')}
for name, module in modules.items():
    assert Path(module.__file__).resolve() == root/'bin'/(name+'.py'), (name, module.__file__)
    print('CANDIDATE', name, module.__file__, flush=True)
for name, digest in manifest.items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest() == digest, name

class OwnershipCheck:
    def pytest_runtest_setup(self, item):
        for name, module in modules.items():
            assert sys.modules[name] is module, name

import pytest
status = pytest.main(sys.argv[1:], plugins=[OwnershipCheck()])
for name, digest in manifest.items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest() == digest, name
raise SystemExit(status)
