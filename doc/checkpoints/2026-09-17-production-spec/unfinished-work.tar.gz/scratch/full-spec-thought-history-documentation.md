# Ordinary thought history and episode credit

Draft implementation reference. Repository installation and validation are
pending the checked-query commit cycle. These APIs supply the history and
credit foundation; the normal learned boundary controller remains separate work.

## One owner and replayable contexts

`SymbolSpace.what_memory` remains the single interaction-memory owner.
`WhatInteractionMemory` stores ordinary `ThoughtRecord` values and transitions
in its existing per-row chronological deque. It also accepts an earlier,
balanced legacy `LTMSlot` prefix. Ordinary and legacy records cannot interleave;
legacy append/begin APIs reject ordinary history instead of resetting its credit.
[Memory owner](@@Layers.py:WhatInteractionMemory@@),
[legacy guard](@@Layers.py:WhatInteractionMemory.begin_what_episode@@).

A record retains a stable occurrence ID, root episode, kind, execution level,
complete conceptual meaning when present, operation, actual charged work,
pressure, support degrees, evidence kind, sources, semantic delta and forced
termination reason. A known supported result must retain its proposition.
Meaning includes all occupied NP1/VP/NP2 roles, references, mode, polarity,
bindings and semantic scope. Addresses remain metadata, not numerical features.
[Record](@@Thoughts.py:ThoughtRecord@@).

`replay_thoughts` reconstructs the current and suspended contexts from this
history. Its `ThoughtState` and `ThoughtContextView` are derived values, not
an independent planner stack or semantic store. Replay retains each context's
initiating/current meaning and returned child results. It rejects missing root
episodes, skipped levels, underflow, non-LIFO return, changed conceptual width,
overlapping episodes and budget/pressure inconsistencies.
[Replay](@@Thoughts.py:replay_thoughts@@).

| Event | Effect |
|---|---|
| `begin` | Record an interrogative root once at level 0 |
| `thought` | Refine/continue at the same level |
| `descend` | Suspend the exact parent context and enter level `d+1` |
| `return` | Resume level `d-1`, retaining the child's result/support |
| `cutoff` | Freeze the current level and stop ordinary work |
| `finish` | Explicitly conclude at level 0 |

Returning and immediately descending again creates a fresh child, even with
no intervening parent thought. Merely recording another question or following
a semantic occurrence reference does not change the execution level. Root
level is both the start and a valid continuing context; it does not imply finish.
[Event API](@@Thoughts.py:LevelledThoughtHistory._thought_event@@).

## Shared budget and capacity

Only root begin declares the work budget. Every ordinary event consumes a
positive declared cost, including same-level work, descent, return and finish.
Pressure is cumulative charged work divided by `max(1, budget)`; children and
returns cannot reset it. An exhausted budget records cutoff automatically.
After cutoff at `d_cut`, only zero-cost forced returns and one root finish
are permitted, in a separately counted drain bounded by `d_cut + 1`.
Finishing or exhausting work supplies no truth by itself.
[Budget enforcement](@@Thoughts.py:replay_thoughts@@),
[event accounting](@@Thoughts.py:LevelledThoughtHistory._thought_event@@).

This history API accounts for the caller's declared cost. The later controller
must include actual executor reads/expansions, intersect local call limits with
remaining work, and record the selected result. Supplying a cost field alone
does not establish end-to-end tool accounting or learned termination.

Capacity reserves the possible cutoff, pending LIFO returns and root finish.
Trimming can evict only whole closed prefixes with no retained semantic
references into them. Active contexts, their required records and drain reserve
cannot be silently evicted. Insufficient capacity raises an explicit overflow.
[Retention](@@Thoughts.py:LevelledThoughtHistory._retain_thought_history@@).

## Occurrences and continuous credit

`('thought', namespace, id)` addresses an existing record in the same owner.
IDs are monotonically allocated and are not reused after reset; row checks
prevent another row from resolving them. A bounded read returns the complete
meaning and actual number of records inspected, counting legacy/noncontent
records too. Missing, wrong-namespace and content-free transition references
fail explicitly. Query formation never creates a record to satisfy a reference.
[Reference](@@Thoughts.py:LevelledThoughtHistory.thought_reference@@),
[read](@@Thoughts.py:LevelledThoughtHistory.resolve_thought@@),
[query adapter](@@Queries.py:_occurrence_description@@).

Under `detach_mode="episode"`, committed meanings own cloned tensors while
preserving the current autograd path. A complete-description query can read
that live value through the same memory owner, so a continuous result may
depend on earlier episode computations. Hard retrieval and choice remain
nondifferentiable. Under `slot` detachment, records are detached immediately.
After explicit finish and the caller's optimizer step, `end_what_episode`
detaches the retained episode, including legacy prompt and trace tensors.
An unfinished ordinary episode cannot release its credit through that API.
[Append](@@Thoughts.py:LevelledThoughtHistory._store_thought_events@@),
[credit end](@@Layers.py:WhatInteractionMemory.end_what_episode@@).

The API adds no learned parameter or trained objective. One optimizer step,
hard-choice policy credit and the aggregate downstream gradient balance still
require the normal controller/training integration described in
[GradientFlow](GradientFlow.md). A live path test does not establish useful
learned reasoning.

## Checkpoint migration

The existing structural checkpoint sidecar includes versioned `what_history`
when this owner has records. It saves detached ordinary meanings and a
detached legacy prefix; snapshotting does not detach the live training owner.
Restore validates all rows before replacing memory, including namespace,
monotonic unique IDs, counters, replay, pressure, capacity and drain reserve.
Prior computations remain detached after restore. An active ordinary episode
opens fresh credit for newly computed values without replenishing its budget.
[Snapshot](@@Thoughts.py:LevelledThoughtHistory.thought_extras@@),
[restore](@@Thoughts.py:LevelledThoughtHistory.load_thought_extras@@),
[model sidecar](@@Models.py:BaseModel._collect_structural_extras@@).

Checkpoints lacking `what_history` retain the existing empty memory behavior.
A checkpoint carrying it requires the existing SymbolSpace memory owner;
restore does not create an alternative owner. Legacy closure pressure and
pending inputs are preserved, and malformed legacy return sequences fail.

## Validation and remaining integration

Record actual repository validation after installation. Reviewer probes cover
level replay, sibling isolation, immutable inputs, shared work/drain limits,
capacity, references, real model save/load, restored live credit, legacy
compatibility, prompt/trace detachment and complete live query operands.

The normal model still needs its learned ordinary controller, semantic chooser
features, phase guard, linguistic selected-derivation adapter, causal answer
construction, actual executor cost accounting and residual-based policy credit.
This API does not replace the old production loop or claim learned utility.
Arbitrary nested grammatical retention and output linkage remain separate
gates. The separate two-truths specification is reserved for the next session.
