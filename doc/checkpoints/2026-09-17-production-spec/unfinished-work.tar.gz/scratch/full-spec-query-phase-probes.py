"""Checked queries cannot run inside sentence paths or cross batch-row boundaries."""
from dataclasses import replace
from types import SimpleNamespace

import pytest
import torch

from Models import BasicModel
from Output import AnswerDerivation
from Queries import BUILTIN_QUERIES, QueryContext
from Understanding import AnswerProgram, InputReconstruction, Understanding
from What import What
from reasoning import TruthGroundedReasoner
from test_cs_symbol_table import _cs


def _fixture():
    model = BasicModel()
    model.spaces = []
    object.__setattr__(model, 'conceptualSpace', _cs())
    object.__setattr__(model, 'perceptualSpace', SimpleNamespace())
    model.reconstruct_in_loop = False
    calls = []
    signature = replace(BUILTIN_QUERIES['isEqual'], executor=lambda *args:
                        calls.append(args) or {'support_true': 1.0, 'support_false': 0.0})
    reasoner = TruthGroundedReasoner(model=model)

    def invoke(row=0):
        return signature.invoke(QueryContext(reasoner, row=row), torch.ones(8), torch.ones(8))

    return model, invoke, calls


def _understanding():
    roles = torch.zeros(3, 8)
    roles[0] = 1
    program = AnswerProgram(
        rows=torch.tensor([0]), word_rows=torch.tensor([0]),
        activations=torch.ones(1), leaves=roles[:1],
        actions=torch.tensor([[0, -1, 0]]), targets=torch.tensor([-1]),
        end_state=roles, concept_ids=torch.tensor([1]))
    return Understanding(conceptual_state=roles[None], answer_program=(program,))


@pytest.mark.parametrize('path', ['compose', 'reconstruct', 'generate'])
def test_checked_executor_is_masked_throughout_each_sentence_path(monkeypatch, path):
    model, invoke, calls = _fixture()
    understanding = _understanding()

    def injected_query(*args, **kwargs):
        invoke()
        raise AssertionError('registered executor escaped the sentence-phase mask')

    if path == 'compose':
        monkeypatch.setattr(model, '_forward_per_stage', injected_query)
        call = lambda: model.forward(torch.ones(1, 1, 8))
    elif path == 'reconstruct':
        value = torch.ones(1, 1, 8)
        owned = InputReconstruction(value, value, None, None, None, None)
        understanding = replace(understanding, input_reconstruction=owned)
        monkeypatch.setattr(model, '_reverse_event_loss', injected_query)
        call = lambda: model.reverseReconstruct(understanding, target=value)
    else:
        monkeypatch.setattr(model, '_materialize_answer_idea', injected_query)
        prepared = AnswerDerivation(None, program=understanding.answer_program)
        call = lambda: model.reverseOutput(understanding, prepared)
    with pytest.raises(RuntimeError, match='query|queries|boundary'):
        call()
    assert calls == []


def test_resolution_opens_only_completed_rows_and_closes_after_return(monkeypatch):
    model, invoke, calls = _fixture()
    one = _understanding()
    understanding = replace(one, conceptual_state=one.conceptual_state.expand(2, -1, -1),
                            answer_program=(one.answer_program[0], None))
    marker = object()

    def resolve(*args):
        assert invoke(0)['support_true'] == 1
        with pytest.raises(RuntimeError, match='row|boundary'):
            invoke(1)
        return marker

    monkeypatch.setattr(model, '_resolve_answer', resolve)
    assert model.resolveAnswer(understanding, (What.inference(0), What.inference(1))) is marker
    with pytest.raises(RuntimeError, match='boundary'):
        invoke(0)
    assert len(calls) == 1


def test_resolution_exception_cannot_leave_query_permission_open(monkeypatch):
    model, invoke, calls = _fixture()

    def resolve(*args):
        invoke()
        raise ValueError('injected resolver failure')

    monkeypatch.setattr(model, '_resolve_answer', resolve)
    with pytest.raises(ValueError, match='injected resolver'):
        model.resolveAnswer(_understanding(), What.inference(0))
    with pytest.raises(RuntimeError, match='boundary'):
        invoke()
    assert len(calls) == 1


def test_nested_resolution_cannot_override_a_sentence_phase(monkeypatch):
    model, invoke, calls = _fixture()
    monkeypatch.setattr(model, '_resolve_answer', lambda *args: invoke())
    monkeypatch.setattr(model, '_forward_per_stage', lambda *args:
                        model.resolveAnswer(_understanding(), What.inference(0)))
    with pytest.raises(RuntimeError, match='sentence|boundary|compose'):
        model.forward(torch.ones(1, 1, 8))
    assert calls == []


def test_tied_input_reconstruction_must_complete_before_query_permission(monkeypatch):
    model, invoke, calls = _fixture()
    model.reconstruct_in_loop = True
    monkeypatch.setattr(model, '_resolve_answer', lambda *args: invoke())
    with pytest.raises(RuntimeError, match='reconstruction'):
        model.resolveAnswer(_understanding(), What.inference(0))
    assert calls == []
