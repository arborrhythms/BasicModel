outputs['doc/QueryPhases.md']=render(Path('/tmp/full-spec-query-phase-documentation.md').read_text())
sections={
'doc/Architecture.md': '''
### Checked query execution phases

`resolveAnswer()` opens only completed program rows after enabled input
reconstruction. Input execution, reconstruction and output realization mask
queries; checked dispatch validates permission before operand reads. Compiled
tracing rejects queries without mutating a host phase flag in the graph.
Held understandings retain their own readiness. No tensor, learned parameter,
memory owner or forward-result slot is added.
[Boundary](@@Models.py:BasicModel.resolveAnswer@@),
[phase mask](@@Models.py:_sentence_query_mask@@),
[preparation guard](@@Queries.py:GrammaticalQueryRegistry.execute@@).
See [Query phases](QueryPhases.md) for validation and remaining integration.
''',
'doc/Language.md': '''
### Representation and query execution permission

Grammatical formation stays pure inside a sentence. A selected completed
question can execute only in an allowed answer-boundary row. Permission is
checked before description resolution or the registered executor. Nested
sentence work masks the boundary until it returns, including supplied input
executors and compiled input calls.
[Dispatch](@@Queries.py:GrammaticalQueryRegistry.execute@@),
[input wrapper](@@Models.py:BasicModel._execute_input_sentence@@).
[Query phases](QueryPhases.md) records the runtime contract; deriving linguistic
VP meaning and replacing the normal legacy controller remain separate gates.
''',
'doc/GradientFlow.md': '''
### Query phase permission

The host sentence mask and completed-row boundary guard add no parameter,
objective or tensor detachment. They constrain when a checked query can read
or execute. Current-step prepared meanings retain their existing continuous
gradient path; hard choice still requires the controller's policy credit.
Compiled numerical calls leave phase bookkeeping to the host wrapper, and
tracing a query fails explicitly. The real fullgraph regression checks forward,
backward and reuse across word counts.
[Mask](@@Models.py:_sentence_query_mask@@),
[boundary](@@Models.py:BasicModel.resolveAnswer@@).
See [Query phases](QueryPhases.md) for the validation evidence and limits.
''',
'doc/Training.md': '''
### Sentence and reasoning permission

Enabled tied input reconstruction must already belong to the `Understanding`
before `resolveAnswer()` opens completed rows for reasoning. Supplied executors
in `understand()`/`what()` run under the same input sentence mask; output
realization cannot start a query. Permissions restore on error and do not
change optimizer or gradient-balancing behavior.
[Input execution](@@Models.py:BasicModel._execute_input_sentence@@),
[resolution](@@Models.py:BasicModel.resolveAnswer@@),
[output](@@Models.py:BasicModel.reverseOutput@@).
[Query phases](QueryPhases.md) contains phase and compilation checks.
''',
'doc/Params.md': '''
### Query phase state

Query permission adds no learned or checkpointed parameter and no new setting.
The model initializes transient host flags before compilation; a boundary
temporarily identifies completed rows, while sentence work disables execution.
No semantic feature contains these administrative flags.
[Initialization](@@Models.py:BasicModel.__init__@@),
[boundary scope](@@Models.py:BasicModel._query_boundary_scope@@).
See [Query phases](QueryPhases.md).
''',
'doc/STM.md': '''
### Completed-row query permission

Boundary readiness comes from the owned sentence programs in the requested
`Understanding`, not the latest mutable STM staging. Missing/padded rows and
program-less dense compatibility values cannot enable checked queries.
Nested boundaries can narrow an existing row permission but cannot widen it.
Sentence execution masks even a previously opened parent boundary.
[Readiness](@@Models.py:BasicModel._completed_query_rows@@),
[scope](@@Models.py:BasicModel._query_boundary_scope@@).
See [Query phases](QueryPhases.md); the ordinary controller still needs to
integrate completed internal-thought boundaries with this permission.
''',
'doc/QueryContracts.md': '''
## Model execution permission

When used by BasicModel, both direct signature calls and grammatical-VP
dispatch require an open, completed row boundary before any operand read.
Sentence processing and compiled tracing reject query execution. Explicit
standalone evidence readers retain their existing API.
[Direct guard](@@Queries.py:_require_query_boundary@@),
[boundary](@@Models.py:BasicModel.resolveAnswer@@).
[Query phases](QueryPhases.md) documents exception handling, nested rows,
compiled execution and the remaining controller integration.
''',
'doc/ThoughtHistory.md': '''
## Sentence-runtime integration status

The input/answer phase guard now enforces completed-row query permission;
ordinary internal-thought controller integration remains open.
[Query phases](QueryPhases.md) records the implemented guard and its limits.
History replay, credit lifetime and declared work accounting are unchanged.
'''}
for name,section in sections.items():
    outputs[name]+=render(section)
outputs['doc/plans/2026-09-15-next-sentence-as-the-production-objective.md']+=render('''
## 19. Sentence masks and completed-row query permission (in progress)

`resolveAnswer()` requires its owned tied reconstruction when enabled and opens
only nonempty captured-program rows. Missing/padded rows cannot execute a query;
held understandings remain usable after another forward. Permission restores
after success or failure, and nested resolution can only narrow parent rows.
[Boundary](@@Models.py:BasicModel.resolveAnswer@@),
[scope](@@Models.py:BasicModel._query_boundary_scope@@).

All input execution entries, input reconstruction and output realization mask
query execution. Checked calls guard before occurrence reads or effects; legacy
query entries also reject calls inside sentence work. Compiled tracing rejects
queries directly, while the host input wrapper covers numerical compiled calls
and their eager islands. The captured graph does not mutate phase flags, and
the 21-value forward contract is unchanged.
[Mask](@@Models.py:_sentence_query_mask@@),
[execution wrapper](@@Models.py:BasicModel._execute_input_sentence@@),
[query preparation](@@Queries.py:GrammaticalQueryRegistry.execute@@).

Repository validation is pending. Reviewer probes reproduced escape through
sentence paths, incomplete rows, operand reads, compiled-state entry and supplied
executors. A real compiled-forward probe also exposed a leaked phase flag; the
host/tracing split addresses that compiler interaction.
[Query phases](../QueryPhases.md) documents the checks and limits.

These guards add no parameter, loss or gradient detachment. The canonical
linguistic adapter, completed internal-thought boundaries, normal learned
controller, raw-text fallback retirement, actual shared executor work, nested
retention, anticipation isolation, residual policy credit and learned utility
remain open. The separate two-truths spec remains next-session work.
''',prefix='../../bin/')
