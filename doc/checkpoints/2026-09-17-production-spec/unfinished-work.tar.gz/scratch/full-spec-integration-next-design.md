# Next integration design notes (not an implementation claim)

Baseline inspected: primary `639034c`; history/phase/nested candidates remain
isolated. The September 17 user instruction prohibits removal of unused
reasoning methods before explicit review and approval. Keep their public APIs,
even when replacing their use in the normal controller. The isolated retirement
candidate is HELD, and its installer refuses to execute.

## Meaning must precede observation

The ordinary pending/packed/eager writers currently observe physical STM at
Models.py:12777,12837,21555. AnswerProgram capture is later at 12073. A semantic
adapter added only to Understanding would miss predictor targets and durable
observations. Reuse owned selected actions and live signed leaves before each
normal writer; preserve the 21-value compiled tuple and chronological masks.

A selected-operation interpreter needs the owning LanguageSpace's immutable
local rule descriptors (captured at construction), not later TheGrammar.
PartLayer/WholeLayer discard one operand numerically (Language.py:4228,4296), so
recovering semantic arguments from the final root is impossible in general.
Replaying the owned actions must retain both operands and native IDs. Preserved
three-slot relative forms need an explicit selected lexical VP binding too;
not every completed structure has a final binary relation fold.

Use transient derivation views only. Commit compound constituents through the
existing TernaryTruthStore occurrence owner with ordered role references,
independent evidence and bounded atomic capacity checks. Do not add a persistent
semantic AST. A child description stored to preserve a report is not an accepted
fact. Native leaf references remain distinct from occurrence references required
by description-valued queries. The nested retention candidate supplies the
reference lifetime contracts, including binding/scope occurrences.

## Lexical and grammatical faces

Queries.GrammaticalQueryRegistry already supplies relation/domain native VPs
and canonical permutations. Linguistic formation must preserve actual signed
operand values, not re-read unit dictionary atoms for captured leaf references.
The current global surface anchor map (Language.py:1092, Spaces.py:17605) is only
one operator per surface, and simple word anchors do not establish multiword
paraphrase recognition or polysemy. No regex question dispatcher is acceptable.
Any extension must make selected lexical/compose senses authoritative and retain
surface order for input reconstruction. In particular, not every `has` is part.
Pure question representation must replace the numerical query-flag dispatch
(Language.py:4419), while leaving the user-protected unused reasoning methods
available for review. Query mode does not grant execution permission.

## Controller and actual budget

Replace normal raw-text/parity selection using completed ConceptualMeaning and
the prepared one-owner ordinary history. Keep mandatory root/active/current and
candidate NP/VP/NP roles outside optional top-k. Native IDs are metadata.
Separate retrieval pool R, attended K, payload widths and STM depth. Existing
GlobalAttention.forward detaches and truncates width; using it unchanged would
lose the specified semantic credit. Its cosine primitive can preserve gradients.

A root history budget must bound work *before* each selected executor read, not
just record the count afterwards. Passing the same remaining limit separately
to nodes, records and expansions permits an overspend. A shared ephemeral meter
can debit per operation/read/expansion, with the history recording actual total
cost once; local limits may only tighten it. The meter is execution accounting,
not a second semantic or planner store. The history cutoff already bounds drain.
All executor and operand-resolution paths need to use that same allowance.

Returned child content/support/provenance must enter subsequent choice and the
actual resolved conceptual answer. Merely adding a trace or an unused metadata
field is insufficient. Keep question proposition and signed evidence recoverable,
even for a yes/no realization. Do not borrow the input's surface witness to
realize a different answer. Hard tool choices need policy credit; continuous
meaning paths remain live to the single step under the existing aggregate
reconstruction budget.

## Anticipation and catalog stages

Estimates need existing-owner occurrence IDs and links to their actual later
observations. Only external observations enter the corpus sequence. A prior
view must exclude arriving dictionaries, staging, other rows and unseen packed
sentences as well as final target tensors. Credit from observed residuals needs
its own scalar reward/work penalty/baseline and parameter-version boundary.

Generation ownership must cover both LanguageSpace's output loop catalog and
LanguageLayer's ordinary unreduce registry. Deep-copying only the former would
leave the no-output-loop path sharing transforms. Preserve independent optimizer
ownership and rule-meaning checkpoint migration, including live input gradients
under the aggregate reconstruction-priority budget.

These notes do not close linguistic, learned-controller, causal-utility,
anticipation or catalog gates. Held-out null utility is a valid measured result,
not grounds to claim learned questioning helps.


## September 17 arbitrary-symbol clarification

The user explicitly requires mathematical syntax to test learned grammar over
arbitrary symbols. Do not register an arithmetic evaluator or convert numeral
surfaces/native IDs/row indices to numeric operands. Preserve exact helpers as
dataset/evaluation utilities only; no solver intermediates or `numeral_code`
may enter learner context. The static audit and proposed poison/renumbering/
renamed-vocabulary gates are in `/tmp/full-spec-arbitrary-symbol-audit.md`.
The history documentation installer will add the contract to the integrated
spec, SymbolFirewall and GradientFlow, with a linked audit. Its runtime gates
remain pending; the static scan is not proof of every execution path. No unused
reasoning methods are removed without the user's review.

The requested fixed-capacity evaluation is in
`/tmp/full-spec-fixed-capacity-future-work.md`. The resource finalizer will
publish it as `doc/plans/2026-09-17-bounded-fixture-reuse.md` and index it in
Testing. Preserve the finite memory/deadline policy; measure constructor,
reset and recompilation separately before adding a reusable fixture pool.
