"""Install this migration's owned documentation once, after candidate application."""
from pathlib import Path
import json
import re

root = Path('/Users/arogers/github/WikiOracle/basicmodel')
maps = json.loads(Path('/tmp/full-spec-query-line-maps.json').read_text())
anchors = json.loads(Path('/tmp/full-spec-query-candidate/source-anchors.json').read_text())
receipt = Path('/tmp/full-spec-query-doc-remap-applied.json')
assert not receipt.exists(), 'Source links were already remapped'
assert not (root/'doc/ExistenceEvidence.md').exists()
documents = ['doc/Architecture.md','doc/GradientFlow.md','doc/Language.md',
             'doc/Params.md','doc/Training.md','doc/STM.md',
             'doc/plans/2026-09-15-next-sentence-as-the-production-objective.md']
outputs = {}
changes = []

def remap(match):
    label, target, filename, line = match.groups()
    mapping = maps.get(filename, {}).get(line)
    if mapping is None:
        assert filename not in maps, (filename,line)
        return match.group(0)
    new = str(mapping['line'])
    label = label.replace(filename+':'+line, filename+':'+new)
    changes.append({'file':filename,'old':int(line),**mapping})
    return '['+label+']('+target+'#L'+new+')'

pattern = re.compile(r'\[([^\]]+)\]\(([^)]+/(Layers\.py|Models\.py|reasoning\.py|thinking\.py))#L(\d+)\)')
for name in documents:
    text = (root/name).read_text()
    if '/plans/' in name:
        # Named historical review sections retain their original baseline.
        chunks = re.split(r'(?=^## |^### )', text, flags=re.M)
        protected = False
        rebuilt = []
        for chunk in chunks:
            if chunk.startswith('## '):
                protected = chunk.startswith(('## 6.', '## 7.', '## 11.'))
            if chunk.startswith('### 11.6 '):
                protected = False
            rebuilt.append(chunk if protected else pattern.sub(remap,chunk))
        text=''.join(rebuilt)
    else:
        text=pattern.sub(remap,text)
    outputs[name]=text

def render(text, prefix='../bin/'):
    def link(m):
        filename, definition=m.group(1).split(':',1)
        return prefix+filename+'#L'+str(anchors[m.group(1)])
    return re.sub(r'@@([^@]+)@@',link,text)

description = Path('/tmp/full-spec-query-documentation.md').read_text()
description = description.replace(
    'Draft for the next bounded migration. Apply after the prepared-answer commit\ncycle, refresh source anchors, and record repository validation before marking\nthis implementation verified.',
    'Implementation reference, September 16. Focused probes pass; affected-file\nand full-suite validation are recorded in integrated specification §15.')
outputs['doc/ExistenceEvidence.md']=render(description)
stm=outputs['doc/STM.md']
a=stm.index('## 10. LTM as the chain of STM end-states')
b=stm.index('## 11. Inter-sentence prediction',a)
stm=stm[:a]+render(Path('/tmp/full-spec-query-doc-stm10.md').read_text())+stm[b:]
outputs['doc/STM.md']=stm

architecture=render('''
### Full-description existence evidence

Boundary `Exist` evaluation checks accepted LTM facts against all occupied
NP1/VP/NP2 roles, bindings, scope and constituent references. It retains
positive and negative support plus occurrence provenance independently;
missing evidence is unknown. Observations, questions, estimates and unverified
legacy records cannot certify their own referents. `ConceptualMeaning` is an
owned value; `TernaryTruthStore` remains the durable evidence owner.
[Lookup](@@reasoning.py:TruthGroundedReasoner.existence_evidence@@),
[value](@@Meaning.py:ConceptualMeaning@@),
[store](@@Layers.py:TernaryTruthStore@@).

The existing checkpoint sidecar now retains semantic context and source text,
bound to stable occurrence IDs and tensor fingerprints. Required metadata
missing on restore makes the corresponding evidence unavailable. This
foundation does not complete grammatical VP dispatch, conceptual-taxonomy
queries or levelled thought history. See [Existence evidence](ExistenceEvidence.md)
for the exact migration and gradient boundaries.
[Restore checks](@@Layers.py:TernaryTruthStore.load_semantic_extras@@).

''')
outputs['doc/Architecture.md']=outputs['doc/Architecture.md'].replace('\n## Sigma and Pi Layers\n','\n'+architecture+'## Sigma and Pi Layers\n',1)
outputs['doc/GradientFlow.md'] += render('''
## Fact evidence and query values

`ConceptualMeaning` clones retain the current computation's gradient. Durable
fact/observation writes detach it. `Exist` matching, eligibility checks,
thresholds and support aggregation use hard reads and scalar evidence; they
provide no ordinary derivative through selected facts. This migration adds
no learned parameter or loss. Query selection still requires its separately
declared policy credit; storing an estimate does not supply an observation or
a new training target. See [Existence evidence](ExistenceEvidence.md).
[Live value](@@Meaning.py:ConceptualMeaning@@),
[detached write](@@Layers.py:TernaryTruthStore.append_meaning@@),
[hard lookup](@@reasoning.py:TruthGroundedReasoner.existence_evidence@@).
''')
outputs['doc/Training.md'] += render('''
## Existence evidence and observation admission (September 16)

The three forward observation writers retain canonical role presence,
including the depth-two VP, and mark records as observations. Explicit
TruthSet admission can accept a fact; an origin tag or high activation alone
cannot. Internal questions, predictions and unverified legacy relations remain
ineligible for `Exist` fact support. The lookup preserves both signed degrees
and provenance, and adds no gradient objective or trainable parameters.
[Observation adapter](@@Models.py:_append_observed_meaning@@),
[admission](@@Layers.py:TernaryTruthStore.accept_fact@@),
[lookup](@@reasoning.py:TruthGroundedReasoner.existence_evidence@@).

See [Existence evidence](ExistenceEvidence.md) for complete-description matching,
testimony, checkpoint migration and the hard lookup boundary, and
[GradientFlow](GradientFlow.md) for the architecture-wide gradient budget.
''')
outputs['doc/Language.md'] += render('''
## Exist at the reasoning boundary (September 16)

The pure `exist` compose wrapper retains its grammatical role; its forward
operation is an identity ([ExistLayer](../bin/Language.py#L4467)). The reasoner's
`Exist`/`isTrue` evaluation now uses accepted LTM facts for the complete
description, preserving occupied roles, scope, bindings, references and both
support polarities. This does not execute a query during composition.
[Boundary lookup](@@reasoning.py:TruthGroundedReasoner.existence_evidence@@).

The typed VP registry, canonical linguistic/internal query agreement and
conceptual-taxonomy `PartOf` migration remain open. See
[Existence evidence](ExistenceEvidence.md) for the implemented evidence layer
and [the integrated specification](plans/2026-09-15-next-sentence-as-the-production-objective.md#2-one-grammatical-deep-structure-multiple-surface-forms)
for the complete grammatical target.
''')
outputs['doc/Params.md'] += render('''
### Consolidated evidence metadata (September 16)

`ltmConsolidation` now also persists role presence, grammatical mode, polarity,
evidence kind, stable occurrence identity and metadata fingerprints in the
existing truth store. Its structural sidecar retains bindings, scope,
constituent references and source text. This adds no configuration switch,
learned parameter or loss. Legacy conversation rows migrate as unverified;
missing required metadata cannot silently become empty scope.
[Store and migration](@@Layers.py:TernaryTruthStore@@),
[checkpoint sidecar](@@Models.py:BaseModel._collect_structural_extras@@),
[details](ExistenceEvidence.md).
''')

specname=documents[-1]
spec=outputs[specname]
start=spec.index('These are implementation requirements for §10.5\'s query migration.')
end=spec.index('### 2.1 Nested clauses and phrases',start)
spec=spec[:start]+render('''The full-description `Exist` evidence foundation now checks accepted facts
with graded support, conflict and occurrence provenance (§15). Grammatical
VP dispatch and conceptual-taxonomy `PartOf` remain open: the legacy kernel's
`part` still routes `meronomy` and `taxonomy` through the same relation rows.
The existence lookup does not claim to complete those migrations.
[Exist lookup](@@reasoning.py:TruthGroundedReasoner.existence_evidence@@),
[legacy Part routing](@@thinking.py:ThinkingKernel.part@@).

''',prefix='../../bin/')+spec[end:]
spec += render('''
## 15. Complete-description existence evidence (in progress)

`ConceptualMeaning` retains canonical occupied roles, grammatical mode,
polarity, bindings, scope and constituent references. The existing truth
store owns durable facts/observations and their stable occurrence IDs.
`Exist` matches the entire description against assertive facts, keeps
positive/negative degrees separately, reports provenance and incomplete
metadata, and never substitutes concept activation for referent evidence.
The public legacy kernel preserves that evidence through its final result.
[Meaning](@@Meaning.py:ConceptualMeaning@@),
[store](@@Layers.py:TernaryTruthStore@@),
[lookup](@@reasoning.py:TruthGroundedReasoner.existence_evidence@@),
[kernel aggregation](@@thinking.py:ThinkingKernel._frame_interval@@).

All three observation writers share the explicit physical-to-canonical
adapter, retaining depth-two VPs. Explicit TruthSet admission accepts facts;
source tags alone do not. Questions, estimates and unspecified observations
cannot satisfy Exist. Legacy relation writers without a grammatical VP
remain unverified for that lookup. Numeric testimony retains complete
descriptions and source identity; prediction content is not truth testimony.
[Observation write](@@Models.py:_append_observed_meaning@@),
[admission](@@Layers.py:TernaryTruthStore.accept_fact@@),
[testimony](@@thinking.py:ThinkingKernel.incorporate@@).

The existing structural sidecar stores context and source text, bound to the
tensor occurrence by a content fingerprint. Partial semantic checkpoints and
missing, replaced or swapped context are rejected; a tensor-only restore
quarantines evidence whose required metadata is absent. Legacy checkpoints
have an explicit migration. No learned parameters or loss were added; live
meaning clones preserve gradients and durable writes detach them.
[Sidecar](@@Models.py:BaseModel._collect_structural_extras@@),
[restore](@@Layers.py:TernaryTruthStore.load_semantic_extras@@),
[legacy migration](@@Layers.py:TernaryTruthStore._load_from_state_dict@@).

The repository's **51 new probes pass in 3.11 s**. The ten affected existing
files are under validation; the background full-suite gate follows them.
Original and follow-up failing probes were run before their corresponding
fixes. The isolated candidate was checked separately and does not substitute
for the repository gate. See [Existence evidence](../ExistenceEvidence.md)
for contracts, limits and validation artifacts.

This is the evidence foundation. The typed grammatical VP registry,
conceptual-taxonomy PartOf, ordinary levelled controller, nested traversal,
anticipation read isolation, residual policy credit and learned-utility gates
remain open. The September 16 two-truths spec remains reserved for the next
session, as requested.
''',prefix='../../bin/')
outputs[specname]=spec

for name,text in outputs.items():
    assert '@@' not in text,name
    (root/name).write_text(text)
receipt.write_text(json.dumps(changes,indent=2)+'\n')
owned=Path('/tmp/full-spec-query-owned-paths.txt')
paths=set(owned.read_text().splitlines())|set(outputs)
owned.write_text('\n'.join(sorted(paths))+'\n')
print('Updated',len(outputs),'owned documents;',len(changes),'source links remapped once.')
print('Definition fallbacks:',[x for x in changes if x['kind']=='definition'])
