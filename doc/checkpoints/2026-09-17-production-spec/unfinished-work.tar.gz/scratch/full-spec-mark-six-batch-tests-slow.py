"""Apply the final timing-based gates only after the frozen affected run passes."""
from pathlib import Path
import ast
import json
from full_spec_bounded_evidence import verified_run

root = Path('/Users/arogers/github/WikiOracle/basicmodel')
verified_run('/tmp/full-spec-slow-switch-affected-v2', root)
manifest = Path('/tmp/full-spec-test-mode-selections.json')
data = json.loads(manifest.read_text())
selections = {
    'test/test_meronomy_ladder.py': [
        'test_recurring_same_whole_pair_is_proposed_and_admitted_as_a_phrase',
        'test_utility_state_and_predicates_round_trip_a_checkpoint',
    ],
    'test/test_prepared_answer_boundary.py': [
        'test_what_reconstructs_then_resolves_then_realizes',
    ],
}
for relative, names in selections.items():
    path = root / relative
    text = path.read_text()
    nodes = {n.name: n for n in ast.parse(text).body if isinstance(n, ast.FunctionDef)}
    lines = text.splitlines(keepends=True)
    for name in sorted(names, key=lambda name: nodes[name].lineno, reverse=True):
        node = nodes[name]
        assert not any(ast.unparse(d) == 'pytest.mark.slow' for d in node.decorator_list)
        line = min([node.lineno, *[d.lineno for d in node.decorator_list]]) - 1
        lines.insert(line, '@pytest.mark.slow\n')
    path.write_text(''.join(lines))
    data.setdefault(relative, []).extend(names)
assert sum(map(len, data.values())) == 36
manifest.write_text(json.dumps(data, indent=2) + '\n')
path = root / 'doc/Testing.md'
text = path.read_text()
assert 'Thirty-three long-running functions' in text
text = text.replace('Thirty-three long-running functions', 'Thirty-six long-running functions')
text = text.replace('repeated corpus-learning experiments, multi-step Adam checks and production-size\n20M configuration/reconstruction integration checks. Small numerical training, ordinary forward/backward, ownership,',
    'repeated corpus-learning experiments, six-batch phrase/checkpoint training,\n'
    'multi-step Adam checks, full compiled reconstruction-order integration and\n'
    'production-size 20M configuration/reconstruction\n'
    'integration checks. Small numerical training, ordinary forward/backward, ownership,')
path.write_text(text)
path = Path('/tmp/full-spec-finalize-bounded-tests.py')
text = path.read_text()
assert 'Gate 33 long' in text
path.write_text(text.replace('Gate 33 long', 'Gate 36 long'))
print('Marked three verified long integration checks slow; 36 functions total.')
