from pathlib import Path
import ast,hashlib,json,shutil
root=Path('/Users/arogers/github/WikiOracle/basicmodel')
work=Path('/tmp/full-spec-legacy-worktree');work.mkdir(exist_ok=False)
for folder in ('bin','test'):
 (work/folder).mkdir()
for name in ('data','doc','.venv','pytest.ini'):
 (work/name).symlink_to(root/name,target_is_directory=(root/name).is_dir())
remove={
 'bin/reasoning.py': ['TruthGroundedReasoner.legacy_parts','TruthGroundedReasoner.legacy_is_part','TruthGroundedReasoner.legacy_materialize','TruthGroundedReasoner._legacy_creates_cycle','TruthGroundedReasoner._legacy_refuting_direct','NeuralToolUser.run_legacy_world','NeuralToolUser._generate_chain'],
 'test/test_truth_grounded_reasoning.py': ['TestLegacyChain','TestLegacyMaterialize','TestLegacyPartialOrder','TestLegacyVectorProposalTools','TestLegacyConsolidation.test_chain_to_target_is_shared_loop','TestGrammarOps.test_parts_is_inverse_of_wholes'],
 'test/test_existence_ingestion.py': ['test_legacy_materialized_relation_without_a_vp_stays_unverified'],
}
base={}; removed_tests=[]
for name,targets in remove.items():
 p=root/name;s=p.read_text();tree=ast.parse(s);found={}
 def visit(node,path=()):
  if isinstance(node,(ast.FunctionDef,ast.ClassDef)):
   path=path+(node.name,);found['.'.join(path)]=node
  for child in ast.iter_child_nodes(node):visit(child,path)
 visit(tree)
 lines=s.splitlines(keepends=True)
 for key in sorted(targets,key=lambda x:found[x].lineno,reverse=True):
  node=found[key]
  first=min([node.lineno]+[d.lineno for d in node.decorator_list])-1
  del lines[first:node.end_lineno]
  if name.startswith('test/'):
   removed_tests.extend(name+'::'+f.name for f in ast.walk(node) if isinstance(f,ast.FunctionDef) and f.name.startswith('test_'))
 new=''.join(lines)
 if name=='bin/reasoning.py':
  new=new.replace('"""Soft-propose / hard-verify policy around ``TruthGroundedReasoner``."""',
   '"""Checked query evidence and the separately gated prediction blend.\n\n    The retired vector-proposal/materialization loop has no execution entry.\n    The prediction blend and its opt-in training callers remain until their\n    structured-controller migration.\n    """')
  new=new.replace('# -- The NeuralToolUser: the recurrent policy over the hard tools (Phase B) ---',
                  '# -- Public query result and the separately gated prediction adapter -------')
 ast.parse(new)
 (work/name).write_text(new)
 base[name]=hashlib.sha256(p.read_bytes()).hexdigest()
for folder in ('bin','test'):
 for p in (root/folder).iterdir():
  dest=work/folder/p.name
  if p.is_file() and not dest.exists():dest.symlink_to(p)
# Isolate mutable pytest globals while sharing the same runtime.
shutil.copyfile('/tmp/full-spec-legacy-query-retirement-probes.py',work/'test/test_legacy_query_retirement.py')
(work/'base-manifest.json').write_text(json.dumps(base,indent=2)+'\n')
(work/'validation-manifest.json').write_text(json.dumps({n:hashlib.sha256((work/n).read_bytes()).hexdigest() for n in remove},indent=2)+'\n')
(work/'removed-tests.json').write_text(json.dumps(removed_tests,indent=2)+'\n')
print('Removed methods:',len(remove['bin/reasoning.py']),'obsolete test cases:',len(removed_tests))
