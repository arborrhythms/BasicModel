"""Finalize only after the isolated full proof and identical primary source."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess

root=Path('/Users/arogers/github/WikiOracle/basicmodel')
exit_record=json.loads(Path('/tmp/full-spec-phase-full-exit.json').read_text())
assert exit_record['exit_code']==0
log=Path(exit_record['log'])
summary=re.findall(r'^\d+ passed[^\n]* in [^\n]+$',log.read_text(),flags=re.M)[-1]
assert 'failed' not in summary and 'error' not in summary
manifest=Path('/tmp/full-spec-phase-checkout-frozen.json')
frozen=json.loads(manifest.read_text());assert len(frozen)==589
for name,digest in frozen.items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
for name,digest in json.loads(Path('/tmp/full-spec-unowned-after-tied.json').read_text()).items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root)
assert Path('/tmp/full-spec-query-phase-doc-remap-applied.json').exists()
affected_exit=json.loads(Path('/tmp/full-spec-phase-primary-affected-exit.json').read_text())
assert affected_exit['exit_code']==0
affected=Path(affected_exit['log'])
affected_summary=re.findall(r'^\d+ passed[^\n]* in [^\n]+$',affected.read_text(),flags=re.M)[-1]
folder='doc/benchmarks/2026-09-16-query-phase-data'
target=root/folder;assert not target.exists();target.mkdir(parents=True)
sources={
    'sentence-phases-red.log':'/tmp/full-spec-query-phase-red-v2.log',
    'boundaries-red.log':'/tmp/full-spec-query-phase-boundaries-red-v2.log',
    'input-entries-red.log':'/tmp/full-spec-query-forward-entries-red.log',
    'compiled-negative-red.log':'/tmp/full-spec-query-phase-compiled-negative-red.log',
    'compiled-phase-leak-red.log':'/tmp/full-spec-query-phase-real-fullgraph-v2.log',
    'candidate-focused-green.log':'/tmp/full-spec-query-phase-focused-fullgraph-v3.log',
    'compiled-negative-green.log':'/tmp/full-spec-query-phase-compiled-negative-green.log',
    'candidate-affected-green.log':'/tmp/full-spec-query-phase-affected-v3.log',
    'isolated-focused-green.log':'/tmp/full-spec-phase-checkout-focused-v1.log',
    'isolated-full-green.log':str(log),
    'primary-affected-green.log':str(affected),
    'validation-manifest.json':str(manifest),
    'validation-provenance.json':'/tmp/full-spec-phase-checkout-provenance.json',
    'source-ownership-guard.py':'/tmp/full_spec_phase_source_guard.py',
    'candidate-base-manifest.json':'/tmp/full-spec-phase-worktree/base-manifest.json',
}
owned=set(Path('/tmp/full-spec-query-phase-owned-paths.txt').read_text().splitlines())
for name,source in sources.items():
    shutil.copyfile(source,target/name);owned.add(folder+'/'+name)

def evidence(prefix):
    base=prefix+'2026-09-16-query-phase-data/'
    return f'''The 23 new reviewer cases cover sentence/legacy entry points, preparation
reads, per-row readiness, nested scopes, exceptions, held understandings,
supplied executors and compiled execution. The real fullgraph test exercises
forward and backward across word counts with one graph. Two additional negative
checks reject query calls during tracing and in compiled input's eager islands.
The independent checkout passed **76 focused/documentation checks in 30.33 seconds**.

The isolated basicmodel full suite passed with exit zero: **{summary}**.
All **589** runtime/test/configuration files in the primary checkout then matched
the validated snapshot byte for byte. The primary affected run passed with exit
zero: **{affected_summary}**. A read-only source guard checked frozen hashes and
module ownership before/after the full run; the Python runtime and parent
documentation fixture are recorded in provenance.

[Phase red]({base}sentence-phases-red.log),
[entry-point red]({base}input-entries-red.log),
[compiled leak red]({base}compiled-phase-leak-red.log),
[focused]({base}isolated-focused-green.log),
[affected]({base}candidate-affected-green.log),
[isolated full green]({base}isolated-full-green.log),
[primary affected]({base}primary-affected-green.log),
[source manifest]({base}validation-manifest.json),
[provenance]({base}validation-provenance.json),
[source guard]({base}source-ownership-guard.py).

Full-suite command, from the isolated basicmodel worktree:

```sh
DEVELOPER_DIR=/Library/Developer/CommandLineTools OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \\
  PYTHONPATH=/tmp:/tmp/full-spec-phase-checkout/bin:/tmp/full-spec-phase-checkout/test \\
  .venv/bin/python -m pytest test -q -x -p no:cacheprovider \\
  -p full_spec_phase_source_guard
```'''

p=root/'doc/QueryPhases.md';s=p.read_text()
old='''Record actual affected and full-suite results after installation. Reviewer probes
cover registered/legacy execution, preparation reads, complete/incomplete rows,
nested scopes, exceptions, held understandings, supplied executors and real
compiled forward/backward.'''
assert old in s;s=s.replace(old,evidence('benchmarks/'),1)
assert 'Implementation reference. Validation is pending.' in s
s=s.replace('Implementation reference. Validation is pending.',
            'Implementation reference, verified September 16.',1);p.write_text(s)
p=root/'doc/plans/2026-09-15-next-sentence-as-the-production-objective.md';s=p.read_text()
old='''Repository validation is pending. Reviewer probes reproduced escape through
sentence paths, incomplete rows, operand reads, compiled-state entry and supplied
executors. A real compiled-forward probe also exposed a leaked phase flag; the
host/tracing split addresses that compiler interaction.
[Query phases](../QueryPhases.md) documents the checks and limits.'''
assert old in s;s=s.replace(old,evidence('../benchmarks/')+'\n\n[Query phases](../QueryPhases.md) documents the checks and limits.',1)
s=s.replace('## 19. Sentence masks and completed-row query permission (in progress)',
            '## 19. Sentence masks and completed-row query permission (verified September 16)',1);p.write_text(s)
Path('/tmp/full-spec-query-phase-owned-paths.txt').write_text('\n'.join(sorted(owned))+'\n')
Path('/tmp/full-spec-query-phase-commit-message.txt').write_text(f'''Enforce query execution boundaries around sentence processing

Allow checked queries only for completed rows during answer resolution, after enabled tied input reconstruction. Guard before operand reads and executor effects, narrow nested permissions, and restore permission on errors. Held understandings retain their own completion evidence.

Mask forward, explicit compiled-state input, supplied executors, reconstruction and output realization. Keep temporary permission on the host; reject query tracing directly so compiled numerical execution cannot leak an attribute update. Legacy query entry points also reject calls inside sentence work.

Validation: 23 new reviewer cases, including real fullgraph forward/backward across word counts and negative tracing/eager-island checks. Isolated full suite: {summary}. The primary checkout matches all 589 validated runtime/test/configuration files; primary affected: {affected_summary}. No parameter, loss or gradient-detachment change. Ordinary controller and linguistic meaning integration remain separate work.

Co-Authored-By: Claude Fable 5.1 <noreply@anthropic.com>
''')
print(summary)
print('Phase evidence archived;',len(owned),'exact owned paths.')
