"""Review: bindings are semantic addresses and must survive origin withdrawal."""
from dataclasses import replace
import copy
import pytest
import torch
from Layers import TernaryTruthStore
from Meaning import ConceptualMeaning


def _meaning(**kwargs):
    return ConceptualMeaning(torch.eye(6)[:3], torch.ones(3, dtype=torch.bool), **kwargs)


@pytest.mark.parametrize('field', ['bindings', 'scope'])
def test_withdrawal_preserves_occurrences_addressed_by_retained_semantic_context(field):
    store = TernaryTruthStore(6, capacity=4)
    child = store.append_meaning(_meaning(), trust=.8)
    store.set_origin(child, store.ORIGIN_USER)
    ref = store.occurrence_of(child)
    outer = store.append_meaning(_meaning(**{field: {'referent': ref}}), kind='observation')
    root = store.occurrence_of(outer)
    assert store.clear_origin(store.ORIGIN_USER) == 0
    assert store.occurrence_of(0) == ref
    assert store.row(0)['trust'] == 0 and store.row(0)['kind'] == 'unverified'
    assert store.occurrence_of(1) == root
    assert getattr(store.meaning_of(1), field) == (('referent', ref),)


@pytest.mark.parametrize('field', ['bindings', 'scope'])
def test_missing_local_context_reference_fails_before_append_mutates_the_owner(field):
    store = TernaryTruthStore(6, capacity=4)
    row = store.append_meaning(_meaning())
    missing = store.occurrence_of(row)[:2] + (99,)
    state = copy.deepcopy(store.state_dict())
    with pytest.raises(ValueError, match='reference|occurrence|context'):
        store.append_meaning(_meaning(**{field: {'referent': missing}}))
    for name, value in state.items():
        torch.testing.assert_close(store.state_dict()[name], value)
