# Next registry/controller investigation — design notes, not implementation

The taxonomy candidate has 266 passing focused/affected cases (five warnings,
10.21s) in /tmp/full-spec-taxonomy-affected-v4.log. Session56586 exited0.
Its six new probe files contain32 cases. No registry module/probes exist yet.
Do not modify/apply taxonomy over the running existence full suite.

## Confirmed code constraints

- Grammar.configure reads query signatures as strings, without a signature or
  executor check (Language.py:1085-1092). test_grammar_sections currently expects
  nine entries; what(Q) is absent. Grammar.load/configure is the right existing
  API for a first failing unknown-executor/arity/domain probe. Parsing static
  grammar signatures is not natural-language keyword dispatch.
- Semantic VP identities can be owned by the existing frozen named concepts:
  ConceptualSpace.mint_frozen_concept at Spaces18963, _csw_row_of19022. A small
  native _cs experiment minted three distinct relation concepts, assigned rows
  0/1/2 and retrieved distinct full-width codebook atoms with unit norms. Thus
  there is an existing payload owner; do not add a separate VP embedding table
  or feed integer IDs as semantic features. This experiment is preparation,
  not a regression/checkpoint/optimizer proof.
- _frozen_named already travels in BaseModel's structural sidecar Models4429.
  Row allocation is a mutation: install predefined VP handles at setup, never
  lazily while constructing/scoring query candidates. A missing/retired handle
  should fail explicitly. Required graph/slot bindings must not be guessed
  from a codebook row number.
- AnswerProgram has rows/word_rows/activations/leaves/actions/targets/end_state
  but no native concept IDs. _ar_word_object_ids and _ar_word_concept_ids are
  available at staging. Capture explicit concept IDs beside interpreted
  dictionary rows (OBJECT preferred, WORD fallback) to keep native grounding.
- _capture_answer_programs (Models12045) and _replay_program(12162) expose actual
  selected compose actions and their live operands. languageSpace._tree_layer
  selects CS operation banks; local action IDs map through the declared banks.
  Do not reconstruct syntax by scanning input text or matching keywords.
- PartLayer is lossy at the root: a selected Part fold returns the whole value.
  A structured semantic adapter must retain the selected relation operands and
  shared VP payload instead of trusting the collapsed dense root as a complete
  relation. Its operand order must follow the recorded compose operation;
  whole is converse. Generic semantic types/nesting need explicit preservation.
- Observation drains currently run before the Understanding capture:
  _finalize_stm_end_state around12632/12638 calls the drains; Understanding
  capture at8010 obtains programs, then completes input reconstruction8011.
  A semantic observation migration cannot merely attach a new Meaning after
  those writes and claim the predictor/facts already received it. Capture the
  selected semantic program at the publication/boundary and thread it to all
  three observation writers, or defer writes coherently and preserve once-only
  observation/reconstruction. Keep compiled21tuple shape stable where possible.
- TernaryTruthStore.occurrence_of already returns ('ltm', namespace, occurrence)
  (Layers8769). A complete unary Exist description/general what(Q) must be held
  intact directly or via this existing occurrence owner; no flatten-to-NP1.
  Candidate construction must not commit child records. Selected commitment
  can retain constituent references without admitting an embedded claim as fact.
  Nested/fusion rules from the separate two-truths spec remain deferred.
- WhatInteractionMemory (Layers9173) is the one SymbolSpace-owned interaction
  memory. Its current _what_slots are legacy two-half/parity records; new
  production history must be ordinary thoughts plus transition events and
  explicit context levels, with replay as the authority. No new planner/frame
  memory alongside it. A derived bounded live-context cache is permitted.

## Registry acceptance / implementation notes

- One checked metadata definition per relation/domain, linking compose/inverse
  methods and boundary execution. Public aliases don't create second VPs.
  Resolve execution from the middle VP reference of ConceptualMeaning, not
  the requested operation string. Assertive/embedded meanings never execute.
- Validate all declared queries, including what(Q); signatures declare absent,
  open, occupied/result roles, result kind, supported domains and read/write
  effects. Missing executors/unsupported domains must fail explicitly. Tense
  executor remains deferred. what schedules the same conceptual controller;
  it cannot call Data.what or a hidden solver. query(X,Y) stays a distinct
  lookup. Quantize is a conceptual read, not symbol snapping. ARMA is an estimate.
- Unary descriptions need a transient owned structured value or a stable
  occurrence reference before commitment; the durable metadata sidecar cannot
  become a second vector store. A future retained-node API should resolve from
  existing owners, preserve mode/scope/bindings, detect unavailable/cyclic refs
  and enforce declared node/depth/traversal bounds.
- Complete.grammar needs representation/effect comments corrected and a pure
  interrogative composition/realization mechanism. Surface senses and argument
  permutations are grammatical choices. Do not force every 'has' to PartOf.
  Mechanical tests can force the known compose derivation; held-out learned
  parsing/utility evidence must be reported separately.
- Runtime boundary permission is per row, with exception-safe masking of all
  three sentence paths. A prepared answer must causally incorporate the actual
  query result while retaining the proposition, rather than merely logging its
  posture. The current _resolve_answer raw answer_query(prompt) route is still
  unfinished and must be removed from normal resolution.

## Ordinary controller acceptance reminders

- Extend the same WhatInteractionMemory owner: chronological immutable thought
  contents plus descent/return/finish events. A return immediately followed by
  descent must remain visible even without a parent thought. No Q/A labels or
  mandatory parent pointers. Replay must restore initiating meaning, pending
  bindings and scope for each live level, isolating sibling contexts and rows.
- One episode budget/pressure covers same-level work and executor internals;
  descent never refreshes it. At cutoff freeze d_cut; at most d_cut returns plus
  one root finish, no new queries/refinement/descent. One optimizer step.
- Chooser inputs preserve mandatory root/active/current NP/VP/NP roles and
  candidate operands. IDs are addresses only. A fixed role-aware encoder can
  encode full semantic payloads with masks; incidental attended context has
  separate R/K bounds. Document actual feature dimensions/parameter count and
  optimizer ownership; prove VP/NP2 sensitivity and padding invariance.
- Retain live continuous values through the episode; durable writes/targets
  detach. Hard operation choice needs explicit policy credit. Residual reward,
  work penalty, baseline and version-safe delayed attribution remain required;
  ordinary MSE has no score-function baseline. No gold subgoals/context leakage.

These are implementation notes. Do not mark the full spec complete based on
them or the taxonomy foundation, and do not edit protected user documents.
