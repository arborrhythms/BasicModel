"""Render registry documentation and remap current-source links exactly once."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import re

root=Path('/Users/arogers/github/WikiOracle/basicmodel')
work=Path('/tmp/full-spec-registry-worktree')
base=Path('/tmp/full-spec-registry-base')
receipt=Path('/tmp/full-spec-registry-doc-remap-applied.json')
assert not receipt.exists(), 'Do not remap links twice'
assert not (root/'doc/QueryContracts.md').exists()
for name,digest in json.loads((work/'validation-manifest.json').read_text()).items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name

def definitions(text):
    found={}
    def visit(node,path=()):
        if isinstance(node,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)):
            path=path+(node.name,)
            found['.'.join(path)]=(node.lineno,node.end_lineno)
        for child in ast.iter_child_nodes(node):
            visit(child,path)
    visit(ast.parse(text))
    return found

maps={}; anchors={}
for name in ('Queries.py','Language.py','Layers.py','Models.py','Understanding.py','reasoning.py','Spaces.py'):
    new=(root/'bin'/name).read_text()
    new_defs=definitions(new)
    anchors.update({name+':'+key:value[0] for key,value in new_defs.items()})
    if not (base/'bin'/name).exists():
        continue
    old=(base/'bin'/name).read_text()
    old_defs=definitions(old)
    old_lines,new_lines=old.splitlines(),new.splitlines()
    mapping={}
    for op,i,j,a,b in difflib.SequenceMatcher(None,old_lines,new_lines,autojunk=False).get_opcodes():
        for index in range(i,j):
            if op=='equal':
                mapping[index+1]={'line':a+(index-i)+1,'kind':'exact'}
                continue
            enclosing=[(hi-lo,key) for key,(lo,hi) in old_defs.items()
                       if lo<=index+1<=hi and key in new_defs]
            if enclosing:
                _,key=min(enclosing)
                mapping[index+1]={'line':new_defs[key][0],'kind':'definition','name':key}
            else:
                mapping[index+1]={'line':min(len(new_lines),a+1),'kind':'adjacent'}
    maps[name]=mapping

names=['doc/Architecture.md','doc/GradientFlow.md','doc/Language.md','doc/Params.md',
       'doc/Training.md','doc/STM.md','doc/ExistenceEvidence.md','doc/TaxonomyQueries.md',
       'doc/plans/2026-09-15-next-sentence-as-the-production-objective.md']
pattern=re.compile(r'\[([^\]]+)\]\(((?:\.\./)+bin/(Layers\.py|Models\.py|Language\.py|reasoning\.py|Understanding\.py))#L(\d+)\)')
changes=[]
def remap(match):
    label,target,filename,line=match.groups()
    mapping=maps[filename][int(line)]
    new=str(mapping['line'])
    changes.append({'file':filename,'old':int(line),**mapping})
    return '['+label.replace(filename+':'+line,filename+':'+new)+']('+target+'#L'+new+')'
def render(text,prefix='../bin/'):
    return re.sub(r'@@([^@]+)@@',lambda m:prefix+m[1].split(':',1)[0]+'#L'+str(anchors[m[1]]),text)
outputs={}
for name in names:
    text=(root/name).read_text()
    if '/plans/' in name:
        protected=False; parts=[]
        for part in re.split(r'(?=^## |^### )',text,flags=re.M):
            if part.startswith('## '):
                protected=part.startswith(('## 6.','## 7.','## 11.'))
            if part.startswith('### 11.6 '):
                protected=False
            parts.append(part if protected else pattern.sub(remap,part))
        text=''.join(parts)
    else:
        text=pattern.sub(remap,text)
    outputs[name]=text

def replace_once(name,old,new):
    assert old in outputs[name],(name,old)
    outputs[name]=outputs[name].replace(old,new,1)

draft=Path('/tmp/full-spec-registry-documentation.md').read_text()
draft=draft.replace('Draft implementation reference. Repository installation and validation are\npending the taxonomy commit cycle.',
                    'Implementation reference, September 16. Repository validation is in progress.')
outputs['doc/QueryContracts.md']=render(draft)
replace_once('doc/Architecture.md',
    'learned parameters. The checked grammatical VP registry and ordinary levelled\ncontroller remain separate work.',
    'learned parameters. The ordinary levelled controller and normal linguistic\nquery integration remain separate work; the shared-VP contract is below.')
addition=render('''### Checked query contracts and shared grammatical VPs

Grammar loading checks boundary signatures before accepting a declaration.
Every declared interface has explicit roles, domain, evidence semantics and an
executor. At explicit setup, the grammatical adapter binds one native named
ConceptualSpace concept per relation/domain; compose and query aliases share
it. Pure candidate formation preserves canonical roles, grammatical mode and
scope. Selected execution derives its operation from the middle VP and role
occupancy, retaining the evaluated proposition with its evidence.
[Contracts](@@Queries.py:QuerySignature@@),
[shared binding](@@Queries.py:GrammaticalQueryRegistry.install@@),
[dispatch](@@Queries.py:GrammaticalQueryRegistry.execute@@).

These are explicit APIs. The normal forward derivation still needs to publish
this meaning through every observation writer, and the ordinary boundary
controller must enforce phases and causal answer construction. No new learned
parameters or parallel semantic memory were added. See
[Query contracts](QueryContracts.md) for current behavior and remaining gates.

''')
replace_once('doc/Architecture.md','\n## Sigma and Pi Layers\n','\n'+addition+'## Sigma and Pi Layers\n')
replace_once('doc/Language.md',
    'The typed VP registry and canonical linguistic/internal query agreement\nremain open.',
    'The checked shared-VP adapter is implemented as an explicit API below.\nCanonical linguistic/internal agreement in normal forward execution remains open.')
outputs['doc/Language.md']+=render('''
## Checked boundary signatures and shared VP identities (September 16)

`Grammar.configure` validates query declarations before changing existing
rules. Static query/anchor strings remain whole when the loader expands
order alternatives. Complete and production ladder grammars include the
distinct `what(Q)` subgoal interface, which requires an interrogative question.
[Declarations](@@Language.py:Grammar.configure@@),
[file normalization](@@Language.py:_expand_compact_order_sets@@).

The explicit shared-VP adapter forms `[NP1, VP, NP2]` with native references,
mode, polarity, scope and bindings. `whole`/`isWhole` reverse surface operands
into the same canonical relation as `part`/`isPart`; `parts`/`wholes` retain
open roles. Formation does not execute. A selected question dispatches from its
middle VP and occupancy, requiring a checked declaration. No keyword matching
is used in this API. The normal linguistic derivation adapter, sense selection,
paraphrase realization and per-row phase guard remain to be integrated.
[Formation](@@Queries.py:GrammaticalQueryRegistry.form@@),
[dispatch](@@Queries.py:GrammaticalQueryRegistry.execute@@),
[full contract](QueryContracts.md).
''')
outputs['doc/GradientFlow.md']+=render('''
## Checked query and grammatical payload boundaries

The checked registry adds no learned parameter or trained loss. Pure VP/operand
formation clones the existing conceptual payloads without detaching live
continuous inputs; concept and occurrence IDs remain addresses, never numeric
semantic features. Hard taxonomy/fact matching and discrete interface choice
have no ordinary derivative. `arma` preserves the full predictor output graph
without changing the pending external prediction. Durable occurrence reads
return detached descriptions; the later episode controller must provide a live
read from its existing owner to retain within-episode credit.
[Formation](@@Queries.py:GrammaticalQueryRegistry.form@@),
[durable read](@@Queries.py:_occurrence_description@@),
[prediction](@@Queries.py:_arma@@).

Future policy credit and continuous feedback into representation remain subject
to the aggregate downstream rule above. These API checks do not establish
trained query usefulness. See [Query contracts](QueryContracts.md).
''')
outputs['doc/Params.md']+=render('''
### Checked query call bounds and native VP setup

`QueryContext` validates a row address and local limits: 256 concepts, 1024
records, 8 path steps and 1024 edge examinations by default. These are call
limits, not a new episode allowance; shared-budget integration remains open.
At explicit setup, each declared relation/domain uses one existing aligned
concept row and named handle. No new parameter tensor or configuration switch
is introduced. A missing native binding cannot be lazily recreated by
candidate formation or execution.
[Context](@@Queries.py:QueryContext@@),
[setup](@@Queries.py:GrammaticalQueryRegistry.install@@),
[contract](QueryContracts.md).
''')
outputs['doc/Training.md']+=render('''
## Checked queries and native grammatical referents (September 16)

Checked query contracts and shared VP binding add no objective or optimizer
parameter. Captured answer programs retain the native concept IDs selected by
forward's OBJECT/WORD row decision; an unknown referent stays unknown. These
addresses remain separate from numerical semantic features and survive later
staging. Pure grammatical formation retains live operand gradients. Hard
lookup is nondifferentiable and durable descriptions stay detached; policy
credit and live episode integration remain subsequent gates.
[Capture](@@Models.py:BasicModel._word_symbol_concept_ids@@),
[owned programs](@@Understanding.py:AnswerProgram@@),
[formation](@@Queries.py:GrammaticalQueryRegistry.form@@),
[details](QueryContracts.md).
''')
outputs['doc/STM.md']+=render('''
## Shared grammatical query references (September 16)

The explicit query adapter uses ConceptualSpace's existing named-concept
owner for specialized VPs. Checkpoints retain that identity and its payload
through the ordinary conceptual tensor state and structural sidecar. Complete
description operands reference existing LTM occurrences, retaining the inner
VP, NP2, bindings and scope. Candidate formation cannot create occurrences;
unknown namespaces or missing metadata fail without row substitution.
[VP owner](@@Queries.py:GrammaticalQueryRegistry.install@@),
[occurrence resolution](@@Queries.py:_occurrence_description@@).

The current occurrence reader is a bounded durable read and does not provide
live episode memory. Ordinary levelled history, nested retention, shared work
accounting and the normal linguistic observation adapter remain open.
[Query contracts](QueryContracts.md) distinguishes these integration gates.
''')
replace_once('doc/ExistenceEvidence.md',
    'The typed VP registry, grammatical query route and ordinary thought\ncontroller remain separate work.',
    'The normal grammatical query route and ordinary thought controller remain\nseparate work. [Query contracts](QueryContracts.md) supplies the explicit\nchecked shared-VP adapter.')
replace_once('doc/TaxonomyQueries.md',
    'The query interface still predates the checked grammatical-VP registry. This\nchange does not implement linguistic relation/sense composition,',
    '[Query contracts](QueryContracts.md) supplies the explicit shared-VP adapter\nabove this evidence reader. This change does not implement linguistic relation/sense composition,')
specname=names[-1]
replace_once(specname,
    'rejecting unsupported perceptual domains (§16). Grammatical VP dispatch,\nlinguistic/internal meaning agreement and the ordinary levelled controller\nremain open. The evidence readers do not complete those migrations.',
    'rejecting unsupported perceptual domains (§16). The checked shared-VP adapter\nforms and dispatches typed meanings through explicit APIs (§17). Normal\nlinguistic/internal meaning agreement and the ordinary levelled controller\nremain open; these foundations do not complete those migrations.')
replace_once(specname,
    'The checked grammatical VP registry, surface/sense agreement, causal answer\nadapter, ordinary levelled controller, nested retention, anticipation isolation,',
    'The explicit checked shared-VP API follows in §17. Surface/sense agreement,\ncausal answer adaptation, ordinary levelled control, nested retention, anticipation isolation,')
outputs[specname]+=render('''
## 17. Checked query contracts and shared grammatical VP API (in progress)

Static grammar loading validates executor availability, typed signatures and
role/domain contracts before mutating the grammar. Complete and production
ladder grammars declare `what(Q)` alongside the distinct two-operand LTM lookup.
The real loader preserves whole query and anchor strings. Every checked entry
has an executor, result type, read/write scope and evidence semantics; tense
execution remains deferred.
[Loader](@@Language.py:Grammar.configure@@),
[contracts](@@Queries.py:QuerySignature@@).

An explicit setup adapter binds one native named conceptual VP per relation
and domain. Compose/query aliases and converse forms share that identity;
mode belongs to the complete idea. Pure formation retains canonical roles,
open/absent masks, references, polarity, bindings and scope. Selected execution
resolves its interface from the middle VP and occupancy and retains the full
proposition with its evidence. Assertions, undeclared calls, unavailable
referents and wrong widths cannot execute.
[Binding](@@Queries.py:GrammaticalQueryRegistry.install@@),
[formation](@@Queries.py:GrammaticalQueryRegistry.form@@),
[dispatch](@@Queries.py:GrammaticalQueryRegistry.execute@@).

Description-valued arguments use existing occurrence references and bounded
full-description reads. The compound NP's illumination summary is not the
structural record; the executor resolves all occupied roles and context.
No candidate may silently commit a description or invent an occurrence.
Captured leaf programs also retain forward's selected native OBJECT/WORD IDs,
with legacy unknown IDs remaining unknown. Native bindings use the existing
conceptual checkpoint owners; no parallel semantic memory or parameter table
is added.
[Occurrence reader](@@Queries.py:_occurrence_description@@),
[leaf identity](@@Models.py:BasicModel._word_symbol_concept_ids@@).

Repository validation is pending. The temporary candidate passed 304 affected
cases with one skip, including native VP checkpoint identity, and previously
passed 98 output/reconstruction/compiled cases with four skips. The new
reviewer probes failed before their corresponding changes. These preparation
runs do not replace the required repository full suite.
See [Query contracts](../QueryContracts.md) for source links and limitations.

These APIs do not yet replace the normal raw-text legacy resolution path.
Selected linguistic derivation capture through all observation writers,
surface/sense agreement, per-row phase guards, causal answer construction,
ordinary levelled history and shared budget, nested retention, live episode
occurrence reads, anticipation isolation, residual policy credit, separate
compose/generate catalogs and learned utility remain open. The two-truths spec
remains reserved for the next session.
''',prefix='../../bin/')

for name,text in outputs.items():
    assert '@@' not in text,name
    for target,line in re.findall(r'\]\(((?:\.\./)+bin/[^)#]+\.py)#L(\d+)\)',text):
        file=((root/name).parent/target).resolve()
        assert file.is_file() and 1<=int(line)<=len(file.read_text().splitlines()),(name,target,line)
for name,text in outputs.items():
    (root/name).write_text(text)
receipt.write_text(json.dumps(changes,indent=2)+'\n')
Path('/tmp/full-spec-registry-line-maps.json').write_text(json.dumps(maps)+'\n')
(work/'source-anchors.json').write_text(json.dumps(anchors,indent=2)+'\n')
owned=Path('/tmp/full-spec-registry-owned-paths.txt')
owned.write_text('\n'.join(sorted(set(owned.read_text().splitlines())|set(outputs)))+'\n')
print('Updated',len(outputs),'documents;',len(changes),'local source links remapped once.')
print('Definition/adjacent fallbacks:',[x for x in changes if x['kind']!='exact'])
