"""Install ordinary thought history only after the registry push/bump cycle."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess

root = Path('/Users/arogers/github/WikiOracle/basicmodel')
work = Path('/tmp/full-spec-thought-worktree')
assert not subprocess.check_output(['git', 'diff', 'HEAD', '--', 'bin', 'test', 'data'], cwd=root)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root).strip()
assert head == subprocess.check_output(['git', 'rev-parse', 'origin/main'], cwd=root).strip()
parent = root.parent
assert head.decode() == subprocess.check_output(['git', 'rev-parse', 'HEAD:basicmodel'], cwd=parent).decode().strip()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=parent) == subprocess.check_output(['git', 'rev-parse', 'origin/main'], cwd=parent)
base = json.loads((work/'base-manifest.json').read_text())
for name, digest in base.items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest() == digest, name
validated = json.loads((work/'validation-manifest.json').read_text())
for name, digest in validated.items():
    assert hashlib.sha256((work/name).read_bytes()).hexdigest() == digest, name
assert not (root/'bin/Thoughts.py').exists()
probes = {
    'full-spec-levelled-thought-probes.py': 'test_levelled_thought_history.py',
    'full-spec-thought-history-boundary-probes.py': 'test_thought_history_boundaries.py',
    'full-spec-live-query-occurrence-probes.py': 'test_live_query_occurrences.py',
    'full-spec-thought-legacy-boundary-probes.py': 'test_thought_legacy_boundaries.py',
    'full-spec-thought-checkpoint-credit-probes.py': 'test_thought_checkpoint_credit.py',
}
for name in probes.values():
    assert not (root/'test'/name).exists(), name
snapshot = Path('/tmp/full-spec-thought-history-base')
assert not snapshot.exists()
for name in base:
    target = snapshot/name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(root/name, target)
owned=[]
for name in validated:
    shutil.copyfile(work/name, root/name)
    owned.append(name)
for source, name in probes.items():
    target='test/'+name
    shutil.copyfile(Path('/tmp')/source, root/target)
    owned.append(target)
Path('/tmp/full-spec-thought-history-owned-paths.txt').write_text('\n'.join(sorted(owned))+'\n')
print('Applied',len(owned),'runtime/test paths. Repository validation is required.')
