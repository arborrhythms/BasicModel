"""Nested retention also needs atomic restore and bounded corrupt-data reads."""
import copy

import pytest
import torch

from Layers import TernaryTruthStore
from Meaning import ConceptualMeaning


def _meaning(ref=None):
    return ConceptualMeaning(torch.eye(5)[:3], torch.ones(3, dtype=torch.bool),
        role_refs=(None, None, ref))


def _world():
    s = TernaryTruthStore(5, capacity=5)
    child = s.occurrence_of(s.append_meaning(_meaning(), kind='question'))
    root = s.occurrence_of(s.append_meaning(_meaning(child), kind='observation'))
    return s, child, root


def _corrupt_child(s, child, reference):
    # Simulate a structurally corrupt but fingerprint-consistent artifact.
    identifier = child[2]
    s._semantic_rows[identifier]['role_refs'] = (None, None, reference)
    s.metadata_required[0] = True
    s.semantic_fingerprint[0] = s.semantic_fingerprint.new_tensor(
        s._context_fingerprint(s._semantic_rows[identifier], s.text_of(0)))


@pytest.mark.parametrize('corruption', ['cycle', 'dangling'])
def test_structural_restore_rejects_invalid_local_links_atomically(corruption):
    s, child, root = _world()
    good = copy.deepcopy(s.semantic_extras())
    wrong = root if corruption == 'cycle' else child[:2] + (999,)
    _corrupt_child(s, child, wrong)
    saved, extras = copy.deepcopy(s.state_dict()), copy.deepcopy(s.semantic_extras())
    restored = TernaryTruthStore(5, capacity=5)
    restored.load_state_dict(saved)
    before_context = copy.deepcopy(restored._semantic_rows)
    before_texts = list(restored._texts)
    with pytest.raises(ValueError, match='cycle|unavailable|constituent'):
        restored.load_semantic_extras(extras)
    assert restored._semantic_rows == before_context and restored._texts == before_texts
    assert good['records'][0]['context']['role_refs'] == (None, None, None)


def test_cycle_is_reported_without_unbounded_read_or_evidence_transfer():
    s, child, root = _world()
    _corrupt_child(s, child, root)
    view = s.read_structure(root, max_nodes=2, max_depth=2, max_records=2)
    assert view['incomplete'] == ('cycle',)
    assert len(view['rows']) == 2 and view['records_scanned'] == 2
    assert view['rows'][1]['kind'] == 'question'


def test_invalid_survivor_closure_cannot_partly_withdraw_evidence():
    s, child, root = _world()
    s.set_origin(0, s.ORIGIN_USER)
    _corrupt_child(s, child, root)
    before = copy.deepcopy(s.state_dict())
    with pytest.raises(ValueError, match='cycle|constituent'):
        s.clear_origin(s.ORIGIN_USER)
    for name, value in before.items():
        torch.testing.assert_close(s.state_dict()[name], value)


def test_derived_structure_read_does_not_expose_mutable_store_slots():
    s, child, root = _world()
    before = s.slots.clone()
    view = s.read_structure(root)
    view['rows'][0]['np1'].zero_()
    view['rows'][0]['meaning'].roles.zero_()
    torch.testing.assert_close(s.slots, before)


def test_unavailable_owner_and_retired_reference_have_explicit_incomplete_results():
    s, child, root = _world()
    other = TernaryTruthStore(5, capacity=5)
    foreign = other.occurrence_of(other.append_meaning(_meaning()))
    assert s.read_structure(foreign)['incomplete'] == ('unavailable_owner',)
    s.reset()
    replacement = s.occurrence_of(s.append_meaning(_meaning()))
    assert replacement not in (child, root)
    assert s.read_structure(root)['incomplete'] == ('unavailable_reference',)
