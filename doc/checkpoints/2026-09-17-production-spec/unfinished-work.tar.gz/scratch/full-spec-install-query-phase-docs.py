"""Render query-phase documentation and remap current-source links exactly once."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import re

root=Path('/Users/arogers/github/WikiOracle/basicmodel')
work=Path('/tmp/full-spec-phase-worktree')
base=Path('/tmp/full-spec-query-phase-base')
receipt=Path('/tmp/full-spec-query-phase-doc-remap-applied.json')
assert not receipt.exists(), 'Do not remap links twice'
assert not (root/'doc/QueryPhases.md').exists()
for name,digest in json.loads((work/'validation-manifest.json').read_text()).items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name

def definitions(text):
    found={}
    def visit(node,path=()):
        if isinstance(node,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)):
            path=path+(node.name,)
            found['.'.join(path)]=(node.lineno,node.end_lineno)
        for child in ast.iter_child_nodes(node):
            visit(child,path)
    visit(ast.parse(text))
    return found

maps={}; anchors={}
for name in ('Thoughts.py','Queries.py','Language.py','Layers.py','Models.py','Understanding.py','reasoning.py','Spaces.py'):
    new=(root/'bin'/name).read_text()
    new_defs=definitions(new)
    anchors.update({name+':'+key:value[0] for key,value in new_defs.items()})
    if not (base/'bin'/name).exists():
        continue
    old=(base/'bin'/name).read_text()
    old_defs=definitions(old)
    old_lines,new_lines=old.splitlines(),new.splitlines()
    mapping={}
    for op,i,j,a,b in difflib.SequenceMatcher(None,old_lines,new_lines,autojunk=False).get_opcodes():
        for index in range(i,j):
            if op=='equal':
                mapping[index+1]={'line':a+(index-i)+1,'kind':'exact'}
                continue
            enclosing=[(hi-lo,key) for key,(lo,hi) in old_defs.items()
                       if lo<=index+1<=hi and key in new_defs]
            if enclosing:
                _,key=min(enclosing)
                mapping[index+1]={'line':new_defs[key][0],'kind':'definition','name':key}
            else:
                mapping[index+1]={'line':min(len(new_lines),a+1),'kind':'adjacent'}
    maps[name]=mapping

names=['doc/Architecture.md','doc/GradientFlow.md','doc/Language.md','doc/Params.md',
       'doc/Training.md','doc/QueryContracts.md','doc/ThoughtHistory.md','doc/STM.md','doc/ExistenceEvidence.md','doc/TaxonomyQueries.md','doc/SymbolFirewall.md','doc/ArbitrarySymbols.md',
       'doc/plans/2026-09-15-next-sentence-as-the-production-objective.md',
       'doc/plans/2026-09-17-bounded-fixture-reuse.md']
pattern=re.compile(r'\[([^\]]+)\]\(((?:\.\./)+bin/(Models\.py|Queries\.py))#L(\d+)\)')
changes=[]
def remap(match):
    label,target,filename,line=match.groups()
    mapping=maps[filename][int(line)]
    new=str(mapping['line'])
    changes.append({'file':filename,'old':int(line),**mapping})
    return '['+label.replace(filename+':'+line,filename+':'+new)+']('+target+'#L'+new+')'
def render(text,prefix='../bin/'):
    return re.sub(r'@@([^@]+)@@',lambda m:prefix+m[1].split(':',1)[0]+'#L'+str(anchors[m[1]]),text)
outputs={}
for name in names:
    text=(root/name).read_text()
    if '/plans/' in name:
        protected=False; parts=[]
        for part in re.split(r'(?=^## |^### )',text,flags=re.M):
            if part.startswith('## '):
                protected=part.startswith(('## 6.','## 7.','## 11.'))
            if part.startswith('### 11.6 '):
                protected=False
            parts.append(part if protected else pattern.sub(remap,part))
        text=''.join(parts)
    else:
        text=pattern.sub(remap,text)
    outputs[name]=text

def replace_once(name,old,new):
    assert old in outputs[name],(name,old)
    outputs[name]=outputs[name].replace(old,new,1)


outputs['doc/QueryPhases.md']=render(Path('/tmp/full-spec-query-phase-documentation.md').read_text())
sections={
'doc/Architecture.md': '''
### Checked query execution phases

`resolveAnswer()` opens only completed program rows after enabled input
reconstruction. Input execution, reconstruction and output realization mask
queries; checked dispatch validates permission before operand reads. Compiled
tracing rejects queries without mutating a host phase flag in the graph.
Held understandings retain their own readiness. No tensor, learned parameter,
memory owner or forward-result slot is added.
[Boundary](@@Models.py:BasicModel.resolveAnswer@@),
[phase mask](@@Models.py:_sentence_query_mask@@),
[preparation guard](@@Queries.py:GrammaticalQueryRegistry.execute@@).
See [Query phases](QueryPhases.md) for validation and remaining integration.
''',
'doc/Language.md': '''
### Representation and query execution permission

Grammatical formation stays pure inside a sentence. A selected completed
question can execute only in an allowed answer-boundary row. Permission is
checked before description resolution or the registered executor. Nested
sentence work masks the boundary until it returns, including supplied input
executors and compiled input calls.
[Dispatch](@@Queries.py:GrammaticalQueryRegistry.execute@@),
[input wrapper](@@Models.py:BasicModel._execute_input_sentence@@).
[Query phases](QueryPhases.md) records the runtime contract; deriving linguistic
VP meaning and replacing the normal legacy controller remain separate gates.
''',
'doc/GradientFlow.md': '''
### Query phase permission

The host sentence mask and completed-row boundary guard add no parameter,
objective or tensor detachment. They constrain when a checked query can read
or execute. Current-step prepared meanings retain their existing continuous
gradient path; hard choice still requires the controller's policy credit.
Compiled numerical calls leave phase bookkeeping to the host wrapper, and
tracing a query fails explicitly. The real fullgraph regression checks forward,
backward and reuse across word counts.
[Mask](@@Models.py:_sentence_query_mask@@),
[boundary](@@Models.py:BasicModel.resolveAnswer@@).
See [Query phases](QueryPhases.md) for the validation evidence and limits.
''',
'doc/Training.md': '''
### Sentence and reasoning permission

Enabled tied input reconstruction must already belong to the `Understanding`
before `resolveAnswer()` opens completed rows for reasoning. Supplied executors
in `understand()`/`what()` run under the same input sentence mask; output
realization cannot start a query. Permissions restore on error and do not
change optimizer or gradient-balancing behavior.
[Input execution](@@Models.py:BasicModel._execute_input_sentence@@),
[resolution](@@Models.py:BasicModel.resolveAnswer@@),
[output](@@Models.py:BasicModel.reverseOutput@@).
[Query phases](QueryPhases.md) contains phase and compilation checks.
''',
'doc/Params.md': '''
### Query phase state

Query permission adds no learned or checkpointed parameter and no new setting.
The model initializes transient host flags before compilation; a boundary
temporarily identifies completed rows, while sentence work disables execution.
No semantic feature contains these administrative flags.
[Initialization](@@Models.py:BasicModel.__init__@@),
[boundary scope](@@Models.py:BasicModel._query_boundary_scope@@).
See [Query phases](QueryPhases.md).
''',
'doc/STM.md': '''
### Completed-row query permission

Boundary readiness comes from the owned sentence programs in the requested
`Understanding`, not the latest mutable STM staging. Missing/padded rows and
program-less dense compatibility values cannot enable checked queries.
Nested boundaries can narrow an existing row permission but cannot widen it.
Sentence execution masks even a previously opened parent boundary.
[Readiness](@@Models.py:BasicModel._completed_query_rows@@),
[scope](@@Models.py:BasicModel._query_boundary_scope@@).
See [Query phases](QueryPhases.md); the ordinary controller still needs to
integrate completed internal-thought boundaries with this permission.
''',
'doc/QueryContracts.md': '''
## Model execution permission

When used by BasicModel, both direct signature calls and grammatical-VP
dispatch require an open, completed row boundary before any operand read.
Sentence processing and compiled tracing reject query execution. Explicit
standalone evidence readers retain their existing API.
[Direct guard](@@Queries.py:_require_query_boundary@@),
[boundary](@@Models.py:BasicModel.resolveAnswer@@).
[Query phases](QueryPhases.md) documents exception handling, nested rows,
compiled execution and the remaining controller integration.
''',
'doc/ThoughtHistory.md': '''
## Sentence-runtime integration status

The input/answer phase guard now enforces completed-row query permission;
ordinary internal-thought controller integration remains open.
[Query phases](QueryPhases.md) records the implemented guard and its limits.
History replay, credit lifetime and declared work accounting are unchanged.
'''}
for name,section in sections.items():
    outputs[name]+=render(section)
outputs['doc/plans/2026-09-15-next-sentence-as-the-production-objective.md']+=render('''
## 19. Sentence masks and completed-row query permission (in progress)

`resolveAnswer()` requires its owned tied reconstruction when enabled and opens
only nonempty captured-program rows. Missing/padded rows cannot execute a query;
held understandings remain usable after another forward. Permission restores
after success or failure, and nested resolution can only narrow parent rows.
[Boundary](@@Models.py:BasicModel.resolveAnswer@@),
[scope](@@Models.py:BasicModel._query_boundary_scope@@).

All input execution entries, input reconstruction and output realization mask
query execution. Checked calls guard before occurrence reads or effects; legacy
query entries also reject calls inside sentence work. Compiled tracing rejects
queries directly, while the host input wrapper covers numerical compiled calls
and their eager islands. The captured graph does not mutate phase flags, and
the 21-value forward contract is unchanged.
[Mask](@@Models.py:_sentence_query_mask@@),
[execution wrapper](@@Models.py:BasicModel._execute_input_sentence@@),
[query preparation](@@Queries.py:GrammaticalQueryRegistry.execute@@).

Repository validation is pending. Reviewer probes reproduced escape through
sentence paths, incomplete rows, operand reads, compiled-state entry and supplied
executors. A real compiled-forward probe also exposed a leaked phase flag; the
host/tracing split addresses that compiler interaction.
[Query phases](../QueryPhases.md) documents the checks and limits.

These guards add no parameter, loss or gradient detachment. The canonical
linguistic adapter, completed internal-thought boundaries, normal learned
controller, raw-text fallback retirement, actual shared executor work, nested
retention, anticipation isolation, residual policy credit and learned utility
remain open. The separate two-truths spec remains next-session work.
''',prefix='../../bin/')

for name,text in outputs.items():
    assert '@@' not in text,name
    for target,line in re.findall(r'\]\(((?:\.\./)+bin/[^)#]+\.py)#L(\d+)\)',text):
        file=((root/name).parent/target).resolve()
        assert file.is_file() and 1<=int(line)<=len(file.read_text().splitlines()),(name,target,line)
for name,text in outputs.items():
    (root/name).write_text(text)
receipt.write_text(json.dumps(changes,indent=2)+'\n')
Path('/tmp/full-spec-query-phase-line-maps.json').write_text(json.dumps(maps)+'\n')
(work/'source-anchors.json').write_text(json.dumps(anchors,indent=2)+'\n')
owned=Path('/tmp/full-spec-query-phase-owned-paths.txt')
owned.write_text('\n'.join(sorted(set(owned.read_text().splitlines())|set(outputs)))+'\n')
print('Updated',len(outputs),'documents;',len(changes),'local source links remapped once.')
print('Definition/adjacent fallbacks:',[x for x in changes if x['kind']!='exact'])
