from pathlib import Path
import ast,json
root=Path('/Users/arogers/github/WikiOracle/basicmodel')
run=Path('/tmp/full-spec-slow-gates-affected-v1')
r=json.loads((run/'result.json').read_text());assert r['exit_code']==0,r['reason']
new={
 'test/test_meronomy_ladder.py':['test_cold_start_learns_space_as_the_basic_boundary','test_recurring_phrases_are_admitted_on_a_text_corpus_with_positive_gain'],
 'test/test_reconstruction_roundtrip.py':['test_mm20m_xor_roundtrip_at_harness_budget'],
 'test/test_output_path_supervised.py':['test_available_input_targets_do_not_train_answer_modules_after_adam'],
}
manifest=Path('/tmp/full-spec-test-mode-selections.json');data=json.loads(manifest.read_text())
Path('/tmp/full-spec-test-mode-initial-selections.json').write_text(manifest.read_text())
for name,selected in new.items():
 p=root/name;s=p.read_text();tree=ast.parse(s);lines=s.splitlines(keepends=True)
 found={f.name:f for f in tree.body if isinstance(f,ast.FunctionDef)}
 for key in sorted(selected,key=lambda k:found[k].lineno,reverse=True):
  n=found[key];assert not any(ast.unparse(d)=='pytest.mark.slow' for d in n.decorator_list)
  start=min([n.lineno]+[d.lineno for d in n.decorator_list])-1
  lines.insert(start,'@pytest.mark.slow\n')
 p.write_text(''.join(lines));data.setdefault(name,[]).extend(selected)
manifest.write_text(json.dumps(data,indent=2)+'\n')
for name in ('test/test_config_matrix.py','test/test_math_thinking_training.py','test/test_blind_decode.py','test/test_reconstruction_roundtrip.py'):
 p=root/name;s=p.read_text();old='not os.environ.get("RUN_SLOW")';assert old in s,name
 p.write_text(s.replace(old,'os.environ.get("RUN_SLOW") != "1"'))
p=root/'doc/Testing.md';s=p.read_text()
s=s.replace('Eighteen long-running functions now use the central slow gate.\nSmall numerical training tests and ordinary forward/backward, ownership,\ncheckpoint and query regressions stay in the default suite.',
 'Twenty-two long-running functions now use the central slow gate. These include\nrepeated corpus-learning experiments and the expensive full-model gradient/Adam\nintegration checks. Small numerical training, ordinary forward/backward, ownership,\ncheckpoint and query regressions stay in the default suite. Run the slow checks\nexplicitly when their corresponding training paths change.')
p.write_text(s)
p=root/'doc/plans/2026-09-15-next-sentence-as-the-production-objective.md';s=p.read_text()
old='requires removing superseded legacy code together with its obsolete tests.';assert old in s
s=s.replace(old,old+' Unused reasoning methods\nrequire review and explicit user approval before removal: the planned grammar\nqueries may introduce their use. Preserve those methods until that decision.')
p.write_text(s)
print('Marked',sum(map(len,data.values())),'functions in',len(data),'files.')
