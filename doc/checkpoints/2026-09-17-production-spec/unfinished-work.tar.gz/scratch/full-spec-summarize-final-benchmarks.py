from pathlib import Path
import collections
import json
import statistics

folder = Path('/Users/arogers/github/WikiOracle/basicmodel/doc/benchmarks/2026-09-16-tied-reconstruction-data')
names = ['answers-b1-legacy-observer','answers-b1-final','answers-b2-final','fineweb-b1-final','long-b1-k8-final','long-b1-k16-final','output-b2-final']

def mean(values):
    values = [x for x in values if x is not None]
    return statistics.mean(values) if values else None

def phasesummary(phase):
    steps = phase['steps']
    fids = [s.get('reconstruction_fidelity', {}) for s in steps]
    return dict(
        steps=len(steps), input_sentences=sum(s.get('input_sentences',0) for s in steps),
        batch_mean_fidelity={k:mean(f.get(k) for f in fids) for k in ('byte_cost','idea_mse','event_mse','event_score')},
        truncated_rows=sum(f.get('truncated_rows',0) or 0 for f in fids),
        output_lengths=dict(collections.Counter(n for s in steps for n in (s.get('output_word_counts') or []))),
        output_truncated_rows=sum(s.get('output_truncated_rows',0) or 0 for s in steps),
        input_word_lengths=dict(collections.Counter(n for s in steps for n in s.get('word_counts',[]))),
        graph_counts=[s.get('compiler_counters',{}).get('stats',{}).get('unique_graphs') for s in steps],
        step_seconds=[s['seconds'] for s in steps],
        epoch_seconds=phase.get('epoch_seconds'), peak_memory=phase.get('peak_memory'),
        expectation=phase.get('expectation'), steady=phase.get('steady'),
        controls=phase.get('encoded_meaning_controls'), fixed_encoding=phase.get('fixed_pretraining_encoding_score'),
    )

result = {}
for name in names:
    p=folder/f'{name}.json'
    if not p.exists():continue
    data=json.loads(p.read_text())
    result[name] = dict(
        error=data.get('error'), setup_seconds=data.get('setup_seconds'),
        config_sha256=data.get('config_sha256'), runtime_sha256=data.get('runtime_sha256'),
        phases={ph['name']:phasesummary(ph) for ph in data['phases']},
        head_delta=data.get('head_parameter_delta_norm'), answer_delta=data.get('answer_parameter_delta_norm'),
        compose_delta={n:v for n,v in data.get('compose_parameter_delta_norms',{}).items() if v},
        compose_owned=all(data.get('compose_optimizer_ownership',{}).values()),
        target_detached=data.get('target_detached'), context_detached=data.get('context_detached'),
        predictor_update=data.get('predictor_update_verified'), answer_update=data.get('supplied_answer_update_verified'),
    )
print(json.dumps(result,indent=2))
