"""Apply the reviewed registry after taxonomy's commit/push/bump/push cycle."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess

root = Path('/Users/arogers/github/WikiOracle/basicmodel')
work = Path('/tmp/full-spec-registry-worktree')
assert not subprocess.check_output(['git', 'diff', 'HEAD', '--', 'bin', 'test', 'data'], cwd=root)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root).strip()
assert head == subprocess.check_output(['git', 'rev-parse', 'origin/main'], cwd=root).strip()
parent = root.parent
assert head.decode() == subprocess.check_output(['git', 'rev-parse', 'HEAD:basicmodel'], cwd=parent).decode().strip()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=parent) == subprocess.check_output(['git', 'rev-parse', 'origin/main'], cwd=parent)
base = json.loads((work/'base-manifest.json').read_text())
for name, digest in base.items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest() == digest, name
validated = json.loads((work/'validation-manifest.json').read_text())
for name, digest in validated.items():
    assert hashlib.sha256((work/name).read_bytes()).hexdigest() == digest, name
assert not (root/'bin/Queries.py').exists()
probes = {
    'full-spec-query-registry-declaration-probes.py': 'test_query_registry.py',
    'full-spec-query-executor-probes.py': 'test_query_executors.py',
    'full-spec-query-contract-boundary-probes.py': 'test_query_contract_boundaries.py',
    'full-spec-query-loader-probes.py': 'test_query_grammar_loader.py',
    'full-spec-query-copy-probe.py': 'test_query_grammar_copy.py',
    'full-spec-query-native-id-probes.py': 'test_query_native_ids.py',
    'full-spec-grammatical-vp-probes.py': 'test_grammatical_query_vps.py',
    'full-spec-query-vp-boundary-probes.py': 'test_query_vp_boundaries.py',
}
for name in probes.values():
    assert not (root/'test'/name).exists(), name
snapshot = Path('/tmp/full-spec-registry-base')
assert not snapshot.exists()
for name in base:
    target = snapshot/name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(root/name, target)
owned=[]
for name in validated:
    shutil.copyfile(work/name, root/name)
    owned.append(name)
for source, name in probes.items():
    target='test/'+name
    shutil.copyfile(Path('/tmp')/source, root/target)
    owned.append(target)
Path('/tmp/full-spec-registry-owned-paths.txt').write_text('\n'.join(sorted(owned))+'\n')
print('Applied',len(owned),'runtime/test/config paths. Run repository validation before committing.')
