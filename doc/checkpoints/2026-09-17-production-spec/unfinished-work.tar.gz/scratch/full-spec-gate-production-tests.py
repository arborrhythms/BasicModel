from pathlib import Path
import ast,json,hashlib
root=Path('/Users/arogers/github/WikiOracle/basicmodel')
manifest=Path('/tmp/full-spec-test-mode-selections.json');prior=json.loads(manifest.read_text())
Path('/tmp/full-spec-test-mode-pre-production-selections.json').write_text(manifest.read_text())
new={
 'test/test_compile_static_loop.py':['test_per_word_body_callable_with_static_signature','test_word_at_returns_padded_shape_past_valid_len'],
 'test/test_compiled_expectation_boundary.py':['test_unpacked_forward_observes_each_published_sentence_once'],
 'test/test_compiled_step_invoked.py':['test_compiled_step_is_invoked'],
 'test/test_conceptual_recurrence.py':['test_reconstruct_enum_retired','test_mm5m_forward_finite_after_combine','test_mm5m_combine_carrier_roundtrip','test_bind_contained_in_conceptual_space','test_intersentence_seed_used','test_parallel_ps_called_once','test_widening_ps_pi_sized_at_embedded_percept_width','test_mm5m_grammar_builds_and_forwards'],
 'test/test_decode_exemplars.py':['test_mm_decode_builds_and_wires_idea_decode','test_mm_phrase_decode_builds_and_wires_idea_decode','test_mm_decode_forward_smoke'],
 'test/test_dimensional_governance.py':['test_mm_5m_builds_and_forwards','test_mm_5m_reconstructs','test_serial_relaxes_symbol_dim_passthrough','test_reference_configs_still_build_no_false_positive'],
 'test/test_discourse_cache_dtype.py':['test_staged_prediction_cast_to_amp_dtype'],
 'test/test_dual_input_contract.py':'all',
 'test/test_dual_towers.py':['test_ws_matches_ps_view_shape','test_off_path_stores_unchanged','test_default_expectation_adds_only_its_owned_checkpoint_keys','test_space_is_the_single_structural_owner_of_slot_modules','test_ws_routes_universe_on_parallel_path','test_ws_routing_after_serial_migration'],
 'test/test_mlx_export.py':['test_stage_for_core_returns_tensor','test_forward_core_matches_normal_forward','test_forward_core_exports','test_mlx_lower_writes_pte','test_pte_runtime_parity'],
 'test/test_output_synthesis.py':['test_chooser_question_bias_trains_through_the_policy_objective'],
 'test/test_per_word_capture_gate.py':['test_per_word_step_runs_eagerly_end_to_end','test_per_word_step_is_extractable_as_a_standalone_callable','test_per_word_step_compiles_fullgraph_clean','test_per_word_loop_completes_two_steps_under_fullgraph'],
 'test/test_per_word_ss_padding_noop.py':'all',
 'test/test_radix_recon_render.py':'all',
 'test/test_rule_gate_isolates_side_effects.py':['test_false_gate_contribution_is_zero','test_false_gate_preserves_stm_buffer'],
 'test/test_symbolic_iteration.py':'all',
 'test/test_word_store.py':['test_concept_index_read_sizes_inventory_by_explicit_nvectors','test_two_epoch_training_severs_cross_batch_graph'],
 'test/test_reference_table.py':['test_symbol_code_shape_and_zero_bands'],
 'test/test_unified_lexicon_codebook.py':['TestExistingConfigsSatisfyFlatSlab.test_mm_5m_satisfies_flat_slab'],
 'test/test_recon_bench.py':['test_byte_lexer_config_decodes'],
 'test/test_explicit_dimensions.py':['TestIdempotentCliRuns.test_cli_does_not_crash','TestXorReconCliReconstruction.test_at_least_50_pct_inputs_reconstruct','TestXorExactCliReconstruction.test_at_least_50_pct_inputs_reconstruct','TestXorExactCliReconstruction.test_output_mse_is_crisp'],
}
base={};applied={}
for name,names in new.items():
 p=root/name;text=p.read_text();base[name]=hashlib.sha256(p.read_bytes()).hexdigest();tree=ast.parse(text)
 functions={}
 def visit(node,prefix=''):
  for child in ast.iter_child_nodes(node):
   if isinstance(child,(ast.FunctionDef,ast.AsyncFunctionDef)):
    if child.name.startswith('test_'):functions[prefix+child.name]=child
   elif isinstance(child,ast.ClassDef):visit(child,prefix+child.name+'.')
 visit(tree)
 if names=='all':names=list(functions)
 assert set(names)<=set(functions),(name,set(names)-set(functions))
 lines=text.splitlines(True);patches=[]
 for item in names:
  assert item not in prior.get(name,[]),(name,item)
  node=functions[item]
  assert not any(ast.unparse(d)=='pytest.mark.slow' for d in node.decorator_list),(name,item)
  index=min([node.lineno,*[d.lineno for d in node.decorator_list]])-1
  patches.append((index,' '*node.col_offset+'@pytest.mark.slow\n'))
 for index,line in sorted(patches,reverse=True):lines.insert(index,line)
 text=''.join(lines)
 if not any(isinstance(n,ast.Import) and any(x.name=='pytest' for x in n.names) for n in tree.body):
  offset=tree.body[0].end_lineno if isinstance(tree.body[0],ast.Expr) and isinstance(tree.body[0].value,ast.Constant) else 0
  # These modules have no future-import declarations.
  assert not any(isinstance(n,ast.ImportFrom) and n.module=='__future__' for n in tree.body)
  lines=text.splitlines(True);lines.insert(offset,'\nimport pytest\n');text=''.join(lines)
 ast.parse(text);p.write_text(text)
 prior[name]=prior.get(name,[])+names;applied[name]=names
manifest.write_text(json.dumps(prior,indent=2)+'\n')
Path('/tmp/full-spec-production-slow-selections.json').write_text(json.dumps(applied,indent=2)+'\n')
Path('/tmp/full-spec-production-slow-base.json').write_text(json.dumps(base,indent=2)+'\n')
count=sum(map(len,prior.values()));addition=sum(map(len,applied.values()))
p=root/'doc/Testing.md';s=p.read_text().replace('Forty-five long-running functions',str(count)+' long-running functions')
old='Repeated packed training, expectation toggling and multi-brick optimizer\nintegrations also use the slow gate.'
newtext='''Repeated packed training, expectation toggling and multi-brick optimizer
integrations also use the slow gate. A further default profile completed only
912 of 4,458 cases in 26.2 minutes before an explicit stop: repeated 20M legacy
builds caused 4–7 GiB footprints and frequent fresh-worker restarts. The same
production-size recurrence, dual-input/tower, symbolic-iteration, decode,
export and per-word compiler fixtures now run with `RUN_SLOW=1`, as do full CLI
training/reconstruction checks. Lightweight geometry, masking, query, dictionary,
checkpoint and compiled-kernel checks remain in the default suite.'''
assert old in s;s=s.replace(old,newtext);p.write_text(s)
print('Added',addition,'function gates; total',count,'in',len(prior),'files')
