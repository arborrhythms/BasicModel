"""Apply the final query-width probe/fix after the current affected run exits."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import re
import shutil

root=Path('/Users/arogers/github/WikiOracle/basicmodel')
work=Path('/tmp/full-spec-registry-worktree')
receipt=Path('/tmp/full-spec-registry-width-followup-applied.json')
assert not receipt.exists()
old=(root/'bin/Queries.py').read_text()
new=(work/'bin/Queries.py').read_text()
assert 'query argument must have the full conceptual width' not in old
assert 'query argument must have the full conceptual width' in new
ast.parse(new)
mapping={}
for op,i,j,a,b in difflib.SequenceMatcher(None,old.splitlines(),new.splitlines(),autojunk=False).get_opcodes():
    assert op in ('equal','insert'),op
    if op=='equal':
        mapping.update({index+1:a+index-i+1 for index in range(i,j)})
owned_path=Path('/tmp/full-spec-registry-owned-paths.txt')
owned=set(owned_path.read_text().splitlines())
pattern=re.compile(r'\[([^\]]+)\]\(((?:\.\./)+bin/Queries\.py)#L(\d+)\)')
changes=[]
def remap(m):
    label,target,line=m.groups()
    mapped=mapping[int(line)]
    changes.append((int(line),mapped))
    return '['+label.replace('Queries.py:'+line,'Queries.py:'+str(mapped))+']('+target+'#L'+str(mapped)+')'
outputs={}
for name in owned:
    if name.endswith('.md'):
        text=(root/name).read_text()
        outputs[name]=pattern.sub(remap,text)
name='doc/QueryContracts.md'
marker='[Invocation]('
assert marker in outputs[name]
outputs[name]=outputs[name].replace(marker,
    'When a ConceptualSpace owner is available, the signature rejects vectors\n'
    'and complete descriptions of a different width before any executor runs.\n'
    +marker,1)
Path('/tmp/full-spec-registry-before-owner-width.py').write_text(old)
shutil.copyfile(work/'bin/Queries.py',root/'bin/Queries.py')
test='test/test_query_owner_width.py'
assert not (root/test).exists()
shutil.copyfile('/tmp/full-spec-query-owner-width-probes.py',root/test)
for name,text in outputs.items():
    (root/name).write_text(text)
owned.add(test)
owned_path.write_text('\n'.join(sorted(owned))+'\n')
receipt.write_text(json.dumps({'links':changes,'old_sha256':hashlib.sha256(old.encode()).hexdigest(),
                             'new_sha256':hashlib.sha256(new.encode()).hexdigest()},indent=2)+'\n')
print('Applied query owner-width check and three reviewer cases;',len(changes),'source links updated.')
