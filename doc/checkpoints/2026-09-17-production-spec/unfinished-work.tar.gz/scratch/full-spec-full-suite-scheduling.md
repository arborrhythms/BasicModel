# Full suite scheduling correction

Registry session 53030 / PID 65321 remains active in the primary checkout.
History session 70651 and phase session 12982 both exited 143 after deliberate SIGTERM.
SIGINT was first requested, but both remained blocked. Sampling showed registry
physical footprint 47.0 GiB (peak 50.1), history 34.8 GiB (peak 40.6), while the
machine has 36 GiB. RSS had hidden compressed memory; all three stopped making
progress. Registry resumed ~91% CPU after stopping the later two.

Do NOT start more concurrent full suites. Finish registry and its commit/push
cycle, then restart history full v4, then phase full v2, serially. Affected tests
and focused probes can run if small. All frozen manifests are still authoritative.
The interrupted history/phase logs are not passing evidence. Tool exits are
recorded in their provenance files. Existing finalizers must accurately preserve
these interrupted-attempt details when successful validation is archived.
