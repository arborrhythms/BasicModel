"""Training test workers must honor an accelerator and keep the quick default."""
import pytest

import bounded_tests as runner


@pytest.mark.parametrize('device', ['gpu', 'mps', 'cuda:0'])
def test_explicit_training_device_is_preserved(tmp_path, monkeypatch, device):
    monkeypatch.setenv('BASICMODEL_DEVICE', device)
    assert runner.worker_environment(tmp_path)['BASICMODEL_DEVICE'] == device


def test_slow_training_defaults_to_a_required_accelerator(tmp_path, monkeypatch):
    monkeypatch.delenv('BASICMODEL_DEVICE', raising=False)
    monkeypatch.setenv('RUN_SLOW', '1')
    assert runner.worker_environment(tmp_path)['BASICMODEL_DEVICE'] == 'gpu'


def test_quick_suite_retains_its_cpu_default(tmp_path, monkeypatch):
    monkeypatch.delenv('BASICMODEL_DEVICE', raising=False)
    monkeypatch.setenv('RUN_SLOW', '0')
    assert runner.worker_environment(tmp_path)['BASICMODEL_DEVICE'] == 'cpu'
