# Hold: explicit user approval required

September 17 steering: Do not remove any unused reasoning methods before checking
with the user; the grammar queries work may introduce their use.

No primary reasoning/test/document deletion was applied or committed. The seven
method, twenty-test removal remains only in /tmp/full-spec-legacy-worktree.
Do not run its installer or include it in a commit until the user has reviewed
and explicitly approved the exact methods. The installer now refuses execution.
Do not infer permission from the earlier broad legacy-cleanup request.
