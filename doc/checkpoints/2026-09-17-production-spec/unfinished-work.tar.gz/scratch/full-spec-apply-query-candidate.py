"""Apply the isolated candidate only after the prepared-answer push cycle."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess


root = Path('/Users/arogers/github/WikiOracle/basicmodel')
candidate = Path('/tmp/full-spec-query-candidate')
head = subprocess.check_output(['git', 'log', '-1', '--format=%s'], cwd=root, text=True).strip()
assert head == 'Require prepared answers before surface generation', head
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root) == subprocess.check_output(
    ['git', 'rev-parse', 'origin/main'], cwd=root), 'prepared commit is not pushed'
parent_pointer = subprocess.check_output(['git', 'ls-tree', 'HEAD', 'basicmodel'], cwd=root.parent, text=True).split()[2]
assert parent_pointer == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root.parent) == subprocess.check_output(
    ['git', 'rev-parse', 'origin/main'], cwd=root.parent), 'parent bump is not pushed'
for manifest, base in [(candidate/'base-manifest.json', root),
                       (candidate/'validation-manifest.json', candidate),
                       (Path('/tmp/full-spec-query-tests/base-manifest.json'), root),
                       (Path('/tmp/full-spec-unowned-after-tied.json'), root)]:
    for name, digest in json.loads(manifest.read_text()).items():
        assert hashlib.sha256((base/name).read_bytes()).hexdigest() == digest, str(base/name)

sources = ['Meaning.py', 'Layers.py', 'Models.py', 'reasoning.py', 'thinking.py']
tests = {
    '/tmp/full-spec-existence-probes.py': 'test/test_existence_evidence.py',
    '/tmp/full-spec-existence-metadata-probes.py': 'test/test_existence_metadata.py',
    '/tmp/full-spec-existence-ingestion-probes.py': 'test/test_existence_ingestion.py',
    '/tmp/full-spec-existence-provenance-path-probes.py': 'test/test_existence_provenance.py',
    '/tmp/full-spec-existence-sidecar-probes.py': 'test/test_existence_sidecar.py',
    '/tmp/full-spec-existence-public-input-probes.py': 'test/test_existence_public_inputs.py',
}
for name in sources:
    if name == 'Meaning.py':
        assert not (root/'bin'/name).exists()
for destination in tests.values():
    assert not (root/destination).exists(), destination
for name in sources:
    shutil.copyfile(candidate/name, root/'bin'/name)
for source, destination in tests.items():
    content = Path(source).read_text()
    content = content.replace('Draft probes for the next bounded item; not installed or executed yet.',
                              'Complete descriptions, evidence provenance, and checkpoint ownership.')
    content = content.replace('Draft next-item probes against existing APIs; do not install until the prepared-answer commit cycle finishes.',
                              'Existence evidence must match the complete conceptual description.')
    (root/destination).write_text(content)
shutil.copyfile('/tmp/full-spec-query-tests/test_truth_grounded_reasoning.py', root/'test/test_truth_grounded_reasoning.py')
owned = ['bin/'+name for name in sources] + list(tests.values()) + ['test/test_truth_grounded_reasoning.py']
Path('/tmp/full-spec-query-owned-paths.txt').write_text('\n'.join(sorted(owned))+'\n')
print('Installed', len(sources), 'runtime files and', len(tests)+1, 'test files.')
