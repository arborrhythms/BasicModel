from pathlib import Path
import ast,json,shutil,subprocess,sys
primary=Path('/Users/arogers/github/WikiOracle/basicmodel')
candidate=Path('/tmp/full-spec-thought-worktree')
dry=Path('/tmp/full-spec-history-docs-sept17-dry-run-v2');assert not dry.exists()
root=dry/'repo';base=dry/'base';work=dry/'work'
for p in [root/'bin',root/'doc',base/'bin',work]:p.mkdir(parents=True)
for p in (primary/'bin').glob('*.py'):
 source=candidate/'bin'/p.name if (candidate/'bin'/p.name).exists() else p
 (root/'bin'/p.name).symlink_to(source)
for p in (candidate/'bin').glob('*.py'):
 if not (root/'bin'/p.name).exists():(root/'bin'/p.name).symlink_to(p)
for name in json.loads((candidate/'base-manifest.json').read_text()):
 target=base/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(primary/name,target)
shutil.copyfile(candidate/'validation-manifest.json',work/'validation-manifest.json')
source=Path('/tmp/full-spec-install-thought-history-docs.py').read_text()
names=next(ast.literal_eval(n.value) for n in ast.parse(source).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='names' for t in n.targets))
for name in names:
 target=root/name;target.parent.mkdir(parents=True,exist_ok=True)
 source_file=primary/name if (primary/name).exists() else Path('/tmp/full-spec-fixed-capacity-future-work.md')
 assert (primary/name).exists() or name=='doc/plans/2026-09-17-bounded-fixture-reuse.md'
 shutil.copyfile(source_file,target)
owned=dry/'owned.txt';owned.write_text('bin/Thoughts.py\n')
for old,new in {
 str(primary):str(root),str(candidate):str(work),
 '/tmp/full-spec-thought-history-base':str(base),
 '/tmp/full-spec-thought-history-doc-remap-applied.json':str(dry/'remap.json'),
 '/tmp/full-spec-thought-history-line-maps.json':str(dry/'line-maps.json'),
 '/tmp/full-spec-thought-history-owned-paths.txt':str(owned)}.items():source=source.replace(old,new)
script=dry/'render.py';script.write_text(source)
r=subprocess.run([sys.executable,str(script)],capture_output=True,text=True)
(dry/'render.log').write_text(r.stdout+r.stderr)
print('Renderer exit',r.returncode)
print((r.stdout+r.stderr)[-2200:])
raise SystemExit(r.returncode)
