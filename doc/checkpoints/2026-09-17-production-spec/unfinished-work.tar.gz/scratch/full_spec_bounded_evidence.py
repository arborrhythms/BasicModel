from pathlib import Path
from collections import Counter
import hashlib,json,re,shutil

def verified_run(directory, root=None):
 directory=Path(directory)
 receipt=json.loads((directory/'result.json').read_text())
 assert receipt['exit_code']==0 and receipt['reason']=='passed',receipt.get('reason')
 assert receipt['selected'] and Counter(receipt['selected'])==Counter(receipt['completed'])
 counts=Counter();summaries=[]
 for worker in receipt['workers']:
  assert worker['exit_code']==0,worker
  text=Path(worker['log']).read_text()
  lines=[line for line in text.splitlines() if re.search(r'\bin [0-9.]+s(?: |$)',line)]
  assert lines,worker['log']
  summary=lines[-1];summaries.append(summary)
  for number,kind in re.findall(r'(\d+) (passed|skipped|xfailed|xpassed|failed|errors?|subtests passed)',summary):
   counts[kind]+=int(number)
 assert counts['failed']==counts['error']==counts['errors']==counts['xpassed']==0,counts
 assert counts['passed']+counts['skipped']+counts['xfailed']==len(receipt['selected']),counts
 frozen=json.loads((directory/'source-manifest.json').read_text())
 if root is not None:
  for name,digest in frozen.items():
   assert hashlib.sha256((Path(root)/name).read_bytes()).hexdigest()==digest,name
 peak=max(w['peak_memory_bytes'] for w in [receipt['collection'],*receipt['workers']])
 summary=', '.join(f'{counts[key]} {key}' for key in ('passed','skipped','xfailed','subtests passed') if counts[key])
 summary+=f" in {receipt['elapsed_seconds']:.2f}s; peak aggregate footprint {peak/1024**3:.2f} GiB"
 return dict(summary=summary,counts=dict(counts),receipt=receipt,manifest=frozen,worker_summaries=summaries)

def archive_run(directory, destination, prefix, result):
 directory,destination=Path(directory),Path(destination)
 for source,name in [('result.json',prefix+'-result.json'),('source-manifest.json',prefix+'-source-manifest.json')]:
  shutil.copyfile(directory/source,destination/name)
 (destination/(prefix+'-summaries.log')).write_text('\n'.join(result['worker_summaries'])+'\n'+result['summary']+'\n')
