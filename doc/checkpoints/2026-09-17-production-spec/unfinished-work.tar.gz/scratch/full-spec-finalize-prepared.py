"""Record the completed prepared-answer gate; invoke after pytest exits zero."""
from pathlib import Path
import hashlib
import json
import re
import shutil

root = Path('/Users/arogers/github/WikiOracle/basicmodel')
log = Path('/tmp/full-spec-prepared-full-v1.log')
content = log.read_text()
summary = next((line.strip('= ').strip() for line in reversed(content.splitlines())
                if re.search(r'\d+ passed, .* in [\d.]+s', line)), None)
assert summary and 'failed' not in summary.replace('xfailed',''), summary
for path in ['/tmp/full-spec-prepared-validation-frozen.json', '/tmp/full-spec-unowned-after-tied.json']:
    manifest = json.loads(Path(path).read_text())
    for name, digest in manifest.items():
        assert hashlib.sha256((root/name).read_bytes()).hexdigest() == digest, name
    print('Verified', len(manifest), 'files from', path)

evidence = root/'doc/benchmarks/2026-09-16-prepared-answer-data'
shutil.copyfile(log, evidence/'full-suite-green.log')
shutil.copyfile('/tmp/full-spec-prepared-validation-frozen.json', evidence/'full-suite-source-manifest.json')
spec = root/'doc/plans/2026-09-15-next-sentence-as-the-production-objective.md'
text = spec.read_text()
assert '## 14. Prepared-answer boundary (in progress)' in text
text = text.replace('## 14. Prepared-answer boundary (in progress)', '## 14. Prepared-answer boundary (verified)')
text = text.replace('The background full suite is running.',
                    'The full suite also passes: **'+summary+'**, with exit status zero.\n'
                    '[Full-suite green](../benchmarks/2026-09-16-prepared-answer-data/full-suite-green.log),\n'
                    '[frozen source manifest](../benchmarks/2026-09-16-prepared-answer-data/full-suite-source-manifest.json).')
text += '\nFull-suite command, from `basicmodel/` (runtime, tests and configuration frozen throughout):\n\n```bash\nDEVELOPER_DIR=/Library/Developer/CommandLineTools OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 .venv/bin/python -m pytest test -q -x -p no:cacheprovider\n```\n'
spec.write_text(text)
message = Path('/tmp/full-spec-prepared-commit-message.txt')
message.write_text(message.read_text().replace(
    'Validation: seven boundary probes and 109 affected tests passed; full-suite result to be recorded before commit.',
    'Validation: seven boundary probes and 109 affected tests passed. Full suite: '+summary+'.'))
whitelist = Path('/tmp/full-spec-prepared-owned-paths.txt')
paths = set(whitelist.read_text().splitlines())
paths.update(str(path.relative_to(root)) for path in [evidence/'full-suite-green.log', evidence/'full-suite-source-manifest.json'])
whitelist.write_text('\n'.join(sorted(paths))+'\n')
print(summary)
print('Prepared commit whitelist:',len(paths),'paths')
