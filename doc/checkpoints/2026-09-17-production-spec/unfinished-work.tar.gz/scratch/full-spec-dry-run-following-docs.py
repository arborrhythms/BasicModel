from pathlib import Path
import ast,hashlib,json,shutil,subprocess,sys
primary=Path('/Users/arogers/github/WikiOracle/basicmodel')
dry=Path('/tmp/full-spec-history-docs-sept17-dry-run');root=dry/'repo'
for slug,folder in [('query-phase','phase'),('nested-retention','nested'),('query-work','query-work')]:
 candidate=Path('/tmp/full-spec-'+folder+'-worktree')
 stage=dry/slug;base=stage/'base';work=stage/'work'
 assert not stage.exists();base.mkdir(parents=True);work.mkdir()
 base_manifest=json.loads((candidate/'base-manifest.json').read_text())
 for name,digest in base_manifest.items():
  assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,(slug,name)
  target=base/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/name,target)
 validated=json.loads((candidate/'validation-manifest.json').read_text())
 for name,digest in validated.items():
  assert hashlib.sha256((candidate/name).read_bytes()).hexdigest()==digest,(slug,name)
  target=root/name
  if target.is_symlink():target.unlink()
  shutil.copyfile(candidate/name,target)
 shutil.copyfile(candidate/'validation-manifest.json',work/'validation-manifest.json')
 source=Path('/tmp/full-spec-install-'+slug+'-docs.py').read_text()
 names=next(ast.literal_eval(n.value) for n in ast.parse(source).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='names' for t in n.targets))
 for name in names:
  if not (root/name).exists():
   target=root/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(primary/name,target)
 owned=stage/'owned.txt';owned.write_text('\n'.join(validated)+'\n')
 for old,new in {
  str(primary):str(root),str(candidate):str(work),
  '/tmp/full-spec-'+slug+'-base':str(base),
  '/tmp/full-spec-'+slug+'-doc-remap-applied.json':str(stage/'remap.json'),
  '/tmp/full-spec-'+slug+'-line-maps.json':str(stage/'line-maps.json'),
  '/tmp/full-spec-'+slug+'-owned-paths.txt':str(owned)}.items():source=source.replace(old,new)
 script=stage/'render.py';script.write_text(source)
 r=subprocess.run([sys.executable,str(script)],capture_output=True,text=True)
 (stage/'render.log').write_text(r.stdout+r.stderr)
 print(slug,'renderer exit',r.returncode);print((r.stdout+r.stderr)[-1600:])
 if r.returncode:raise SystemExit(r.returncode)
