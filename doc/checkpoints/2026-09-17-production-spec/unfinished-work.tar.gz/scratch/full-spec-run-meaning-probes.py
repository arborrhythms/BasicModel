"""Run a selected isolated probe group under the shared finite test guard."""
from pathlib import Path
import argparse
import json
import os
import sys

root = Path('/Users/arogers/github/WikiOracle/basicmodel')
work = Path('/tmp/full-spec-meaning-worktree')
sys.path.insert(0, str(root / 'test'))
from bounded_tests import run_guarded, suite_lock, worker_environment

parser = argparse.ArgumentParser()
parser.add_argument('group', choices=('pure', 'meaning', 'oracle', 'oracle-training', 'renaming'))
parser.add_argument('label')
args = parser.parse_args()
selection = {
    'pure': '/tmp/full-spec-pure-query-compose-probes.py',
    'meaning': '/tmp/full-spec-selected-relation-meaning-probes.py',
    'oracle': '/tmp/full-spec-arithmetic-isolation-probes.py::test_numeric_sentence_paths_use_learned_representations_with_oracles_poisoned',
    'oracle-training': '/tmp/full-spec-arithmetic-isolation-probes.py::test_supervised_training_cannot_use_exact_arithmetic_or_fallback_codes',
    'renaming': '/tmp/full-spec-arithmetic-isolation-probes.py::test_taxonomy_query_uses_relations_and_payloads_under_native_id_renaming',
}[args.group]
log = Path('/tmp/full-spec-' + args.label + '.log')
result_path = Path('/tmp/full-spec-' + args.label + '.process.json')
assert not log.exists() and not result_path.exists()
env = worker_environment(root)
env['PYTHONPATH'] = os.pathsep.join((str(work / 'bin'), str(root / 'test'), str(root / 'bin')))
env['MODEL_COMPILE'] = 'none'
env['DEVELOPER_DIR'] = '/Library/Developer/CommandLineTools'
env['RUN_SLOW'] = '1' if args.group == 'oracle-training' else '0'
source = (
    "import Language,Models,Queries,pytest; "
    "assert '/full-spec-meaning-worktree/' in Language.__file__; "
    "assert '/full-spec-meaning-worktree/' in Models.__file__; "
    f"raise SystemExit(pytest.main({['-q', '--tb=short', '-p', 'slow_tests', selection]!r}))"
)
with suite_lock():
    result = run_guarded([sys.executable, '-c', source], cwd=work, env=env,
        log_path=log, memory_bytes=2 * 1024**3,
        timeout=300 if args.group.startswith('oracle') else 120)
result_path.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
print(log.read_text()[-14000:])
raise SystemExit(result['exit_code'])
