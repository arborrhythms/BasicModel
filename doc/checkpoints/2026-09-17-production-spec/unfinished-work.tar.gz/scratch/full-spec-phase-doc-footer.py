for name,text in outputs.items():
    assert '@@' not in text,name
    for target,line in re.findall(r'\]\(((?:\.\./)+bin/[^)#]+\.py)#L(\d+)\)',text):
        file=((root/name).parent/target).resolve()
        assert file.is_file() and 1<=int(line)<=len(file.read_text().splitlines()),(name,target,line)
for name,text in outputs.items():
    (root/name).write_text(text)
receipt.write_text(json.dumps(changes,indent=2)+'\n')
Path('/tmp/full-spec-query-phase-line-maps.json').write_text(json.dumps(maps)+'\n')
(work/'source-anchors.json').write_text(json.dumps(anchors,indent=2)+'\n')
owned=Path('/tmp/full-spec-query-phase-owned-paths.txt')
owned.write_text('\n'.join(sorted(set(owned.read_text().splitlines())|set(outputs)))+'\n')
print('Updated',len(outputs),'documents;',len(changes),'local source links remapped once.')
print('Definition/adjacent fallbacks:',[x for x in changes if x['kind']!='exact'])
