from pathlib import Path
import ast,re,json
root=Path('/Users/arogers/github/WikiOracle/basicmodel')
assert json.loads(Path('/tmp/full-spec-fast-native-fixture-green-v1.process.json').read_text())['exit_code']==0
assert json.loads(Path('/tmp/full-spec-slow-gates-affected-v1/result.json').read_text())['exit_code']==0
p=root/'test/test_output_path_supervised.py';s=p.read_text()
a=s.index('def _native_answer_model(');b=s.index('\n\n@pytest.mark.parametrize',a)
helper=Path('/tmp/full-spec-native-fixture-helper.txt').read_text()
s=s[:a]+helper+s[b:]
names=['test_native_answer_uses_owned_ideas_without_dense_symbol_state',
       'test_native_realized_answer_loss_trains_the_active_conditioner',
       'test_native_thinking_changes_the_owned_conceptual_answer',
       'test_native_checkpoint_restores_active_answer_widths']
funcs={n.name:n for n in ast.parse(s).body if isinstance(n,ast.FunctionDef)}
lines=s.splitlines(keepends=True)
for name in sorted(names,key=lambda x:funcs[x].lineno,reverse=True):
 n=funcs[name];first=min([n.lineno]+[d.lineno for d in n.decorator_list])-1
 part=''.join(lines[first:n.end_lineno])
 part='@pytest.mark.parametrize("concept_width", _NATIVE_CONCEPT_WIDTHS)\n'+part
 part=re.sub(r'(def '+re.escape(name)+r'\([^\n]+)\):',r'\1, concept_width):',part)
 part=part.replace('_native_answer_model(tmp_path, output_loop)', '_native_answer_model(tmp_path, output_loop, concept_width=concept_width)')
 part=part.replace('_native_answer_model(tmp_path, False)', '_native_answer_model(tmp_path, False, concept_width=concept_width)')
 part=part.replace('_native_answer_model(folder, False)', '_native_answer_model(folder, False, concept_width=concept_width)')
 part=part.replace('["1032"]','[str(concept_width)]')
 part=re.sub(r'\b1032\b','concept_width',part)
 lines[first:n.end_lineno]=[part]
s=''.join(lines)
s=s.replace('def _native_answer_model(', '_NATIVE_CONCEPT_WIDTHS = [\n    pytest.param(264, id="development"),\n    pytest.param(1032, id="production", marks=pytest.mark.slow),\n]\n\n\ndef _native_answer_model(',1)
ast.parse(s);p.write_text(s)
p=root/'doc/Testing.md';s=p.read_text();needle='explicitly when their corresponding training paths change.';assert needle in s
s=s.replace(needle,needle+'\n\nNative answer fixtures use 264-wide concepts and 136-wide percepts during\ndevelopment. Their ownership, checkpoint and gradient checks retain distinct\nwidths. Seven corresponding 1032-wide cases remain available under `RUN_SLOW=1`.\nThe compact numerical readout and metadata tests continue covering larger\nproduction shapes without materializing their full training graph.')
p.write_text(s)
Path('/tmp/full-spec-native-fixture-widths.json').write_text(json.dumps(dict(development=264,production=1032,percepts=136,parameterized_functions=names,slow_cases=7),indent=2)+'\n')
print('Installed compact development fixtures and seven production-width slow cases.')
