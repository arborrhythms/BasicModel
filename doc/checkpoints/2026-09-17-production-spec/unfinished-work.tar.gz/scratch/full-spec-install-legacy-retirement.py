raise SystemExit('HELD: September 17 user requires approval of specific unused reasoning methods before removal; no approval received.')
"""Install reviewed retirement only when the preceding push cycle is complete."""
from pathlib import Path
import ast,difflib,hashlib,json,re,shutil,subprocess
root=Path('/Users/arogers/github/WikiOracle/basicmodel'); work=Path('/tmp/full-spec-legacy-worktree')
assert not subprocess.check_output(['git','diff','HEAD','--','bin','test','data'],cwd=root)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).strip()
assert head==subprocess.check_output(['git','rev-parse','origin/main'],cwd=root).strip()
assert head==subprocess.check_output(['git','rev-parse','HEAD:basicmodel'],cwd=root.parent).strip()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root.parent)==subprocess.check_output(['git','rev-parse','origin/main'],cwd=root.parent)
base=json.loads((work/'base-manifest.json').read_text()); candidate=json.loads((work/'validation-manifest.json').read_text())
for name,d in base.items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==d,name
for name,d in candidate.items():assert hashlib.sha256((work/name).read_bytes()).hexdigest()==d,name
assert not (root/'test/test_legacy_query_retirement.py').exists()
snapshot=Path('/tmp/full-spec-legacy-retirement-base');assert not snapshot.exists()
old=(root/'bin/reasoning.py').read_text();new=(work/'bin/reasoning.py').read_text()
def defs(text):
 found={}
 def visit(n,path=()):
  if isinstance(n,(ast.FunctionDef,ast.ClassDef)):
   path=path+(n.name,);found['.'.join(path)]=(n.lineno,n.end_lineno)
  for c in ast.iter_child_nodes(n):visit(c,path)
 visit(ast.parse(text));return found
old_defs,new_defs=defs(old),defs(new)
maplines={}
for op,i,j,a,b in difflib.SequenceMatcher(None,old.splitlines(),new.splitlines(),autojunk=False).get_opcodes():
 for x in range(i,j):
  if op=='equal':maplines[x+1]=a+(x-i)+1
  else:
   enclosing=[(hi-lo,k) for k,(lo,hi) in old_defs.items() if lo<=x+1<=hi and k in new_defs]
   maplines[x+1]=new_defs[min(enclosing)[1]][0] if enclosing else min(len(new.splitlines()),a+1)
def link(name,prefix='../bin/'):
 return prefix+'reasoning.py#L'+str(new_defs[name][0])
outputs={}
protected=json.loads(Path('/tmp/full-spec-unowned-after-tied.json').read_text())
for p in (root/'doc').rglob('*.md'):
 name=str(p.relative_to(root))
 if name in protected or '/benchmarks/' in name:continue
 s=p.read_text()
 if re.search(r'(?:\.\./)+bin/reasoning\.py#L',s):outputs[name]=s
# Replace statements about removed behavior before remapping surviving lines.
name='doc/TaxonomyQueries.md';s=outputs[name]
a=s.index('Old geometric/world-row helper methods');b=s.index('\n\n[Query contracts]',a)
s=s[:a]+('The unused vector-proposal/materialization loop and its obsolete tests have\n'
 'been removed. The separately enabled legacy prediction and answer-policy\n'
 'objectives still have active callers and keep their required geometric helpers.\n'
 'Public PartOf uses checked conceptual-taxonomy evidence.\n'
 f'[Public entry]({link("NeuralToolUser.run")}),\n'
 f'[optional prediction]({link("NeuralToolUser.reason_predict_next")}),\n'
 f'[optional answer objective]({link("policy_answer_loss")}).\n'
 'See [Legacy retirement](LegacyRetirement.md) for the exact removal and evidence.')+s[b:]
# These freshly rendered links must not receive the old-source mapping.
outputs[name]=s.replace('../bin/reasoning.py#L','@@CURRENT_REASONING@@')
name='doc/Training.md';s=outputs[name]
s=s.replace('materialize world facts. Old geometric/world-row experiments remain under\nexplicit `legacy_...` helpers and `run_legacy_world`; their optional policy\nobjectives are not the default sentence-expectation controller. No new loss\nor learned parameters were added.',
 'materialize world facts. The unused world-proposal/materialization loop is\nremoved. The separately enabled prediction and answer-policy objectives retain\nthe helpers their active callers require. No loss or learned parameter changes\nare part of this retirement.')
s=s.replace('[legacy experiment](../bin/reasoning.py#L772),\n','')
outputs[name]=s
name='doc/ExistenceEvidence.md';s=outputs[name]
s=s.replace('The legacy Part testimony/materialization adapter has no grammatical VP;\nthose rows remain `unverified` for Exist until the structured-query migration.',
 'The legacy Part testimony adapter has no grammatical VP; those rows remain\n`unverified` for Exist until the structured-query migration. The unused\nworld-relation materialization entry has been removed.')
s=s.replace('[Legacy materialization](../bin/reasoning.py#L507).','See [Legacy retirement](LegacyRetirement.md).')
outputs[name]=s
name='doc/plans/2026-09-15-next-sentence-as-the-production-objective.md';s=outputs[name]
s=s.replace('geometric/world-row experiments remain explicitly named compatibility paths.\n[Curriculum](../../bin/thinking.py#L621),\n[legacy proposal](../../bin/reasoning.py#L772).',
 'optional prediction/answer experiments retain their required geometric helpers.\nThe unused world-proposal/materialization loop and its obsolete tests are\nremoved; see [Legacy retirement](../LegacyRetirement.md).\n[Curriculum](../../bin/thinking.py#L621).')
outputs[name]=s
pattern=re.compile(r'\[([^\]]+)\]\(((?:\.\./)+bin/reasoning\.py)#L(\d+)\)')
changes=[]
def remap(m):
 label,target,line=m.groups();now=maplines[int(line)];changes.append((int(line),now))
 return '['+label.replace('reasoning.py:'+line,'reasoning.py:'+str(now))+']('+target+'#L'+str(now)+')'
for name,s in list(outputs.items()):
 if '/plans/' in name:
  protected_section=False;parts=[]
  for part in re.split(r'(?=^## |^### )',s,flags=re.M):
   if part.startswith('## '):protected_section=part.startswith(('## 6.','## 7.','## 11.'))
   if part.startswith('### 11.6 '):protected_section=False
   parts.append(part if protected_section else pattern.sub(remap,part))
  s=''.join(parts)
 else:s=pattern.sub(remap,s)
 outputs[name]=s.replace('@@CURRENT_REASONING@@','../bin/reasoning.py#L')
outputs['doc/LegacyRetirement.md']='''# Legacy query retirement

The unused world-row query chain and materialization loop had no runtime callers
outside their own obsolete tests. The checked public PartOf route already uses
conceptual taxonomy evidence. This retirement removes seven methods:

- `TruthGroundedReasoner.legacy_parts`, `legacy_is_part`, `legacy_materialize`,
  `_legacy_creates_cycle` and `_legacy_refuting_direct`.
- `NeuralToolUser.run_legacy_world` and `_generate_chain`.

It also removes the unused `materialize_floor` constructor setting and twenty
tests solely exercising the retired chain. Four reviewer cases verify the old
execution/write entries are unavailable. Retained regression coverage checks
public taxonomy evidence, LTM existence evidence and optional policy training.

The optional `reason_predict_next` and `policy_answer_loss` objectives still
have active callers; their necessary geometric helpers remain until that
controller migration. No learned parameter, objective or gradient boundary
changes in this deletion.
'''+f'[Public query]({link("NeuralToolUser.run")}),\n[optional prediction]({link("NeuralToolUser.reason_predict_next")}),\n[optional policy loss]({link("policy_answer_loss")}).\n\n'+'''## Validation

Reviewer probes failed before removal. The isolated candidate passed 53 selected
cases. Primary affected files and the complete default suite are pending.
'''
for name in base:
 target=snapshot/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/name,target)
owned=list(candidate)
for name in candidate:shutil.copyfile(work/name,root/name)
shutil.copyfile(work/'test/test_legacy_query_retirement.py',root/'test/test_legacy_query_retirement.py');owned.append('test/test_legacy_query_retirement.py')
for name,s in outputs.items():
 p=root/name
 if not p.exists() or p.read_text()!=s:p.write_text(s);owned.append(name)
Path('/tmp/full-spec-legacy-retirement-owned-paths.txt').write_text('\n'.join(sorted(owned))+'\n')
Path('/tmp/full-spec-legacy-retirement-doc-remap-applied.json').write_text(json.dumps(changes,indent=2)+'\n')
print('Installed',len(owned),'owned paths; primary validation required.')
