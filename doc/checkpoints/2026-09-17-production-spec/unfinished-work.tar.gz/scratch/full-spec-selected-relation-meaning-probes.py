"""Owned compose actions preserve semantic operands lost by their folded root."""
from types import SimpleNamespace
import pytest
import torch

import Language
from Understanding import AnswerProgram
from test_query_vp_boundaries import _world


def _program_owner(monkeypatch, *, face='part', interrogative=False):
    cs, grammar, registry, a, b, context = _world()
    selected=next(i for i,r in enumerate(grammar.rules_upward)
                  if r.space_role=='CS' and r.method_name==face and r.arity==2)
    grammar.rules_upward[selected]=grammar.rules_upward[selected]._replace(query=interrogative)
    binary=tuple(i for i,r in enumerate(grammar.rules_upward) if r.space_role=='CS' and r.arity==2)
    unary=tuple(i for i,r in enumerate(grammar.rules_upward) if r.space_role=='CS' and r.arity==1)
    def bank(ids):
        return SimpleNamespace(ops=tuple(
            Language.GRAMMAR_LAYER_CLASSES[face]() if i==selected else None for i in ids))
    layer=SimpleNamespace(_binary_rule_ids={'CS':binary},_unary_rule_ids={'CS':unary},
                          _binary_layers={'CS':bank(binary)},_unary_layers={'CS':bank(unary)})
    monkeypatch.setattr(Language,'TheGrammar',grammar)
    owner=Language.LanguageSpace(SimpleNamespace(subspace=SimpleNamespace(languageLayer=layer)))
    local=binary.index(selected)
    leaves=torch.stack((-.25*registry._payload(a),.75*registry._payload(b))).detach().requires_grad_()
    folded=layer._binary_layers['CS'].ops[local].compose(
        leaves[0].reshape(1,1,-1),leaves[1].reshape(1,1,-1)).reshape(-1)
    end=torch.cat((folded.unsqueeze(0),leaves.new_zeros(2,leaves.shape[-1])))
    def program(values=leaves,refs=(a,b)):
        return AnswerProgram(rows=torch.tensor([3,5]),word_rows=torch.tensor([7,9]),
            activations=torch.tensor([-.25,.75]),leaves=values,
            actions=torch.tensor([[0,-1,0],[0,-1,1],[1,local,-1]]),
            targets=torch.tensor([local,-1]),end_state=end,
            concept_ids=torch.tensor([r[1] for r in refs]))
    return cs,grammar,registry,owner,leaves,program,a,b


@pytest.mark.parametrize('face,order',[('part',(0,1)),('whole',(1,0)),('equal',(0,1))])
@pytest.mark.parametrize('interrogative',[False,True])
def test_selected_binary_relation_preserves_signed_operands_middle_vp_and_mode(monkeypatch,face,order,interrogative):
    cs,grammar,registry,owner,leaves,program,a,b=_program_owner(
        monkeypatch,face=face,interrogative=interrogative)
    entry=program(); before=entry.actions.clone()
    meaning=owner.program_meaning(entry,registry)
    canonical=registry.form(face,a,b,mode='interrogative' if interrogative else 'assertive')
    assert meaning.role_refs==canonical.role_refs
    assert meaning.mode==canonical.mode and meaning.polarity
    assert meaning.role_mask.tolist()==[True,True,True]
    torch.testing.assert_close(meaning.roles[1],canonical.roles[1])
    torch.testing.assert_close(meaning.roles[0],leaves[order[0]])
    torch.testing.assert_close(meaning.roles[2],leaves[order[1]])
    torch.testing.assert_close(entry.actions,before)
    (meaning.roles[0].sum()+2*meaning.roles[2].sum()).backward()
    expected=torch.empty_like(leaves);expected[order[0]]=1;expected[order[1]]=2
    torch.testing.assert_close(leaves.grad,expected)


def test_changed_part_operand_remains_distinguishable_when_folded_root_is_identical(monkeypatch):
    cs,grammar,registry,owner,leaves,program,a,b=_program_owner(monkeypatch)
    other=leaves.detach().clone();other[0]*=3
    first,second=program(),program(other)
    torch.testing.assert_close(first.end_state,second.end_state)
    x,y=(owner.program_meaning(p,registry) for p in (first,second))
    assert not torch.equal(x.roles[0],y.roles[0])
    torch.testing.assert_close(x.roles[1:],y.roles[1:])


def test_native_addresses_do_not_become_semantic_operand_values(monkeypatch):
    cs,grammar,registry,owner,leaves,program,a,b=_program_owner(monkeypatch)
    aliases=[]
    for original in (a,b):
        ref=('sym',cs.new_concept());row=cs._csw_concept_row(0,ref[1]);aliases.append(ref)
        with torch.no_grad():cs.similarity_codebook.getW()[row].copy_(registry._payload(original))
    first=owner.program_meaning(program(),registry)
    renamed=owner.program_meaning(program(refs=tuple(aliases)),registry)
    torch.testing.assert_close(first.roles,renamed.roles)
    assert renamed.role_refs[0]==aliases[0] and renamed.role_refs[2]==aliases[1]


def test_owned_local_rule_meaning_survives_global_grammar_reconfiguration(monkeypatch):
    cs,grammar,registry,owner,leaves,program,a,b=_program_owner(monkeypatch,interrogative=True)
    entry=program()
    grammar.configure({'compose':{'S':['sum(S,S)']}})
    meaning=owner.program_meaning(entry,registry)
    assert meaning.mode=='interrogative'
    assert meaning.role_refs==registry.form('isPart',a,b).role_refs
    torch.testing.assert_close(meaning.roles[0],leaves[0])


@pytest.mark.parametrize('path',['pending','packed'])
def test_observation_boundary_uses_selected_relation_before_prediction_and_ltm(monkeypatch,path):
    from Models import BasicModel
    from Layers import TernaryTruthStore
    cs,grammar,registry,owner,leaves,program,a,b=_program_owner(monkeypatch,interrogative=True)
    entry=program();slots=entry.end_state.unsqueeze(0)
    calls=[]
    def predict(depths,payloads,**kwargs):calls.append((depths,payloads,kwargs))
    discourse=SimpleNamespace(observe_stm_end_state=lambda *a:None,
                              predict_and_observe_stm_end_state=predict,
                              expectation_scope='structured')
    store=TernaryTruthStore(8,capacity=16)
    host=SimpleNamespace(
        conceptualSpace=SimpleNamespace(_ltm_consolidation=True,stm_end_state_trust=lambda *a:torch.tensor([.9])),
        symbolSpace=SimpleNamespace(ltm_store=store,discourse=discourse),
        languageSpace=owner,grammatical_queries=registry,
        _capture_answer_programs=lambda:((entry,),{0:(entry,)}),
        _expectation_documents_for_slot=lambda *a:['doc'])
    monkeypatch.setattr(registry,'execute',lambda *a,**k:pytest.fail('query executed during observation'))
    if path=='pending':
        host._pending_stm_end_state=(slots,torch.tensor([1]),torch.tensor([True]))
        BasicModel._drain_pending_stm_end_state(host)
        BasicModel._drain_pending_stm_end_state(host)
    else:
        host._packed_sentence_roots=slots[:,:1]
        host._tensor_sentence_roots_live=slots.reshape(1,1,-1)
        host._tensor_sentence_roots_depth=torch.tensor([[1]])
        host._tensor_final_end_slots=slots;host._tensor_final_end_depth=torch.tensor([1])
        host.inputSpace=SimpleNamespace(_packed_sentence_slot_end_positions=torch.tensor([[1]]),
            _packed_sentence_slot_mask=torch.tensor([[True]]),_packed_sentence_counts_host=(1,))
        BasicModel._drain_packed_stm_end_states(host)
    assert len(store)==1 and len(calls)==1
    stored=store.meaning_of(0)
    assert stored.mode=='interrogative'
    assert stored.role_refs==registry.form('isPart',a,b).role_refs
    assert stored.role_mask.tolist()==[True,True,True]
    assert store.row(0)['kind'] in ('question','observation')
    assert calls[0][0]==[3]
    assert calls[0][2]['layout']=='infix'
    torch.testing.assert_close(calls[0][1][0][0],leaves[0])
    torch.testing.assert_close(calls[0][1][0][2],leaves[1])
    assert not stored.roles.requires_grad
    assert calls[0][1][0].requires_grad
