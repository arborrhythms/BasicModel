"""Full-spec review: a surviving occurrence must not lose its constituents."""
import copy

import pytest
import torch

from Layers import TernaryTruthStore
from Meaning import ConceptualMeaning


def _meaning(*, child=None, mode='assertive', scope=(), twice=False):
    return ConceptualMeaning(torch.eye(6)[:3], torch.ones(3, dtype=torch.bool),
        mode=mode, role_refs=(child if twice else None, ('sym', 17), child),
        scope=scope)


def _index(store, reference):
    return next((i for i in range(len(store)) if store.occurrence_of(i) == reference), None)


def _unchanged(store, before):
    for name, value in before.items():
        torch.testing.assert_close(store.state_dict()[name], value)


def test_origin_replacement_retains_reachable_content_without_retaining_its_fact_authority():
    s = TernaryTruthStore(6, capacity=8)
    leaf = s.append_meaning(_meaning(scope={'quote': 'inner'}), trust=.8)
    s.set_origin(leaf, s.ORIGIN_USER, text='reported content')
    leaf_ref = s.occurrence_of(leaf)
    inner = s.append_meaning(_meaning(child=leaf_ref, mode='interrogative'), kind='question')
    s.set_origin(inner, s.ORIGIN_USER)
    inner_ref = s.occurrence_of(inner)
    root = s.append_meaning(_meaning(child=inner_ref, scope={'speaker': 'outer'}), kind='observation')
    root_ref = s.occurrence_of(root)
    orphan = s.append_meaning(_meaning(), trust=.7)
    s.set_origin(orphan, s.ORIGIN_USER)

    assert s.clear_origin(s.ORIGIN_USER) == 1
    assert len(s) == 3
    for reference in (leaf_ref, inner_ref, root_ref):
        assert _index(s, reference) is not None, 'compaction discarded a reachable occurrence'
    kept = s.row(_index(s, leaf_ref))
    assert kept['kind'] == 'unverified' and kept['trust'] == 0
    assert kept['text'] == 'reported content'
    assert kept['meaning'].scope == (('quote', 'inner'),)
    assert s.meaning_of(_index(s, inner_ref)).mode == 'interrogative'
    assert s.clear_origin(s.ORIGIN_USER) == 0


def test_external_live_root_can_pin_an_occurrence_through_origin_replacement():
    s = TernaryTruthStore(6, capacity=3)
    row = s.append_meaning(_meaning(), trust=1)
    s.set_origin(row, s.ORIGIN_USER)
    ref = s.occurrence_of(row)
    assert s.clear_origin(s.ORIGIN_USER, retained_occurrences=(ref,)) == 0
    assert s.row(0)['occurrence'] == ref
    assert s.row(0)['kind'] == 'unverified'
    assert s.clear_origin(s.ORIGIN_USER) == 1


def test_missing_local_constituent_is_rejected_before_any_append_mutation():
    s = TernaryTruthStore(6, capacity=3)
    row = s.append_meaning(_meaning())
    prefix = s.occurrence_of(row)[:2]
    before = copy.deepcopy(s.state_dict())
    with pytest.raises(ValueError, match='occurrence|constituent|reference'):
        s.append_meaning(_meaning(child=prefix + (99,)))
    _unchanged(s, before)


def test_repeated_edges_keep_role_order_without_duplicating_or_inheriting_evidence():
    s = TernaryTruthStore(6, capacity=4)
    row = s.append_meaning(_meaning(mode='interrogative', scope={'quote': True}), kind='question')
    child = s.occurrence_of(row)
    root_row = s.append_meaning(_meaning(child=child, twice=True), kind='fact', trust=.9)
    root = s.occurrence_of(root_row)
    view = s.read_structure(root, max_nodes=2, max_depth=1, max_records=4)
    assert view['incomplete'] == ()
    assert view['occurrences'] == (root, child)
    assert view['edges'] == ((root, 0, child), (root, 2, child))
    assert view['records_scanned'] == 2
    assert view['rows'][1]['kind'] == 'question'
    assert view['rows'][1]['trust'] == 0
    assert view['rows'][1]['meaning'].scope == (('quote', True),)


@pytest.mark.parametrize('limit,reason', [({'max_nodes': 1}, 'node_limit'),
    ({'max_depth': 0}, 'depth_limit'), ({'max_records': 1}, 'record_limit')])
def test_nested_read_limits_are_separate_and_explicit(limit, reason):
    s = TernaryTruthStore(6, capacity=4)
    child = s.occurrence_of(s.append_meaning(_meaning()))
    root = s.occurrence_of(s.append_meaning(_meaning(child=child)))
    before = copy.deepcopy(s.state_dict())
    view = s.read_structure(root, **dict({'max_nodes': 4, 'max_depth': 4, 'max_records': 4}, **limit))
    assert reason in view['incomplete']
    _unchanged(s, before)


def test_retained_structure_and_reference_identity_survive_checkpoint_restore():
    s = TernaryTruthStore(6, capacity=4)
    child = s.occurrence_of(s.append_meaning(_meaning()))
    s.set_origin(0, s.ORIGIN_USER)
    root = s.occurrence_of(s.append_meaning(_meaning(child=child)))
    s.clear_origin(s.ORIGIN_USER)
    restored = TernaryTruthStore(6, capacity=4)
    restored.load_state_dict(copy.deepcopy(s.state_dict()))
    restored.load_semantic_extras(copy.deepcopy(s.semantic_extras()))
    view = restored.read_structure(root)
    assert view['incomplete'] == () and view['occurrences'] == (root, child)
    assert view['rows'][1]['kind'] == 'unverified'
    assert not view['rows'][0]['meaning'].roles.requires_grad
