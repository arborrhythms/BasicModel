from pathlib import Path
import hashlib, importlib, json, sys
root = Path('/tmp/full-spec-nested-worktree').resolve()
base = Path('/tmp/full-spec-phase-checkout').resolve()
owners = {name: (root if name in ('Layers', 'Thoughts', 'Models', 'Language') else base)
          for name in ('Layers', 'Thoughts', 'Meaning', 'Queries', 'Models', 'Understanding', 'Language')}
modules = {name: importlib.import_module(name) for name in owners}
frozen = {str(owners[name] / 'bin' / (name + '.py')):
          hashlib.sha256((owners[name] / 'bin' / (name + '.py')).read_bytes()).hexdigest()
          for name in owners}
for name, module in modules.items():
    assert Path(module.__file__).resolve() == owners[name] / 'bin' / (name + '.py')
    print('CANDIDATE', name, module.__file__, flush=True)
class OwnershipCheck:
    def pytest_runtest_setup(self, item):
        for name, module in modules.items():
            assert sys.modules[name] is module
import pytest
status = pytest.main(sys.argv[1:], plugins=[OwnershipCheck()])
for name, digest in frozen.items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest, name
raise SystemExit(status)
