# Conceptual-taxonomy PartOf evidence

PartOf reads ConceptualSpace's existing conceptual reference records. A native
`("sym", concept_id)` handle is an address; it is never interpreted as a
dictionary row or a numeric feature. The derived invocation view contains no
authoritative memory and creates no allocator, concept, fact or learned
parameter. Raw percept/whole codes, vector containment and LTM world-relation
rows cannot establish this relation.
[Reference validation](@@Taxonomy.py:concept_reference@@),
[bounded capture](@@Taxonomy.py:capture_taxonomy@@).

## Evidence and domains

A recorded `part` reference points from the constituent to its owner; a
`whole` reference points from the owner to its containing concept. Both direct
definitions and reified relations are visible. For a reified relation concept
R with part A and whole B, the evidence is the two native links A → R → B;
the endpoint sets need not have been modified. Each proof keeps its record
owner, role and endpoints. Retired/unavailable references cannot supply a
link. The snapshot does not change when its source is subsequently edited.
[Capture](@@Taxonomy.py:capture_taxonomy@@),
[proof search](@@Taxonomy.py:ConceptualTaxonomyView.part_of@@).

Structural inclusion has support 1 when a path exists; repeated links do not
increase it. Sparse learned weights are not interpreted as world-fact
confidence. Missing paths remain unknown. A supported path refutes the
negated inclusion question; a missing path does not prove that negation.
LTM existence degrees and conflicting world facts remain the separate
[Exist evidence domain](ExistenceEvidence.md).
[PartOf evaluation](@@reasoning.py:TruthGroundedReasoner.evaluate@@).

The public legacy `QuerySpec` aliases `PartOf`, `part`, `queryPart` and
`isPart` select conceptual-taxonomy evidence. `whole` / `isWhole` reverse
their supplied operands into that canonical direction. Unsupported requested
domains fail explicitly. A legacy vector-only operand has no grounded
concept reference and returns unknown with an `unbound_concept_reference`
diagnostic; it is not silently snapped to a codebook row.
[Interface](@@reasoning.py:QuerySpec.from_surface@@),
[evidence adapter](@@reasoning.py:TruthGroundedReasoner.taxonomy_evidence@@).

`parts` and `wholes` return typed neighboring references and their native
record sources. The legacy kernel's `part(..., mode="taxonomy")` uses this
reader. Its former `meronomy` mode is rejected as unsupported: a perceptual
mereonomy adapter must declare its own domain and source before it can run.
[Neighbors](@@reasoning.py:TruthGroundedReasoner.taxonomy_neighbors@@),
[kernel adapter](@@thinking.py:ThinkingKernel.part@@).

## Public routes and provenance

`TruthGroundedReasoner.evaluate`, `NeuralToolUser.run`, `BasicModel.reason_about`
and the PartOf path through `BasicModel.think_about` use this evidence source.
The model entries do not initialize or read the old global vector-proposal
route. The returned reasoning result preserves the complete evidence dict,
including unknown/incomplete diagnostics, rather than only its posture.
[Reasoner](@@reasoning.py:TruthGroundedReasoner.evaluate@@),
[tool entry](@@reasoning.py:NeuralToolUser.run@@),
[model entry](@@Models.py:BasicModel.reason_about@@),
[kernel entry](@@Models.py:BasicModel.think_about@@).

The existing frame kernel may still follow a taxonomy neighbor into a child
question. A child contributes to its parent only through a checked native
taxonomy hop, with the same requested goal and polarity. An unrelated true
child or numeric testimony cannot certify the parent's taxonomic inclusion.
The final result retains the hop sources and the child's evidence. An
incomplete-read diagnostic remains visible but contributes no invented zero
evidence to an otherwise supported interval.
[Selected step](@@thinking.py:ThinkingKernel.execute@@),
[aggregation](@@thinking.py:ThinkingKernel._frame_interval@@).

Taxonomy queries are read-only. Neither a successful proof nor the legacy
`materialize` flag grants permission to append a world-fact lemma. Legacy
incomplete relation testimony remains unverified and cannot satisfy the
taxonomy reader or full-description Exist.
[Public PartOf helper](@@reasoning.py:TruthGroundedReasoner.is_part@@),
[write boundary](@@thinking.py:ThinkingKernel._materialize_close@@),
[testimony](@@thinking.py:ThinkingKernel.incorporate@@).

## Bounds, persistence and gradients

The reader defaults to at most 256 scanned concepts and 1024 native reference
records; direct `part_of` traversal allows at most 8 links and 1024 examined
edges. `evaluate` further bounds edge examinations by `beam × max_steps`.
Every fetched record, including an ignored raw-domain reference, is counted.
Limits and unavailable references yield explicit incomplete diagnostics.
Node scans, record reads and edge expansions are distinct counters. These
local limits do not complete the specification's shared episode budget.
[Capture limits](@@Taxonomy.py:capture_taxonomy@@),
[traversal limits](@@Taxonomy.py:ConceptualTaxonomyView.part_of@@),
[query limits](@@reasoning.py:TruthGroundedReasoner.evaluate@@).

Concept identities and ordered reference records already belong to the
existing structural checkpoint sidecar. The view itself is not serialized;
a restored model captures it again from that owner. The model save/load probe
checks identical proof sources after strict restore and loss of support when
the restored reified relation is retired. No checkpoint schema or learned
parameter was added for this reader.
[Structural ownership](@@Models.py:BaseModel._collect_structural_extras@@).

Native reference traversal and its evidence are hard reads, with no gradient
through the discrete lookup/path choice. IDs do not enter numerical chooser
features. The old operation head's behavior-cloning examples now come from
bounded native taxonomy paths; this checks the existing training mechanism,
not learned question utility. The architecture-wide gradient contract remains
in [GradientFlow](GradientFlow.md).
[Trace curriculum](@@thinking.py:traces_from_store@@),
[operation-head training](@@thinking.py:next_op_loss@@).

## Compatibility and unfinished work

Old geometric/world-row helper methods have explicit `legacy_...` names;
`NeuralToolUser.run_legacy_world` retains the historical vector-proposal
experiment. Its tests are labelled as legacy. Those helpers are not used by
public PartOf dispatch. The older optional prediction/answer policy objectives
still use their explicitly named legacy evidence machinery and are not the
default sentence-expectation controller.
[Legacy proposal entry](@@reasoning.py:NeuralToolUser.run_legacy_world@@),
[legacy prediction experiment](@@reasoning.py:NeuralToolUser.reason_predict_next@@),
[legacy answer objective](@@reasoning.py:policy_answer_loss@@).

The query interface still predates the checked grammatical-VP registry. This
change does not implement linguistic relation/sense composition, the causal
answer adapter, ordinary levelled thought history, nested semantic traversal,
anticipation isolation, residual policy credit or learned utility. The frame
kernel remains a legacy controller. The full integrated specification remains
unfinished, and the separate two-truths design remains deferred as requested.
[Implementation order](plans/2026-09-15-next-sentence-as-the-production-objective.md#10-consolidated-implementation-and-verification-order).

## Validation

To be filled with actual repository focused, affected and full-suite results
after the existence-evidence commit/push/submodule cycle. Candidate results
are preparation evidence only and do not replace that gate.
