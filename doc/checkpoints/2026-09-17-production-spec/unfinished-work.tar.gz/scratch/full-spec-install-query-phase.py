"""Install only after the history commit/push/bump cycle and stopped validations."""
from pathlib import Path
import hashlib,json,shutil,subprocess

root=Path('/Users/arogers/github/WikiOracle/basicmodel')
work=Path('/tmp/full-spec-phase-worktree')
assert not subprocess.check_output(['git','diff','HEAD','--','bin','test','data'],cwd=root)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).strip()
assert head==subprocess.check_output(['git','rev-parse','origin/main'],cwd=root).strip()
assert head.decode()==subprocess.check_output(['git','rev-parse','HEAD:basicmodel'],cwd=root.parent).decode().strip()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root.parent)==subprocess.check_output(['git','rev-parse','origin/main'],cwd=root.parent)
base=json.loads((work/'base-manifest.json').read_text())
for name,digest in base.items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
validated=json.loads((work/'validation-manifest.json').read_text())
for name,digest in validated.items():
    assert hashlib.sha256((work/name).read_bytes()).hexdigest()==digest,name
probes={
    'full-spec-query-phase-probes.py':'test_query_sentence_phases.py',
    'full-spec-query-phase-boundary-probes.py':'test_query_phase_boundaries.py',
    'full-spec-query-forward-entry-probes.py':'test_query_forward_entries.py',
    'full-spec-query-phase-fullgraph-probes.py':'test_query_phase_fullgraph.py',
}
for name in probes.values():
    assert not (root/'test'/name).exists(),name
snapshot=Path('/tmp/full-spec-query-phase-base')
assert not snapshot.exists()
for name in base:
    target=snapshot/name;target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(root/name,target)
owned=[]
for name in validated:
    shutil.copyfile(work/name,root/name);owned.append(name)
for source,name in probes.items():
    target='test/'+name;shutil.copyfile(Path('/tmp')/source,root/target);owned.append(target)
Path('/tmp/full-spec-query-phase-owned-paths.txt').write_text('\n'.join(sorted(owned))+'\n')
print('Installed',len(owned),'runtime/test paths. Repository validation is required.')
