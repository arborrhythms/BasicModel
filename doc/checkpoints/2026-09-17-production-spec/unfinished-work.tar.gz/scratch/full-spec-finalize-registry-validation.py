"""Archive the recovered complete passing summary and verified frozen source."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess

root=Path('/Users/arogers/github/WikiOracle/basicmodel')
log=Path('/tmp/full-spec-registry-full-v1.log')
summary=re.findall(r'^\d+ passed[^\n]* in [^\n]+$',log.read_text(),flags=re.M)[-1]
assert re.search(r'\b\d+ failed(?:,| )',summary) is None and 'errors' not in summary
for name in ('/tmp/full-spec-registry-validation-frozen.json','/tmp/full-spec-unowned-after-tied.json'):
    values=json.loads(Path(name).read_text())
    for relative,digest in values.items():
        assert hashlib.sha256((root/relative).read_bytes()).hexdigest()==digest,relative
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root)
relative='doc/benchmarks/2026-09-16-checked-query-data'
shutil.copyfile(log,root/relative/'full-green.log')
shutil.copyfile('/tmp/full-spec-registry-validation-frozen.json',root/relative/'full-validation-manifest.json')
old='The background full suite is running with all 579\nruntime/test/configuration files frozen.'
new=f'The full suite completed: **{summary}**. All 579\nruntime/test/configuration files remained frozen.'
for name,prefix in [('doc/QueryContracts.md','benchmarks/'),('doc/plans/2026-09-15-next-sentence-as-the-production-objective.md','../benchmarks/')]:
    path=root/name; text=path.read_text(); assert old in text,name
    text=text.replace(old,new,1)
    target=prefix+'2026-09-16-checked-query-data/'
    end='[width red]('+target+'owner-width-red.log).'
    assert end in text,name
    text=text.replace(end,'[width red]('+target+'owner-width-red.log),\n[full green]('+target+'full-green.log),\n[frozen source manifest]('+target+'full-validation-manifest.json).\n\nFull-suite command:\n\n```sh\nOMP_NUM_THREADS=1 MKL_NUM_THREADS=1 DEVELOPER_DIR=/Library/Developer/CommandLineTools \\\n  .venv/bin/python -m pytest test -q -x -p no:cacheprovider\n```',1)
    text=text.replace('## 17. Checked query contracts and shared grammatical VP API (in progress)',
                      '## 17. Checked query contracts and shared grammatical VP API (verified September 16)',1)
    text=text.replace('Implementation reference, September 16. Repository validation is in progress.',
                      'Implementation reference, verified September 16.',1)
    path.write_text(text)
message=Path('/tmp/full-spec-registry-commit-message.txt')
text=message.read_text();assert 'FULL_SUITE_PENDING' in text
message.write_text(text.replace('FULL_SUITE_PENDING','Full suite: '+summary+'.'))
owned=Path('/tmp/full-spec-registry-owned-paths.txt')
owned.write_text('\n'.join(sorted(set(owned.read_text().splitlines())|{relative+'/full-green.log',relative+'/full-validation-manifest.json'}))+'\n')
receipt = {'validation': 'recovered complete pytest passing summary', 'managed_exit_status': None, 'reason': 'Managed tool session expired before exit status could be reread; no exit code is inferred.', 'summary': summary, 'source_files_verified': 579}
(root/relative/'completion-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
owned.write_text(owned.read_text()+relative+'/completion-receipt.json\n')
print(summary)
print('Validation archived; exact whitelist now',len(owned.read_text().splitlines()),'paths.')
