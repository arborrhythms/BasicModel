from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time

root=Path('/Users/arogers/github/WikiOracle/basicmodel')
python=str(root/'.venv/bin/python')
env=dict(os.environ, DEVELOPER_DIR='/Library/Developer/CommandLineTools')
status_path=Path('/tmp/full-spec-reconstruction-validation-status.json')
status=[]

def record(name,state,**detail):
    item=dict(name=name,status=state,time=time.time(),**detail)
    status.append(item)
    status_path.write_text(json.dumps(status,indent=2)+'\n')
    print(f'{name}: {state}',flush=True)

def run(name,command,log):
    record(name,'running',command=command,log=str(log))
    with Path(log).open('w') as stream:
        result=subprocess.run(command,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
    record(name,'completed' if result.returncode==0 else 'failed',returncode=result.returncode,log=str(log))
    if result.returncode:
        raise SystemExit(result.returncode)

record('readout-checkpoint-and-l1','waiting',pid=43217)
while True:
    try:
        os.kill(43217,0)
    except ProcessLookupError:
        break
    time.sleep(2)
log=Path('/tmp/full-spec-readout-checkpoint-l1-green-v2.log').read_text()
last=log.strip().splitlines()[-1]
if not re.search(r'\b\d+ passed\b',last) or re.search(r'\b(failed|error|errors)\b',last):
    record('readout-checkpoint-and-l1','failed',summary=last)
    raise SystemExit(1)
record('readout-checkpoint-and-l1','completed',summary=last)
manifest={str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
          for directory in ('bin','test','data') for p in (root/directory).rglob('*')
          if p.is_file() and p.suffix in ('.py','.xml','.xsd','.grammar')}
Path('/tmp/full-spec-tied-validation-frozen.json').write_text(json.dumps(manifest,indent=2)+'\n')
run('output-affected', [python,'-m','pytest','test/test_output_synthesis.py',
    'test/test_output_path_supervised.py','test/test_output_walk.py',
    '-q','-p','no:cacheprovider'], '/tmp/full-spec-readout-output-affected.log')
run('native-manifest',[python,'/tmp/full-spec-prepare-final-benchmarks.py'],
    '/tmp/full-spec-native-preparation-v2.log')
run('native-measurements',[python,'/tmp/full-spec-run-all-final-benchmarks.py'],
    '/tmp/full-spec-native-final-runner-v2.log')
changed=[p for p,digest in manifest.items() if hashlib.sha256((root/p).read_bytes()).hexdigest()!=digest]
if changed:
    record('frozen-source','failed',changed=changed)
    raise SystemExit(1)
run('full-suite',[python,'-m','pytest','test','-q','-p','no:cacheprovider'],
    '/tmp/full-spec-tied-full-v1.log')
changed=[p for p,digest in manifest.items() if hashlib.sha256((root/p).read_bytes()).hexdigest()!=digest]
record('frozen-source','completed' if not changed else 'failed',changed=changed)
raise SystemExit(1 if changed else 0)
