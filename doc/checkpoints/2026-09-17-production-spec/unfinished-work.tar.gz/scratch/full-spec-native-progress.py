from pathlib import Path
import json,time
folder=Path('/Users/arogers/github/WikiOracle/basicmodel/doc/benchmarks/2026-09-16-tied-reconstruction-data')
try:
    rows=json.loads((folder/'final-runs-status.json').read_text())
    print('Completed:',', '.join(r['name'] for r in rows if r['status']=='completed'))
    last=rows[-1]
    print(last['name'],last['status'],round(last.get('ended_at',time.time())-last['started_at'],1),'seconds elapsed')
    report=folder/(last['name']+'.json')
    if report.exists():
        data=json.loads(report.read_text())
        print('Phases:',[(p['name'],len(p['steps'])) for p in data['phases']])
        for phase in data['phases']:
            if phase['name']=='training':
                print('Captured graphs:',[s.get('compiler_counters',{}).get('stats',{}).get('unique_graphs') for s in phase['steps']])
                if phase.get('steady'):
                    s=phase['steady'];print('Steady:',s['input_sentences_per_second'],'sentences/s;',s['predicted_targets_per_second'],'prediction targets/s')
        if data.get('error'):print('Failure:',data['error'])
except json.JSONDecodeError:
    print('Report is being written; inspect on the next poll.')
