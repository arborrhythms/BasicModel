"""Prepare the catalog split in isolation; do not install it ahead of item 5."""
from pathlib import Path
import hashlib
import json
import shutil

root = Path('/Users/arogers/github/WikiOracle/basicmodel')
work = Path('/tmp/full-spec-generation-worktree')
assert not work.exists()
work.mkdir()
for folder in ('bin', 'test'):
    (work / folder).mkdir()
    for path in (root / folder).iterdir():
        if path.name == '__pycache__':
            continue
        if folder == 'bin' and path.name in ('Language.py', 'Models.py'):
            shutil.copyfile(path, work / folder / path.name)
        else:
            (work / folder / path.name).symlink_to(path)
for name in ('data', 'pytest.ini'):
    (work / name).symlink_to(root / name)
(work / 'base-manifest.json').write_text(json.dumps({
    str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
    for path in (root / 'bin/Language.py', root / 'bin/Models.py')
}, indent=2))

path = work / 'bin/Language.py'
text = path.read_text()
text = text.replace('import itertools, math, os, re, warnings',
                    'import copy, itertools, math, os, re, warnings', 1)
old = '''        catalog = {1: [], 2: []}
        for offset, rule in enumerate(TheGrammar.rules_downward if walk_on else ()):
'''
new = '''        catalog = {1: [], 2: []}
        self.generation_ops = nn.ModuleDict()
        sources, resolved, copies = {}, {}, {}
        # Share only non-owning space references. Numerical parameters and
        # buffers are copied together so internal aliases remain internal.
        memo = {id(value): value for value in (
            symbol_space, symbol_space.subspace,
            getattr(symbol_space, "conceptualSpace", None),
            getattr(symbol_space, "perceptualSpace", None),
            getattr(symbol_space, "wholeSpace", None)) if value is not None}
        for offset, rule in enumerate(TheGrammar.rules_downward):
'''
assert old in text
text = text.replace(old, new, 1)
old = '''            catalog[arity].append((rule.space_role, offset, rule, op))
        for arity in (2, 1):
'''
new = '''            source = op
            identity = (str(rule.space_role), _dispatch_method_name_for_rule(rule))
            if id(source) not in copies:
                import hashlib
                key = "op_" + hashlib.sha256(repr(identity).encode()).hexdigest()[:20]
                self.generation_ops[key] = copy.deepcopy(source, memo)
                sources[key] = source
                copies[id(source)] = self.generation_ops[key]
            op = copies[id(source)]
            resolved[identity] = op
            catalog[arity].append((rule.space_role, offset, rule, op))
        object.__setattr__(self, "_generation_sources", sources)
        object.__setattr__(self, "_generation_resolved", resolved)
        # Legacy stack dispatch reaches the same owned registry without
        # registering LanguageSpace twice or taking ownership of its state.
        object.__setattr__(symbol_space.subspace, "_generation_space", self)
        for arity in (2, 1):
'''
assert old in text
text = text.replace(old, new, 1)
text = text.replace('''            # Learned numerical operators remain owned by their host spaces.
            object.__setattr__(self, f"_generate_{label}_ops",
''', '''            # Non-registering catalog views; generation_ops owns state once.
            object.__setattr__(self, f"_generate_{label}_ops",
''', 1)
old = '''    @staticmethod
    def _generate_rule_key(rule, arity):
'''
new = '''    def resolve_generation_op(self, space_role, method):
        """Resolve declared output operators without returning a compose owner."""
        exact = self._generation_resolved.get((str(space_role), str(method)))
        if exact is not None:
            return exact
        matches = {id(op): op for (role, name), op in self._generation_resolved.items()
                   if name == method}
        if len(matches) == 1:
            return next(iter(matches.values()))
        raise KeyError(f"undeclared or ambiguous generate operator: {space_role}:{method}")

    def migrate_generation_operators(self, state, prefix, model):
        """Copy saved comprehension values only for pre-split checkpoints.

        Existing generation weights keep their own values. Newly introduced
        optimizer parameters retain fresh moments under name-based migration.
        Missing members of a present catalog remain load errors.
        """
        base = prefix + "generation_ops."
        if any(key.startswith(base) for key in state):
            return
        source_names = {}
        for name, value in itertools.chain(
                model.named_parameters(remove_duplicate=False),
                model.named_buffers(remove_duplicate=False)):
            if name in state:
                source_names.setdefault(id(value), []).append(name)
        for key, source in self._generation_sources.items():
            live = self.generation_ops[key].state_dict()
            members = dict(itertools.chain(source.named_parameters(remove_duplicate=False),
                                          source.named_buffers(remove_duplicate=False)))
            for name, value in live.items():
                names = source_names.get(id(members[name]), ())
                if not names:
                    raise ValueError(f"legacy checkpoint has no source for generate {key}.{name}")
                saved = state[names[0]]
                if saved.shape != value.shape:
                    raise ValueError(f"legacy generate source shape differs: {names[0]}")
                state[base + key + "." + name] = saved.detach().clone()

    @staticmethod
    def _generate_rule_key(rule, arity):
'''
assert old in text
text = text.replace(old, new, 1)
old = '''        if self.languageSpace.generate_policy is not None:
            self.params.extend(self.languageSpace.generate_policy.parameters())
'''
assert old in text
text = text.replace(old, '''        self.params.extend(self.languageSpace.parameters())
''', 1)
# A standalone unreduce remains a mathematical inverse. A model's declared
# output dispatch uses the same owned output catalog as the compiled walk.
old = '''        method_name = grammar.method_name(rule_id)
        layer = syntactic_layer._by_name.get(method_name)
'''
new = '''        method_name = grammar.method_name(rule_id)
        owner = getattr(syntactic_layer, "_word_space", None)
        generation = getattr(owner, "_generation_space", None)
        layer = (generation.resolve_generation_op(syntactic_layer.space_role, method_name)
                 if generation is not None else syntactic_layer._by_name.get(method_name))
'''
assert old in text
text = text.replace(old, new, 1)
path.write_text(text)

path = work / 'bin/Models.py'
text = path.read_text()
old = '''            migrate = getattr(type(module), "migrate_generate_checkpoint", None)
            if migrate is not None:
'''
new = '''            migrate_ops = getattr(type(module), "migrate_generation_operators", None)
            if migrate_ops is not None:
                migrate_ops(module, state, name + ".", self)
            migrate = getattr(type(module), "migrate_generate_checkpoint", None)
            if migrate is not None:
'''
assert old in text
text = text.replace(old, new, 1)
old = '''                       getattr(getattr(self, "languageSpace", None), "generate_policy", None)):
'''
new = '''                       getattr(getattr(self, "languageSpace", None), "generate_policy", None),
                       getattr(getattr(self, "languageSpace", None), "generation_ops", None)):
'''
assert old in text
text = text.replace(old, new, 1)
path.write_text(text)
print('Prepared isolated catalog candidate; primary remains unchanged.')
