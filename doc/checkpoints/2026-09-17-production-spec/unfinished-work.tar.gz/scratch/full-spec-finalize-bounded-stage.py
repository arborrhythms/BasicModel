from pathlib import Path
import hashlib,json,shutil,subprocess,sys
from full_spec_bounded_evidence import verified_run,archive_run
key=sys.argv[1]
info=next(x for x in json.loads(Path('/tmp/full-spec-bounded-stage-config.json').read_text()) if x['key']==key)
root=Path('/Users/arogers/github/WikiOracle/basicmodel')
full=Path(sys.argv[2]); affected=Path(sys.argv[3])
f=verified_run(full,root);a=verified_run(affected)
for name,digest in json.loads(Path('/tmp/full-spec-unowned-after-tied.json').read_text()).items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root)
slug=info['slug'];owned_file=Path('/tmp/full-spec-'+slug+'-owned-paths.txt')
owned=set(owned_file.read_text().splitlines())
assert Path('/tmp/full-spec-'+slug+'-doc-remap-applied.json').is_file()
folder=root/('doc/benchmarks/2026-09-17-'+slug+'-data');assert not folder.exists()
doc=root/('doc/'+info['doc']+'.md');spec=root/'doc/plans/2026-09-15-next-sentence-as-the-production-objective.md'
assert info['old_doc'] in doc.read_text() and info['old_spec'] in spec.read_text()
folder.mkdir(parents=True)
for name,source in info['sources'].items(): shutil.copyfile(source,folder/name)
archive_run(full,folder,'full',f);archive_run(affected,folder,'affected',a)
def evidence(prefix):
 base=prefix+folder.name+'/'
 return (f"Reviewer probes failed before the corresponding fixes; {info['count']} new cases cover these contracts.\n"
  f"The primary affected run passed: **{a['summary']}**.\n"
  f"The complete default suite then passed in fresh bounded workers: **{f['summary']}**.\n"
  f"All {len(f['receipt']['selected'])} selected cases completed exactly once, each worker exited zero,\n"
  f"and all {len(f['manifest'])} source/configuration/documentation hashes remained unchanged.\n\n"
  f"[Affected receipt]({base}affected-result.json), [full receipt]({base}full-result.json),\n"
  f"[full summaries]({base}full-summaries.log), [source manifest]({base}full-source-manifest.json).\n\n"
  +info.get('prior_note', "Earlier isolated full attempts were interrupted or lacked harness fixtures; those attempts\n"
  "are not counted as proof. The successful primary runs use [the bounded workflow](Testing.md)."))
s=doc.read_text().replace(info['old_doc'],evidence('benchmarks/'),1)
s=s.replace(info['old_header'],'Implementation reference, verified September 17.',1);doc.write_text(s)
s=spec.read_text().replace(info['old_spec'],evidence('../benchmarks/').replace('(Testing.md)','(../Testing.md)'),1)
s=s.replace('## '+info['section']+' (in progress)','## '+info['section']+' (verified September 17)',1);spec.write_text(s)
owned.update(str(p.relative_to(root)) for p in folder.iterdir())
owned_file.write_text('\n'.join(sorted(owned))+'\n')
Path('/tmp/full-spec-'+slug+'-commit-message.txt').write_text(info['heading']+'\n\n'+info['body']+'\n\n'
 +f"Validation: {info['count']} reviewer cases; primary affected: {a['summary']}. Full default suite: {f['summary']}. "
 +'Normal semantic controller, linguistic integration and learned utility remain separate gates.\n\n'
 +'Co-Authored-By: Claude Fable 5.1 <noreply@anthropic.com>\n')
print(f['summary']);print('Exact owned paths:',len(owned))
