"""Generation must own numerical operators independently of comprehension."""
from pathlib import Path
import sys

ROOT = Path('/Users/arogers/github/WikiOracle/basicmodel')
for path in (ROOT / 'bin', ROOT / 'test'):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

import pytest
import torch
from test_meronomy_ladder import _build_ladder_variant


def model(tmp_path, output_loop):
    edits = []
    if output_loop:
        edits = [('<training>', '<training>\n<outputInLoop>true</outputInLoop>')]
    result = _build_ladder_variant(tmp_path, 'independent_catalog', edits)
    result._tensor_peer_while_eager = True
    result._chart_compose_per_word = lambda: None
    return result


@pytest.mark.parametrize('output_loop', [False, True])
def test_generation_has_an_independent_catalog_even_without_output_loop(tmp_path, output_loop):
    m = model(tmp_path, output_loop)
    try:
        language = m.languageSpace
        assert language._generate_binary_ops, 'ordinary output also needs generation-owned operators'
        pairs = []
        for name, generated in zip(language._generate_binary_names, language._generate_binary_ops):
            composed = m.symbolSpace.subspace._resolve_rule_layer(generated.space_role, name)
            assert generated is not composed, name
            expected = dict(composed.named_parameters())
            for key, parameter in generated.named_parameters():
                assert parameter is not expected[key], (name, key)
                torch.testing.assert_close(parameter, expected[key], rtol=0, atol=0)
                pairs.append((parameter, expected[key]))
        assert pairs, 'the probe must cover learned numerical operations'
        owned = [id(p) for group in m.getOptimizer(lr=1e-3).param_groups for p in group['params']]
        assert all(owned.count(id(generated)) == 1 for generated, _ in pairs)
        generated, composed = pairs[0]
        original = generated.detach().clone()
        with torch.no_grad():
            composed.add_(0.125)
        torch.testing.assert_close(generated, original, rtol=0, atol=0)
    finally:
        m.End()
        m.symbolSpace.soft_reset()
        torch._dynamo.reset()


def test_detached_output_trains_only_generation_but_live_input_can_train_comprehension(tmp_path):
    m = model(tmp_path, True)
    try:
        language = m.languageSpace
        generated = language._generate_binary_ops[list(language._generate_binary_names).index('lift')]
        composed = m.symbolSpace.subspace._resolve_rule_layer('CS', 'lift')
        assert generated is not composed, 'generation still shares the comprehension transform'
        width = int(m.conceptualSpace.stm.concept_dim)
        left = torch.linspace(-0.4, 0.2, width).reshape(1, width)
        right = torch.linspace(0.1, 0.5, width).reshape(1, width)
        parent = composed.compose(left, right)
        weights = torch.linspace(0.3, 1.1, width).reshape(1, width)
        parameters = tuple(composed.parameters()) + tuple(generated.parameters())
        cut = len(tuple(composed.parameters()))
        a, b = generated.reverse(parent.detach())
        gradients = torch.autograd.grad(((a + b) * weights).sum(), parameters, allow_unused=True)
        assert all(g is None for g in gradients[:cut])
        assert any(g is not None and g.abs().sum() > 0 for g in gradients[cut:])
        a, b = generated.reverse(parent)
        gradients = torch.autograd.grad(((a + b) * weights).sum(), parameters, allow_unused=True)
        assert any(g is not None and g.abs().sum() > 0 for g in gradients[:cut])
        assert all(g is None or torch.isfinite(g).all() for g in gradients)
    finally:
        m.End()
        m.symbolSpace.soft_reset()
        torch._dynamo.reset()
