# Shared query work accounting

Draft implementation reference. This candidate is isolated; primary installation
and affected/full-suite validation are pending. Normal learned-controller
integration remains a separate gate.

## One allowance across selected work

`QueryWorkBudget` holds one transient integer allowance. Its read-only `spent`,
`remaining` and per-kind counts report actual debits. It owns no meanings,
checkpoints, child allowance or reset. A debit is atomic: an overlarge request
fails without partially consuming it. `QueryContext.work` carries the same
object through a selected call. The caller must supply the episode's remaining
allowance and record the resulting cost once in ordinary thought history.
[Meter](@@QueryWork.py:QueryWorkBudget@@),
[context](@@Queries.py:QueryContext@@).

| Cost kind | Charged before |
|---|---|
| `operation` | Calling a validated selected executor |
| `reference` | Validating the selected native VP or a native operand address |
| `payload` | Reading an addressed conceptual payload |
| `node` | Inspecting a taxonomy node or codebook candidate |
| `record` | Reading an LTM/thought row, taxonomy constituent, or prediction-context record |
| `expansion` | Using a captured taxonomy edge in a proof or neighbor result |

These are explicit bounded work units, not wall time or FLOPs. Local node,
record, depth and expansion limits can tighten the shared allowance; none
creates a new one. Taxonomy capture reserves a portion for traversal, so reading
a snapshot cannot always consume all remaining work before a direct proof.
Every category still debits the same meter.
[Capture allocation](@@QueryWork.py:capture_limits@@),
[taxonomy capture](@@Taxonomy.py:capture_taxonomy@@),
[traversal](@@Taxonomy.py:ConceptualTaxonomyView.part_of@@).

## Validate, charge, then read

Phase permission and declared argument/domain/width validation run before
execution. Registry dispatch accounts for selected VP validation and operand
preparation as well as the executor. Description-valued operands resolve through
their existing occurrence owner; preparation cannot evade its allowance by
reading a full description before invoking the checked call. Missing or invalid
references are not silently rebound.
[Dispatch](@@Queries.py:GrammaticalQueryRegistry.execute@@),
[checked call](@@Queries.py:QuerySignature.invoke@@),
[occurrence resolution](@@Queries.py:_occurrence_description@@).

Exist records actual inspected facts and preserves partial signed support when
work ends. Quantize does not materialize the conceptual basis after exhaustion.
ARMA reserves its prior-context record cost before running the predictor and
does not replace the pending external-input estimate. Native vector reads and
lookup rows use the same accounting. Nested `what(Q)` callbacks must receive
the same meter; starting another allowance would violate the episode contract.
[Exist](@@reasoning.py:TruthGroundedReasoner.existence_evidence@@),
[Quantize](@@Queries.py:_quantize@@),
[ARMA](@@Layers.py:InterSentenceLayer.expect_next_meaning@@).

Exhaustion returns explicit `work_budget` incompleteness; it does not establish
falsity or resolution. Positive evidence found within the allowance remains
available. Failed native/occurrence preparation reports unknown rather than
performing later reads. The meter retains all actual costs, including a partial
failed resolution whose older per-result scanned field cannot report progress.

## Gradients and ownership

Accounting uses host integers and supplies no learned parameter, objective or
ordinary derivative. It does not detach live operand payloads or ordinary thought
reads. Durable records retain their existing detached-read boundary. Hard
selection and evidence traversal still require policy credit where trained;
counting their work does not make them differentiable.
[Live read](@@Thoughts.py:LevelledThoughtHistory.resolve_thought@@),
[architecture gradient contract](GradientFlow.md).

Standalone audited readers can omit the optional meter and retain their local
limits. Normal episode execution must supply it throughout the selected path.
The ordinary history owns the root budget and cutoff drain; this meter does not
create another controller or change that history's `d_cut + 1` bound.
[History](ThoughtHistory.md).

## Validation and remaining integration

Thirteen new reviewer cases cover shared capture/traversal limits, validation,
atomic overdraw, native VP and operand preparation, partial fact reads, live
occurrence reads, nested callbacks, prediction reservation and codebook reads.
The isolated affected selection passed 154 tests with one skip. Primary affected
files and the complete default suite must pass after installation.

The normal learned controller must still forward one meter to every selected
read/callback, commit actual cost once, preserve causal result use, and train its
hard choices. Linguistic meaning, owned estimates, residual credit and learned
utility are not supplied by this accounting API. Unused reasoning methods remain
available for the user's grammar-query review.
