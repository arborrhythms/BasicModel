# Arbitrary symbols and the arithmetic testbed

User clarification, September 17. Architectural requirement and static audit;
the new controller's behavioral gates remain pending.

## Required boundary

Numerals and operators are known symbolic concepts with arbitrary native
addresses. The learner must not convert a surface numeral, symbol ID, dictionary
row or answer-class index into its numerical value and evaluate a formula.
Arithmetic is a formal-grammar learning task: composition, prediction, reasoning
and output operate over symbol-attached meanings and learned syntactic
operations. No arithmetic evaluator, binary-digit fallback encoding, solver
binding order or gold subgoal may enter the runtime query menu or chooser.
Changing an address by a consistent renumbering cannot change its meaning.

Tensor algebra used by learned layers, loss calculations, truth/support degrees,
work counters and presentation metadata retain their declared roles. They may
not become a covert channel for numerical operand values. A tensor operation
called `sum` does not establish that it implements arithmetic addition over the
meanings of numeral symbols. Report learned task performance separately.

## Current static audit

- The legacy grammatical query helper uses a clipped cosine over concept
  tensors. It is not an arithmetic formula parser. Its automatic use as
  parthood evidence during composition violates the pure-representation/query
  boundary; the isolated reviewer probe reproduced that separate problem.
  [Similarity helper](../bin/Language.py#L4081),
  [query class](../bin/Language.py#L4341),
  [mode dispatch](../bin/Language.py#L4419).
- Checked registry entries describe existing conceptual-taxonomy, LTM,
  conceptual-identity, codebook, prediction and conceptual-subgoal readers.
  Native IDs resolve through their owning tables; they do not supply numeric
  operand features. [Registry](../bin/Queries.py#L318),
  [reference resolution](../bin/Queries.py#L129).
- Exact arithmetic helpers remain in `exact.py`, including `eval_expr`,
  `ExactState` and `numeral_code`. The module previously described a
  "model-owned scratchpad"; its documentation is being corrected to its oracle-only role. A static scan of `bin/*.py` found its
  external production import in dataset construction (`MathProblemGenerator`
  and splitting helpers); it found no imports/calls to these evaluators from
  Models, Language, Queries, reasoning or thinking. Dataset generation computes
  target labels before the model runs. This is a call-site audit, not a new
  runtime isolation test.
  [Evaluator](../bin/exact.py#L98), [legacy scratchpad](../bin/exact.py#L275),
  [legacy numeral code](../bin/exact.py#L397),
  [dataset construction](../bin/data.py#L1350),
  [label construction](../bin/data.py#L1433).
- The current What choice head uses action/position/memory/pressure features;
  it does not evaluate the lexical referent. Its replacement must preserve
  the arbitrary-symbol boundary while adding complete semantic roles.
  [Features](../bin/Language.py#L7182),
  [referents](../bin/Models.py#L8450).

Do not infer that every legacy API is approved for a future query registry.
Unused reasoning methods remain intact pending the user's review. Dataset and
evaluation utilities need an explicit boundary; any proposed removal or move
must name the concrete methods and their actual callers before approval.

## Acceptance gates for the new paths

1. Consistently permute native symbol IDs and dictionary rows while preserving
   their payloads, typed relations, selected grammar derivations and grounded
   references. Semantic query results and chooser features/logits must agree
   after references are translated back. Use adequate identical work limits so
   truncation is not a confound; report bounded-retrieval ordering separately.
2. After constructing the corpus, replace exact arithmetic evaluators, solver
   primitives and `numeral_code` with failing spies. Exercise real understanding,
   tied reconstruction, selected boundary queries, output and training; none
   may call those helpers. Desired labels remain loss targets only.
3. Train/test formal arithmetic with a consistently renamed symbol vocabulary,
   including nonnumeric numeral names and renamed operator words. Match data,
   initialization, budgets and held-out structures. Report learning and transfer
   without assuming an untrained grammar computes arithmetic.
4. Separately perturb semantic VP/operand payloads with their IDs held fixed;
   the semantic chooser must retain those distinctions. Targets, solver traces
   and expected answers never enter that input.

The gradient contract follows the actual learned computation: live semantic
operands and memory reads can receive balanced downstream credit; hard choices
receive explicit policy credit; observed targets and durable history detach.
Host-side exact scoring creates no hidden differentiable or symbolic solve path.
[Architecture-wide gradient flow](GradientFlow.md).
