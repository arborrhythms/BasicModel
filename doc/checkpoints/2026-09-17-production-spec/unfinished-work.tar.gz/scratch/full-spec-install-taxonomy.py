"""Apply the reviewed candidate only after the existence commit is complete."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess

root = Path('/Users/arogers/github/WikiOracle/basicmodel')
candidate = Path('/tmp/full-spec-taxonomy-candidate')
worktree = Path('/tmp/full-spec-taxonomy-worktree')
assert not subprocess.check_output(
    ['git', 'diff', 'HEAD', '--', 'bin', 'test'], cwd=root), 'Source still uncommitted'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root) == subprocess.check_output(
    ['git', 'rev-parse', 'origin/main'], cwd=root), 'Push existence before applying taxonomy'
for manifest in [candidate/'base-manifest.json', worktree/'base-manifest.json']:
    for name, digest in json.loads(manifest.read_text()).items():
        assert hashlib.sha256((root/name).read_bytes()).hexdigest() == digest, name
for name, digest in json.loads((candidate/'validation-manifest.json').read_text()).items():
    assert hashlib.sha256((candidate/name).read_bytes()).hexdigest() == digest, name

sources = ['Layers.py', 'Models.py', 'reasoning.py', 'thinking.py', 'Taxonomy.py']
assert not (root/'bin/Taxonomy.py').exists()
probes = {
    'view': 'test_taxonomy_view.py',
    'routing': 'test_taxonomy_routing.py',
    'entry': 'test_taxonomy_entry.py',
    'policy': 'test_taxonomy_policy.py',
    'boundary': 'test_taxonomy_boundary.py',
    'public-helper': 'test_taxonomy_public_helpers.py',
    'unknown': 'test_taxonomy_unknown.py',
}
for name in probes.values():
    assert not (root/'test'/name).exists(), name
owned = []
for name in sources:
    target = 'bin/'+name
    shutil.copyfile(candidate/name, root/target)
    owned.append(target)
for source, name in probes.items():
    target = 'test/'+name
    suffix = 'probe' if source == 'unknown' else 'probes'
    shutil.copyfile(Path('/tmp')/f'full-spec-taxonomy-{source}-{suffix}.py', root/target)
    owned.append(target)
for name in json.loads((worktree/'base-manifest.json').read_text()):
    shutil.copyfile(worktree/name, root/name)
    owned.append(name)
Path('/tmp/full-spec-taxonomy-owned-paths.txt').write_text('\n'.join(sorted(owned))+'\n')
print('Applied', len(owned), 'runtime/test files; validation must run in the repository.')
