# Structured query migration preparation (not implemented)

Apply only after the prepared-answer and existence-evidence commit/push cycles.
The two taxonomy evidence probes are in /tmp/full-spec-taxonomy-routing-probes.py;
/tmp/full-spec-taxonomy-routing-red.log records both failing against the isolated
existence candidate. They exercise existing public APIs, not an import-only failure.

## Verified source constraints

- Conceptual taxonomy owner: ConceptualSpace.concept_parts/concept_wholes,
  Spaces.py:17916/17921. Reads must not lazily create an allocator. Direct sym
  links and reified records both matter: reify_concept17942 stores a new concept
  with Parts={sym A}, Wholes={sym B}, without updating endpoint sets. The
  ConceptAllocator records (Layers.py:5630) are authoritative, not relate_idx.
  Skip unavailable/retired identities; bounded traversal reports incomplete.
  Raw PS/WS codes and vector overlap are not conceptual-taxonomy evidence.
  Learned sparse values are not automatically fact confidence; define the
  structural membership semantics separately from graded LTM fact evidence.
- A word's interpreted object ID already exists at inputSpace._ar_word_object_ids,
  separately from dictionary rows. Models.py:10853-10861 publishes both; row
  lookup is not a substitute. AnswerProgram currently retains rows and word_rows
  but no concept IDs (Understanding.py:24); preserve explicit IDs if needed for
  grounded query arguments, never infer them from numeric row coincidence.
- _capture_answer_programs Models.py:12020 and _replay_program12137 contain actual
  identified compose actions and their live operand values. These are the
  available grammatical source for a query, not raw prompt words. A semantic
  adapter must retain selected relation operands/VP instead of trusting a
  collapsed root (PartLayer.forward Language.py:4266 returns the whole only).
- Closed-class anchors are already grammatical: Language.py:5331-5354 assigns
  operator output roles, but that alone does not create canonical meaning or
  interrogative mode. complete.grammar currently has no dedicated interrogative
  composition operation. A new pure mode operator needs compose/inverse and
  generate rules; only selected completed root mode may activate a query.
  An embedded question is content, never an executor call.
- Multiple surface forms must be grammar/lexicon mappings with explicit senses
  and argument permutations. Do not replace _detect_query with a new sentence
  regex or call "has" parthood unconditionally. The actual forward-selected
  lexical/grammatical meaning must determine relation/domain. Controlled known
  parses test mechanics; held-out learned parsing/utility remains separate.
- _resolve_answer Models.py:8187 currently invokes answer_query(prompt), suppresses
  failures and records only posture. That route must be replaced with structured
  execution whose actual result changes conceptual_answer, preserving the
  proposition even for yes/no surfaces. Updating an unused registry is insufficient.
- _detect_query22402/answer_query22470 and serving callers need explicit migration;
  raw-text detection cannot remain a fallback on the normal reasoning path.

## Required registry contract

One semantic VP identity per relation/domain links pure compose/inverse grammar
faces and checked boundary execution. part/isPart share identity; whole/isWhole
declare the converse permutation. QuerySpec and WhatQuestion adapt this meaning;
they must not form an independent semantic store. Signatures declare occupied,
open and result roles, result kind, supported domains, read/write scope and
evidence semantics. Include every complete.grammar Queries entry plus what(Q).
Missing executor or unsupported type/domain fails explicitly; deferred tense
does not manufacture evidence. Candidate construction/scoring is read-only.

Exist's unary wrapper must preserve its complete description (directly or through
an owned semantic reference), not silently use only NP1. Queries and predictions
remain ineligible as facts. Registry results keep both signed support channels,
sources, canonical roles and references; quantize is conceptual, never symbol
snapping. what(Q) yields a conceptual subgoal to the same boundary controller,
not Data.what or a hidden solver. arma returns an estimate.

## Acceptance additions before fixes

- Real taxonomy links, reified-only edge, converse order, cycles/retirements,
  missing identity, bounded work; world/percept/parse-only perturbations inert.
- Same lexical word with part-whole versus ownership meaning; retain word/object
  distinction and identified reconstruction derivations.
- Linguistic forward and internal selection yield the same full relation roles,
  grounding, mode/scope and evidence; assertions/embedded questions do not execute.
- Per-row completed-boundary permissions; queries forbidden throughout compose,
  tied reconstruction and generate, including exception cleanup/restaging.
- Registry-selected intermediate result causally changes the actual answer,
  not merely trace metadata; no targets or input reconstruction witnesses in
  the answer's generate derivation.

The ordinary levelled history/controller and retained arbitrary nested semantics
remain later migrations. Extend the one WhatInteractionMemory owner; do not add
another authoritative frame/dependency store. The two-truths spec is explicitly
reserved for the user's next session and must not be adopted or committed.
