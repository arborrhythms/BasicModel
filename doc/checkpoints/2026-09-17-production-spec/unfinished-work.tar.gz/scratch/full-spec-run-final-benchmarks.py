from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

root = Path('/Users/arogers/github/WikiOracle/basicmodel')
folder = root / 'doc/benchmarks/2026-09-16-tied-reconstruction-data'
manifest = json.loads((folder / 'final-candidate-manifest.json').read_text())
runs = [
    ('answers-b1-final', 'answers', 'data/BasicModel_answers_tied_benchmark.xml', 1, 7, []),
    ('answers-b2-final', 'answers', 'data/BasicModel_answers_tied_benchmark.xml', 2, 7, []),
    ('fineweb-b1-final', 'fineweb', 'data/BasicModel.xml', 1, 7, ['--docs', '24']),
    ('long-b1-k8-final', 'answers', 'data/BasicModel_long_tied_benchmark.xml', 1, 7, ['--basis-limit', '8']),
    ('long-b1-k16-final', 'answers', 'data/BasicModel_long_tied_benchmark.xml', 1, 7, ['--basis-limit', '16']),
    ('output-b2-final', 'answers', 'data/BasicModel_output_tied_benchmark.xml', 2, 15, []),
]
env = dict(os.environ, DEVELOPER_DIR='/Library/Developer/CommandLineTools',
           PYTORCH_MPS_HIGH_WATERMARK_RATIO='0.60', PYTORCH_MPS_LOW_WATERMARK_RATIO='0.50',
           MODEL_AMP='off')
status_path = folder / 'final-runs-status.json'
status = []

def check_source():
    changed = [p for p, digest in manifest.items()
               if hashlib.sha256((root / p).read_bytes()).hexdigest() != digest]
    if changed:
        raise RuntimeError(f'Frozen benchmark source changed: {changed}')
    processes = subprocess.check_output(['ps', '-axo', 'args'], text=True)
    if any('-m pytest ' in line for line in processes.splitlines()):
        raise RuntimeError('A pytest process is still running; benchmark not started')

for name, workload, config, batch, steps, extra in runs:
    check_source()
    command = [str(root / '.venv/bin/python'), 'bin/bench_sentence_expectation.py', workload,
               '--config', config, '--device', 'mps', '--backend', 'eager',
               '--batch-size', str(batch), '--train-steps', str(steps), '--eval-steps', '8',
               '--threads', '1', '--out', str(folder / f'{name}.json'), *extra]
    item = dict(name=name, command=command, started_at=time.time(), status='running')
    status.append(item)
    status_path.write_text(json.dumps(status, indent=2) + '\n')
    print(f'Starting {name}', flush=True)
    with (folder / f'{name}.log').open('w') as log:
        result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    item.update(returncode=result.returncode, ended_at=time.time(),
                status='completed' if result.returncode == 0 else 'failed')
    status_path.write_text(json.dumps(status, indent=2) + '\n')
    check_source()
    print(f'{name}: {item["status"]}', flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
print('All final native benchmark runs completed.', flush=True)
