"""The ordinary unary output dispatcher must use its generation owner too."""
from pathlib import Path
import sys

ROOT = Path('/Users/arogers/github/WikiOracle/basicmodel')
for path in (ROOT / 'bin', ROOT / 'test'):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

import copy
from types import SimpleNamespace
import torch


def test_default_unary_output_does_not_fall_back_to_the_host_inverse():
    from Language import SyntacticLayer, use_generation_catalog
    from Layers import SigmaLayer
    source = SigmaLayer(nInput=4, nOutput=4, invertible=True)
    generated = copy.deepcopy(source)
    with torch.no_grad():
        generated.layer.d.mul_(1.5)
    value = torch.tensor([[[0.1, 0.2, 0.3, 0.4]]])
    expected = generated.reverse(value)
    original = source.reverse(value)
    assert not torch.allclose(expected, original)
    generation = SimpleNamespace(resolve_generation_op=lambda role, name: generated)
    owner = SimpleNamespace(_grammar_is_default_only=True, _generation_space=generation)
    model = SimpleNamespace(languageSpace=generation)
    layer = SyntacticLayer.__new__(SyntacticLayer)
    torch.nn.Module.__init__(layer)
    object.__setattr__(layer, '_word_space', owner)
    object.__setattr__(layer, '_host_space', SimpleNamespace(_sigma_reverse=source.reverse))
    object.__setattr__(layer, '_by_name', {'sigma': source})
    object.__setattr__(layer, 'space_role', 'SS')
    object.__setattr__(layer, '_next_rule_name', lambda **kwargs: 'sigma')
    object.__setattr__(layer, '_read_subspace', lambda subspace, **kwargs: subspace.value)
    object.__setattr__(layer, '_write_subspace',
                       lambda subspace, result, **kwargs: setattr(subspace, 'value', result))

    @use_generation_catalog
    def output(model, carrier):
        return layer.reverse(carrier)

    got = output(model, SimpleNamespace(value=value))
    torch.testing.assert_close(got.value, expected)
    got = layer.reverse(SimpleNamespace(value=value))
    torch.testing.assert_close(got.value, original)
