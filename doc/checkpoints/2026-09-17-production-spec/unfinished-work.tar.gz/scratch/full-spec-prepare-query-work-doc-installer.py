from pathlib import Path
import json
source=Path('/tmp/full-spec-install-nested-retention-docs.py').read_text()
prefix=source[:source.index("outputs['doc/NestedRetention.md']")]
prefix=prefix.replace('nested-retention','query-work').replace('nested-worktree','query-work-worktree').replace('NestedRetention.md','QueryWork.md')
prefix=prefix.replace("'reasoning.py','Spaces.py')","'reasoning.py','Spaces.py','Taxonomy.py','QueryWork.py')")
prefix=prefix.replace("'doc/TaxonomyQueries.md',", "'doc/TaxonomyQueries.md','doc/NestedRetention.md',")
prefix=prefix.replace(r'Models\.py|Layers\.py|Language\.py|Thoughts\.py',r'Queries\.py|Layers\.py|Thoughts\.py|Taxonomy\.py|reasoning\.py')
body='''
outputs['doc/QueryWork.md']=render(Path('/tmp/full-spec-query-work-documentation.md').read_text())
sections={
'doc/Architecture.md': """
### Shared accounting for selected queries

A transient work meter spans selected VP/operand preparation, executor reads
and traversal. Local caps tighten the allowance; they cannot replenish it.
The ordinary thought history remains the episode owner and must record actual
spent cost once. Normal controller integration remains open.
[Meter](@@QueryWork.py:QueryWorkBudget@@),
[dispatch](@@Queries.py:GrammaticalQueryRegistry.execute@@).
See [Query work](QueryWork.md) for cost units and exhaustion behavior.
""",
'doc/GradientFlow.md': """
### Query cost does not change continuous credit

The shared meter counts host-side work and owns no parameters or loss. Live
thought/operand reads preserve the current episode's gradients; durable reads
remain detached. Hard choices and evidence traversal need explicit policy
credit when trained. Exhaustion preserves available signed evidence and reports
incompleteness; it does not create a successful answer or a derivative through
a hard operation. The existing aggregate reconstruction-priority rule is
unchanged by accounting.
[Live read](@@Thoughts.py:LevelledThoughtHistory.resolve_thought@@),
[checked execution](@@Queries.py:QuerySignature.invoke@@),
[Query work](QueryWork.md).
""",
'doc/QueryContracts.md': """
## One meter through preparation and execution

`QueryContext.work` optionally carries the same remaining episode allowance to
selected VP validation, native/occurrence operand reads and the executor.
Taxonomy capture reserves work for proof traversal. Exist retains partial signed
evidence; exhausted Quantize and ARMA preparation cannot perform later reads.
Standalone readers retain their explicit local limits when no meter is supplied.
The normal controller still needs to supply this meter throughout each selected
path and commit actual cost once. No reasoning method is removed.
[Context](@@Queries.py:QueryContext@@),
[preparation](@@Queries.py:GrammaticalQueryRegistry.execute@@),
[allocation](@@QueryWork.py:capture_limits@@), [Query work](QueryWork.md).
""",
'doc/ThoughtHistory.md': """
## Actual executor cost

[Query work](QueryWork.md) supplies a transient meter for the remaining root
allowance. The controller must pass one object through selected reads and nested
callbacks, then record its actual spent cost once in this existing history.
Neither local query caps nor nested contexts create another allowance. The
history's ordinary-work cutoff and `d_cut + 1` termination drain remain the
execution contract; accounting alone does not implement the learned controller.
[Meter](@@QueryWork.py:QueryWorkBudget@@),
[live occurrence read](@@Thoughts.py:LevelledThoughtHistory.resolve_thought@@).
"""}
for name,section in sections.items():outputs[name]+=render(section)
outputs['doc/plans/2026-09-15-next-sentence-as-the-production-objective.md']+=render("""
## 21. Shared selected-query work accounting (in progress)

Selected VP and operand preparation, native payload reads, executor invocation,
fact/occurrence scans, taxonomy capture/traversal and prediction-context reads
can debit one ephemeral meter. Taxonomy capture reserves room for proof work.
Local caps cannot replenish it. Exhaustion preserves available partial evidence
and reports incompleteness rather than establishing falsity or resolution.
[Meter](@@QueryWork.py:QueryWorkBudget@@),
[registry](@@Queries.py:GrammaticalQueryRegistry.execute@@),
[taxonomy allocation](@@QueryWork.py:capture_limits@@).

The existing ordinary history remains the episode owner. Accounting creates no
learned parameter or loss and does not detach live thought operands. Its caller
must supply the remaining episode allowance throughout nested work and commit
actual cost once. The normal learned-controller integration is still open.
[Live reads](@@Thoughts.py:LevelledThoughtHistory.resolve_thought@@).

Primary validation is pending. Thirteen reviewer cases cover shared limits,
preparation reads, partial evidence, nested callbacks and prediction reservation.
The isolated affected run passed 154 tests with one skip. [Query work](../QueryWork.md)
documents the API and its limits.

Linguistic integration, causal ordinary-controller use, owned estimates,
anticipation isolation, residual credit and learned utility remain open.
Unused reasoning methods remain available for the user's grammar-query review;
the separate two-truths specification remains reserved for the next session.
""",prefix='../../bin/')
'''
end=source[source.index('for name,text in outputs.items():\n    assert'):]
end=end.replace('nested-retention','query-work')
out=prefix+body+end
compile(out,'query work docs installer','exec')
Path('/tmp/full-spec-install-query-work-docs.py').write_text(out)
print('Prepared query work docs installer; not executed.')
