from pathlib import Path
import ast,json
root=Path('/Users/arogers/github/WikiOracle/basicmodel')
marks={
 'test/test_aligned_fold_binding.py': ['test_mini_basicmodel_ps128_ws128_cs1024_runs_forward_backward'],
 'test/test_basicmodel.py': ['TestSPNN.test_xor_training'],
 'test/test_blind_decode.py': ['test_blind_rate_default_is_scaffold','test_blind_decode_ignores_scaffold_spans','test_blind_size_hypotheses_from_claim_diffs','test_curriculum_fraction_masks_some_tiles','test_recon_bench_blind_flag'],
 'test/test_compile_static_loop.py': ['test_per_word_body_does_not_recompile_on_accumulator_length'],
 'test/test_math_thinking_training.py': ['test_stage_zero_direct_arithmetic_learns_as_syntax','test_stage_one_dependency_chains_learn_as_syntax'],
 'test/test_mm_xor.py': ['TestMMXOR.test_learns_xor_signal','TestMMXOR.test_mm_grammar_learns_xor_signal','TestMMXOR.test_convergence'],
 'test/test_output_path_supervised.py': ['test_output_path_memorizes_supervised_labels_on_the_parallel_topology','test_output_path_memorizes_supervised_labels_on_the_serial_topology'],
 'test/test_what_training.py': ['test_temporal_question_content_is_causally_used','test_joint_training_keeps_both_primary_costs_in_band','test_supplied_text_answer_quality_improves_with_training'],
}
# Resolve all names before touching files; use only exact chosen nodes.
prepared={}
for name,wanted in marks.items():
 source=(root/name).read_text();tree=ast.parse(source);found={}
 def visit(node,path=()):
  if isinstance(node,(ast.FunctionDef,ast.ClassDef)):
   path=path+(node.name,)
   found['.'.join(path)]=node
  for child in ast.iter_child_nodes(node):visit(child,path)
 visit(tree)
 # unittest class spelling is not part of the selection's behavior.
 for value in list(wanted):
  if value not in found:
   matches=[k for k in found if k.endswith('.'+value.split('.')[-1])]
   assert len(matches)==1,(name,value,matches)
   wanted[wanted.index(value)]=matches[0]
 lines=source.splitlines(keepends=True)
 for value in sorted(wanted,key=lambda x:found[x].lineno,reverse=True):
  node=found[value]
  line=min([node.lineno]+[d.lineno for d in node.decorator_list])-1
  assert not any(ast.unparse(d)=='pytest.mark.slow' for d in node.decorator_list)
  lines.insert(line,' '*node.col_offset+'@pytest.mark.slow\n')
 prepared[name]=''.join(lines)
 assert 'import pytest' in prepared[name],name
plugin=root/'test/slow_tests.py';assert not plugin.exists()
plugin.write_text('''"""Central RUN_SLOW gate for long training, quality and compilation checks."""
import os
import pytest


def pytest_configure(config):
    config.addinivalue_line(
        "markers", "slow: long training/quality/compilation check; opt in with RUN_SLOW=1")


def pytest_collection_modifyitems(items):
    if os.environ.get("RUN_SLOW") == "1":
        return
    skipped = pytest.mark.skip(reason="slow -- set RUN_SLOW=1")
    for item in items:
        if item.get_closest_marker("slow") is not None:
            item.add_marker(skipped)
''')
p=root/'test/conftest.py';s=p.read_text();assert 'pytest_plugins' not in s
p.write_text(s+'\n\n# Skip expensive checks before fixture/model construction, using the existing switch.\npytest_plugins = ["slow_tests"]\n')
for name,source in prepared.items():(root/name).write_text(source)
Path('/tmp/full-spec-test-mode-selections.json').write_text(json.dumps(marks,indent=2)+'\n')
print('Marked',sum(map(len,marks.values())),'long-running functions in',len(marks),'files')
