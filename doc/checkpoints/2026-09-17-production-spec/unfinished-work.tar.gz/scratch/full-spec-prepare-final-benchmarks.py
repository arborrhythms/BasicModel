from pathlib import Path
import hashlib
import json
import os
import subprocess

root = Path('/Users/arogers/github/WikiOracle/basicmodel')
folder = root / 'doc/benchmarks/2026-09-16-tied-reconstruction-data'
env = dict(os.environ, DEVELOPER_DIR='/Library/Developer/CommandLineTools')
base = 'aa5e018b67bf3be946c0b75c5baf33c9cc84ab4b'
processes = subprocess.check_output(['ps', '-axo', 'args'], text=True)
if any('-m pytest ' in line or 'bin/bench_sentence_expectation.py ' in line for line in processes.splitlines()):
    raise RuntimeError('Another test or benchmark is running')
tracked = ['bin/Models.py', 'bin/Language.py', 'bin/Layers.py', 'bin/Spaces.py', 'bin/Understanding.py',
           'bin/bench_sentence_expectation.py', 'data/BasicModel.xml', 'data/model.xsd']
new = ['data/BasicModel_answers_tied_benchmark.xml', 'data/BasicModel_long_tied_benchmark.xml',
       'data/BasicModel_output_tied_benchmark.xml', 'data/tied_reconstruction_output_benchmark.grammar']
manifest = {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in tracked + new}
(folder / 'final-candidate-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
patch = subprocess.check_output(['git', 'diff', '--binary', base, '--', *tracked], cwd=root, env=env)
for p in new:
    result = subprocess.run(['git', 'diff', '--binary', '--no-index', '/dev/null', p],
                            cwd=root, env=env, stdout=subprocess.PIPE)
    if result.returncode != 1:
        raise RuntimeError(f'Expected a new-file diff for {p}')
    patch += result.stdout
(folder / 'final-candidate-source.patch').write_bytes(patch)
worktree = Path('/tmp/basicmodel-aa5e018-reconstruction-baseline')
if not worktree.exists():
    subprocess.run(['git', 'worktree', 'add', '--detach', str(worktree), base], cwd=root, env=env, check=True)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=worktree, env=env, text=True).strip()
if head != base:
    raise RuntimeError(f'Unexpected baseline revision: {head}')
(worktree / 'bin/bench_sentence_expectation.py').write_bytes((root / 'bin/bench_sentence_expectation.py').read_bytes())
observer_patch = subprocess.check_output(['git', 'diff', '--binary', '--', 'bin/bench_sentence_expectation.py'], cwd=worktree, env=env)
(folder / 'legacy-observer-source.patch').write_bytes(observer_patch)
print(f'Final candidate manifest contains {len(manifest)} source/config files; baseline is {worktree}', flush=True)
