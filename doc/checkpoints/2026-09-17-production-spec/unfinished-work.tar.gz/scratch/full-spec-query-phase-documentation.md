# Query execution phases

Implementation reference. Validation is pending.

## Permission follows completed sentence rows

`resolveAnswer()` accepts an owned `Understanding`. When tied reconstruction is
enabled, that value must already own its completed input reconstruction. Its
nonempty captured programs identify the completed rows; a padded or missing row
cannot execute a query. A program-less compatibility topology can still prepare
its answer, but lacks per-row sentence-commit evidence for the checked executor.
Held understandings keep their own readiness after later staging.
[Boundary](@@Models.py:BasicModel.resolveAnswer@@),
[completed rows](@@Models.py:BasicModel._completed_query_rows@@).

The permission opens only around conceptual answer resolution. `finally`
restores the previous permission on success or exception. Nested resolution can
narrow the parent's allowed rows but cannot enable another batch row. Being at
an input boundary does not itself select a query or turn a proposition into a
true assertion; the checked grammatical contract still validates the selected
interrogative relation and its operands.
[Scope](@@Models.py:BasicModel._query_boundary_scope@@),
[signature](@@Queries.py:QuerySignature.invoke@@).

## Sentence work masks execution

The input `forward()`, explicit compiled-state forward, input-executor wrapper,
input-reconstruction completion, `reverseReconstruct()` and `reverseOutput()`
mask query execution for the duration of sentence work. Nested sentence work
cannot reopen a reasoning boundary. The input wrapper also covers supplied
executors used by `understand()` and `what()`.
[Mask](@@Models.py:_sentence_query_mask@@),
[executor wrapper](@@Models.py:BasicModel._execute_input_sentence@@),
[explicit forward](@@Models.py:BasicModel._forward_with_compiled_sentence_state@@),
[reconstruction](@@Models.py:BasicModel._complete_input_reconstruction@@),
[output](@@Models.py:BasicModel.reverseOutput@@).

Both direct checked calls and shared-VP dispatch apply permission before
operand occurrence resolution or executor work. Pure grammatical formation
remains available: constructing or realizing a question does not execute it.
Standalone evidence readers without a sentence runtime retain their explicit
read API. The legacy `answer_query()`, `reason_about()` and `think_about()`
entry points also reject calls inside sentence processing; their remaining
production migration is separate from this guard.
[Query preparation](@@Queries.py:GrammaticalQueryRegistry.execute@@),
[direct call](@@Queries.py:_require_query_boundary@@),
[legacy API](@@Models.py:BasicModel.answer_query@@).

## Compilation and gradients

The phase permission is host execution state, not a tensor, semantic feature,
learned parameter, or checkpoint field. Compiled tracing rejects query calls
directly. Captured numerical execution does not mutate the temporary phase flag;
the host input wrapper masks the compiled call and any eager islands and restores
permission afterward. This avoids relying on compiler replay of attribute-only
updates. There is no change to the 21-result forward tuple.
[Compile guard](@@Models.py:BasicModel._assert_queries_outside_sentence@@),
[mask](@@Models.py:_sentence_query_mask@@).

The guards perform no tensor detachment and add no loss. Input reconstruction,
predictive representation feedback and prepared-answer gradients retain their
existing routes; [GradientFlow](GradientFlow.md) documents their joint balance.
The real fullgraph probe checks one graph across different word counts, forward
and backward, and phase restoration after each invocation.

## Validation and remaining integration

Record actual affected and full-suite results after installation. Reviewer probes
cover registered/legacy execution, preparation reads, complete/incomplete rows,
nested scopes, exceptions, held understandings, supplied executors and real
compiled forward/backward.

This guard does not implement the ordinary learned controller, derive complete
linguistic query meaning, retire normal raw-text query dispatch, or establish
causal learned reasoning. Those remain separate gates in the
[integrated spec](plans/2026-09-15-next-sentence-as-the-production-objective.md).
