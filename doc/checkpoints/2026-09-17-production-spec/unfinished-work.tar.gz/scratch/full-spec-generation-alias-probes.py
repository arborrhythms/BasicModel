"""Reordering aliases cannot rename a generation parameter owner."""
from pathlib import Path
import sys
from types import SimpleNamespace

ROOT = Path('/Users/arogers/github/WikiOracle/basicmodel')
for path in (ROOT / 'bin', ROOT / 'test'):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

import torch


def test_generate_alias_order_preserves_operator_checkpoint_identity(monkeypatch):
    import Language
    import util

    source = torch.nn.Linear(4, 4)
    coordinator = SimpleNamespace(
        languageLayer=None, muxedSize=4, _grammar_is_default_only=False,
        _host_layer_registry={('CS', 'sum'): source},
        _resolve_rule_layer=lambda role, name: source)
    symbols = SimpleNamespace(subspace=coordinator)
    grammar = SimpleNamespace(rules_upward=[], rule_table=[], rules_downward=[])
    monkeypatch.setattr(Language, 'TheGrammar', grammar)
    monkeypatch.setattr(util.TheXMLConfig, 'training', lambda name, default=None: False)

    def catalog(roles):
        grammar.rules_downward = [SimpleNamespace(
            space_role=role, method_name='sum', lhs='X,Y',
            canonical='X,Y = sum.reverse(Z)', width_min=None, width_max=None)
            for role in roles]
        before = torch.get_rng_state().clone()
        result = Language.LanguageSpace(symbols)
        assert torch.equal(torch.get_rng_state(), before)
        assert result.resolve_generation_op('CS', 'sum') is result.resolve_generation_op('SS', 'sum')
        assert len(result.generation_ops) == 1
        assert set(map(id, result.parameters())).isdisjoint(map(id, source.parameters()))
        return result

    first = catalog(('CS', 'SS'))
    with torch.no_grad():
        for parameter in first.parameters():
            parameter.fill_(.375)
    second = catalog(('SS', 'CS'))
    # No tensor-row remapping is needed: this is the same numerical operator
    # reached through the same two interfaces, only declared in another order.
    second.load_state_dict(first.state_dict(), strict=True)
    assert set(first.state_dict()) == set(second.state_dict())
    for name, value in first.state_dict().items():
        torch.testing.assert_close(second.state_dict()[name], value, rtol=0, atol=0)
