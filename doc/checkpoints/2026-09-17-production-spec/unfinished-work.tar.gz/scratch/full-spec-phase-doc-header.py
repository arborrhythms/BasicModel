"""Render query-phase documentation and remap current-source links exactly once."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import re

root=Path('/Users/arogers/github/WikiOracle/basicmodel')
work=Path('/tmp/full-spec-phase-worktree')
base=Path('/tmp/full-spec-query-phase-base')
receipt=Path('/tmp/full-spec-query-phase-doc-remap-applied.json')
assert not receipt.exists(), 'Do not remap links twice'
assert not (root/'doc/QueryPhases.md').exists()
for name,digest in json.loads((work/'validation-manifest.json').read_text()).items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name

def definitions(text):
    found={}
    def visit(node,path=()):
        if isinstance(node,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)):
            path=path+(node.name,)
            found['.'.join(path)]=(node.lineno,node.end_lineno)
        for child in ast.iter_child_nodes(node):
            visit(child,path)
    visit(ast.parse(text))
    return found

maps={}; anchors={}
for name in ('Thoughts.py','Queries.py','Language.py','Layers.py','Models.py','Understanding.py','reasoning.py','Spaces.py'):
    new=(root/'bin'/name).read_text()
    new_defs=definitions(new)
    anchors.update({name+':'+key:value[0] for key,value in new_defs.items()})
    if not (base/'bin'/name).exists():
        continue
    old=(base/'bin'/name).read_text()
    old_defs=definitions(old)
    old_lines,new_lines=old.splitlines(),new.splitlines()
    mapping={}
    for op,i,j,a,b in difflib.SequenceMatcher(None,old_lines,new_lines,autojunk=False).get_opcodes():
        for index in range(i,j):
            if op=='equal':
                mapping[index+1]={'line':a+(index-i)+1,'kind':'exact'}
                continue
            enclosing=[(hi-lo,key) for key,(lo,hi) in old_defs.items()
                       if lo<=index+1<=hi and key in new_defs]
            if enclosing:
                _,key=min(enclosing)
                mapping[index+1]={'line':new_defs[key][0],'kind':'definition','name':key}
            else:
                mapping[index+1]={'line':min(len(new_lines),a+1),'kind':'adjacent'}
    maps[name]=mapping

names=['doc/Architecture.md','doc/GradientFlow.md','doc/Language.md','doc/Params.md',
       'doc/Training.md','doc/QueryContracts.md','doc/ThoughtHistory.md','doc/STM.md','doc/ExistenceEvidence.md','doc/TaxonomyQueries.md',
       'doc/plans/2026-09-15-next-sentence-as-the-production-objective.md']
pattern=re.compile(r'\[([^\]]+)\]\(((?:\.\./)+bin/(Models\.py|Queries\.py))#L(\d+)\)')
changes=[]
def remap(match):
    label,target,filename,line=match.groups()
    mapping=maps[filename][int(line)]
    new=str(mapping['line'])
    changes.append({'file':filename,'old':int(line),**mapping})
    return '['+label.replace(filename+':'+line,filename+':'+new)+']('+target+'#L'+new+')'
def render(text,prefix='../bin/'):
    return re.sub(r'@@([^@]+)@@',lambda m:prefix+m[1].split(':',1)[0]+'#L'+str(anchors[m[1]]),text)
outputs={}
for name in names:
    text=(root/name).read_text()
    if '/plans/' in name:
        protected=False; parts=[]
        for part in re.split(r'(?=^## |^### )',text,flags=re.M):
            if part.startswith('## '):
                protected=part.startswith(('## 6.','## 7.','## 11.'))
            if part.startswith('### 11.6 '):
                protected=False
            parts.append(part if protected else pattern.sub(remap,part))
        text=''.join(parts)
    else:
        text=pattern.sub(remap,text)
    outputs[name]=text

def replace_once(name,old,new):
    assert old in outputs[name],(name,old)
    outputs[name]=outputs[name].replace(old,new,1)

