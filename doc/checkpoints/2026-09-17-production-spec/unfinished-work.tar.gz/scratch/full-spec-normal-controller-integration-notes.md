# Normal controller integration — verified constraints, not implementation

Read the standing invariants after compaction. Do not edit repository source
while registry full-suite session53030 is active. Do not adopt the separate
two-truths spec. The prepared history API is still not the normal learned loop.

## Current source boundary (registry frozen manifest, September 16)

- `Models._capture_understanding` publishes the compiled result, then captures
  owned answer programs and completes reconstruction (Models7954/8010). Programs
  retain selected action kinds/local operation IDs, live leaves and native concept
  IDs. `_answer_leaf_slab` (11882) scales aligned dictionary atoms by the selected
  symbol activations; raw row IDs are not concept IDs or semantic features.
- `_capture_answer_programs` (12072) and `_replay_program` (12187) provide the
  identified compose trace. Replay chooses forward unary/binary operation banks;
  canonical grammatical meaning must derive from these selected operations,
  retaining actual operands rather than reading the collapsed root as NP1/VP/NP2.
- All three observation writers still run before/independently of Understanding:
  `_drain_pending_stm_end_state` (12778), `_drain_packed_stm_end_states` (12837),
  and eager `_run_tensor_peer_word_pipeline` sink block (21665/21693). The eager
  packed path drains at21595+. Attaching a Meaning only after capture would leave
  LTM/predictor targets semantically incomplete. Thread owned completed meanings
  through all writers, preserve once-only observation and the 21-result contract.
- `Grammar.configure` (Language1092) maps each closed-class surface to a single
  operator anchor. That is not a multi-sense lexicon. The semantic adapter must
  use the identified grammatical sense and explicit converse permutation;
  mapping every occurrence of "has" to parthood would violate the spec. Recognition
  and generation need declared compatible surfaces, with distinct other senses.
- `_dispatch_method_name_for_rule` (Language4423) still has an explicit legacy
  query-flag numerical alias. The normal representation/execution distinction
  needs a pure interrogative composition/inverse route and phase permission;
  a quoted question must remain content. Do not replace old regex dispatch with
  another lexical shortcut.
- `WhatStepChooser` (Language7151) consumes29context+6lexicalcandidate features.
  `_what_step_chooser` (Models8363), `_begin_referents` (8450+) and the current
  selection block8585+ still implement the word-menu/parity path. Merely installing
  the new registry/history does not replace them or provide semantic policy input.
- `GlobalAttention` (Spaces533) is an existing typed optional-field mechanism,
  but its forward detaches queries and keys and truncates to a common leading
  width (Spaces680+). It cannot be reused unchanged for full semantic episode
  credit. Its `_cos_keys` primitive (619) itself preserves gradients; mandatory
  question/NP/VP/NP roles must remain separate from optional top-k retrieval.
- `_attend_ltm` (Models8405+) flattens legacy responses and uses minimum key width;
  the ordinary path must consume full structured child results with their actual
  support/provenance. A trace attachment or boolean alone is insufficient.

## Concrete next dependency order

1. Decode selected compose semantics from owned programs, preserving native VP,
   canonical operands, mode, polarity, scope/bindings and nested occurrences.
   Keep input surface order/derivation independent for reconstruction. Use the
   existing occurrence/constituent owners, not a new authoritative semantic tree.
   Test actual selected part/whole/equal/exist parses and distinct senses before
   asserting linguistic/internal equivalence. Every observation writer must use
   the same canonical completed meaning before its one observation.
2. Per-row phase permissions around composition, reconstruction and generation;
   only completed selected questions at the boundary may execute the registry.
   Resolve before `reverseOutput`, and causally use the actual result in the
   owned answer. Retire the normal raw-text fallback; preserve explicit legacy
   experiment APIs only where clearly named.
3. Semantic ordinary controller over the prepared one-owner history. Preserve
   mandatory root/active/current/candidate roles and masks. Separate retrieval R,
   optional attention K, payload widths and STM depth. Native IDs stay addresses.
   Use independent whatThinkingHidden/Depth capacity, explicit optimizer ownership,
   checkpoint migration and policy credit. It is a chooser, not an unconstrained
   next-state generator. Returned child results must change choices/root answers.
4. Charge actual executor preparation/record reads/path expansions against the
   same episode budget, not each local bound independently. A local maximum can
   tighten the remaining budget; it cannot renew it. Candidate formation must
   stay side-effect-free. At cutoff only the recorded d_cut+1 termination drain
   remains. One optimizer step; live continuous states stay live until then.
5. Owned estimates and observations, anticipation prior-view isolation (including
   dictionaries/staging and unseen packed slots), observed residual reward/work
   penalty/baseline and parameter-version-safe delayed credit. Keep observed
   targets/durable history detached while allowing current-step source feedback.
6. Separate compose/generate module catalogs, then held-out utility/causal
   ablations and quality/throughput evidence. Report null results explicitly.

These notes are a source audit and dependency plan, not a completion claim.
