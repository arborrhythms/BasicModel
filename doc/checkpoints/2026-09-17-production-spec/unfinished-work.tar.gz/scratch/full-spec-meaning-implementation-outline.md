# Selected-meaning integration outline (not implemented)

September 17. Primary full suite v4 remains frozen. The isolated Language
candidate has the pure-dispatch/rule-snapshot fix following three genuine red
cases; its green rerun is pending. Eleven semantic cases are prepared but have
not run, so do not implement their missing API before obtaining that red.

## Immediate bounded change

`LanguageSpace.program_meaning(entry, registry)` interprets the owned selected
actions, not raw words, later global grammar state, answer targets, row numbers
as features, or only the folded root. The local rule snapshots are immutable.
For selected part/whole/equal faces, preserve the actual signed live operands,
the registry's single native middle VP, the declared converse permutation and
selected interrogative mode. Preserve all physical actions and the input
reconstruction product. The first probes cover this primitive relation case;
they do not prove arbitrary nested composition or natural-language paraphrases.

Unknown native references must remain unknown. An opaque compound operand must
not be silently reidentified by a dictionary row, assigned a tool-name string,
or replaced by a unit lookup. A later nested integration must commit its
constituents through an existing occurrence owner with atomic bounds. No new
authoritative semantic AST is allowed. The two-truths revision remains reserved
for the next session.

## Normal boundary ownership

Capture meanings for all completed programs at the same host boundary where
their signed leaves, selected local actions, final slots and chronological
packed seals are available. Share those products with Understanding and the
three writers; do not reinterpret them after later staging. Keep any cache
forward-local and invalidate it at input/compiled publication, including
exploration trials and mixed/packed rows. No target or future sentence becomes
a preceding context through this cache.

All three normal observation sites must use canonical infix payloads and masks
before predictor observation and the durable append. The current source sites
are `_drain_pending_stm_end_state`, `_drain_packed_stm_end_states`, and the
unpacked eager sink within `_run_tensor_peer_word_pipeline`. The packed eager
path already calls the packed drain. Preserve the 21-value compiled contract,
once-only external observations, per-row trust and per-slot document IDs.
Durable stores detach; current-step predictor source paths remain live under
the aggregate reconstruction-priority gradient rule.

Registry setup must occur after the conceptual owner exists and before input
staging. Reuse its named/checkpointed native VP bindings. Do not install
unrelated VPs into legacy grammars with no declared faces or query entries;
small fixed-capacity configurations must not receive an accidental new table.
Checkpoint migration and construction order need explicit tests.

The pure-dispatch change also affects `LanguageSpace._generate_rule_key`, which
hashes the dispatch method name. Review custom legacy `query="true"` generate
catalogs before landing: their former geometric-query keys differ from the
pure relation keys. Default complete.grammar relations use `query="false"`,
but that does not prove custom checkpoint migration. Add a probe and document
whether incompatible old action meaning is rejected or explicitly reset;
do not claim silent row reinitialization preserves the old policy.

## Following gates, still open

- Unary mode/polarity, unreduced three-slot lexical relations, quoted/embedded
  questions and lexical sense selection must use selected grammatical meaning.
  The current one-operator Anchors map cannot establish multiword paraphrases
  or distinguish senses of `has` by itself.
- A separate semantic thought chooser needs mandatory root/active/current and
  candidate NP/VP/NP roles outside optional retrieval R and attended K. Use full
  conceptual widths and masks, not the detached/truncated legacy attention.
- The normal levelled controller must consume this meaning and actual child
  evidence, record all selected operations and answers, charge one shared
  budget before reads, and link the final thought to generated output. Keep
  unused reasoning methods; replacing their normal call sites is not removal.
- Anticipation needs a prior view isolated from dictionaries, staging, other
  rows and unseen packed sentences. Residual policy reward needs a separate
  baseline and parameter-version-safe trajectory credit; do not backpropagate
  a graph across an intervening optimizer step.
- `/tmp/full-spec-arithmetic-isolation-probes.py` is prepared and AST-valid,
  but has not run. It poisons exact helpers after corpus construction and
  exercises actual sentence paths and supervised training. The training case
  is an explicit slow integration gate. Native-ID renumbering is also covered
  by the selected-meaning probes; chooser/logit and renamed-vocabulary learning
  gates remain open.

No new implementation or passing-test claim is made by this outline.
