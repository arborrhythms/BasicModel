"""Independent generation values and optimizer state survive strict reload."""
from pathlib import Path
import sys

ROOT = Path('/Users/arogers/github/WikiOracle/basicmodel')
for path in (ROOT / 'bin', ROOT / 'test'):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

import pytest
import torch
from test_meronomy_ladder import _build_ladder_variant


def _model(tmp_path, name='catalog_checkpoint', *, flat=False):
    edits = []
    if flat:
        from test_output_path_supervised import _build
        source = (ROOT / 'data/MM_xor.xml').read_text()
        source = source.replace('<grammar>xor.grammar</grammar>',
                                '<grammar><P>sigma(P)</P><C>pi(C)</C><S>sigma(S)</S></grammar>')
        config = tmp_path / 'flat_compatibility.xml'
        config.write_text(source)
        return _build(config, 'xor')
    return _build_ladder_variant(tmp_path, name, edits)


def test_generation_values_and_adam_moments_are_independent_after_reload(tmp_path):
    m = _model(tmp_path)
    fresh = None
    try:
        m._materialize_answer_path()
        generated = m.languageSpace.resolve_generation_op('CS', 'lift')
        source = m.symbolSpace.subspace._resolve_rule_layer('CS', 'lift')
        opt = m.getOptimizer(lr=.001)
        m._optimizer = opt
        # Isolate the ownership/migration contract without a sentence compiler.
        total = sum(p.square().sum() + .25 * p.sum() for p in generated.parameters())
        total = total + sum(.125 * p.sum() for p in source.parameters())
        total.backward()
        opt.step()
        expected = {name: p.detach().clone() for name, p in generated.named_parameters()}
        moments = {name: {k: v.detach().clone() for k, v in opt.state[p].items()}
                   for name, p in generated.named_parameters()}
        assert any(not torch.equal(expected[name], dict(source.named_parameters())[name])
                   for name in expected)
        path = tmp_path / 'split_catalog.ckpt'
        m.save_weights(str(path))
        fresh = _model(tmp_path, 'catalog_reload')
        assert fresh.load_weights(str(path), strict=True, require_match=True)
        restored = fresh.languageSpace.resolve_generation_op('CS', 'lift')
        other = fresh.symbolSpace.subspace._resolve_rule_layer('CS', 'lift')
        restored_opt = fresh.getOptimizer(lr=.001)
        owned = [id(p) for group in restored_opt.param_groups for p in group['params']]
        for name, p in restored.named_parameters():
            assert p is not dict(other.named_parameters())[name]
            assert owned.count(id(p)) == 1
            torch.testing.assert_close(p, expected[name], rtol=0, atol=0)
            for key, value in moments[name].items():
                torch.testing.assert_close(restored_opt.state[p][key], value, rtol=0, atol=0)
        restored_opt.zero_grad(set_to_none=True)
        sum(p.square().sum() for p in restored.parameters()).backward()
        restored_opt.step()
    finally:
        m.End()
        if fresh is not None:
            fresh.End()
        torch._dynamo.reset()


def test_partial_generation_checkpoint_does_not_silently_copy_comprehension(tmp_path):
    m = _model(tmp_path)
    fresh = None
    try:
        m._materialize_answer_path()
        path = tmp_path / 'partial_catalog.ckpt'
        m.save_weights(str(path))
        saved = torch.load(path, weights_only=False)
        keys = [key for key in saved['state_dict'] if '.generation_ops.' in key]
        assert len(keys) > 1
        removed = keys[0]
        del saved['state_dict'][removed]
        torch.save(saved, path)
        fresh = _model(tmp_path, 'catalog_partial')
        # The public loader reports strict incompatibility with False.
        assert fresh.load_weights(str(path), strict=True, require_match=True) is False
    finally:
        m.End()
        if fresh is not None:
            fresh.End()
        torch._dynamo.reset()


def test_flat_natural_fold_output_fallback_also_has_independent_owners(tmp_path):
    from Language import TheGrammar
    m = _model(tmp_path, flat=True)
    try:
        owner = m.symbolSpace.subspace
        assert owner._grammar_is_default_only
        assert not TheGrammar.rules_downward, 'probe must exercise legacy implicit inverses'
        rules = owner._default_generate_rules()
        assert rules
        count = 0
        for role, rows in rules.items():
            for rule_id in rows[0]:
                method = TheGrammar.rules[rule_id].method_name
                source = owner._host_layer_registry.get((role, method))
                if source is None:  # retired subsymbolic dispatch has no host
                    continue
                count += 1
                generated = m.languageSpace.resolve_generation_op(role, method)
                assert generated is not source
                for name, p in generated.named_parameters():
                    expected = dict(source.named_parameters())[name]
                    assert p is not expected
                    torch.testing.assert_close(p, expected, rtol=0, atol=0)
        assert count, 'the fixture must exercise a live natural-fold dispatcher'
    finally:
        m.End()
        torch._dynamo.reset()
