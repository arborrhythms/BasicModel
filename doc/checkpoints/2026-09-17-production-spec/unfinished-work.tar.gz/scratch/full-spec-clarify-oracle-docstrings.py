from pathlib import Path
import ast,hashlib,json
primary=Path('/Users/arogers/github/WikiOracle/basicmodel');work=Path('/tmp/full-spec-thought-worktree')
path=primary/'bin/exact.py';before=path.read_text();tree=ast.parse(before)
header='''"""Oracle utilities for generating and evaluating arithmetic test corpora.

Arithmetic is a formal-grammar learning task over arbitrary symbols. These
parameter-free helpers compute corpus labels and evaluation results; the learner
must not call them to answer a question, choose a subgoal or construct an answer
representation. Solver bindings and oracle traces are not learner inputs.

* ``ExactLexer`` and ``ExactState`` implement the oracle's equation parsing,
  scratch state and recorded primitives for generation/evaluation utilities.
* ``MathProblemGenerator`` creates problems with labels, structural splits and
  oracle metadata. Only the permitted input surface and scoring targets cross
  the dataset boundary.
* ``ExactVerifier`` and ``illumination`` are evaluation-side helpers.
* ``numeral_code`` is a legacy encoding utility for isolated tests/oracles.
  Its binary-digit/one-hot encoding is not an authorized learner fallback.

The model's numeral concepts have arbitrary native addresses. Its grammar,
prediction, reasoning and output must use learned symbol-attached meanings,
without interpreting an address or a numeral surface as a numeric operand.
See ``doc/ArbitrarySymbols.md`` and ``doc/SymbolFirewall.md``.
"""'''
lines=before.splitlines(True);after=header+'\n'+''.join(lines[tree.body[0].end_lineno:])
after=after.replace('''    # Premise indices the model has APPLIED (evaluate / substitute /
    # constrain); the oracle-side candidate measure counts only these.''','''    # Premise indices the oracle trace has applied (evaluate / substitute /
    # constrain); the evaluation-side candidate measure counts only these.''')
old='''    integers give distinct codes; the model's answer symbol root slot
    receives it when no lexicon row exists for the numeral surface.'''
new='''    integers give distinct codes. This is an isolated legacy oracle/test
    utility; it must not seed a learner's answer or bypass its symbol lexicon.'''
assert old in after;after=after.replace(old,new,1)
class StripDocs(ast.NodeTransformer):
 def visit(self,node):
  node=super().visit(node)
  if isinstance(node,(ast.Module,ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)) and node.body and isinstance(node.body[0],ast.Expr) and isinstance(node.body[0].value,ast.Constant) and isinstance(node.body[0].value.value,str):node.body=node.body[1:]
  return node
assert ast.dump(StripDocs().visit(ast.parse(before)))==ast.dump(StripDocs().visit(ast.parse(after)))
target=work/'bin/exact.py';assert not target.exists();target.write_text(after)
for file,digest in [('base-manifest.json',hashlib.sha256(path.read_bytes()).hexdigest()),('validation-manifest.json',hashlib.sha256(target.read_bytes()).hexdigest())]:
 p=work/file;data=json.loads(p.read_text());assert 'bin/exact.py' not in data;data['bin/exact.py']=digest;p.write_text(json.dumps(data,indent=2)+'\n')
Path('/tmp/full-spec-oracle-docstrings-review.json').write_text(json.dumps({'source':'bin/exact.py','change':'Documentation and comments only; normalized executable AST unchanged.','runtime_helpers_removed':False,'primary_modified':False},indent=2)+'\n')
for file in ['full-spec-arbitrary-symbol-audit.md','full-spec-arbitrary-symbol-documentation.md']:
 p=Path('/tmp')/file;s=p.read_text().replace('The module\'s old description of a\n  "model-owned scratchpad" is stale.','The module previously described a\n  "model-owned scratchpad"; its documentation is being corrected to its oracle-only role.')
 if file.endswith('documentation.md'):
  for old,new in {'../bin/exact.py#L98':'@@exact.py:eval_expr@@','../bin/exact.py#L275':'@@exact.py:ExactState@@','../bin/exact.py#L397':'@@exact.py:numeral_code@@'}.items():assert old in s;s=s.replace(old,new)
 p.write_text(s)
p=Path('/tmp/full-spec-install-thought-history-docs.py');s=p.read_text().replace("'reasoning.py','Spaces.py')","'reasoning.py','Spaces.py','exact.py')");p.write_text(s)
print('Oracle documentation clarified in isolated history candidate; executable AST identical. No helpers removed.')
