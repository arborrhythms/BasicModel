from pathlib import Path
import ast,json
entries=[dict(key='history', old='/tmp/full-spec-finalize-thought-history-validation.py',
 slug='thought-history', doc='ThoughtHistory', section='18. Ordinary thought-history and live occurrence APIs',
 count=33, heading='Add levelled thought history and live occurrence reads',
 body='Store ordinary structured thoughts and explicit nested transitions in the existing per-row memory owner. Replay exact contexts, enforce the shared budget and bounded cutoff drain, retain referenced records and preserve live episode credit until the optimizer boundary. Checkpoint through the existing structural sidecar without a second planner store.'),
 dict(key='phase', old='/tmp/full-spec-finalize-query-phase-validation.py',slug='query-phase',
 doc='QueryPhases',section='19. Sentence masks and completed-row query permission',count=23,
 heading='Enforce query execution boundaries around sentence processing',
 body='Open checked query execution only for completed rows during answer resolution after enabled tied input reconstruction. Mask composition, reconstruction, generation and supplied executors; reject query tracing before operand reads. Keep temporary permission on the host and restore it on errors without changing the forward tuple, parameters, losses or gradient paths.')]
for info in entries:
 tree=ast.parse(Path(info['old']).read_text())
 sources=next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='sources' for t in n.targets))
 info['sources']={ast.literal_eval(k):ast.literal_eval(v) for k,v in zip(sources.keys,sources.values) if isinstance(v,ast.Constant)}
 info['sources'].pop('source-ownership-guard.py',None)
 info['sources'].pop('validation-manifest.json',None)
 for path in info['sources'].values(): assert Path(path).is_file(),path
 olds=[ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='old' for t in n.targets) and isinstance(n.value,ast.Constant)]
 info['old_doc'],info['old_spec']=olds
 info['old_header']='Implementation reference, September 16. Repository validation is in progress.' if info['key']=='history' else 'Implementation reference. Validation is pending.'
Path('/tmp/full-spec-bounded-stage-config.json').write_text(json.dumps(entries,indent=2)+'\n')
print('Prepared history/phase stage configuration; red/affected artifact paths exist.')
