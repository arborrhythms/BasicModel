draft=Path('/tmp/full-spec-thought-history-documentation.md').read_text()
draft=draft.replace('Draft implementation reference. Repository installation and validation are\npending the checked-query commit cycle.',
                    'Implementation reference, September 16. Repository validation is in progress.')
outputs['doc/ThoughtHistory.md']=render(draft)
sections={
'doc/Architecture.md': '''
## Ordinary thought-history owner (September 16)

`SymbolSpace.what_memory` remains the single interaction owner. Its existing
per-row deque now accepts ordinary structured thoughts and explicit level and
termination transitions. Replay derives active/suspended contexts; these views
do not own a second planner stack. Native occurrence references, scope, evidence
and the one root budget survive checkpoint restore. A closed legacy prefix is
retained through an explicit compatibility adapter.
[Owner](@@Layers.py:WhatInteractionMemory@@),
[replay](@@Thoughts.py:replay_thoughts@@),
[history contract](ThoughtHistory.md).

Normal learned selection, linguistic integration and causal answer construction
remain subsequent work. These APIs have not replaced the legacy production loop.
''',
'doc/GradientFlow.md': '''
## Live ordinary episode history

Episode-mode writes clone complete meanings without detaching their continuous
computation. Description queries can resolve that live value from a `thought`
occurrence in the same owner. Durable `ltm` reads remain detached. Addresses,
hard evidence matches and context transitions have no ordinary derivative.
[Write](@@Thoughts.py:LevelledThoughtHistory._store_thought_events@@),
[query read](@@Queries.py:_occurrence_description@@).

Explicit finish is required before `end_what_episode` releases ordinary credit.
The caller must perform its single optimizer step first; release then detaches
retained meanings, legacy prompts and trace tensors. Checkpoints detach copies
without cutting the live training graph. Restore preserves detached past values
and permits fresh credit for new computations under the remaining budget.
[Credit end](@@Layers.py:WhatInteractionMemory.end_what_episode@@),
[restore](@@Thoughts.py:LevelledThoughtHistory.load_thought_extras@@).

No parameter or loss is added. Controller optimizer ownership, policy credit,
residual attribution and learned utility remain separate gates. Permitted
downstream feedback stays subject to the aggregate gradient rule above.
See [Thought history](ThoughtHistory.md).
''',
'doc/Params.md': '''
### Ordinary thought-history bounds

`begin_thought_episode` accepts an explicit `work_budget` (API default 32).
Only root begin declares it; each ordinary event charges positive work. Pressure
is cumulative work divided by `max(1, budget)`. Cutoff freezes the active level
and permits at most `d_cut` returns plus one root finish. Capacity reserves the
drain and cannot evict active or referenced occurrences. These are API bounds;
the normal controller still must account for actual executor work.
[Begin](@@Thoughts.py:LevelledThoughtHistory.begin_thought_episode@@),
[accounting](@@Thoughts.py:LevelledThoughtHistory._thought_event@@),
[retention](@@Thoughts.py:LevelledThoughtHistory._retain_thought_history@@).

The existing slot/episode detachment setting applies. No XML switch or parameter
is added. Checkpoint migration and limits are in [Thought history](ThoughtHistory.md).
''',
'doc/Training.md': '''
## Ordinary history and live query credit (September 16)

Ordinary history supports same-level continuation, strict nested descent/return,
explicit finish and one budget. Episode-mode meanings and query reads remain
live until the caller steps the optimizer and ends the finished episode.
Restore retains detached past values and permits new computation credit without
refreshing budget or pressure. No new objective or optimizer parameter is added.
[Write](@@Thoughts.py:LevelledThoughtHistory._store_thought_events@@),
[restore](@@Thoughts.py:LevelledThoughtHistory.load_thought_extras@@),
[credit end](@@Layers.py:WhatInteractionMemory.end_what_episode@@).

Controller selection, residual reward and causal learned-utility tests remain
open. A live selected read does not establish useful thinking.
[Thought history](ThoughtHistory.md) documents the mechanism.
''',
'doc/STM.md': '''
## Ordinary levelled thoughts (September 16)

The existing interaction deque accepts ordinary `ThoughtRecord` values with
execution levels and separate transitions. Contexts are recovered from history,
retaining exact parent meaning, scope and child results. Root level alone is
not completion. Only a closed legacy prefix may precede ordinary records.
[Records](@@Thoughts.py:ThoughtRecord@@),
[replay](@@Thoughts.py:replay_thoughts@@).

Stable row-local `thought` references resolve complete live episode meanings.
Capacity preserves active contexts and referenced occurrences. The existing
structural sidecar persists this owner with validated IDs, levels and budget.
[Reader](@@Thoughts.py:LevelledThoughtHistory.resolve_thought@@),
[retention](@@Thoughts.py:LevelledThoughtHistory._retain_thought_history@@),
[sidecar](@@Models.py:BaseModel._collect_structural_extras@@).

The legacy production loop remains until controller integration. These APIs do
not establish arbitrary nested grammatical retention or learned utility.
[Thought history](ThoughtHistory.md) describes the migration.
'''}
for name,section in sections.items():
    outputs[name]+=render(section)
replace_once('doc/QueryContracts.md',
    'A description-valued argument references an existing LTM occurrence.',
    'A description-valued argument references an existing durable LTM or live\nordinary-thought occurrence.')
replace_once('doc/QueryContracts.md',
    'detached by their existing owners; the current occurrence reader therefore\nreturns a detached description. Live episode occurrences will need the same\nowner\'s live read path before controller integration can claim episode credit.',
    'detached by their existing owners. A `thought` occurrence instead resolves\nthrough the one WhatInteractionMemory owner and preserves its live episode\nmeaning. [Thought history](ThoughtHistory.md) describes that boundary; normal\ncontroller integration remains open.')
replace_once('doc/GradientFlow.md',
    'return detached descriptions; the later episode controller must provide a live\nread from its existing owner to retain within-episode credit.',
    'return detached descriptions. Ordinary `thought` occurrences now provide the\nsame interaction owner\'s live read path, described below; the later controller\nstill must integrate that path.')
replace_once('doc/STM.md',
    'The current occurrence reader is a bounded durable read and does not provide\nlive episode memory. Ordinary levelled history, nested retention, shared work\naccounting and the normal linguistic observation adapter remain open.',
    'Durable LTM reads remain detached; ordinary `thought` occurrences now provide\nbounded live episode reads as described below. Normal controller integration,\nnested retention, actual executor work accounting and the linguistic observation\nadapter remain open.')
outputs['doc/plans/2026-09-15-next-sentence-as-the-production-objective.md']+=render('''
## 18. Ordinary thought-history and live occurrence APIs (in progress)

The one WhatInteractionMemory owner now stores ordinary structured thoughts and
explicit level/termination transitions in its existing chronological deque.
Replay recovers current/suspended contexts, exact meanings, scope and returned
child results without a second authoritative stack. Same-level continuation and
root finish are distinct; sibling re-entry creates a fresh context. Invalid
levels, overlapping episodes and width changes fail.
[Owner](@@Layers.py:WhatInteractionMemory@@),
[replay](@@Thoughts.py:replay_thoughts@@).

Each root declares one work budget. Positive ordinary charges accumulate across
all levels; cutoff freezes `d_cut` and permits only its bounded LIFO drain plus
one root finish. Capacity reserves those transitions and rejects eviction of
active or referenced records. Known support requires its complete proposition.
Stable row-local occurrence IDs are not reused on reset.
[Accounting](@@Thoughts.py:LevelledThoughtHistory._thought_event@@),
[retention](@@Thoughts.py:LevelledThoughtHistory._retain_thought_history@@).

Episode-mode records and query reads preserve live continuous gradients.
Explicit finish is required before post-step detachment. Structural checkpoints
save detached copies; restore validates all rows atomically and resumes remaining
budget/pressure with fresh computation credit. Legacy prompt and trace tensors
cannot keep the finished graph alive.
[Query read](@@Queries.py:_occurrence_description@@),
[checkpoint](@@Thoughts.py:LevelledThoughtHistory.load_thought_extras@@),
[credit end](@@Layers.py:WhatInteractionMemory.end_what_episode@@).

Repository validation is pending. Reviewer probes failed before the corresponding
history, checkpoint and credit fixes. [Thought history](../ThoughtHistory.md)
documents behavior and limits. This API adds no learned module or trained loss.

Normal learned control, semantic chooser features, actual executor cost accounting,
phase isolation, canonical linguistic observation and causal answer construction
remain open. Nested retention, owned expectations, anticipation isolation,
residual credit, catalog separation and learned utility are still required.
The separate two-truths spec remains next-session work.
''',prefix='../../bin/')
