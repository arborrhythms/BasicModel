from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

root = Path('/Users/arogers/github/WikiOracle/basicmodel')
legacy = Path('/tmp/basicmodel-aa5e018-reconstruction-baseline')
folder = root / 'doc/benchmarks/2026-09-16-tied-reconstruction-data'
python = str(root / '.venv/bin/python')
env = dict(os.environ, DEVELOPER_DIR='/Library/Developer/CommandLineTools',
           PYTORCH_MPS_HIGH_WATERMARK_RATIO='0.60', PYTORCH_MPS_LOW_WATERMARK_RATIO='0.50',
           MODEL_AMP='off')
processes = subprocess.check_output(['ps', '-axo', 'args'], text=True)
if any('-m pytest ' in line or 'bin/bench_sentence_expectation.py ' in line for line in processes.splitlines()):
    raise RuntimeError('Another test or benchmark is running')
changes = subprocess.check_output(['git', 'diff', '--name-only'], cwd=legacy, env=env, text=True).splitlines()
if changes != ['bin/bench_sentence_expectation.py']:
    raise RuntimeError(f'Unexpected baseline changes: {changes}')
observer_hash = hashlib.sha256((root / 'bin/bench_sentence_expectation.py').read_bytes()).hexdigest()
if hashlib.sha256((legacy / 'bin/bench_sentence_expectation.py').read_bytes()).hexdigest() != observer_hash:
    raise RuntimeError('Observer differs between baseline and candidate')
command = [python, 'bin/bench_sentence_expectation.py', 'answers',
           '--config', 'data/BasicModel_answers_benchmark.xml', '--device', 'mps', '--backend', 'eager',
           '--batch-size', '1', '--train-steps', '7', '--eval-steps', '8', '--threads', '1',
           '--out', str(folder / 'answers-b1-legacy-observer.json')]
status = dict(command=command, started_at=time.time(), status='running', observer_sha256=observer_hash,
              cwd=str(legacy), allocator_high='0.60', allocator_low='0.50', amp='off')
status_path = folder / 'legacy-observer-status.json'
status_path.write_text(json.dumps(status, indent=2) + '\n')
print('Starting the original detached student with the matched observer.', flush=True)
with (folder / 'answers-b1-legacy-observer.log').open('w') as log:
    result = subprocess.run(command, cwd=legacy, env=env, stdout=log, stderr=subprocess.STDOUT)
status.update(returncode=result.returncode, ended_at=time.time(),
              status='completed' if result.returncode == 0 else 'failed')
status_path.write_text(json.dumps(status, indent=2) + '\n')
print('Matched legacy observer: ' + status['status'], flush=True)
if result.returncode:
    raise SystemExit(result.returncode)
result = subprocess.run([python, '/tmp/full-spec-run-final-benchmarks.py'], cwd=root, env=env)
raise SystemExit(result.returncode)
