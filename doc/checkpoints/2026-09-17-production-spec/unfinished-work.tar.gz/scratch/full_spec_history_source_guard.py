"""Read-only provenance checks for the isolated full history suite."""
from pathlib import Path
import hashlib
import json
import sys

ROOT=Path('/tmp/full-spec-history-checkout').resolve()
MANIFEST=Path('/tmp/full-spec-history-checkout-frozen.json')

def _check_sources():
    for name,digest in json.loads(MANIFEST.read_text()).items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name

def pytest_sessionstart(session):
    assert Path(session.config.rootpath).resolve()==ROOT
    _check_sources()

def pytest_collection_finish(session):
    for name,module in tuple(sys.modules.items()):
        path=getattr(module,'__file__',None)
        if path and '/Users/arogers/github/WikiOracle/basicmodel/' in str(path):
            assert '/.venv/' in str(path),(name,path)
    for name in ('Thoughts','Queries','Layers','Models','Language','Understanding','reasoning'):
        module=sys.modules[name]
        assert Path(module.__file__).resolve()==ROOT/'bin'/(name+'.py'),(name,module.__file__)
    print('Validated isolated history source ownership and frozen manifest.',flush=True)

def pytest_sessionfinish(session,exitstatus):
    _check_sources()
