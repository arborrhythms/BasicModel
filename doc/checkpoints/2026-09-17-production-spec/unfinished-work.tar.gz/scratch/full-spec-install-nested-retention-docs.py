"""Render nested-retention documentation and remap current-source links exactly once."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import re

root=Path('/Users/arogers/github/WikiOracle/basicmodel')
work=Path('/tmp/full-spec-nested-worktree')
base=Path('/tmp/full-spec-nested-retention-base')
receipt=Path('/tmp/full-spec-nested-retention-doc-remap-applied.json')
assert not receipt.exists(), 'Do not remap links twice'
assert not (root/'doc/NestedRetention.md').exists()
for name,digest in json.loads((work/'validation-manifest.json').read_text()).items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name

def definitions(text):
    found={}
    def visit(node,path=()):
        if isinstance(node,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)):
            path=path+(node.name,)
            found['.'.join(path)]=(node.lineno,node.end_lineno)
        for child in ast.iter_child_nodes(node):
            visit(child,path)
    visit(ast.parse(text))
    return found

maps={}; anchors={}
for name in ('Thoughts.py','Queries.py','Language.py','Layers.py','Models.py','Understanding.py','reasoning.py','Spaces.py'):
    new=(root/'bin'/name).read_text()
    new_defs=definitions(new)
    anchors.update({name+':'+key:value[0] for key,value in new_defs.items()})
    if not (base/'bin'/name).exists():
        continue
    old=(base/'bin'/name).read_text()
    old_defs=definitions(old)
    old_lines,new_lines=old.splitlines(),new.splitlines()
    mapping={}
    for op,i,j,a,b in difflib.SequenceMatcher(None,old_lines,new_lines,autojunk=False).get_opcodes():
        for index in range(i,j):
            if op=='equal':
                mapping[index+1]={'line':a+(index-i)+1,'kind':'exact'}
                continue
            enclosing=[(hi-lo,key) for key,(lo,hi) in old_defs.items()
                       if lo<=index+1<=hi and key in new_defs]
            if enclosing:
                _,key=min(enclosing)
                mapping[index+1]={'line':new_defs[key][0],'kind':'definition','name':key}
            else:
                mapping[index+1]={'line':min(len(new_lines),a+1),'kind':'adjacent'}
    maps[name]=mapping

names=['doc/Architecture.md','doc/GradientFlow.md','doc/Language.md','doc/Params.md',
       'doc/Training.md','doc/QueryContracts.md','doc/QueryPhases.md','doc/ThoughtHistory.md','doc/STM.md','doc/ExistenceEvidence.md','doc/TaxonomyQueries.md','doc/SymbolFirewall.md','doc/ArbitrarySymbols.md',
       'doc/plans/2026-09-15-next-sentence-as-the-production-objective.md',
       'doc/plans/2026-09-17-bounded-fixture-reuse.md']
pattern=re.compile(r'\[([^\]]+)\]\(((?:\.\./)+bin/(Models\.py|Layers\.py|Language\.py|Thoughts\.py))#L(\d+)\)')
changes=[]
def remap(match):
    label,target,filename,line=match.groups()
    mapping=maps[filename][int(line)]
    new=str(mapping['line'])
    changes.append({'file':filename,'old':int(line),**mapping})
    return '['+label.replace(filename+':'+line,filename+':'+new)+']('+target+'#L'+new+')'
def render(text,prefix='../bin/'):
    return re.sub(r'@@([^@]+)@@',lambda m:prefix+m[1].split(':',1)[0]+'#L'+str(anchors[m[1]]),text)
outputs={}
for name in names:
    text=(root/name).read_text()
    if '/plans/' in name:
        protected=False; parts=[]
        for part in re.split(r'(?=^## |^### )',text,flags=re.M):
            if part.startswith('## '):
                protected=part.startswith(('## 6.','## 7.','## 11.'))
            if part.startswith('### 11.6 '):
                protected=False
            parts.append(part if protected else pattern.sub(remap,part))
        text=''.join(parts)
    else:
        text=pattern.sub(remap,text)
    outputs[name]=text

def replace_once(name,old,new):
    assert old in outputs[name],(name,old)
    outputs[name]=outputs[name].replace(old,new,1)


outputs['doc/NestedRetention.md']=render(Path('/tmp/full-spec-nested-retention-documentation.md').read_text())
sections={
'doc/Architecture.md': """
### Retention of grammatical occurrences

The durable meaning store retains the transitive constituent closure of
surviving records and thought-owned roots. Bounded structure reads preserve
ordered role edges, repeated references, scope and each occurrence's evidence.
Views are derived from the existing owner; they add no semantic store.
[Reader](@@Layers.py:TernaryTruthStore.read_structure@@),
[retention](@@Layers.py:TernaryTruthStore.clear_origin@@).
See [Nested retention](NestedRetention.md) for limits, restoration and open gates.
""",
'doc/GradientFlow.md': """
### Grammatical reference retention

Durable structure reads return detached copies. Discovering thought-owned roots
reads only addresses and metadata, so it does not detach live episode meanings.
Normal TruthSet replacement passes those roots before removing records; the
live episode's continuous path remains available. This change adds no trained
loss or optimizer owner and does not alter gradient balancing.
[Roots](@@Thoughts.py:LevelledThoughtHistory.retained_ltm_occurrences@@),
[replacement](@@Models.py:BasicModel._store_truths_into_ltm@@),
[durable reads](@@Layers.py:TernaryTruthStore.read_structure@@).
[Nested retention](NestedRetention.md) records the regression evidence.
""",
'doc/STM.md': """
### Referenced LTM content survives origin withdrawal

Origin clearing retains records reachable from surviving occurrences and the
ordinary thought history. IDs and source content survive physical compaction.
The withdrawn origin loses trust; an accepted fact becomes unverified, while
questions and estimates keep their provenance kinds. Referenced content is
therefore available without continuing to certify the withdrawn claim.
[Withdrawal](@@Layers.py:TernaryTruthStore.withdraw_origin@@),
[closure](@@Layers.py:TernaryTruthStore.clear_origin@@).
See [Nested retention](NestedRetention.md).
""",
'doc/Training.md': """
### Restoring dependent occurrences

Stateless tensor restore withdraws request authority immediately. Physical
pruning waits for the semantic sidecar and thought owners, then preserves their
reachable constituents. Tensor-only restore retains zero-trust content while
ownership metadata is unavailable. Checkpoint snapshots remain detached;
normal live episode records keep their existing gradient paths.
[Tensor hook](@@Language.py:SymbolSubSpace._revive_ltm_post_load@@),
[restore order](@@Models.py:BaseModel._restore_structural_extras@@),
[final pruning](@@Language.py:SymbolSubSpace._finish_ltm_restore@@).
[Nested retention](NestedRetention.md) distinguishes completed retention checks
from the pending linguistic and controller migrations.
""",
'doc/ThoughtHistory.md': """
## Roots retained in durable LTM

The ordinary history supplies occurrence roots from all retained rows, including
role references, bindings, scope and evidence sources. The set is derived when
needed; there is no second authoritative reference index. An episode can retain
content after its request-scoped evidential authority is withdrawn.
[Roots](@@Thoughts.py:LevelledThoughtHistory.retained_ltm_occurrences@@),
[retention](@@Layers.py:TernaryTruthStore.clear_origin@@).
See [Nested retention](NestedRetention.md).
""",
'doc/QueryContracts.md': """
## Durable constituent retention

Occurrence traversal exposes independent node/depth/record limits and explicit
incomplete results. It preserves role-labelled edges and each row's scope and
evidence. Retaining a referenced withdrawn occurrence cannot promote it back
into accepted fact evidence. The normal linguistic adapter must still record
its full typed structure through the existing occurrence owners.
[Traversal](@@Layers.py:TernaryTruthStore.read_structure@@),
[withdrawal](@@Layers.py:TernaryTruthStore.withdraw_origin@@).
See [Nested retention](NestedRetention.md).
"""}
for name,section in sections.items(): outputs[name]+=render(section)
outputs['doc/plans/2026-09-15-next-sentence-as-the-production-objective.md']+=render("""
## 20. Bounded nested-occurrence retention (in progress)

The existing durable meaning owner now derives bounded structure views with
ordered role edges, repeated references and independent node/depth/record
limits. Missing or cyclic structure is explicit. Each occurrence keeps its own
scope and evidence; support does not propagate into a reported clause.
[Reader](@@Layers.py:TernaryTruthStore.read_structure@@),
[validation](@@Layers.py:TernaryTruthStore._validate_constituent_graph@@).

Origin clearing retains the reachable closure of surviving records and
thought-owned roots, while withdrawing evidential authority. Full checkpoint
restore restores those owners before pruning; tensor-only restore preserves
zero-trust content when ownership metadata is incomplete. Live episode gradients
survive normal TruthSet replacement; durable reads remain detached.
[Retention](@@Layers.py:TernaryTruthStore.clear_origin@@),
[roots](@@Thoughts.py:LevelledThoughtHistory.retained_ltm_occurrences@@),
[restore](@@Models.py:BaseModel._restore_structural_extras@@).

Primary validation is pending. Twenty-three reviewer probes cover retention,
bounded traversal, withdrawal, live credit and restore ordering. An earlier isolated
affected run passed 257 tests; the context-reference follow-up passed 23 focused cases. [Nested retention](../NestedRetention.md)
documents the APIs and their limits.

Typed linguistic meaning from all observation writers, the normal semantic
controller, causal answer use, actual shared executor cost, owned estimates,
anticipation isolation, residual policy credit, separate catalogs and learned
utility remain open. The separate two-truths specification stays reserved for
the next session.
""",prefix='../../bin/')
for name,text in outputs.items():
    assert '@@' not in text,name
    for target,line in re.findall(r'\]\(((?:\.\./)+bin/[^)#]+\.py)#L(\d+)\)',text):
        file=((root/name).parent/target).resolve()
        assert file.is_file() and 1<=int(line)<=len(file.read_text().splitlines()),(name,target,line)
for name,text in outputs.items():
    (root/name).write_text(text)
receipt.write_text(json.dumps(changes,indent=2)+'\n')
Path('/tmp/full-spec-nested-retention-line-maps.json').write_text(json.dumps(maps)+'\n')
(work/'source-anchors.json').write_text(json.dumps(anchors,indent=2)+'\n')
owned=Path('/tmp/full-spec-nested-retention-owned-paths.txt')
owned.write_text('\n'.join(sorted(set(owned.read_text().splitlines())|set(outputs)))+'\n')
print('Updated',len(outputs),'documents;',len(changes),'local source links remapped once.')
print('Definition/adjacent fallbacks:',[x for x in changes if x['kind']!='exact'])
