# Next migration notes — not implemented

Only start after the tied reconstruction item is green, committed and pushed,
with its WikiOracle bump pushed. Never edit bin/tests/config while pytest runs.

Current reviewed source, after complete-byte target staging:
- Models.py:9139 reverseOutput still calls _resolve_answer at9150.
- Models.py:8146 _resolve_answer selects current/recalled programs, optionally
  calls answer_query(prompt), materializes concepts, executes _resolve_step,
  and returns the owned AnswerDerivation (conceptual_answer/context/program).
- Models.py:9839 what calls reverseOutput after capturing Understanding.
- Models.py:9975 think invokes what repeatedly over one saved execution; this
  avoids repeating forward but still generates a surface every iteration.
- Output.py:48 AnswerDerivation owns conceptual_answer and context; clone retains
  current gradients. What.py:36 WhatQuestion is target-free but has presentation
  addresses, not the future internal structured-query semantics.

A public resolveAnswer(Understanding, question) -> AnswerDerivation is a useful
explicit boundary. reverseOutput should require an already resolved derivation,
never call resolution as an implicit compatibility fallback. Store the target-free
question tuple on the derivation if needed for existing temporal surface metadata.
The materializer currently does not use its question argument; it uses the sole
owned conditioning_context. Preserve that one-conditioner contract.

Do not claim moving this single call completes the phase controller: think still
has to do all conceptual subgoal work before final response realization, and
internal thoughts need no surfaces. Its old parity/LIFO slots are a later levelled
history migration, not a valid end state. No second planner/frame hierarchy.
Boundary execution must be masked throughout compose/reconstruct/generate; typed
query executor entry checks belong with the structured query migration.

Use real ownership/phase probes: resolver forbidden during held-derivation
realization; resolution before any generate walk; repeat realization/restage does
not trigger a query; target absence; packed row independence; reconstruct once;
actual gradients through owned clones. Update every direct reverseOutput caller
and tests explicitly. Existing Models.reason(givens,...) near23900 is an unrelated
method; do not overwrite it. Full suite/push cycle remains required per migration.

Subsequent contracts: semantic NP1/VP/NP2 query input, typed relation registry,
PartOf canonical conceptual taxonomy (not WholeSpace proxy); Exist full-description
LTM match with graded positive/negative/conflict/unknown provenance. Tense deferred.
Two-truths spec is explicitly for after this session and must remain untouched.

Additional read-only review during tied validation (September 16):
- AnswerDerivation is frozen, owns cloned conceptual_answer and conditioning_context
  (Output.py:48), but has no original target-free question tuple. Adding that tuple
  would let reverseOutput consume a prepared derivation without reconstructing
  presentation metadata from mutable model state. Keep Understanding for permitted
  synthesis carrier restoration; never use it as an implicit unresolved seed.
- _resolve_answer currently may invoke answer_query(prompt) and catches all errors
  (Models.py:8169); checked query failures must eventually remain explicit. The phase
  extraction alone should not claim to fix legacy text dispatch or query evidence.
- Direct reverseOutput callers are in output_synthesis, output_path_supervised,
  output_walk and what_training tests. Update explicit resolution at every caller;
  do not hide it in a compatibility fallback inside output.
- For later residual-credit work, a preceding-context-only tensor argument is not
  sufficient if a query executor can read LTM that already includes the arriving
  sentence or later packed rows. The anticipation view needs occurrence/version
  bounds, source/document/row masks and candidate construction from permitted prior
  state. Test future-target and future-fact perturbations independently.
- Keep graph versions explicit for delayed query credit: no live autograd tape may
  cross an optimizer mutation. Recomputing a policy from saved permitted context
  must declare its credit semantics; an immutable recorded estimate cannot silently
  become a new prediction when replayed. Resolve this before implementing item 8.

September 16 read-only audit while output validation runs (no next-item code edits):
- After readout insertion, reverseOutput is Models.py:9142; _resolve_answer8146; what9761; think9978; public resolveAnswer does not exist. AnswerDerivation remains Output.py:48 with conceptual/context clones, no owned question tuple.
- Direct production caller is what at9842. Direct tests: output_synthesis (many), output_path_supervised121/181/475, output_walk583/587, what_training240, newoutput_percept_readout72. Update each call explicitly; no hidden compatibility resolution in output.
- First next-item probe should resolve a real native Understanding in advance, forbid _resolve_answer/_resolve_step/answer_query at realization, call reverseOutput(u,held_derivation), verify returned derivation identity + fixed outputs across restaging in both output modes. This currently fails because reverseOutput invokes _resolve_answer unconditionally. Add a separate public resolveAnswer order/gradient test and rejection of unresolved question arguments.
- Add a target-free immutable question tuple on AnswerDerivation so output uses owned temporal presentation metadata. Public resolveAnswer validates Understanding then calls boundary resolver; reverseOutput requires AnswerDerivation. what explicitly resolves then realizes. Preserve existing owned program and conceptual/context clones.
- This bounded commit only establishes the prepared-answer API boundary. It does NOT complete thought control: think still calls what each iteration, producing a surface each time; levelled history/controller must replace that later. Do not label all phase requirements complete.
- Existing WhatInteractionMemory is Layers.py:8927: one owner, Python per-row deques, legacy LTMSlot pairs/parity, live episode values. New ordinary thought history should migrate/extend that owner with explicit version/checkpoint adapters, not add an independent planner store. Existing reset/trim/episode detachment contracts must remain explicit legacy until migrated.

Read-only preparation for residual query credit (not implemented or verified):
- Existing target-isolation/full-role tests predominantly exercise InterSentenceLayer
  and explicit published-role drains. Add an actual forward/packed perturbation
  probe for dictionary/staging leakage, beyond changing target tensors after encoding.
- Prefer current-step anticipation computed from an explicit immutable prior view,
  captured before the arriving observation. For packed rows, extend that view only
  with earlier completed observed roles (live within this step). Executors must
  read only this view, never global LTM/dictionary after later observations land.
  This avoids keeping an autograd graph across optimizer mutations. A replay of
  a previously recorded estimate must not silently replace its original value.
- A bounded invocation view of source-tagged semantic payloads, stable occurrence
  ids and typed relations is a derived read view, not a new authoritative memory.
  Capture its declared retrieval pool before input; unavailable evidence stays
  unknown/incomplete. Future-content isolation must include taxonomy/fact mutations.
- Old TernaryTruthStore at Layers.py8658 has NP1/VP/NP2, trust, timestamp and writer
  origin, but lacks question/estimate/observation kinds, binding/scope metadata and
  stable ids through clear_origin compaction. WhatInteractionMemory has no visible
  checkpoint serialization in Models.py. Do not claim these contracts already exist.
- Conceptual taxonomy source is ConceptAllocator-backed ConceptualSpace concept_parts /
  concept_wholes / reify_concept (Spaces.py17927-17948), including reified ('sym', id)
  endpoints. Percept/WholeSpace .where taxonomy and generic vector parthood are not
  substitutes. Inspect reified edge indexing and signed/evidence semantics before
  designing PartOf traversal; do not assume an edge also mutates each endpoint's set.
- Existence must retain the complete described structure, mode, roles, bindings,
  scope and evidence provenance; current reasoning.exist137 checks only NP1 and
  falls back to isTrue. Query/estimate records cannot satisfy that lookup. The
  direct-description and typed registry probes must come before replacing it.

Further preparation during final native measurements (still no implementation):
- Complete direct-caller search includes the new test_output_percept_readout.py checkpoint helper. There are no additional production callers beyond Models.what. Do not rewrite old historical docs to advertise a new API before its commit.
- Existing native _answer_training_probe verifies actual answer gradient into the active conditioner, full-width realization, optimizer ownership and a step. Re-run the whole file after boundary extraction; supplement with a direct resolved-concept leaf gradient test in both output modes, so a wrapper accidentally detaching AnswerDerivation cannot pass.
- Add a production what/runBatch phase-order probe using a tied configuration. Capture the completed input_reconstruction before resolveAnswer and assert all query/generate spies stay silent through understanding/reconstruction; then resolution completes before reverseOutput starts. This must observe actual calls, not assert source strings.
- Output-only calls may still realize an explicitly unresolved derivation (legacy FUTURE compatibility). Requiring prepared AnswerDerivation is not a reason to silently fill it from current input or to claim a predicted answer was consumed.
- WhatQuestion is frozen; its relation/where/offset/split are normalized primitive metadata. prompt is Any, but output must never inspect it after resolution. Store the target-free question tuple for temporal presentation only, without adding a second conditioner.
- Output-length coverage audit: existing test_walk_handles_mixed_output_lengths_per_row expands two live input IDEAS into three output words; it does not compare against a real captured input sentence's word count. Add an explicit prepared-answer native test whose generate policy completes a response longer than the captured input, with no input trace or target supplying the actions. The present native sampled-output run currently covers lengths 1 and 2; report its eventual counts literally, without claiming long-response coverage from padded tensor dimensions.
- When Models.py is next edited for the prepared-answer boundary, reconcile the stale runBatch comments around current lines13800-13860: they still describe an output-head-seeded reverse and unconditional reconstruction_reverse, even though the actual code uses reverseReconstruct with owned concepts and deduplicates tied mode. The current full-suite IR probe now checks the exact conceptual seed at _reverse_input_surface, not the old m.reverse orchestration name. No comment-only runtime edits during the present frozen native/full-suite version.

Further read-only audit during full-suite V3:
- The repository tracks bin/thinking.py (lowercase), despite case-insensitive macOS accepting Thinking.py. Corrected the owned integrated-spec link. Check exact path casing, not only Path.exists(), for future citations.
- ExistLayer.forward is a pure identity (Language.py:4467), not the boundary LTM lookup. Keep pure compose/inverse identity separate from the new checked Exist query semantics. Current PartLayer/WholeLayer (4233/4301) discard one operand and contain historical geometry descriptions; changing query evidence must not accidentally execute lookup during their composition.
- _reconstruction_priority_parameters currently deduplicates using p.data_ptr() (Models.py:2700), not Python id(p). GradientFlow now says tensor address explicitly.
- Later anticipation isolation must test actual packed forward with unseen vocabulary/dictionary/fact/taxonomy changes, not just mutate an already encoded target. For prediction of a later sentence in the pack, its preceding observed encoding must itself remain isolated from future staging effects. A snapshot around only the query executor is insufficient if its prior-role inputs already leaked future data. No defect has been demonstrated yet; this is an acceptance-test obligation.
- The actual two-mode packed joint-gradient test has passed during full-suite V3 (suite progressed beyond 62%). The full run remains unfinished; do not claim overall green yet.
