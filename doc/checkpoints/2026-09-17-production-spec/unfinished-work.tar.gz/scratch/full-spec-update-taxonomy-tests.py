from pathlib import Path
import ast
import hashlib
import json
import textwrap

repo = Path('/Users/arogers/github/WikiOracle/basicmodel')
out = Path('/tmp/full-spec-taxonomy-worktree')
(out / 'test').mkdir(parents=True, exist_ok=True)
for name, target in [('data', repo / 'data'), ('bin', Path('/tmp/full-spec-taxonomy-candidate'))]:
    if not (out / name).exists():
        (out / name).symlink_to(target, target_is_directory=True)
files = ('test_truth_grounded_reasoning.py', 'test_thinking_kernel.py')
manifest = {f'test/{name}': hashlib.sha256((repo/'test'/name).read_bytes()).hexdigest()
            for name in files}
(out/'base-manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')


def replace_methods(text, replacements):
    tree = ast.parse(text)
    edits = []
    found = set()
    lines = text.splitlines(keepends=True)
    for cls in tree.body:
        if not isinstance(cls, ast.ClassDef):
            continue
        for method in cls.body:
            if not isinstance(method, ast.FunctionDef):
                continue
            key = f'{cls.name}.{method.name}'
            if key not in replacements:
                continue
            body = textwrap.indent(textwrap.dedent(replacements[key]).strip()+'\n', '    ')
            edits.append((method.lineno-1, method.end_lineno, body))
            found.add(key)
    assert found == replacements.keys(), replacements.keys()-found
    for start, end, value in sorted(edits, reverse=True):
        lines[start:end] = [value]
    return ''.join(lines)


text = (repo/'test'/files[0]).read_text()
helper = '''
def _taxonomy(*links):
    """Explicit conceptual links; vector row fixtures do not define taxonomy."""
    from types import SimpleNamespace
    from test_cs_symbol_table import _cs
    cs = _cs()
    refs = tuple(("sym", cs.new_concept()) for _ in range(4))
    for left, right in links:
        cs.add_whole(refs[left][1], refs[right])
    return TruthGroundedReasoner(SimpleNamespace(conceptualSpace=cs), store=_store()), refs


'''
text = text.replace('class TestEvaluate(unittest.TestCase):', helper+'class TestEvaluate(unittest.TestCase):')
text = replace_methods(text, {
 'TestEvaluate.test_is_part_direct_true': '''
def test_is_part_direct_true(self):
    r, (a, b, _c, _d) = _taxonomy((0, 1))
    res = r.evaluate(QuerySpec.from_surface("isPart", a, b))
    self.assertEqual(res["posture"], TRUE)
    self.assertEqual(res["kind"], KIND_IS_PART)
    self.assertEqual(len(res["path"]), 1)
    self.assertEqual(res["domain"], "conceptual-taxonomy")
''',
 'TestPostureAndTrace.test_is_part_false_from_refuting_edge': '''
def test_world_refutation_does_not_establish_taxonomic_falsehood(self):
    r = TruthGroundedReasoner(store=_store(rows_partof=[(LEFT, RIGHT, -0.9)]))
    res = r.evaluate(QuerySpec.from_surface("isPart", LEFT, RIGHT))
    self.assertEqual(res["posture"], UNKNOWN)
    self.assertEqual(res["support_false"], 0)
''',
 'TestPostureAndTrace.test_is_part_both_when_supported_and_refuted': '''
def test_geometry_and_world_refutation_do_not_establish_taxonomic_conflict(self):
    r = TruthGroundedReasoner(store=_store(rows_partof=[(PART, WHOLE, -0.9)]))
    res = r.evaluate(QuerySpec.from_surface("isPart", PART, WHOLE))
    self.assertEqual(res["posture"], UNKNOWN)
    self.assertEqual((res["support_true"], res["support_false"]), (0, 0))
''',
 'TestPostureAndTrace.test_chain_trace_rendered': '''
def test_chain_trace_rendered(self):
    r, (a, _b, c, _d) = _taxonomy((0, 1), (1, 2))
    res = r.evaluate(QuerySpec.from_surface("isPart", a, c))
    self.assertEqual(res["posture"], TRUE)
    self.assertEqual(len(res["path"]), 2)
    self.assertIn("2 links", res["trace"])
''',
 'TestPostureAndTrace.test_direct_trace_rendered': '''
def test_direct_trace_rendered(self):
    r, (a, b, _c, _d) = _taxonomy((0, 1))
    res = r.evaluate(QuerySpec.from_surface("isPart", a, b))
    self.assertIn("1 links", res["trace"])
    self.assertEqual(res["path"][0].owner, a)
''',
})
start, end = text.index('class TestNeuralToolUser'), text.index('class TestReasonPredictNext')
legacy = text[start:end].replace('class TestNeuralToolUser', 'class TestLegacyVectorProposalTools')
legacy = legacy.replace('Phase B: the recurrent tool-use driver (soft propose / hard verify).',
                        'Explicit legacy vector proposals; public PartOf uses taxonomy evidence.')
legacy = legacy.replace('tool.run(', 'tool.run_legacy_world(')
text = text[:start]+legacy+text[end:]
for name in ('TestIsPartDirect', 'TestChain', 'TestMaterialize', 'TestConsolidation', 'TestPartialOrder'):
    text = text.replace('class '+name+'(', 'class TestLegacy'+name[4:]+'(')
text = text.replace('"""The reasoner\'s tool surface = the grammar <queries> ops."""',
                    '"""Legacy vector helpers and the current full-description Exist adapter."""')
(out/'test'/files[0]).write_text(text)

text = (repo/'test'/files[1]).read_text()
helper = '''
def _taxonomy_kernel(*links, **options):
    """Use native reference records for positive taxonomic evidence."""
    from types import SimpleNamespace
    from test_cs_symbol_table import _cs
    cs = _cs()
    refs = tuple(("sym", cs.new_concept()) for _ in range(4))
    for left, right in links:
        cs.add_whole(refs[left][1], refs[right])
    reasoner = TruthGroundedReasoner(SimpleNamespace(conceptualSpace=cs), store=_store())
    return ThinkingKernel(reasoner, **options), refs


'''
text = text.replace('# -- Truth intervals', helper+'# -- Truth intervals', 1)
changes = {
'TestLookup.test_direct_stored_edge': '''
def test_direct_taxonomic_edge(self):
    k, (a, b, _c, _d) = _taxonomy_kernel((0, 1))
    iv = k.lookup(QuerySpec(KIND_IS_PART, a, b))
    self.assertEqual(iv.status(k.tau), TRUE)
    self.assertEqual(iv.trust, 1)
''',
'TestLookup.test_refuting_edge_is_false': '''
def test_negative_world_relation_is_not_taxonomic_evidence(self):
    k = _kernel(_store(rows_partof=[(MAN, MORTAL, -0.8)]))
    iv = k.lookup(QuerySpec(KIND_IS_PART, MAN, MORTAL))
    self.assertEqual(iv.status(k.tau), UNKNOWN)
''',
'TestLookup.test_conflicting_evidence': '''
def test_conflicting_world_relations_are_not_taxonomic_evidence(self):
    k = _kernel(_store(rows_partof=[(MAN, MORTAL, 0.8), (MAN, MORTAL, -0.7)]))
    iv = k.lookup(QuerySpec(KIND_IS_PART, MAN, MORTAL))
    self.assertEqual(iv.status(k.tau), UNKNOWN)
''',
'TestPart.test_up_and_down': '''
def test_up_and_down(self):
    k, (a, b, _c, _d) = _taxonomy_kernel((0, 1))
    ups = k.part(a, direction="up")
    self.assertEqual([item["reference"] for item in ups], [b])
    downs = k.part(b, direction="down")
    self.assertEqual([item["reference"] for item in downs], [a])
''',
'TestPart.test_mode_rides_provenance': '''
def test_mode_and_domain_match_the_actual_source(self):
    k, (a, _b, _c, _d) = _taxonomy_kernel((0, 1))
    result = k.part(a, mode="taxonomy")[0]
    self.assertEqual(result["mode"], "taxonomy")
    self.assertEqual(result["domain"], "conceptual-taxonomy")
    with self.assertRaises(ValueError):
        k.part(a, mode="meronomy")
''',
'TestCurriculum.test_depth0_direct_edge': '''
def test_depth0_direct_edge(self):
    k, (a, b, _c, _d) = _taxonomy_kernel((0, 1))
    res = k.run(QuerySpec(KIND_IS_PART, a, b))
    self.assertEqual(res.value, TRUE)
''',
'TestCurriculum.test_depth1_syllogism_nested_think': '''
def test_depth1_syllogism_nested_think(self):
    k, (a, _b, c, _d) = _taxonomy_kernel((0, 1), (1, 2))
    res = k.run(QuerySpec(KIND_IS_PART, a, c))
    self.assertEqual(res.value, TRUE)
    self.assertEqual(res.trust, 1)
    ops = [e["op"] for e in res.trace]
    self.assertIn("part", ops)
    self.assertIn("think", ops)
''',
'TestCurriculum.test_depth2_two_hops': '''
def test_depth2_two_hops(self):
    k, (a, _b, _c, d) = _taxonomy_kernel((0, 1), (1, 2), (2, 3))
    res = k.run(QuerySpec(KIND_IS_PART, a, d))
    self.assertEqual(res.value, TRUE)
    self.assertEqual(res.trust, 1)
''',
'TestCurriculum.test_false_close_on_refutation': '''
def test_world_refutation_does_not_close_taxonomy_false(self):
    k = _kernel(_store(rows_partof=[(MAN, MORTAL, -0.8)]))
    res = k.run(QuerySpec(KIND_IS_PART, MAN, MORTAL))
    self.assertEqual(res.value, UNKNOWN)
''',
'TestCurriculum.test_dead_end_is_unknown': '''
def test_dead_end_is_unknown(self):
    k, (a, _b, c, _d) = _taxonomy_kernel((0, 1))
    res = k.run(QuerySpec(KIND_IS_PART, a, c))
    self.assertEqual(res.value, UNKNOWN)
''',
'TestFramesAndBudget.test_budget_exhaustion_bounded_unknown': '''
def test_budget_exhaustion_bounded_unknown(self):
    k, (a, _b, c, _d) = _taxonomy_kernel((0, 1), (1, 2), budget=2)
    res = k.run(QuerySpec(KIND_IS_PART, a, c))
    self.assertEqual(res.value, BOUNDED_UNKNOWN)
''',
'TestFramesAndBudget.test_stack_pops_clean': '''
def test_stack_pops_clean(self):
    k, (a, _b, c, _d) = _taxonomy_kernel((0, 1), (1, 2))
    res = k.run(QuerySpec(KIND_IS_PART, a, c))
    self.assertEqual(res.value, TRUE)
    self.assertEqual(k.stack, [])
''',
'TestFramesAndBudget.test_child_returns_result_not_scratch': '''
def test_child_returns_result_not_scratch(self):
    k, (a, _b, c, _d) = _taxonomy_kernel((0, 1), (1, 2))
    res = k.run(QuerySpec(KIND_IS_PART, a, c))
    self.assertEqual(res.value, TRUE)
    self.assertIsInstance(res, ChildResult)
    self.assertFalse(hasattr(res, "bindings"))
''',
'TestFramesAndBudget.test_cycle_terminates': '''
def test_cycle_terminates(self):
    k, (a, _b, c, _d) = _taxonomy_kernel((0, 1), (1, 0), budget=64)
    res = k.run(QuerySpec(KIND_IS_PART, a, c))
    self.assertIn(res.value, (UNKNOWN, BOUNDED_UNKNOWN))
''',
'TestInvariants.test_success_without_materialize_flag_does_not_write': '''
def test_success_without_materialize_flag_does_not_write(self):
    k, (a, _b, c, _d) = _taxonomy_kernel((0, 1), (1, 2), materialize=False)
    store = k.reasoner.reasoning_store()
    before = len(store)
    res = k.run(QuerySpec(KIND_IS_PART, a, c))
    self.assertEqual(res.value, TRUE)
    self.assertEqual(len(store), before)
''',
'TestInvariants.test_grounded_derivation_materializes_lemma': '''
def test_taxonomy_derivation_does_not_materialize_a_world_lemma(self):
    k, (a, _b, c, _d) = _taxonomy_kernel((0, 1), (1, 2), materialize=True)
    store = k.reasoner.reasoning_store()
    before = len(store)
    for _ in range(2):
        res = k.run(QuerySpec(KIND_IS_PART, a, c))
        self.assertEqual(res.value, TRUE)
        self.assertFalse(any("materialized_row" in p for p in res.provenance))
        self.assertEqual(len(store), before)
''',
'TestInvariants.test_direct_hit_does_not_rewrite': '''
def test_direct_hit_does_not_rewrite(self):
    k, (a, b, _c, _d) = _taxonomy_kernel((0, 1), materialize=True)
    store = k.reasoner.reasoning_store()
    before = len(store)
    res = k.run(QuerySpec(KIND_IS_PART, a, b))
    self.assertEqual(res.value, TRUE)
    self.assertEqual(len(store), before)
''',
'TestQueryTestimony.test_incorporate_relation': '''
def test_legacy_incomplete_relation_cannot_certify_taxonomy(self):
    store = _store()
    k = _kernel(store)
    t = Testimony(proposition=QuerySpec(KIND_IS_PART, MAN, MORTAL),
                  value=1.0, source="expert", source_trust=0.8)
    row = k.incorporate(t)
    self.assertGreaterEqual(row, 0)
    self.assertEqual(store.row(row)["kind"], "unverified")
    self.assertEqual(k.lookup(t.proposition).status(k.tau), UNKNOWN)
''',
'TestRewardsAndTraces._success': '''
def _success(self):
    k, (a, _b, c, _d) = _taxonomy_kernel((0, 1), (1, 2))
    return k, k.run(QuerySpec(KIND_IS_PART, a, c))
''',
'TestNextOpPolicy._syllogism_kernel': '''
def _syllogism_kernel(self):
    return _taxonomy_kernel((0, 1), (1, 2))[0]
''',
'TestNextOpPolicy.test_head_prefers_stop_short_circuits': '''
def test_head_prefers_stop_short_circuits(self):
    class StopHead:
        def choose(self, state, options):
            return "answer"
    k, (a, _b, c, _d) = _taxonomy_kernel((0, 1), (1, 2),
                                       policy=KernelPolicy(next_op=StopHead()))
    res = k.run(QuerySpec(KIND_IS_PART, a, c))
    self.assertEqual(res.value, UNKNOWN)
    self.assertNotIn("think", [e["op"] for e in res.trace])
''',
'TestNextOpPolicy.test_head_preferring_explore_keeps_baseline': '''
def test_head_preferring_explore_keeps_baseline(self):
    class GoHead:
        def choose(self, state, options):
            return next(o for o in options if o != "answer")
    k, (a, _b, c, _d) = _taxonomy_kernel((0, 1), (1, 2),
                                       policy=KernelPolicy(next_op=GoHead()))
    self.assertEqual(k.run(QuerySpec(KIND_IS_PART, a, c)).value, TRUE)
''',
'TestModelIntegration.test_syllogism_over_live_ltm': '''
def test_syllogism_over_live_taxonomy(self):
    cs = self.m.conceptualSpace
    refs = tuple(("sym", cs.new_concept()) for _ in range(3))
    a, b, c = refs
    try:
        cs.add_whole(a[1], b)
        cs.add_whole(b[1], c)
        res = self.m.think_about(QuerySpec(KIND_IS_PART, a, c))
        self.assertEqual(res.value, TRUE)
        self.assertEqual(res.trust, 1)
    finally:
        for ref in refs:
            cs.retire_concept(ref[1])
''',
}
text = replace_methods(text, changes)
text = text.replace('self.assertEqual(int(k.reasoner.reasoning_store().count.item()), 2)',
                    'self.assertEqual(int(k.reasoner.reasoning_store().count.item()), 0)')
text = text.replace('trace compilers. Unit tests over a hand-built TernaryTruthStore (same fixture\nconventions as test_truth_grounded_reasoning.py) + Models/config integration.',
                    'trace compilers. The frame controller remains legacy. Fact tests use\nTernaryTruthStore; PartOf tests use native conceptual reference records.')
(out/'test'/files[1]).write_text(text)
for name in files:
    ast.parse((out/'test'/name).read_text())
print('Prepared', len(files), 'affected test files in', out)
