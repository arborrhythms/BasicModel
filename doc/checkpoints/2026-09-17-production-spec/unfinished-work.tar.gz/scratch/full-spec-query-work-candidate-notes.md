# Shared query work accounting — isolated candidate

Not installed. Primary remains 639034c. Layered on the prepared history, phase and nested-retention candidates. No reasoning method was removed. The separate legacy-deletion candidate stays held pending user review.

A transient QueryWorkBudget records one allowance shared by preparation, native payload/occurrence reads, taxonomy capture/traversal and selected operation execution. Charge before the selected read. Local limits only tighten; children must receive the same meter. It has no semantic persistence, child allowance or reset. Invalid declared argument/domain/width calls do not invoke an operation. Exhaustion preserves partial signed evidence and explicitly marks incomplete work.

QueryContext.work carries the allowance. Registry form/signature/execute account for selected VP references, operand payloads and complete occurrence-valued descriptions. Taxonomy capture charges nodes and constituent records, traversal charges expansions. Capture caps reserve a share for proof traversal while the same meter still bounds all work. Exist charges accepted-record inspection, quantize defers basis access until a charged candidate exists, and ARMA reserves all prior-context record cost before prediction without replacing the pending input estimate. Thought occurrence resolution preserves the live episode tensor while charging reads.

Evidence:
- Initial six probes failed against the pre-candidate implementation: /tmp/full-spec-query-work-red.log, actual exit1.
- First focused run hit a missing data symlink in the isolated harness (four pass, two fixture failures); fixed the harness, not runtime. Focused v2 passed six.
- Boundary red identified unmetered selected VP/preparation reads. Its ARMA case also had an invalid fixture width, corrected to layer.concept_dim. Combined focused v3 passed twelve.
- A direct taxonomy proof with five units failed because capture spent the allowance before traversal. After reserving capture shares, full affected selection passed.
- /tmp/full-spec-query-work-affected-v1.log: 154 passed, one skipped, 31.22s pytest; process exit0, guarded50.71s, peak443548848bytes. This covers both new probe files, live occurrence probes and fifteen existing query/taxonomy/prediction files. Source hashes are in validation-manifest.json.

Remaining work before acceptance:
- Rebase/install after history, phase and nested-retention commits, then affected files and complete default suite against primary.
- Wire the SAME meter through the normal learned boundary controller and every nested callback, recording actual total cost once in ordinary thought history. Standalone readers may omit a meter for audited APIs; that is not acceptable for normal episode execution.
- Ensure native VP validation costs and payload costs are documented as explicit cost units. Lookup/ref resolution partial progress currently appears in the meter even when legacy per-result scanned fields cannot report a partial failed resolution.
- Add actual controller/history integration, hard-choice credit, causal result influence, owner/checkpoint and gradient gates. This candidate supplies accounting, not the missing normal controller or linguistic meaning adapter.
