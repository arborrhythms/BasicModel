# Isolated generation-catalog candidate; do not install before item 5

Primary runtime remains 639034c. This candidate copies only Language.py and Models.py;
other files are symlinks to the primary. It must be rebased onto history/phase/nested
and normal controller integration before installation. No installer/docs/full gate.

Reviewer probes /tmp/full-spec-generation-catalog-probes.py: three genuine baseline
failures (no non-loop catalog; shared operators; shared learnable lift). RED managed
28381 exit1, /tmp/full-spec-generation-catalog-red.log, bounded 26.10s / .47GiB.
Candidate v1 managed6907 exit0, 3pass7.05s (guard28.15s/.53GiB).

Candidate clones declared generate numerical operators into LanguageSpace.generation_ops
with one parameter owner, retains non-owning Space references, adopts all params in
SymbolSpace.params and includes them in dedicated synthesis parameters. Source-valued
initialization preserves RNG. Both loop and ordinary catalog exist independently of
outputInLoop. Legacy checkpoint migration copies saved comprehension values into absent
generation keys, keeps independent generation weights, and leaves new optimizer moments
fresh under existing name-based rules. Existing rule-meaning chooser migration retained.

Boundary probes exposed an actual candidate mistake: unscoped mathematical unreduce
used output weights even for an input inverse. Corrected by a ContextVar-backed host
reverseOutput boundary decorator. Ordinary unreduce uses output-owned declared rules
only inside that matching model scope; restored on exceptions. Standalone/input math
continues using comprehension. No reasoning methods are removed.
Boundary RED managed54233 exit1: first routing failure genuine; second checkpoint failure
was a fixture that omitted lazy synthesis materialization before save, not a new runtime
checkpoint bug. Fixed that fixture by calling _materialize_answer_path before save.
Added explicit output-scope/error-restoration routing check.
Final focused v2 managed90582 exit0, 6passed15.95s, guard36.32s/.62GiB.
Log /tmp/full-spec-generation-catalog-candidate-v2.log and matching process JSON.

Still needs rigorous review: aliases/checkpoint round-trip and saved optimizer moments;
partial missing generation state; normal reverseOutput dispatch for both topologies;
compiled output walk plus existing rule migration tests; input reconstruction unchanged;
combined reconstruction-priority budget with live input; RNG/base initialization; retained
syntax/reverse compatibility; no-output-loop default-only grammar behavior. SyntacticLayer
reverse for default-only unary dispatch may still share host modules and needs audit.
No full validation or installation claim. All primary tested source remains frozen.

Existing output-contract subset also passed: six cases (24 deselected), 61.66s;
managed95705 exit0, guard91.19s/.71GiB. This covers a real rule-stamped walk,
generate-only inventory without compose, compiled empty-generate emission,
and existing rule-meaning checkpoint / Adam-row migrations. Raw log/process:
/tmp/full-spec-generation-existing-contracts-v1.log and matching -result.json.
This remains selected affected evidence, not a full-suite or installation proof.

Unary follow-through: first unary probe failed during fixture setup because SigmaLayer
was not configured invertible; that log is not counted as behavioral evidence.
Corrected explicit invertible=True; genuine red-v2 managed94455 exit1 demonstrates
the default unary SyntacticLayer.reverse still used the host inverse in output scope.
Candidate now resolves unary output through its generation registry and bypasses the
comprehension host's two-pass inverse in that scope. Unscoped input inverse unchanged.
Final focused v3 managed96005 exit0: seven passes18.30s, guard38.43s/.60GiB.
Log /tmp/full-spec-generation-catalog-candidate-v3.log. Validation manifest refreshed.
Explicit generate unary dispatch is fixed; legacy flat compose-only fallback still needs
review, as do full normal output / optimizer / budget and checkpoint gates listed above.

Checkpoint/fallback review (September 17 continued): new probes in
/tmp/full-spec-generation-checkpoint-probes.py. Independent generation weights and
Adam moments survive strict reload and a further step. A partial generation
checkpoint is rejected with the public loader's False return (the initial test
wrongly expected an exception; no runtime change for this). Initial flat fixture
used an aligned model without live natural-fold hosts; replaced with a real legacy
MM_xor configuration. Genuine flat RED-v2 managed81957 exit1 shows missing SS:sigma
generation ownership in /tmp/full-spec-generation-flat-red-v2.log.

Candidate now owns existing exact per-space default natural-fold inverse interfaces,
without inventing walk choices or reviving the retired subsymbolic dispatcher.
The same declared interface reuses its copy even when repeated in generate rules.
All ten focused probes passed in v5: managed58173 exit0; 24.26s tests, 52.15s guard,
.62GiB peak. Logs /tmp/full-spec-generation-catalog-candidate-v5.log and matching
-result.json. Current two-file validation manifest refreshed. No primary install.
Normal output selection is running separately; do not mistake focused evidence
for full gradient/budget, alias migration or full-suite acceptance.

Normal output review: first selection included the production MM_phrase_decode
fixture (1024-wide spaces, 65,536-row tables) and hit the separate 2 GiB probe cap
before a result: managed53033 exit137, /tmp/full-spec-generation-normal-output-v1.log.
No assertion failure or passing claim for that run. Repeated selection v2 used
the development native fixtures for output-loop off/on plus the real policy
evaluation route. Three passed, 48 deselected in97.46s; managed53033(reused ID)
exit0, guard111.73s/.87GiB. Matching v2 log/process JSON retained.

Model gradient-owner review probes: /tmp/full-spec-generation-gradient-budget-probes.py.
Detached output keeps source reconstruction gradients; live inputs remain under
BaseModel's aggregate projection, and generation-owned parameters keep ordinary
gradients. Initial float32 near-orthogonal dot was -1.538e-7 against a fixed -1e-7
threshold, so the diagnostic now uses float64 operator/input values rather than
claiming float32 cancellation is a catalog regression. No runtime code changed.
Both mechanics probes passed, managed92824 exit0:3.80s, guard21.81s/.45GiB,
/tmp/full-spec-generation-gradient-budget-v2.log and matching result JSON.
This adversarial loss diagnostic is not corpus or actual runBatch learning evidence.

Still required: coherent rebase after item5, docs, actual supplied-answer/unsupervised
Adam gating, alias reordering/migration review, full affected files and full suite.
The twelve new focused cases plus three normal selected cases remain isolated.

Alias checkpoint probe: /tmp/full-spec-generation-alias-probes.py. Reordering
generate aliases for one shared host identity renamed the copy and broke strict
loading (red managed38826 exit1; /tmp/full-spec-generation-alias-red.log).
The generation owner now derives its key from the sorted canonical host registry
aliases of that source identity, preserving one independent copy and caller RNG.
Combined v6 passes all 19 selected cases (13 new and six existing output contracts):
38.22s pytest, guarded elapsed53.30s, peak0.742GiB, exit0 verified from the guard
receipt /tmp/full-spec-generation-catalog-candidate-v6-result.json. The managed
exec session ID was unavailable after tool-output truncation; the completed guard
receipt records actual process exit. Two-file source validation manifest refreshed.
No primary installation or full-suite acceptance. Required gates remain rebase
after item5, docs, actual supplied/unsup Adam gating, full affected files and suite.

Real runBatch review v1: generated operators receive supplied-answer gradients,
Adam steps, then no updates on missing labels with output-loop enabled. That
case passed. The no-output-loop supplied fixture did not select any numerical
generate operation, so requiring such an update was an invalid probe assumption,
not evidence of a catalog bug (v1: one pass, one failure; managed51004 exit1;
163.98s tests,190.55s guard,1.25GiB). Keep its raw log. The follow-up warms actual
generation Adam moments using a supplied output-loop call, then verifies the
missing-label gate after switching output-loop off. No runtime change for this.

Real Adam gate follow-up v2 passed: warm generation through the actual supplied
output-loop route, turn labels off and output-loop off, then prove no generation
gradient or Adam drift. Managed29305 exit0; guard124.96s,1.13GiB. The enabled-loop
unlabelled case passed in v1. This replaces the invalid assumption that the
non-loop supplied fixture must select a generation operator; no runtime fix.
Both probes remain slow integration checks, isolated from primary.
