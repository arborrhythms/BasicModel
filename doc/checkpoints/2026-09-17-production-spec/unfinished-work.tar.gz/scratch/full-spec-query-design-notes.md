# Next query migration: design notes, NOT implemented or approved evidence

Follow prepared-answer green/full-suite/commit/push/bump cycle before any next-item repo edit.
User requires full integrated spec; two-truths fusion/collapse is explicitly later.

Read-only source findings:
- TernaryTruthStore Layers8658 has fixed [capacity,3,D] infix slots, trust/timestamp/origin registered buffers; source text transient. append/append_idea/append_relation do not retain grammatical mode, scope, bindings, occurrence id or question/estimate/fact distinction. clear_origin compacts indices. New evidence metadata must preserve old checkpoint loading and stable identities under compaction; do not use row position as durable occurrence id.
- ConceptualSpace conceptual taxonomy uses ConceptAllocator-backed part/whole ('sym', id) records and reified relation records. reify_concept(a,b) makes a relation concept via relate((sym,a),(sym,b)); it may not mutate a/b endpoints. A correct traversal must include both explicit endpoint links and reified-edge records, handle retirement, and not read WholeSpace/percept trees or vector-overlap as proof.
- assert_concept_relation (Spaces19252) can add endpoint sym_part/sym_whole and optionally assign sparse weight. Learned transform/activation magnitude is not automatically evidential trust. Keep relationship identity/provenance separate from any graded support design.
- Concept id -> dictionary row uses _csw_row_of/_csw_concept_row; ids are not row indices. mint_frozen_concept(name) supplies an existing stable hard-coded concept facility. Registry VP binding must use one grammatical relation identity, not a second tool-only VP or numeric-id feature.
- reasoning.QuerySpec currently only predicate/left/right/variables/polarity; from_surface maps exist->isTrue. TruthGroundedReasoner.exist checks only NP1 of REL_NONE rows then falls back model.isTrue. part() is a static vector-energy diagnostic; is_part_direct can grant geometric proof. These cannot serve new full-description Exist or conceptual-taxonomy PartOf.
- thinking.ThinkingKernel.part maps both meronomy and taxonomy to same REL_PARTOF rows. Legacy kernel has its own Frame hierarchy; do not build another such hierarchy for new ordinary thought execution.
- WhatInteractionMemory is the required single owner for chronological ordinary thoughts and transition history. Legacy LTMSlot parity methods must be explicitly migrated/adapted, not relabelled as levelled replay.
- Models._detect_query is keyword/regex-style prompt dispatch; answer_query wraps it and can swallow kernel errors. New actual boundary path must derive operation/operands from grammatical meaning. Merely adding an unused registry does not meet the spec.
- complete.grammar currently declares isTrue,isEqual,isPart,isWhole,parts,wholes,quantize,arma,query; general what(Q) is absent. It already has relative_truth starts part/whole/equal and Anchors for partOf,wholeOf,equals. Comments wrongly say query VPs build no structure. Tense remains deferred.
- InterSentenceLayer._canonical_meaning(payload,depth,layout,role_mask) supports stm/infix: depth3 STM permutation[1,2,0], depth2 flip, pad to3. Reuse an explicit common adapter; do not silently label arbitrary stack order canonical.

Potential bounded substeps (design still to verify against code/probes):
1. One canonical ConceptualMeaning value (roles/mask, mode, role refs, bindings/scope, provenance/evidence), reused as the meaning accepted by QuerySpec and retained in thought/fact metadata; not a second semantic store. Full-description Exist evidence, source kinds, durable ids/checkpoint migration, no activation fallback. Consider preserving a clearly named legacy scalar diagnostic, but actual Exist must return both positive and negative support/provenance without collapsing conflict.
2. Checked relation registry linked to canonical VP concepts and pure grammar faces; explicit supported domains and argument permutations; selected-boundary-only execution. PartOf reads conceptual taxonomy; meronomy separate. Every declared operation must execute or fail explicitly, and queries must not run inside any sentence path. Full-model grammatical route must reach the registry; host text dispatch is insufficient.
3. One-owner levelled history/controller, replay/trim/checkpoints, causal intermediate results and one shared ordinary-work budget with cutoff drain <=d_cut+1. Policy uses mandatory complete role inputs plus bounded optional context, not just scalar summaries, ids or a word menu. No surface per internal step.
4. Retained nested semantics, owned estimates/observation links and anticipation prior-view isolation; separate remaining catalogs and residual-credit milestones.

Tests needed before fixes: same NP1/different VP/NP2/scope/bindings; questions/estimates cannot self-certify; missing/negative/conflicting/partial support; taxonomy-edge vs percept-edge perturbations; reified edges; stable ids/load/clear; selected-only effects and all-path query spies; canonical linguistic/internal equivalence and converse scope; actual causal upstream gradients. Do not claim these draft notes implement any of them.


Checkpoint caveat from current Models.py inspection:
- No existing nn.Module.get_extra_state/set_extra_state implementation found in bin/. save_weights saves tensor state plus vocab/bpe/structural sidecars. load_weights at5347 calls saved_v.dim() and at~5370 compares .shape unconditionally. Adding a dict-valued _extra_state key to TernaryTruthStore would require deliberately updating these audits plus tests that assume tensor-only state. Prefer established structural sidecar for non-tensor meaning/fact metadata, with an explicit versioned migration and actual BasicModel save/load regression; or carefully implement full non-tensor audit support. Do not assume state_dict persistence works automatically.
- New fixed-size provenance/occurrence buffers need old-checkpoint defaults; the module can declare migration before strict load, with stable ids assigned to existing rows. Tensor row positions are compacted by clear_origin, so keep occurrence ids alongside survivors. Non-tensor scope/bindings/mode metadata must be compacted identically and actually checkpointed.

Existing-behavior RED probes suitable for next bounded evidence item, before inventing a public API:
1. Append a ternary fact [a, v, b] with trust.85 using actual TernaryTruthStore.append_relation, evaluate QuerySpec.from_surface('exist', torch.stack((a,v,b))). It currently flattens the description and only scans REL_NONE rows, so reportsUNKNOWN for a present fact.
2. Keep a fixedNP1, independently changeVP andNP2; no falsematches from subject presence.
3. Append unary same-description rows +.85 and-.8; evaluate must preserve both support values/postureBOTH. Current exist picks one strongest scalar and evaluate loses conflict.
4. No fact, model.isTrue returns1: evaluate must stayUNKNOWN and not invoke activation fallback.
Then add scope/binding/kind/provenance/restore tests as actual canonical meaning and fact metadata are introduced. A legacy float compatibility helper may survive, but checked Exist and ThinkingKernel.lookup must consume the detailed support, never collapse conflict to that helper.

## Further read-only review during the prepared-answer full suite

Additional draft tests are in `/tmp/full-spec-existence-metadata-probes.py`.
They are NOT installed or run, and no corresponding implementation has been
written. First run the five original-API probes after the current commit cycle;
then run these additional contracts before their fixes.

The existing observation writers also discard the second occupied role for a
depth-two sentence. `_drain_pending_stm_end_state`,
`_drain_packed_stm_end_states`, and the eager word-pipeline tail append a unary
idea whenever depth is below three. The current predictor adapter explicitly
reverses a depth-two STM payload into canonical NP1/VP order. Draft tests call
the actual pending/packed writer boundaries with controlled payloads at depths
1, 2, and 3. The eventual fix should share one explicit layout adapter, not
infer role presence from nonzero vector coordinates.

Suggested bounded evidence design (still to implement and verify):

- Put an owned canonical `ConceptualMeaning` value in a dependency-light
  `Meaning.py`. It carries roles `[3,D]`, presence mask, grammatical mode,
  polarity, role references, bindings, and scope. It is a value, not another
  semantic store or planner. Factory calls declare STM versus infix layout.
  Current-step clones retain gradients; writes to durable facts detach them.
  Reuse the adapter from InterSentenceLayer rather than duplicating its role
  permutation. Require equal widths at the evidence boundary; `_idea_identity`
  currently truncates to the shorter vector and cannot validate widths for us.
- Extend the existing TernaryTruthStore with fixed tensor columns for record
  kind (fact/question/estimate/observation/unverified), mode, polarity, role
  presence, durable occurrence ID, and whether semantic metadata is required.
  Keep a store namespace stable through checkpoints and never recycle an
  occurrence identity during compaction/reset. Physical row numbers remain
  diagnostic indexes only. Existing low-level append methods explicitly write
  facts by default for compatibility; actual external-observation writers must
  pass observation provenance. Provisioning/user TruthSets explicitly accept
  facts when tagging their rows. An interrogative cannot be accepted as a fact.
- Keep bindings/scope/role references and source text in a versioned semantic
  sidecar, included by the existing model structural-extras save/load path.
  This avoids non-tensor entries in state_dict, whose consumers assume tensors.
  A tensor flag must quarantine scoped evidence if its required sidecar is
  absent, so a bare state_dict load cannot turn a scoped fact into an unscoped
  one. Restore checks occurrence identity and rejects rebinding/missing data.
  Actual BasicModel strict save/load is a required test, not just a toy store.
  Preserve existing structural checkpoint versions or explicitly migrate them.
- Legacy checkpoints have no kind/mode/scope metadata. Preserve explicitly
  provisioned/user truth rows where their old contract establishes fact status;
  mark unclassified conversation rows unverified. Do not pretend their missing
  grammatical mode was known. Old role masks need a documented best-effort
  migration or incomplete status where zero roles are ambiguous.
- Full-description Exist scans facts only, compares all occupied roles plus
  scope/bindings/references, and keeps positive and negative support separately.
  Exact matches retain the stored degree; partial identity may attenuate it
  under an explicitly documented threshold. Repetition uses max supported
  degree rather than summation. Each candidate retains its stable occurrence,
  origin/text and signed support. Missing facts remain unknown. No activation
  fallback. `evaluate` and ThinkingKernel.lookup must use this rich evidence;
  any surviving float `exist` API is explicitly a lossy compatibility view.

This bounded item does NOT finish the typed VP registry, grammatical surface
route, conceptual-taxonomy PartOf, or the ordinary levelled controller. Do not
describe a new value/API as implementing those later requirements.

Prepared-source findings for later grammar work: complete.grammar already has
pure part/whole/equal compose and inverse rules and anchor declarations, but
its old comments claim query VPs build no structure; `_detect_query` dispatches
from prompt words. A registry bolted onto that dispatcher would still fail the
actual grammatical-route requirement. The accepted compose derivation and its
owned operands must produce the query meaning; questions and assertions share
the same relation/domain VP identity. This needs a separate real forward-path
probe, not merely two hand-constructed objects compared for equality.
