"""Freeze resource/gating evidence only after the complete default suite passes."""
from pathlib import Path
from collections import Counter
import hashlib,json,shutil,subprocess
from full_spec_bounded_evidence import verified_run,archive_run
root=Path('/Users/arogers/github/WikiOracle/basicmodel')
run=Path('/tmp/full-spec-bounded-fast-full-v5')
f=verified_run(run,root)
a=verified_run('/tmp/full-spec-bounded-affected-v4')
s=verified_run('/tmp/full-spec-slow-gates-affected-v1')
n=verified_run('/tmp/full-spec-slow-switch-affected-v2')
e=verified_run('/tmp/full-spec-compiler-slow-gates-affected-v2')
d=verified_run('/tmp/full-spec-production-slow-affected-v2')
g=verified_run('/tmp/full-spec-additional-large-affected-v1')
h=verified_run('/tmp/full-spec-time-device-affected-v3')
for name,digest in json.loads(Path('/tmp/full-spec-unowned-after-tied.json').read_text()).items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root)
folder=root/'doc/benchmarks/2026-09-17-bounded-test-data';assert not folder.exists()
folder.mkdir(parents=True)
files={
 'time-boundary-red.log':'/tmp/full-spec-time-boundary-red-v1.log',
 'live-progress-red.log':'/tmp/full-spec-live-progress-red-v1.log',
 'training-device-red.log':'/tmp/full-spec-training-device-red-v1.log',
 'reconstruction-profile-result.json':'/tmp/full-spec-bounded-fast-full-v4/result.json',
 'reconstruction-profile-process.json':'/tmp/full-spec-bounded-fast-full-v4/worker-025.process.json',
 'reconstruction-profile-worker.log':'/tmp/full-spec-bounded-fast-full-v4/worker-025.log',
 'reconstruction-slow-selections.json':'/tmp/full-spec-reconstruction-slow-selections.json',
 'reconstruction-slow-base.json':'/tmp/full-spec-reconstruction-slow-base.json',
 'pre-reconstruction-slow-selections.json':'/tmp/full-spec-test-mode-pre-reconstruction-selections.json',
 'reconstruction-stack-sample.txt':'/tmp/full-spec-fast-v4-worker-025-sample-excerpt.txt',
 'additional-large-profile-result.json':'/tmp/full-spec-bounded-fast-full-v3/result.json',
 'additional-large-profile.json':'/tmp/full-spec-additional-large-profile.json',
 'additional-large-profile-stop.json':'/tmp/full-spec-additional-large-profile-stop.json',
 'additional-large-selections.json':'/tmp/full-spec-additional-large-applied.json',
 'additional-large-base.json':'/tmp/full-spec-additional-large-base.json',
 'remaining-large-fixture-audit.json':'/tmp/full-spec-remaining-large-fixture-audit.json',
 'global-large-fixture-audit.json':'/tmp/full-spec-global-large-fixture-audit.json',
 'pre-additional-large-selections.json':'/tmp/full-spec-test-mode-pre-additional-large-selections.json',
 'production-collection-import-red.log':'/tmp/full-spec-production-slow-affected-v1/collect.log',
 'production-profile-result.json':'/tmp/full-spec-bounded-fast-full-v2/result.json',
 'production-config-profile.json':'/tmp/full-spec-production-config-profile.json',
 'production-slow-selections.json':'/tmp/full-spec-production-slow-selections.json',
 'pre-production-slow-selections.json':'/tmp/full-spec-test-mode-pre-production-selections.json',
 'initial-red.log':'/tmp/full-spec-bounded-tests-red.log',
 'recycle-red.log':'/tmp/full-spec-bounded-recycle-red/worker-000.log',
 'modes-red.log':'/tmp/full-spec-test-modes-red/worker-000.log',
 'native-fixture-red.log':'/tmp/full-spec-fast-native-fixture-red.log',
 'native-fixture-candidate-green.log':'/tmp/full-spec-fast-native-fixture-green-v1.log',
 'native-fixture-probe.py':'/tmp/full-spec-fast-native-fixture-probes.py',
 'native-fixture-widths.json':'/tmp/full-spec-native-fixture-widths.json',
 'joint-training-profile-result.json':'/tmp/full-spec-compiler-slow-gates-affected-v1/result.json',
 'joint-training-profile-worker.log':'/tmp/full-spec-compiler-slow-gates-affected-v1/worker-000.log',
 'joint-training-profile-request.json':'/tmp/full-spec-compiler-slow-gates-affected-v1/worker-000.request.json',
 'compiler-timeout-profile.json':'/tmp/full-spec-compiler-timeout-profile.json',
 'compiler-timeout-request.json':'/tmp/full-spec-bounded-fast-full-v1/worker-004.request.json',
 'compiler-timeout-stack-excerpt.txt':'/tmp/full-spec-compiler-timeout-stack-excerpt.txt',
 'compiler-timeout-result.json':'/tmp/full-spec-bounded-fast-full-v1/result.json',
 'compiler-timeout-worker.log':'/tmp/full-spec-bounded-fast-full-v1/worker-004.log',
 'memory-stop-result.json':'/tmp/full-spec-bounded-full-v1/result.json',
 'pre-gating-interrupted-result.json':'/tmp/full-spec-bounded-full-v2/result.json',
 'large-config-profile-result.json':'/tmp/full-spec-slow-switch-affected-v1/result.json',
 'recycle-green-result.json':'/tmp/full-spec-bounded-recycle-green-v1/result.json',
 'slow-selections.json':'/tmp/full-spec-test-mode-selections.json',
 'initial-slow-selections.json':'/tmp/full-spec-test-mode-initial-selections.json',
 'focused-green.log':'/tmp/full-spec-bounded-focused-v5/worker-000.log',
 'focused-result.json':'/tmp/full-spec-bounded-focused-v5/result.json',
}
for name,source in files.items():shutil.copyfile(source,folder/name)
for path,prefix,result in [(run,'full',f),('/tmp/full-spec-bounded-affected-v4','tooling-affected',a),
 ('/tmp/full-spec-slow-gates-affected-v1','slow-affected',s),('/tmp/full-spec-slow-switch-affected-v2','switch-affected',n),
 ('/tmp/full-spec-compiler-slow-gates-affected-v2','compiler-affected',e),
 ('/tmp/full-spec-production-slow-affected-v2','production-affected',d),
 ('/tmp/full-spec-additional-large-affected-v1','additional-large-affected',g),
 ('/tmp/full-spec-time-device-affected-v3','time-device-affected',h)]:
 archive_run(path,folder,prefix,result)
calls=[report for worker in f['receipt']['workers'] for report in worker['reports']
       if report['phase']=='call' and report['outcome']=='passed']
by_file=Counter()
for report in calls:
 by_file[report['nodeid'].split('::')[0]] += report['duration']
profile={
 'scope':'Completed passing call phases only; setup, imports and supervisor overhead are included only in total elapsed time.',
 'full_elapsed_seconds':f['receipt']['elapsed_seconds'],
 'selected_cases':len(f['receipt']['selected']),
 'longest_calls':[dict(nodeid=p['nodeid'],seconds=p['duration'])
                 for p in sorted(calls,key=lambda p:p['duration'],reverse=True)[:30]],
 'call_seconds_by_file':dict(by_file.most_common()),
}
(folder/'full-call-profile.json').write_text(json.dumps(profile,indent=2)+'\n')
p=root/'doc/Testing.md';text=p.read_text()
old='Full-suite evidence will\nbe recorded after the bounded background run completes.';assert old in text
text=text.replace(old,
 'The 20 resource/coverage probes, five training-device probes and three slow-switch probes passed.\n'
 +'Tooling affected files: **'+a['summary']+'**.\n'
 +'Files receiving slow markers: **'+s['summary']+'**.\n'
 +'Additional slow gates, switch normalization and native fixtures: **'+n['summary']+'**.\n'
 +'Additional compiler and production integration gates: **'+e['summary']+'**.\n'
 +'Production-configuration and CLI gates: **'+d['summary']+'**.\n'
 +'Additional full-model fixture gates: **'+g['summary']+'**.\n'
 +'Time, live-progress, device and reconstruction files: **'+h['summary']+'**.\n'
 +'The complete default suite passed: **'+f['summary']+'**.\n'
 +f"All {len(f['receipt']['selected'])} selected cases completed exactly once and the source manifest remained unchanged.\n"
 +'This measures the default regression gate; optional `RUN_SLOW=1` experiments\n'
 +'are not included in the passing learning evidence. The earlier full run was\n'
 +'interrupted explicitly to introduce the requested slow gates; it is not counted as passing.\n\n'
 +'[Reviewer red](benchmarks/2026-09-17-bounded-test-data/initial-red.log),\n'
 +'[slow-switch red](benchmarks/2026-09-17-bounded-test-data/modes-red.log),\n'
 +'[tooling receipt](benchmarks/2026-09-17-bounded-test-data/tooling-affected-result.json),\n'
 +'[full receipt](benchmarks/2026-09-17-bounded-test-data/full-result.json),\n'
 +'[worker summaries](benchmarks/2026-09-17-bounded-test-data/full-summaries.log),\n'
 +'[source manifest](benchmarks/2026-09-17-bounded-test-data/full-source-manifest.json).')
text += "\n## Future work: bounded fixture reuse\n\n" + (
 "Fixed-capacity vocabulary and staging contracts remain in place. Evaluate "
 "reuse of compatible preallocated fixtures inside each bounded worker, with "
 "complete state-reset checks and separate build/recompile counters. "
 "[Assessment and acceptance criteria](plans/2026-09-17-bounded-fixture-reuse.md) "
 "record the requested follow-up; comparative speedups remain unmeasured.\n")
p.write_text(text)
future=root/'doc/plans/2026-09-17-bounded-fixture-reuse.md';assert not future.exists()
future.write_text(Path('/tmp/full-spec-fixed-capacity-future-work.md').read_text())
owned=['Makefile','test/bounded_tests.py','test/pytest_worker.py','test/test_report.py',
 'test/test_bounded_test_runner.py','test/test_bounded_test_recycling.py','test/test_training_device.py','doc/Testing.md',
 'test/conftest.py','test/slow_tests.py','test/test_test_modes.py',
 'test/test_config_matrix.py',
 'doc/plans/2026-09-14-answer-path-ownership-and-training.md',
 'doc/plans/2026-09-15-next-sentence-as-the-production-objective.md']
owned.append('doc/plans/2026-09-17-bounded-fixture-reuse.md')
owned+=list(json.loads(Path('/tmp/full-spec-test-mode-selections.json').read_text()))
owned+=[str(p.relative_to(root)) for p in folder.iterdir()]
owned=sorted(set(owned))
Path('/tmp/full-spec-bounded-owned-paths.txt').write_text('\n'.join(sorted(owned))+'\n')
Path('/tmp/full-spec-bounded-commit-message.txt').write_text(
 'Bound development tests and gate slow training experiments\n\n'
 'Run selections and the complete default suite in fresh sequential pytest workers, recycling at completed-test boundaries at half the hard memory cap or worker deadline. Persist live completed-case receipts and preserve confirmed progress after termination. Honor explicit test devices and default significant slow training to an available GPU without silent CPU fallback. '
 'Enforce one suite per user, aggregate process-tree memory, finite deadlines and cleanup after failure or interruption. '
 'Count compressed footprint on macOS, add a kernel limit, restrict thread pools and preserve disk compilation caches.\n\n'
 'Gate 245 long convergence, memorization, production-size integration and compiler checks before fixture setup unless RUN_SLOW=1. '
 'Normalize older gates so RUN_SLOW=0 remains fast. Keep distinct concept/percept widths in smaller native development fixtures and retain seven 1032-wide cases as slow parameters. Keep ordinary numerical and ownership regressions in the default suite. '
 'Replace unrestricted parallel Make targets and persist exact coverage, source hashes, exits and reports.\n\n'
 'Validation: 20 resource, five training-device and three slow-switch probes; tooling: '+a['summary']+'. '
 'Slow-marked files: '+s['summary']+'. Switch files: '+n['summary']+'. Additional compiler files: '+e['summary']+'. Production configuration files: '+d['summary']+'. Additional full-model fixture files: '+g['summary']+'. Time/device/reconstruction files: '+h['summary']+'. Full default: '+f['summary']+'.\n\n'
 'Co-Authored-By: Claude Fable 5.1 <noreply@anthropic.com>\n')
print(f['summary']);print('Owned paths:',len(owned))
