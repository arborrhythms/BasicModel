from pathlib import Path
import hashlib,json,shutil,subprocess
root=Path('/Users/arogers/github/WikiOracle/basicmodel')
work=Path('/tmp/full-spec-nested-worktree')
assert not subprocess.check_output(['git','diff','HEAD','--','bin','test','data'],cwd=root)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).strip()
assert head==subprocess.check_output(['git','rev-parse','origin/main'],cwd=root).strip()
assert head.decode()==subprocess.check_output(['git','rev-parse','HEAD:basicmodel'],cwd=root.parent,text=True).strip()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root.parent)==subprocess.check_output(['git','rev-parse','origin/main'],cwd=root.parent)
base=json.loads((work/'base-manifest.json').read_text())
validated=json.loads((work/'validation-manifest.json').read_text())
for name,digest in base.items(): assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
for name,digest in validated.items(): assert hashlib.sha256((work/name).read_bytes()).hexdigest()==digest,name
snapshot=Path('/tmp/full-spec-nested-retention-base');assert not snapshot.exists()
for name in base:
 target=snapshot/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/name,target)
owned=[]
for name in validated:
 shutil.copyfile(work/name,root/name);owned.append(name)
for source,target in [('full-spec-nested-retention-probes.py','test_nested_retention.py'),
 ('full-spec-nested-boundary-probes.py','test_nested_retention_boundaries.py'),
 ('full-spec-nested-owner-probes.py','test_nested_occurrence_owners.py'),
 ('full-spec-nested-context-reference-probes.py','test_nested_context_references.py')]:
 assert not (root/'test'/target).exists()
 shutil.copyfile(Path('/tmp')/source,root/'test'/target);owned.append('test/'+target)
Path('/tmp/full-spec-nested-retention-owned-paths.txt').write_text('\n'.join(sorted(owned))+'\n')
print('Installed nested-retention candidate; primary affected and bounded full suite still required.')
