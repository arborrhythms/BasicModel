"""Validate a temporary candidate without changing the repository under test."""
from pathlib import Path
import hashlib
import importlib
import json
import sys

candidate = Path('/tmp/full-spec-query-candidate').resolve()
modules = {name: importlib.import_module(name)
           for name in ('Meaning', 'Layers', 'Models', 'reasoning', 'thinking')}
for name, module in modules.items():
    path = Path(module.__file__).resolve()
    assert path.parent == candidate, (name, path)
    print(f'CANDIDATE {name}: {path}', flush=True)
manifest = json.loads((candidate / 'validation-manifest.json').read_text())
for name, digest in manifest.items():
    assert hashlib.sha256((candidate / name).read_bytes()).hexdigest() == digest


class OwnershipCheck:
    def pytest_runtest_setup(self, item):
        for name, module in modules.items():
            assert sys.modules[name] is module, f'candidate module replaced: {name}'


import pytest
result = pytest.main(sys.argv[1:], plugins=[OwnershipCheck()])
for name, digest in manifest.items():
    assert hashlib.sha256((candidate / name).read_bytes()).hexdigest() == digest
raise SystemExit(result)
