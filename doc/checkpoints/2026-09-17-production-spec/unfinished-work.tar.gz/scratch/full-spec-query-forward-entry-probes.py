"""The explicit compiled forward and supplied executors share the sentence mask."""
from dataclasses import replace
from types import SimpleNamespace

import pytest
import torch

from Models import BasicModel
from Queries import BUILTIN_QUERIES, QueryContext
from What import What
from reasoning import TruthGroundedReasoner
from test_cs_symbol_table import _cs


@pytest.mark.parametrize('entry', ['explicit_state', 'understand_executor', 'what_executor'])
def test_every_input_execution_entry_masks_queries(monkeypatch, entry):
    model = BasicModel()
    model.spaces = []
    object.__setattr__(model, 'conceptualSpace', _cs())
    object.__setattr__(model, 'perceptualSpace', SimpleNamespace())
    model.reconstruct_in_loop = False
    # Simulate a completed parent context asking to parse a linguistic child.
    # Its boundary permission must be masked until the child sentence finishes.
    model._query_ready_rows = (0,)
    calls = []
    signature = replace(BUILTIN_QUERIES['isEqual'],
                        executor=lambda *args: calls.append(args) or {})
    context = QueryContext(TruthGroundedReasoner(model))

    def query(*args, **kwargs):
        signature.invoke(context, torch.ones(8), torch.ones(8))
        raise AssertionError('input execution escaped its phase mask')

    if entry == 'explicit_state':
        monkeypatch.setattr(model, '_forward_per_stage', query)
        call = lambda: model._forward_with_compiled_sentence_state(None)
    elif entry == 'understand_executor':
        call = lambda: model.understand(torch.ones(1, 1, 8), executor=query)
    else:
        monkeypatch.setattr(model, '_begin_referents', lambda *args: None)
        monkeypatch.setattr(model, '_what_grammar_context',
                            lambda *args, **kwargs: (torch.zeros(1, 4), ({},)))
        call = lambda: model.what(What.inference(0), torch.ones(1, 1, 8), executor=query)
    with pytest.raises(RuntimeError, match='sentence|query|queries'):
        call()
    assert calls == []
